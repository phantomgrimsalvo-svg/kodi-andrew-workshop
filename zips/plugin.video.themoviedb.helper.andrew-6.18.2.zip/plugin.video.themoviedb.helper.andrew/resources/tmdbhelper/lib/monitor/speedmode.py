# -*- coding: utf-8 -*-
"""Speed mode presets for the heavy TMDb Helper settings.

Choosing Max Quality, Balanced, Fast, or Max Speed writes the switches.
Custom does not. Changing one of those switches sets Custom.
A preset is applied only when Speed mode itself changes.
"""
from tmdbhelper.lib.addon.plugin import get_condvisibility, get_setting, set_setting

MODE_QUALITY = 0
MODE_BALANCED = 1
MODE_FAST = 2
MODE_MAX = 3
MODE_CUSTOM = 4

# bool values are real bools; artwork_quality is the settings integer.
PRESETS = {
    MODE_QUALITY: {
        'service_light': False,
        'use_online_artwork': True,
        'use_online_ratings': True,
        'service_prefers_online_clearlogo': True,
        'force_recache_kodidb': True,
        'library_autoupdate': True,
        'trakt_cacheownlists': True,
        'artwork_quality': 0,
    },
    MODE_BALANCED: {
        'service_light': False,
        'use_online_artwork': True,
        'use_online_ratings': True,
        'service_prefers_online_clearlogo': False,
        'force_recache_kodidb': False,
        'library_autoupdate': False,
        'trakt_cacheownlists': True,
        'artwork_quality': 0,
    },
    MODE_FAST: {
        'service_light': True,
        'use_online_artwork': True,
        'use_online_ratings': False,
        'service_prefers_online_clearlogo': False,
        'force_recache_kodidb': False,
        'library_autoupdate': False,
        'trakt_cacheownlists': False,
        'artwork_quality': 2,
    },
    MODE_MAX: {
        'service_light': True,
        'use_online_artwork': False,
        'use_online_ratings': False,
        'service_prefers_online_clearlogo': False,
        'force_recache_kodidb': False,
        'library_autoupdate': False,
        'trakt_cacheownlists': False,
        'artwork_quality': 3,
    },
}

_BOOLS = tuple(key for key in PRESETS[MODE_BALANCED] if key != 'artwork_quality')

_busy = False
_last = None
_skip_once = False


def _as_bool(value, default):
    if value is None or value == '':
        return default
    if isinstance(value, bool):
        return value
    return str(value).lower() == 'true'


def _as_int(value, default):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def read_state():
    state = {}
    for key in _BOOLS:
        state[key] = _as_bool(get_setting(key), PRESETS[MODE_BALANCED][key])
    state['artwork_quality'] = _as_int(get_setting('artwork_quality', 'int'), 0)
    return state


def _mode():
    return _as_int(get_setting('speed_mode', 'int'), MODE_CUSTOM)


def capture():
    """Remember the current preset without writing any setting."""
    global _last
    _last = _mode()


def _sync_skin_light(enabled):
    import xbmc
    if enabled:
        xbmc.executebuiltin('Skin.SetBool(TMDbHelper.LightService)')
        xbmc.executebuiltin('Skin.Reset(TMDbHelper.Service)')
        return
    xbmc.executebuiltin('Skin.Reset(TMDbHelper.LightService)')
    try:
        if get_condvisibility('Skin.HasSetting(TMDbHelper.EnableData)'):
            xbmc.executebuiltin('Skin.SetBool(TMDbHelper.Service)')
    except Exception:
        pass


def _write(key, value):
    if key == 'artwork_quality':
        set_setting(key, value, 'int')
        return
    set_setting(key, 'true' if value else 'false', 'bool')
    if key == 'service_light':
        _sync_skin_light(bool(value))


def on_settings_changed():
    """Apply a newly chosen preset, or mark Custom when a switch changes."""
    global _busy, _last, _skip_once
    if _busy:
        return
    if _last is None:
        capture()
        return
    if _skip_once:
        _skip_once = False
        _last = _mode()
        return
    mode = _mode()
    if mode != _last:
        _last = mode
        if mode not in PRESETS:
            return
        _busy = True
        try:
            current = read_state()
            for key, value in PRESETS[mode].items():
                if current.get(key) != value:
                    _write(key, value)
            _skip_once = True
        finally:
            _busy = False
        return
    if mode in PRESETS and read_state() != PRESETS[mode]:
        _busy = True
        try:
            set_setting('speed_mode', MODE_CUSTOM, 'int')
            _skip_once = True
        finally:
            _busy = False
        _last = MODE_CUSTOM
