'''Device-code sign-in and the one-time import. Pull only. No collection.'''

from __future__ import annotations

from trakt.client import TraktClient, TraktError
from trakt.importer import import_trakt, plan_import
from util import redact


def dry_run_import(store, settings, guard, progress=None, sleep=None, clock=None):
    try:
        prepared = _dry_run_import(store, settings, guard, progress, sleep, clock)
    except TraktError as exc:
        return str(exc)
    if isinstance(prepared, str):
        return prepared
    lines, _payload, _client = prepared
    return lines


def import_from_trakt(store, settings, guard, confirm=None, progress=None,
                      dialog=None, sleep=None, clock=None):
    '''Preview, ask, then write the same payload. No is a complete no-op.'''
    try:
        prepared = _dry_run_import(store, settings, guard, progress, sleep, clock)
    except TraktError as exc:
        return str(exc)
    if isinstance(prepared, str):
        return prepared
    lines, payload, client = prepared
    ask = confirm if confirm is not None else _yesno
    if not ask('Import from Trakt', lines + '\n\nImport these into Hearth now?'):
        return lines + '\n\nNothing was imported.'
    bar = progress if progress is not None else _progress_dialog()
    bar.create('Import from Trakt', 'Starting')

    def on_stage(index, total, label):
        bar.update(int(index * 100 / max(total, 1)), label)

    try:
        stats = import_trakt(
            store, settings, client, payload=payload, on_stage=on_stage
        )
    finally:
        bar.close()
    _refresh_taste_profile(store)
    result = (
        'Imported %d titles, %d episodes, %d ratings, '
        '%d watchlist, %d favorites, and %d lists.'
    ) % (
        stats['titles'], stats['episodes'], stats['ratings'],
        stats['watchlist'], stats['favorites'], stats['lists']
    )
    if dialog is not None:
        dialog.ok('Import from Trakt', result)
    else:
        _result_dialog(result)
    return result


def _refresh_taste_profile(store):
    '''Save the profile now, and leave the next recommendations run a full pass.'''
    from recs.engine import build_taste_profile
    from util import dumps, iso
    profile = build_taste_profile(store)
    profile['rating_count'] = -1
    store.meta_set('taste_profile', dumps(profile))
    store.meta_set('taste_profile_at', iso())


def _yesno(heading, message):
    import xbmcgui
    return bool(xbmcgui.Dialog().yesno(heading, message))


def _result_dialog(message):
    import xbmcgui
    xbmcgui.Dialog().ok('Import from Trakt', message)


def _dry_run_import(store, settings, guard, progress=None, sleep=None, clock=None):
    from trakt.auth import SIGN_IN_AGAIN, ensure_access_token
    settings.store = store
    client_id = settings.get('trakt_client_id')
    if not client_id:
        return (
            'Add a Trakt client id in Hearth settings first. '
            'Create the app at https://trakt.tv/oauth/applications/new and leave the secret blank.'
        )
    if settings.trakt_authorized() and not ensure_access_token(settings, guard):
        return SIGN_IN_AGAIN
    client = TraktClient(
        guard,
        client_id,
        access_token=settings.get('trakt_access_token'),
        client_secret=settings.get('trakt_client_secret'),
        settings=settings
    )
    if not settings.trakt_authorized():
        token = sign_in(client, settings, progress=progress, sleep=sleep, clock=clock)
        if not token:
            return 'Trakt sign-in was cancelled.'
        client.access_token = token.get('access_token') or ''
    summary, payload = plan_import(client)
    lines = (
        'Trakt has %d movies, %d shows, %d playback rows, %d ratings, '
        '%d watchlist, %d favorites, %d lists. Collection is not included. %s'
    ) % (
        summary['movies'], summary['shows'], summary['playback'], summary['ratings'],
        summary['watchlist'], summary['favorites'], summary['lists'], summary['note']
    )
    store.meta_set('last_import_preview', redact(lines)[:500])
    return lines, payload, client


def sign_in(client, settings, progress=None, sleep=None, clock=None):
    '''Show the device code and poll until Trakt approves it, or the user cancels.'''
    import time
    from trakt.client import POLL_STATUS, TraktError, trakt_refusal
    code = client.request_device_code() or {}
    device_code = code.get('device_code') or ''
    if not device_code:
        raise TraktError('Trakt did not return a device code. Check the client id.')
    user_code = code.get('user_code') or ''
    url = code.get('verification_url') or 'https://trakt.tv/activate'
    try:
        interval = max(1, int(code.get('interval') or 5))
    except (TypeError, ValueError):
        interval = 5
    try:
        expires = max(interval, int(code.get('expires_in') or 600))
    except (TypeError, ValueError):
        expires = 600
    settings.set('trakt_device_code', device_code)
    settings.set('trakt_device_interval', str(interval))
    settings.set('trakt_device_expires_in', str(expires))
    from pairing.qr import activate_url, write_qr
    direct = activate_url(url, user_code)
    try:
        from paths import profile_dir
        write_qr(direct, profile_dir())
    except Exception:
        direct = direct
    line = 'Code %s. Open %s' % (user_code, direct)
    dialog = progress if progress is not None else _progress_dialog()
    sleeper = sleep if sleep is not None else time.sleep
    now = clock if clock is not None else time.monotonic
    started = now()
    dialog.create('Hearth', line)
    try:
        while True:
            if dialog.iscanceled():
                return None
            elapsed = now() - started
            if elapsed >= expires:
                raise TraktError('That Trakt code expired. Run Import again.')
            status, body = client.poll_device_result(device_code)
            if status == 200 and body.get('access_token'):
                from trakt.auth import remember_token
                remember_token(settings, body)
                return body
            if status == 400:
                pass
            elif status in (418, 429):
                interval = min(interval + 5, 60)
                settings.set('trakt_device_interval', str(interval))
            elif status in POLL_STATUS:
                raise TraktError(POLL_STATUS[status], status=status)
            else:
                raise TraktError(
                    trakt_refusal(status, body if isinstance(body, dict) else None),
                    status=status
                )
            dialog.update(int(min(99, (elapsed / float(expires)) * 100)), line)
            sleeper(interval)
    finally:
        dialog.close()


def _progress_dialog():
    import xbmcgui
    return xbmcgui.DialogProgress()


def apply_confirmed_import(store, settings, guard):
    from trakt.auth import ensure_access_token
    settings.store = store
    ensure_access_token(settings, guard)
    client = TraktClient(
        guard,
        settings.get('trakt_client_id'),
        access_token=settings.get('trakt_access_token'),
        client_secret=settings.get('trakt_client_secret'),
        settings=settings
    )
    _summary, payload = plan_import(client)
    return import_trakt(store, settings, client, payload=payload)
