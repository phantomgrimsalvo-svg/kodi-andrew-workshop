'''Sync the two inbox files and read picks back. Lists stay cached if GitHub is down.'''

from __future__ import annotations

import json
import threading

from brain.apply import apply_picks
from brain.github import GitHubError, append_text, get_file, get_json, post_webhook, put_json
from brain.log import (
    mark_synced, read_picks, read_taste, unsynced_events, write_picks, write_taste
)
from brain.wanted import lists_wanted, refresh_wanted
from util import iso

_POLL = {'thread': None}


def configured(settings):
    return bool(
        (settings.get('brain_repo') or '').strip()
        and (settings.get('brain_token') or '').strip()
    )


def sync_with_bot(store, settings, guard, progress=None, want_picks=True):
    if not configured(settings):
        return {'skipped': 'Set the Grok Bot repo and GitHub token first.'}
    refresh_wanted(store, settings, version=_version())
    if progress is not None:
        progress.update(15, 'Sending new ratings')
    sent = _upload_ratings(store, settings, guard)
    if progress is not None:
        progress.update(45, 'Sending the list requests')
    _upload_wanted(store, settings, guard, want_picks)
    if progress is not None:
        progress.update(70, 'Waking Grok Bot')
    _wake(guard, settings, sent, want_picks)
    store.meta_set('brain_last_sync', iso())
    store.meta_set('brain_last_sent_count', str(sent))
    if want_picks:
        store.meta_set('brain_waiting', 'true')
        start_poll(store, settings)
        message = 'Sent %s new ratings. Grok Bot is working.' % sent
    else:
        message = 'Sent %s new ratings. No new picks were requested.' % sent
    if progress is not None:
        progress.update(100, message)
    return {'message': message, 'sent': sent, 'want_picks': want_picks}


def pull_if_newer(store, settings, guard):
    '''Download picks and the taste note when GitHub has a newer file.'''
    if not configured(settings):
        return {'skipped': 'Grok Bot is not configured.'}
    repo = settings.get('brain_repo').strip()
    token = settings.get('brain_token').strip()
    try:
        document = get_json(guard, repo, token, 'outbox/picks.json')
    except GitHubError as exc:
        store.meta_set('brain_last_error', str(exc)[:300])
        return {'failed': str(exc), 'cached': True}
    generated = str((document or {}).get('generated_at') or '')
    previous = store.meta_get('brain_picks_at') or ''
    if document:
        write_picks(document)
        result = apply_picks(store, document)
        if result.get('failed'):
            store.meta_set('brain_last_error', result['failed'][:300])
            return result
        store.meta_set('brain_picks_at', generated)
        if generated and generated != previous:
            store.meta_set('brain_picks_ready', 'true')
    try:
        taste = get_file(guard, repo, token, 'outbox/taste.md', missing_ok=True)
    except GitHubError:
        taste = None
    if taste and taste.get('text') is not None:
        write_taste(taste['text'])
    store.meta_set('brain_last_error', '')
    store.meta_set('brain_waiting', 'false')
    return {
        'message': 'Picks from %s.' % (generated or 'the cached file'),
        'generated_at': generated,
        'newer': bool(generated and generated != previous)
    }


def status_text(store, settings):
    ready = store.meta_get('brain_picks_ready') == 'true'
    waiting = store.meta_get('brain_waiting') == 'true'
    return '\n'.join([
        'Grok Bot',
        '',
        'Last sync: %s' % (store.meta_get('brain_last_sync') or 'never'),
        'New ratings sent: %s' % (store.meta_get('brain_last_sent_count') or '0'),
        'New picks ready: %s' % ('yes' if ready else 'no'),
        'Picks generated: %s' % (store.meta_get('brain_picks_at') or 'never'),
        'Waiting on Grok Bot: %s' % ('yes' if waiting else 'no'),
        'Last error: %s' % (store.meta_get('brain_last_error') or 'none')
    ])


def taste_text():
    text = read_taste().strip()
    if text:
        return text
    picks = read_picks() or {}
    path = picks.get('taste_summary_path') or ''
    if path:
        return 'Grok Bot has not sent taste.md yet. It named %s.' % path
    return 'Grok Bot has not sent a taste summary yet.'


def start_poll(store, settings):
    '''Check for picks every 30 seconds for up to 15 minutes. Returns immediately.'''
    current = _POLL.get('thread')
    if current is not None and current.is_alive():
        return
    thread = threading.Thread(
        target=_poll, args=(store, settings), name='hearth-grok-poll', daemon=True
    )
    _POLL['thread'] = thread
    thread.start()


def note_open(store, settings):
    '''Menu open stays fast. A newer picks file is fetched in the background.'''
    try:
        refresh_wanted(store, settings, version=_version())
    except Exception:
        pass
    if not configured(settings):
        return
    thread = threading.Thread(
        target=_quiet_pull, args=(store, settings), name='hearth-grok-open', daemon=True
    )
    thread.start()


def _poll(store, settings):
    import time
    deadline = time.monotonic() + 15 * 60
    while time.monotonic() < deadline:
        time.sleep(30)
        try:
            from network.guard import active_guard
            result = pull_if_newer(store, settings, active_guard())
        except Exception:
            continue
        if result.get('newer'):
            _notify('New picks from Grok Bot are ready.')
            return
    store.meta_set('brain_waiting', 'false')


def _quiet_pull(store, settings):
    try:
        from network.guard import active_guard
        pull_if_newer(store, settings, active_guard())
    except Exception:
        return


def _upload_ratings(store, settings, guard):
    pending = unsynced_events()
    if not pending:
        return 0
    text = ''.join(json.dumps(row, ensure_ascii=False, sort_keys=True) + '\n' for row in pending)
    append_text(
        guard, settings.get('brain_repo').strip(), settings.get('brain_token').strip(),
        'inbox/ratings.jsonl', text, 'Hearth ratings'
    )
    mark_synced(row.get('event_id') for row in pending)
    return len(pending)


def _upload_wanted(store, settings, guard, want_picks):
    document = lists_wanted(settings, version=_version())
    document['want_picks'] = bool(want_picks)
    put_json(
        guard, settings.get('brain_repo').strip(), settings.get('brain_token').strip(),
        'inbox/lists_wanted.json', document, 'Hearth list requests'
    )


def _wake(guard, settings, sent, want_picks):
    url = (settings.get('brain_webhook_url') or '').strip()
    if not url:
        return
    try:
        post_webhook(guard, url, (settings.get('brain_webhook_key') or '').strip(), {
            'event': 'sync',
            'want_picks': bool(want_picks),
            'new_ratings': int(sent),
            'generated_at': iso()
        })
    except GitHubError as exc:
        store_error = str(exc)[:200]
        return store_error


def _notify(message):
    try:
        import xbmc
        xbmc.executebuiltin('Notification(Grok Bot, %s, 5000)' % message.replace(',', ' ')[:120])
    except Exception:
        return


def _version():
    try:
        import xml.etree.ElementTree as ET
        from pathlib import Path
        root = Path(__file__).resolve().parents[3] / 'addon.xml'
        return ET.parse(root).getroot().attrib.get('version') or '0.8.0'
    except Exception:
        return '0.8.0'
