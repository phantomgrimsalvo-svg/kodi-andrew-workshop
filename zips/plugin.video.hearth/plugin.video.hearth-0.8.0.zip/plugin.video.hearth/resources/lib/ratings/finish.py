'''Quick rating after a title finishes. The line is written before the dialog closes.'''

from __future__ import annotations

from brain.log import append_event
from kodi_dialog import kodi_input, kodi_select, kodi_yesno
from util import iso


def prompt_finished(store, settings, title, watched_at=None):
    if title is None:
        return None
    import xbmcgui
    dialog = xbmcgui.Dialog()
    choices = [str(number) for number in range(10, 0, -1)] + ['Skip']
    heading = 'Rate %s' % (title['title'] or 'this title')
    index = kodi_select(dialog, heading, choices, 2)
    moment = watched_at or iso()
    if index is None or index < 0 or index >= len(choices) or choices[index] == 'Skip':
        append_event(_base(title, 'skip', moment))
        return {'type': 'skip'}
    rating = int(choices[index])
    notes = kodi_input(dialog, 'Notes for %s. Leave blank to skip.' % title['title'])
    rewatch = kodi_yesno(dialog, 'Rewatch', 'Was this a rewatch?')
    event = _base(title, 'rating', moment)
    event.update({'rating': rating, 'notes': notes, 'rewatch': bool(rewatch)})
    append_event(event)
    try:
        store.save_rating(
            title['id'], rating, thoughts=notes, source='local', rated_at=moment
        )
    except Exception:
        pass
    return event


def _base(title, kind, moment):
    return {
        'type': kind,
        'tmdb_id': title['tmdb'] or '',
        'imdb_id': title['imdb'] or '',
        'media_type': 'tv' if title['media_type'] == 'show' else 'movie',
        'title': title['title'] or '',
        'year': title['year'],
        'rating': None,
        'notes': '',
        'rewatch': False,
        'watched_at': moment
    }
