'''Add-on settings with an in-memory implementation for tests and headless jobs.'''

from __future__ import annotations

ADDON_ID = 'plugin.video.hearth'

DEFAULTS = {
    'network_policy': 'strict',
    'watch_threshold_percent': '85',
    'backup_keep': '4',
    'backup_interval_days': '7',
    'include_artwork': 'true',
    'exclude_specials': 'true',
    'include_fully_watched': 'false',
    'recent_limit': '25',
    'resume_behavior': 'ask',
    'track_other_addons': 'true',
    'default_player_movie': '',
    'default_player_episode': '',
    'players_url': 'https://bit.ly/Gplayers',
    'last_player_movie': '',
    'last_player_episode': '',
    'cloud_mirror': 'none',
    'use_own_keys': 'false',
    'trakt_push_ratings': 'true',
    'mirror_base_url': '',
    'trakt_client_id': '',
    'trakt_client_secret': '',
    'trakt_access_token': '',
    'trakt_refresh_token': '',
    'trakt_token_created_at': '',
    'trakt_token_expires_in': '',
    'trakt_device_code': '',
    'trakt_device_interval': '',
    'trakt_device_expires_in': '',
    'tmdb_api_key': '',
    'tmdb_list_id': '',
    'tmdb_v4_token': '',
    'tmdb_session_id': '',
    'simkl_client_id': '',
    'simkl_access_token': '',
    'mdblist_api_key': '',
    'mdblist_list_id': '',
    'backup_folder': '',
    'wizard_done': 'false',
    'channels_enabled': 'false',
    'live_channel_hours': '6',
    'channel_server_port': '52849',
    'channel_server_token': 'hearth',
    'scrobble_during_playback': 'true',
    'seek_floor_percent': '2',
    'gl_for_you_enabled': 'true',
    'gl_for_you_name': 'For you',
    'gl_for_you_size': '20',
    'gl_for_you_media': 'both',
    'gl_for_you_year_from': '0',
    'gl_for_you_year_to': '0',
    'gl_for_you_genres': '',
    'gl_for_you_genres_exclude': '',
    'gl_for_you_min_rating': '0',
    'gl_for_you_min_votes': '0',
    'gl_for_you_language': '',
    'gl_for_you_request': '',
    'gl_movies_enabled': 'true',
    'gl_movies_name': 'Movies',
    'gl_movies_size': '20',
    'gl_movies_media': 'movie',
    'gl_movies_year_from': '0',
    'gl_movies_year_to': '0',
    'gl_movies_genres': '',
    'gl_movies_genres_exclude': '',
    'gl_movies_min_rating': '0',
    'gl_movies_min_votes': '0',
    'gl_movies_language': '',
    'gl_movies_request': '',
    'gl_shows_enabled': 'true',
    'gl_shows_name': 'Shows',
    'gl_shows_size': '20',
    'gl_shows_media': 'tv',
    'gl_shows_year_from': '0',
    'gl_shows_year_to': '0',
    'gl_shows_genres': '',
    'gl_shows_genres_exclude': '',
    'gl_shows_min_rating': '0',
    'gl_shows_min_votes': '0',
    'gl_shows_language': '',
    'gl_shows_request': '',
    'gl_gems_enabled': 'true',
    'gl_gems_name': 'Hidden gems',
    'gl_gems_size': '15',
    'gl_gems_media': 'both',
    'gl_gems_year_from': '0',
    'gl_gems_year_to': '0',
    'gl_gems_genres': '',
    'gl_gems_genres_exclude': '',
    'gl_gems_min_rating': '7',
    'gl_gems_min_votes': '50',
    'gl_gems_language': '',
    'gl_gems_request': '',
    'gl_custom_1_enabled': 'false',
    'gl_custom_1_name': 'Custom list 1',
    'gl_custom_1_size': '15',
    'gl_custom_1_media': 'both',
    'gl_custom_1_year_from': '0',
    'gl_custom_1_year_to': '0',
    'gl_custom_1_genres': '',
    'gl_custom_1_genres_exclude': '',
    'gl_custom_1_min_rating': '0',
    'gl_custom_1_min_votes': '0',
    'gl_custom_1_language': '',
    'gl_custom_1_request': '',
    'gl_custom_2_enabled': 'false',
    'gl_custom_2_name': 'Custom list 2',
    'gl_custom_2_size': '15',
    'gl_custom_2_media': 'both',
    'gl_custom_2_year_from': '0',
    'gl_custom_2_year_to': '0',
    'gl_custom_2_genres': '',
    'gl_custom_2_genres_exclude': '',
    'gl_custom_2_min_rating': '0',
    'gl_custom_2_min_votes': '0',
    'gl_custom_2_language': '',
    'gl_custom_2_request': '',
    'brain_enabled': 'false',
    'brain_repo': 'phantomgrimsalvo-svg/hearth-brain',
    'brain_token': '',
    'brain_webhook_url': '',
    'brain_webhook_key': ''
}

TRUTHY = {'1', 'true', 'yes', 'on'}

# Stored in the SQLite meta table. Kodi drops setSetting for ids that are
# not declared in settings.xml, so these must not go through the add-on settings.
TRAKT_FIELDS = {
    'trakt_access_token': 'access_token',
    'trakt_refresh_token': 'refresh_token',
    'trakt_token_created_at': 'created_at',
    'trakt_token_expires_in': 'expires_in',
    'trakt_device_code': 'device_code',
    'trakt_device_interval': 'interval',
    'trakt_device_expires_in': 'device_expires_in'
}


class Settings:
    '''Key/value settings. Values are stored as strings, matching Kodi.'''

    def __init__(self, values=None):
        self.values = dict(DEFAULTS)
        if values:
            for key, value in values.items():
                self.values[key] = '' if value is None else str(value)

    def get(self, key, default=None):
        if key in TRAKT_FIELDS and getattr(self, 'store', None) is not None:
            from trakt.auth import read_field
            return read_field(self.store, TRAKT_FIELDS[key])
        if key in self.values:
            value = self.values[key]
        elif default is not None:
            value = default
        else:
            value = DEFAULTS.get(key, '')
        if not str(value or '').strip():
            from builtin_keys import FALLBACK
            builtin = FALLBACK.get(key) or ''
            if str(builtin).strip():
                return builtin
        return value

    def set(self, key, value):
        text = '' if value is None else str(value)
        self.values[key] = text
        if key in TRAKT_FIELDS and getattr(self, 'store', None) is not None:
            from trakt.auth import write_field
            write_field(self.store, TRAKT_FIELDS[key], text)

    def flag(self, key, default=False):
        raw = self.get(key, 'true' if default else 'false')
        return str(raw).strip().lower() in TRUTHY

    def integer(self, key, default=0):
        try:
            return int(float(self.get(key, default)))
        except (TypeError, ValueError):
            return int(default)

    @property
    def threshold(self):
        percent = self.integer('watch_threshold_percent', 85)
        return max(0.01, min(percent, 99)) / 100.0

    @property
    def floor(self):
        percent = self.integer('seek_floor_percent', 2)
        return max(0.0, percent) / 100.0

    def mirror_enabled(self):
        value = (self.get('cloud_mirror') or 'none').strip().lower()
        return value not in ('', 'none', 'off')

    def trakt_authorized(self):
        if getattr(self, 'store', None) is not None:
            from trakt.auth import read_field
            return bool(read_field(self.store, 'access_token'))
        return bool(self.get('trakt_access_token') or '')

    def reload_from_kodi(self):
        '''Pick up values saved in the settings dialog during this session.'''
        fresh = load_kodi_settings()
        store = getattr(self, 'store', None)
        for key, value in fresh.values.items():
            if key in TRAKT_FIELDS:
                continue
            self.values[key] = value
        self.store = store

    def policy(self):
        value = (self.get('network_policy') or 'strict').strip().lower()
        if value in ('debug', 'debug log only'):
            return 'debug'
        if value in ('allow_all', 'allow all', 'allow all (developer)'):
            return 'allow_all'
        return 'strict'

    def public_dict(self):
        '''Settings safe to write into a backup. Secrets stay out.'''
        hidden = {
            'trakt_client_secret', 'trakt_access_token', 'trakt_refresh_token',
            'trakt_device_code', 'tmdb_api_key', 'tmdb_v4_token', 'tmdb_session_id',
            'simkl_client_id', 'simkl_access_token', 'mdblist_api_key',             'recs_api_key',
            'recs_research_key', 'brain_token', 'brain_webhook_key'
        }
        return {key: value for key, value in self.values.items() if key not in hidden}


def declared_setting_ids():
    '''Ids Kodi will actually store. Anything else is silently dropped.'''
    import xml.etree.ElementTree as ET
    from pathlib import Path
    root = Path(__file__).resolve().parents[2] / 'resources' / 'settings.xml'
    tree = ET.parse(root)
    return {
        element.get('id')
        for element in tree.getroot().iter('setting')
        if element.get('id')
    }


def save_kodi_setting(key, value):
    '''Write a declared setting. Undefined ids are refused.'''
    if key not in declared_setting_ids():
        raise ValueError('Kodi will not store %s because it is not in settings.xml' % key)
    text = '' if value is None else str(value)
    try:
        import xbmcaddon
        xbmcaddon.Addon(ADDON_ID).setSetting(key, text)
    except Exception:
        return text
    return text


def load_kodi_settings():
    '''Read settings from xbmcaddon when the add-on is running inside Kodi.'''
    try:
        import xbmcaddon
    except ImportError:
        return Settings()
    addon = xbmcaddon.Addon(ADDON_ID)
    values = {}
    for key in DEFAULTS:
        try:
            values[key] = addon.getSetting(key)
        except Exception:
            values[key] = DEFAULTS[key]
    return Settings(values)
