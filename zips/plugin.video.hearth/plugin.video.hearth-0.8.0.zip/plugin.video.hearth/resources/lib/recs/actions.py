'''Actions on a Grok Bot pick. Nothing here calls a model.'''

from __future__ import annotations

from brain.log import append_event
from kodi_dialog import kodi_input
from util import iso, loads


def run_rec_action(name, parts, store, settings, notify, show_text):
    title_id = int(parts[2]) if len(parts) > 2 and str(parts[2]).isdigit() else None
    if name == 'not_interested' and title_id:
        _not_interested(store, title_id, notify)
    elif name == 'why_pick' and title_id:
        _why(store, title_id, show_text, notify)
    elif name == 'correct_reason' and title_id:
        _correct(store, title_id, notify)
    elif name == 'lock_list' and len(parts) > 2:
        _lock(store, parts[2], notify)
    elif name == 'never_show' and title_id:
        store.ensure_list('never_show', 'Never show', show=False)
        store.add_list_item('never_show', title_id, None)
        notify('Hearth', 'That title will not be recommended.')
    elif name == 'already_seen' and title_id:
        store.set_watch(title_id, None, play_count=1, resume_seconds=0, source='local')
        notify('Hearth', 'Marked watched.')
    elif name == 'trailer' and title_id:
        _trailer(store, title_id)
    elif name == 'more_like' and title_id:
        notify('Hearth', 'More like this uses the title already in your library.')


def _detail(store, title_id):
    for row in store.all_lists():
        slug = str(row['slug'])
        if not slug.startswith('grok_'):
            continue
        for item in store.list_items(slug):
            if item['title_id'] != title_id:
                continue
            detail = loads(item['detail'], {}) if item['detail'] else {}
            detail = detail or {}
            detail['slug'] = slug
            detail['reason'] = detail.get('why') or item['reason'] or ''
            return detail
    return {}


def _not_interested(store, title_id, notify):
    title = store.get_title(title_id)
    detail = _detail(store, title_id)
    note = ''
    try:
        import xbmcgui
        note = kodi_input(xbmcgui.Dialog(), 'Optional note')
    except Exception:
        note = ''
    append_event({
        'type': 'not_interested',
        'list_id': detail.get('list_id') or '',
        'tmdb_id': (title['tmdb'] if title is not None else '') or detail.get('tmdb') or '',
        'notes': note,
        'watched_at': iso()
    })
    for row in store.all_lists():
        if str(row['slug']).startswith('grok_'):
            store.remove_list_item(row['slug'], title_id, None)
    notify('Hearth', 'Noted. Grok Bot will see that thumbs-down.')


def _why(store, title_id, show_text, notify):
    detail = _detail(store, title_id)
    reason = detail.get('reason') or 'No reason was stored for this pick.'
    show_text('Why was this picked?', reason)
    import xbmcgui
    from kodi_dialog import kodi_yesno
    if kodi_yesno(xbmcgui.Dialog(), 'Correct this', 'Type a correction to this reason?'):
        _correct(store, title_id, notify)


def _correct(store, title_id, notify):
    title = store.get_title(title_id)
    detail = _detail(store, title_id)
    import xbmcgui
    text = kodi_input(xbmcgui.Dialog(), 'What should Grok Bot have said?')
    if not text:
        notify('Hearth', 'No correction was saved.')
        return
    append_event({
        'type': 'reason_correction',
        'list_id': detail.get('list_id') or '',
        'tmdb_id': (title['tmdb'] if title is not None else '') or detail.get('tmdb') or '',
        'reason': detail.get('reason') or '',
        'correction': text,
        'watched_at': iso()
    })
    notify('Hearth', 'Correction saved. It goes out on the next sync.')


def _lock(store, list_id, notify):
    slug = 'grok_%s' % list_id
    row = store.list_row(slug)
    if row is None:
        notify('Hearth', 'That list is not on this device.')
        return
    import xbmcgui
    note = kodi_input(xbmcgui.Dialog(), 'What did you like about this list? Optional.')
    items = []
    snapshot = []
    for item in store.list_items(slug):
        title = store.get_title(item['title_id'])
        items.append({
            'title_id': item['title_id'],
            'episode_id': None,
            'reason': item['reason'] or ''
        })
        snapshot.append({
            'tmdb_id': title['tmdb'] if title is not None else '',
            'title': title['title'] if title is not None else '',
            'year': title['year'] if title is not None else None
        })
    locked = 'locked_%s' % list_id
    store.ensure_list(locked, row['name'], show=True, system=False)
    store.replace_list_items(locked, items)
    store.clear_list(slug)
    append_event({
        'type': 'list_locked',
        'list_id': list_id,
        'titles': snapshot,
        'notes': note,
        'watched_at': iso()
    })
    notify('Hearth', 'Locked as a list of yours. Grok Bot can refill this slot.')


def _trailer(store, title_id):
    import xbmc
    from urllib.parse import quote
    title = store.get_title(title_id)
    if title is None:
        return
    target = 'plugin://plugin.video.youtube/kodion/search/query/?q=%s' % quote(
        '%s trailer' % (title['title'] or '')
    )
    xbmc.executebuiltin('PlayMedia("%s")' % target)
