'''Localhost export for the channel app.

Kodi's /vfs/ path only serves configured media sources, so addon_data
returns 401 even with the right web-server password. This server binds
127.0.0.1 and checks a shared token.
'''

from __future__ import annotations

import hmac
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from threading import Thread
from urllib.parse import unquote, urlparse

_SERVER = None


def ensure_server(settings):
    '''Start once per process. A second call leaves the running server alone.'''
    global _SERVER
    if _SERVER is not None:
        return _SERVER
    port = _port(settings)
    token = _token(settings)
    from paths import art_dir, channels_export_path
    try:
        httpd = start_server(port, token, channels_export_path(), art_dir())
    except OSError:
        return None
    _SERVER = httpd
    return httpd


def start_server(port, token, export_path, art_root):
    handler = _handler(token or '', Path(export_path), Path(art_root))
    httpd = ThreadingHTTPServer(('127.0.0.1', int(port)), handler)
    thread = Thread(target=httpd.serve_forever, name='hearth-channels', daemon=True)
    thread.start()
    return httpd


def _handler(token, export_path, art_root):
    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            parsed = urlparse(self.path)
            parts = [unquote(part) for part in parsed.path.split('/') if part]
            header = self.headers.get('X-Hearth-Token') or ''
            if len(parts) >= 2 and parts[0] == 'export':
                if not _matches(token, parts[1]) and not _matches(token, header):
                    self._reply(401, b'{"error":"bad token"}')
                    return
                if not export_path.is_file():
                    self._reply(404, b'{"error":"export not written yet"}')
                    return
                self._reply(200, export_path.read_bytes(), 'application/json; charset=utf-8')
                return
            if len(parts) >= 3 and parts[0] == 'art':
                if not _matches(token, parts[1]) and not _matches(token, header):
                    self._reply(401, b'{"error":"bad token"}')
                    return
                target = _safe_art(art_root, parts[2:])
                if target is None or not target.is_file():
                    self._reply(404, b'{"error":"no artwork"}')
                    return
                kind = 'image/jpeg'
                if target.suffix.lower() == '.png':
                    kind = 'image/png'
                elif target.suffix.lower() == '.webp':
                    kind = 'image/webp'
                self._reply(200, target.read_bytes(), kind)
                return
            self._reply(404, b'{"error":"not found"}')

        def log_message(self, fmt, *args):
            return

        def _reply(self, status, body, content_type='application/json'):
            self.send_response(status)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(len(body)))
            self.send_header('Cache-Control', 'no-store')
            self.end_headers()
            self.wfile.write(body)

    return Handler


def _matches(expected, got):
    if not expected or not got:
        return False
    return hmac.compare_digest(str(expected), str(got))


def _safe_art(root, parts):
    if any(part in ('', '.', '..') for part in parts):
        return None
    root = root.resolve()
    target = root.joinpath(*parts).resolve()
    try:
        target.relative_to(root)
    except ValueError:
        return None
    return target


def _port(settings):
    port = settings.integer('channel_server_port', 52849)
    if port < 1 or port > 65535:
        return 52849
    return port


def _token(settings):
    token = (settings.get('channel_server_token') or '').strip()
    return token or 'hearth'
