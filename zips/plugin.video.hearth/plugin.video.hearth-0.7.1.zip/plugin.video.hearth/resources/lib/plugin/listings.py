'''Lucent-ready directory payloads. Art paths are local files. No network.'''

from __future__ import annotations

from data.store import art_map, genre_list
from paths import placeholder_art
from util import loads

PLUGIN = 'plugin://plugin.video.hearth'


def plugin_url(*parts):
    tail = '/'.join(str(part).strip('/') for part in parts if part is not None and part != '')
    if not tail:
        return PLUGIN + '/'
    return PLUGIN + '/' + tail


def build_root(store):
    store.ensure_system_lists()
    items = []
    for row in store.lists_in_menu():
        live = (
            row['kind'] == 'import'
            and (row['import_mode'] or '') == 'live'
            and row['import_plugin_path']
        )
        items.append({
            'label': row['name'],
            'title': row['name'],
            'is_folder': True,
            'is_playable': False,
            'path': row['import_plugin_path'] if live else plugin_url('list', row['slug']),
            'mediatype': 'tvshow' if row['media_filter'] == 'shows' else '',
            'plot': _list_plot(row),
            'art': _list_art(row),
            'uniqueid': {'hearth': row['slug']},
            'list_slug': row['slug'],
            'can_remove': not int(row['is_system'] or 0)
        })
    if not store.meta_get('last_initial_import_at'):
        items.append({
            'label': 'Import from Trakt',
            'title': 'Import from Trakt',
            'is_folder': False,
            'is_playable': False,
            'path': plugin_url('action', 'import_dry_run'),
            'plot': 'One-time pull of watched, playback, ratings, watchlist, favorites, and your lists. Collection is not imported.',
            'art': {'poster': str(placeholder_art()), 'fanart': str(placeholder_art())}
        })
    return items


def build_list(store, slug, settings):
    row = store.list_row(slug)
    if row is None:
        return []
    if slug == 'next_up':
        return _next_up(store)
    if row['kind'] == 'import' and (row['import_mode'] or '') == 'live' and row['import_plugin_path']:
        return [_live_shortcut(row)]
    limit = None
    if slug == 'recent_movies':
        limit = _recent_limit(settings)
    can_remove = not int(row['is_system'] or 0)
    items = list(store.list_items(slug))
    if slug == 'recs_mood':
        mood = (store.meta_get('recs_mood') or '').strip().lower()
        if mood:
            kept = []
            for item in items:
                detail = loads(item['detail'], {}) if item['detail'] else {}
                if str(detail.get('mood') or '').strip().lower() == mood:
                    kept.append(item)
            items = kept
    payloads = []
    for item in items:
        payload = _title_payload(store, item, playable=row['media_filter'] != 'shows')
        payload['list_slug'] = slug
        payload['can_remove'] = can_remove
        if str(slug).startswith('recs'):
            _decorate_rec(payload, item)
        payloads.append(payload)
    if slug == 'recs_mood':
        payloads.insert(0, {
            'label': 'Pick a mood',
            'title': 'Pick a mood',
            'is_folder': False,
            'is_playable': False,
            'path': plugin_url('action', 'pick_mood'),
            'plot': 'Choose a mood. The list is in Hearth settings.',
            'art': {'poster': str(placeholder_art()), 'fanart': str(placeholder_art())}
        })
    if slug == 'recent_movies':
        payloads.sort(key=lambda entry: entry.get('lastplayed') or '', reverse=True)
        if limit is not None:
            payloads = payloads[:limit]
    return payloads


def build_info(store, title_id):
    title = store.get_title(int(title_id))
    if title is None:
        return None
    watch = store.get_watch(title['id'], None)
    rating = store.get_rating(title['id'], None)
    lines = [title['title']]
    if title['year']:
        lines.append(str(title['year']))
    if title['plot']:
        lines.append(title['plot'])
    if watch is not None and watch['resume_seconds']:
        lines.append('Resume at %s seconds.' % int(watch['resume_seconds']))
    if rating is not None and rating['score']:
        lines.append('Your rating: %s/10.' % rating['score'])
        if rating['liked']:
            lines.append('Liked: ' + rating['liked'])
        if rating['disliked']:
            lines.append('Disliked: ' + rating['disliked'])
    for item in store.list_items('recs'):
        if item['title_id'] == title['id'] and item['reason']:
            lines.append('Why this is here: ' + item['reason'])
            break
    membership = []
    for lst in store.lists_in_menu():
        if store.in_list(lst['slug'], title['id'], None):
            membership.append(lst['name'])
    if membership:
        lines.append('On lists: ' + ', '.join(membership))
    return {'title': title['title'], 'text': '\n\n'.join(lines)}


def _next_up(store):
    items = []
    for item in store.list_items('next_up'):
        payload = _title_payload(store, item, playable=item['episode_id'] is not None)
        if item['episode_id'] is None:
            payload['is_folder'] = True
            payload['is_playable'] = False
            payload['mediatype'] = 'tvshow'
            payload['title'] = payload.get('tvshowtitle') or payload.get('label') or ''
            payload['label'] = payload['title']
            payload['season'] = None
            payload['episode'] = None
            payload['path'] = plugin_url('show', item['title_id'])
            payload['file'] = payload['path']
        items.append(payload)
    return items


def build_show_seasons(store, show_id):
    title = store.get_title(int(show_id))
    if title is None:
        return []
    seasons = []
    seen = []
    for episode in store.episodes_for_show(title['id']):
        number = int(episode['season'])
        if number in seen:
            continue
        seen.append(number)
        label = 'Specials' if number == 0 else 'Season %s' % number
        seasons.append({
            'label': label,
            'title': label,
            'tvshowtitle': title['title'],
            'mediatype': 'season',
            'season': number,
            'is_folder': True,
            'is_playable': False,
            'path': plugin_url('show', title['id'], 'season', number),
            'plot': title['plot'] or '',
            'art': _art(title, None)
        })
    return seasons


def build_season_episodes(store, show_id, season):
    title = store.get_title(int(show_id))
    if title is None:
        return []
    items = []
    for episode in store.episodes_for_show(title['id']):
        if int(episode['season']) != int(season):
            continue
        items.append(_title_payload(store, {
            'title_id': title['id'],
            'episode_id': episode['id'],
            'reason': episode['title'] or 'Episode %s' % episode['episode']
        }, playable=True))
    return items


def _title_payload(store, item, playable):
    title = store.get_title(item['title_id'])
    episode = store.get_episode(item['episode_id']) if item['episode_id'] else None
    if episode is not None:
        watch = store.get_watch(title['id'], episode['id'])
        mediatype = 'episode'
        file_path = plugin_url('play', title['id'], episode['id'])
        label = item['reason'] or episode['title'] or title['title']
        showtitle = title['title']
        season = episode['season']
        number = episode['episode']
        name = episode['title'] or title['title']
        premiered = episode['first_aired'] or title['premiered'] or ''
        plot = episode['plot'] or title['plot'] or ''
        runtime = episode['runtime_seconds'] or title['runtime_seconds'] or 0
        art = _art(title, episode)
        unique = {
            'hearth': str(episode['id']),
            'imdb': episode['imdb'] or title['imdb'] or '',
            'tmdb': episode['tmdb'] or title['tmdb'] or '',
            'tvdb': episode['tvdb'] or title['tvdb'] or ''
        }
    else:
        watch = store.get_watch(title['id'], None)
        mediatype = 'movie' if title['media_type'] == 'movie' else 'tvshow'
        file_path = plugin_url('play', title['id'])
        label = title['title']
        showtitle = title['title'] if title['media_type'] == 'show' else ''
        season = None
        number = None
        name = title['title']
        premiered = title['premiered'] or ''
        plot = title['plot'] or ''
        runtime = title['runtime_seconds'] or 0
        art = _art(title, None)
        unique = {
            'hearth': str(title['id']),
            'imdb': title['imdb'] or '',
            'tmdb': title['tmdb'] or '',
            'tvdb': title['tvdb'] or ''
        }
        playable = title['media_type'] == 'movie'
    rating = store.get_rating(title['id'], None)
    resume_seconds = float(watch['resume_seconds'] or 0) if watch is not None else 0
    total = int(watch['runtime_seconds'] or runtime or 0) if watch is not None else int(runtime or 0)
    return {
        'label': label,
        'title': name,
        'tvshowtitle': showtitle,
        'mediatype': mediatype,
        'plot': plot,
        'art': art,
        'trailer': '',
        'year': title['year'] or 0,
        'premiered': premiered,
        'rating': float(rating['score']) if rating is not None and rating['score'] else 0,
        'userrating': int(rating['score']) if rating is not None and rating['score'] else 0,
        'mpaa': title['mpaa'] or '',
        'playcount': int(watch['play_count']) if watch is not None else 0,
        'resume': {'position': resume_seconds, 'total': total},
        'runtime': int(total or runtime or 0),
        'season': season,
        'episode': number,
        'showtitle': showtitle,
        'uniqueid': unique,
        'dateadded': title['added_at'] or '',
        'file': file_path,
        'genre': genre_list(title),
        'studio': title['studio'] or '',
        'lastplayed': (watch['last_played'] or '') if watch is not None else '',
        'cast': [],
        'director': [],
        'is_playable': bool(playable),
        'is_folder': not playable and title['media_type'] == 'show' and episode is None,
        'path': file_path if playable else plugin_url('show', title['id']),
        'reason': item['reason'] or ''
    }


def _decorate_rec(payload, item):
    detail = {}
    if 'detail' in item.keys() and item['detail']:
        detail = loads(item['detail'], {}) or {}
    bits = [payload.get('title') or payload.get('label') or '']
    year = detail.get('year') or payload.get('year')
    if year:
        bits.append(str(year))
    if detail.get('match') not in (None, ''):
        try:
            bits.append('%s%%' % int(float(detail['match'])))
        except (TypeError, ValueError):
            pass
    if detail.get('tmdb_rating') not in (None, ''):
        bits.append('TMDB %s' % detail['tmdb_rating'])
    runtime = detail.get('runtime') or payload.get('runtime') or 0
    try:
        runtime = int(runtime)
    except (TypeError, ValueError):
        runtime = 0
    if runtime >= 3600:
        bits.append('%dh %dm' % (runtime // 3600, (runtime % 3600) // 60))
    elif runtime >= 60:
        bits.append('%d min' % (runtime // 60))
    payload['label'] = ' · '.join(str(bit) for bit in bits if bit)
    extra = []
    why = detail.get('why') or item['reason'] or ''
    if why:
        extra.append(why)
    if detail.get('source'):
        extra.append('Source: %s' % detail['source'])
    if detail.get('credit'):
        extra.append(str(detail['credit']))
    if extra:
        payload['plot'] = '\n'.join(extra) + (('\n' + payload['plot']) if payload.get('plot') else '')
    title_id = item['title_id']
    base = 'RunPlugin(plugin://plugin.video.hearth/action/%s/%s)'
    payload['context'] = [
        ('Play trailer', base % ('trailer', title_id)),
        ('More like this', base % ('more_like', title_id)),
        ('Not interested', base % ('not_interested', title_id)),
        ('Never show', base % ('never_show', title_id)),
        ('Already seen', base % ('already_seen', title_id)),
        ('Why this pick', base % ('why_pick', title_id))
    ]


def _art(title, episode):
    poster = str(placeholder_art())
    mapping = art_map(episode) or art_map(title)
    title_art = art_map(title)

    def pick(kind):
        local = mapping.get(kind) or title_art.get(kind) or ''
        if _local_file(local):
            return local
        remote = _remote_art(mapping, title_art, kind)
        if remote:
            return remote
        if local and not str(local).startswith(('http://', 'https://')):
            return local
        return poster

    def pick_url(kind):
        return _remote_art(mapping, title_art, kind)

    return {
        'poster': pick('poster'),
        'fanart': pick('fanart'),
        'thumb': pick('thumb'),
        'poster_url': pick_url('poster'),
        'fanart_url': pick_url('fanart'),
        'thumb_url': pick_url('thumb')
    }


def _local_file(path):
    from pathlib import Path
    text = str(path or '')
    if not text or text.startswith(('http://', 'https://')):
        return False
    return Path(text).is_file()


def _remote_art(mapping, title_art, kind):
    for source in (mapping, title_art):
        url = source.get(kind + '_url') or ''
        if str(url).startswith(('http://', 'https://')):
            return url
    for source in (mapping, title_art):
        file_path = source.get(kind + '_path') or ''
        if file_path:
            from art.store import image_url
            image_kind = 'fanart' if kind == 'fanart' else ('thumb' if kind == 'thumb' else 'poster')
            return image_url(file_path, image_kind)
    return ''


def _list_art(row):
    poster = str(placeholder_art())
    if row['import_art']:
        poster = row['import_art']
    return {'poster': poster, 'fanart': poster, 'thumb': poster}


def _live_shortcut(row):
    return {
        'label': row['name'],
        'title': row['name'],
        'is_folder': True,
        'is_playable': False,
        'path': row['import_plugin_path'],
        'plot': 'Opens this add-on folder. Hearth does not copy the items.',
        'art': _list_art(row),
        'uniqueid': {'hearth': row['slug']},
        'list_slug': row['slug'],
        'can_remove': True
    }


def _list_plot(row):
    if row['kind'] == 'import' and row['import_mode'] == 'live':
        return 'Opens this add-on folder. Hearth does not copy the items.'
    if row['kind'] == 'import':
        return 'Snapshot of another add-on folder.'
    if str(row['slug']).startswith('recs'):
        return 'Recommendations from your ratings. Rebuild them in Hearth settings.'
    return row['name']


def _recent_limit(settings):
    raw = (settings.get('recent_limit') or '25').strip().lower()
    if raw in ('all', '0', ''):
        return None
    try:
        return int(raw)
    except ValueError:
        return 25
