'''One Gemini call with Google Search grounding. It updates notes and taste twins.'''

from __future__ import annotations

import json
from urllib.parse import quote

from recs.engine import _count_call, _message_text, _within_budget
from recs.profile import andrew_text, journal_markdown, save_research
from util import iso


def deep_research(store, settings, guard, now=None):
    now = now or iso()
    key, model = _gemini(settings)
    if not key:
        return {
            'skipped': 'Add a Gemini key. Deep research uses Google Search grounding.'
        }
    if not _within_budget(store, settings, now):
        return {'skipped': 'monthly budget'}
    url = (
        'https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent?key=%s'
        % (quote(model, safe=''), key)
    )
    guard.allow_host('generativelanguage.googleapis.com')
    prompt = _prompt(store)
    body = {
        'contents': [{'role': 'user', 'parts': [{'text': prompt}]}],
        'tools': [{'google_search': {}}]
    }
    response = guard.post(
        url, 'weekly_recs',
        headers={'Content-Type': 'application/json'},
        body=json.dumps(body)
    )
    status = int(getattr(response, 'status', 0) or 0)
    if status < 200 or status >= 300 or isinstance(getattr(response, 'body', None), (bytes, bytearray)):
        from recs.engine import ProviderError
        raise ProviderError('Deep research failed (%s).' % (status or 0))
    text = _message_text('gemini', response.body)
    parsed = _object(text)
    insights = parsed.get('insights') or []
    notes = parsed.get('notes') or ''
    twins = parsed.get('twins') or []
    picks = parsed.get('picks') or []
    if andrew_text(store.meta_get('ai_notes') or ''):
        notes = notes  # save_research keeps the Andrew block
    save_research(store, insights, notes, twins, picks)
    _count_call(store, now)
    return {
        'insights': len(insights) if isinstance(insights, list) else 0,
        'twins': len(twins) if isinstance(twins, list) else 0
    }


def _gemini(settings):
    provider = (settings.get('recs_provider') or '').strip().lower()
    key = ''
    if provider == 'gemini':
        key = (settings.get('recs_api_key') or '').strip()
    if not key:
        key = (settings.get('recs_research_key') or '').strip()
    model = 'gemini-2.5-flash'
    if provider == 'gemini' and (settings.get('recs_model') or '').strip():
        model = settings.get('recs_model').strip()
    return key, model


def _prompt(store):
    kept = andrew_text(store.meta_get('ai_notes') or '')
    return (
        'Read this taste journal and write what it shows about the person.\n'
        + journal_markdown(store)[:8000]
        + '\nAndrew wrote this. Keep it. Do not contradict it:\n'
        + (kept or '(nothing yet)')
        + '\nReturn JSON only with keys insights (list of strings), notes (markdown), '
        + 'twins (list of {name, where, why, link} for critics, YouTubers, bloggers, '
        + 'Letterboxd or Trakt users), and picks (list of {name, media_type, title, year, tmdb_id, why} '
        + 'for titles those people loved that he has not). '
        + 'Look for patterns in theme, tone, craft and characters, and contrasts inside a genre.'
    )


def _object(text):
    raw = (text or '').strip()
    start = raw.find('{')
    end = raw.rfind('}')
    if start < 0 or end < start:
        return {}
    try:
        data = json.loads(raw[start:end + 1])
    except ValueError:
        return {}
    return data if isinstance(data, dict) else {}
