'''Readable taste profile, the journal, and the notes Andrew can edit.'''

from __future__ import annotations

from collections import Counter
from pathlib import Path

from util import dumps, iso, loads

ANDREW_START = '<!-- andrew -->'
ANDREW_END = '<!-- /andrew -->'


def render_profile(store, settings=None):
    '''What View taste profile shows. No prompt rules.'''
    rows = _counted_ratings(store, settings)
    if not rows:
        return 'No ratings yet. Rate a few titles and this page fills in.'
    insights = loads(store.meta_get('taste_insights'), []) or []
    lines = ['Taste profile', '']
    favorites = sorted(rows, key=lambda row: (-row['weight'], -row['score']))[:8]
    lows = sorted(
        [row for row in rows if row['score'] <= 4],
        key=lambda row: (row['score'], row['title'])
    )[:8]
    lines.append('Favorites')
    for row in favorites:
        if row['score'] < 8:
            break
        lines.append(_title_line(row))
    lines.append('')
    lines.append('Least favorite')
    if lows:
        for row in lows:
            lines.append(_title_line(row))
    else:
        lines.append('Nothing at 4 or below.')
    lines.append('')
    lines.append('Themes')
    high_genres = _genres(favorites)
    low_genres = _genres(lows)
    if high_genres:
        lines.append('Shows up in what you rate highly: ' + ', '.join(high_genres))
    if low_genres:
        lines.append('Shows up in what you rate low: ' + ', '.join(low_genres))
    notes = [row for row in rows if row['liked'] or row['disliked'] or row['thoughts']]
    if notes:
        lines.append('')
        lines.append('In your words')
        for row in notes[:12]:
            bits = []
            if row['liked']:
                bits.append('liked ' + row['liked'])
            if row['disliked']:
                bits.append('disliked ' + row['disliked'])
            if row['thoughts']:
                bits.append(row['thoughts'])
            lines.append('%s — %s' % (row['title'], '; '.join(bits)))
    lines.append('')
    lines.append('Key insights')
    if insights:
        for item in insights[:8]:
            lines.append('- ' + str(item))
    else:
        lines.append('Run Deep research after a few ratings and this section fills in.')
    lines.append('')
    lines.append('Ratings')
    scores = [row['score'] for row in rows]
    lines.append('%s ratings, average %s.' % (len(scores), _average(scores)))
    counted = Counter(scores)
    for score in range(10, 0, -1):
        count = counted.get(score, 0)
        if count:
            lines.append('%2d  %s  %s' % (score, '|' * min(count, 40), count))
    sources = Counter(row['source'] or 'local' for row in rows)
    lines.append('')
    lines.append('Sources')
    for name, count in sorted(sources.items()):
        lines.append('%s: %s' % (_source_label(name), count))
    boost = 1
    if settings is not None:
        boost = settings.integer('recs_rewatch_boost', 1)
    lines.append('')
    lines.append(
        'A rating drives the profile. Each extra full play adds %s. '
        'A watch with no rating adds nothing.' % boost
    )
    return '\n'.join(lines)


def journal_markdown(store):
    lines = ['# Taste journal', '']
    entries = list(reversed(store.journal_entries(800)))
    if not entries:
        lines.append('No ratings or notes yet.')
        return '\n'.join(lines) + '\n'
    for entry in entries:
        title = store.get_title(entry['title_id']) if entry['title_id'] else None
        name = title['title'] if title is not None else 'Untitled'
        when = (entry['created_at'] or '')[:10]
        score = entry['score']
        score_text = '%s/10' % score if score is not None else 'no score'
        lines.append('- %s · %s · %s · %s' % (
            when, name, score_text, _source_label(entry['source'])
        ))
        if entry['liked']:
            lines.append('  - Liked: %s' % entry['liked'])
        if entry['disliked']:
            lines.append('  - Disliked: %s' % entry['disliked'])
        if entry['thoughts']:
            lines.append('  - Thoughts: %s' % entry['thoughts'])
        if entry['note']:
            lines.append('  - %s' % entry['note'])
    return '\n'.join(lines) + '\n'


def export_text_files(store, folder=None):
    root = Path(folder) if folder is not None else _profile()
    root.mkdir(parents=True, exist_ok=True)
    journal = root / 'taste_journal.md'
    notes = root / 'ai_notes.md'
    journal.write_text(journal_markdown(store), encoding='utf-8')
    notes.write_text((store.meta_get('ai_notes') or '').strip() + '\n', encoding='utf-8')
    return {'journal': str(journal), 'notes': str(notes)}


def andrew_text(document):
    text = document or ''
    if ANDREW_START not in text or ANDREW_END not in text:
        return ''
    return text.split(ANDREW_START, 1)[1].split(ANDREW_END, 1)[0].strip()


def notes_body(document):
    text = document or ''
    if ANDREW_END in text:
        return text.split(ANDREW_END, 1)[1].strip()
    if ANDREW_START in text:
        return ''
    return text.strip()


def compose_notes(andrew, body):
    return '%s\n%s\n%s\n\n%s\n' % (
        ANDREW_START, (andrew or '').strip(), ANDREW_END, (body or '').strip()
    )


def set_andrew_notes(store, text, folder=None):
    current = store.meta_get('ai_notes') or ''
    store.meta_set('ai_notes', compose_notes(text, notes_body(current)))
    store.meta_set('ai_notes_at', iso())
    export_text_files(store, folder)


def save_research(store, insights, body, twins, picks, folder=None):
    current = store.meta_get('ai_notes') or ''
    written = compose_notes(andrew_text(current), body)
    store.meta_set('ai_notes', written)
    store.meta_set('ai_notes_at', iso())
    store.meta_set('taste_insights', dumps(list(insights or [])))
    store.meta_set('taste_twins', dumps(list(twins or [])))
    store.meta_set('taste_twin_picks', dumps(list(picks or [])))
    export_text_files(store, folder)


def clear_notes(store, folder=None):
    store.meta_set('ai_notes', '')
    store.meta_set('taste_insights', '[]')
    store.meta_set('taste_twins', '[]')
    store.meta_set('taste_twin_picks', '[]')
    export_text_files(store, folder)


def twins_text(store):
    twins = loads(store.meta_get('taste_twins'), []) or []
    if not twins:
        return 'No taste twins yet. Run Deep research after you have some ratings.'
    lines = ['Taste twins', '']
    for twin in twins:
        if not isinstance(twin, dict):
            continue
        lines.append(twin.get('name') or 'Someone')
        where = twin.get('where') or ''
        if where:
            lines.append(where)
        if twin.get('why'):
            lines.append(twin['why'])
        if twin.get('link'):
            lines.append(twin['link'])
        lines.append('')
    return '\n'.join(lines).strip()


def _counted_ratings(store, settings):
    unfinished_counts = False
    boost = 1
    if settings is not None:
        unfinished_counts = settings.flag('recs_unfinished_counts', False)
        boost = max(0, settings.integer('recs_rewatch_boost', 1))
    document = store.export_document()
    titles = {row['id']: row for row in document['titles']}
    counted = []
    for rating in document['ratings']:
        score = rating.get('score')
        unfinished = int(rating.get('unfinished') or 0)
        if score is None:
            if unfinished and unfinished_counts:
                title = titles.get(rating['title_id'])
                if title is None:
                    continue
                counted.append({
                    'title': title['title'],
                    'year': title.get('year'),
                    'score': 0,
                    'weight': 0,
                    'liked': '',
                    'disliked': 'did not finish',
                    'thoughts': rating.get('thoughts') or '',
                    'source': rating.get('source') or '',
                    'genres': loads(title.get('genres'), []) or []
                })
            continue
        title = titles.get(rating['title_id'])
        if title is None:
            continue
        plays = _plays(store, title, rating)
        extra = max(0, plays - 1)
        weight = int(score) + min(2, extra) * boost
        counted.append({
            'title': title['title'] + _unit(rating),
            'year': title.get('year'),
            'score': int(score),
            'weight': weight,
            'liked': rating.get('liked') or '',
            'disliked': rating.get('disliked') or '',
            'thoughts': rating.get('thoughts') or '',
            'source': rating.get('source') or '',
            'genres': loads(title.get('genres'), []) or []
        })
    return counted


def _plays(store, title, rating):
    episode_id = rating.get('episode_id')
    watch = store.get_watch(title['id'], episode_id)
    if watch is None:
        return 0
    return int(watch['play_count'] or 0)


def _unit(rating):
    if rating.get('episode_id'):
        return ''
    if rating.get('season') not in (None, ''):
        return ' season %s' % rating['season']
    return ''


def _title_line(row):
    year = ' (%s)' % row['year'] if row.get('year') else ''
    return '- %s%s — %s/10' % (row['title'], year, row['score'])


def _genres(rows):
    found = []
    for row in rows:
        for genre in row.get('genres') or []:
            if genre not in found:
                found.append(genre)
    return found[:6]


def _average(scores):
    if not scores:
        return '0'
    return '%.1f' % (sum(scores) / float(len(scores)))


def _source_label(source):
    labels = {
        'local': 'Hearth',
        'local_play': 'Hearth',
        'manual': 'Hearth',
        'trakt_import': 'Trakt',
        'tmdb': 'TMDb',
        'tmdb_import': 'TMDb'
    }
    return labels.get(source or '', source or 'Hearth')


def _profile():
    from paths import profile_dir
    return profile_dir()
