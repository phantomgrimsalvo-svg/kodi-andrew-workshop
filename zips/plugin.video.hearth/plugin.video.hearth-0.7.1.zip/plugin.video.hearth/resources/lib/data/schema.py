'''Schema migrations. Version 1 is the Milestone 1 model; version 2 adds a column.'''

from __future__ import annotations

SCHEMA_VERSION = 6

V1_STATEMENTS = (
    '''
    CREATE TABLE titles (
        id INTEGER PRIMARY KEY,
        media_type TEXT NOT NULL,
        imdb TEXT,
        tmdb TEXT,
        tvdb TEXT,
        trakt_id TEXT,
        title TEXT NOT NULL,
        original_title TEXT,
        year INTEGER,
        premiered TEXT,
        runtime_seconds INTEGER,
        mpaa TEXT,
        genres TEXT,
        plot TEXT,
        tagline TEXT,
        studio TEXT,
        status TEXT,
        art TEXT,
        added_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        nextup_hidden INTEGER NOT NULL DEFAULT 0,
        needs_fixup TEXT,
        rewatch_mode INTEGER NOT NULL DEFAULT 0,
        rewatch_from_season INTEGER,
        rewatch_from_episode INTEGER,
        watch_order TEXT NOT NULL DEFAULT 'aired',
        pinned_season INTEGER,
        pinned_episode INTEGER
    )
    ''',
    'CREATE INDEX idx_titles_imdb ON titles(imdb)',
    'CREATE INDEX idx_titles_tmdb ON titles(tmdb)',
    'CREATE INDEX idx_titles_trakt ON titles(trakt_id)',
    '''
    CREATE TABLE episodes (
        id INTEGER PRIMARY KEY,
        show_id INTEGER NOT NULL REFERENCES titles(id),
        season INTEGER NOT NULL,
        episode INTEGER NOT NULL,
        title TEXT,
        first_aired TEXT,
        runtime_seconds INTEGER,
        plot TEXT,
        tvdb TEXT,
        tmdb TEXT,
        imdb TEXT,
        trakt_id TEXT,
        art TEXT,
        UNIQUE (show_id, season, episode)
    )
    ''',
    'CREATE INDEX idx_episodes_show ON episodes(show_id)',
    '''
    CREATE TABLE watch_state (
        id INTEGER PRIMARY KEY,
        title_id INTEGER,
        episode_id INTEGER,
        play_count INTEGER NOT NULL DEFAULT 0,
        resume_seconds REAL,
        runtime_seconds REAL,
        last_played TEXT,
        rewatch_mode INTEGER NOT NULL DEFAULT 0,
        rewatch_from_season INTEGER,
        rewatch_from_episode INTEGER,
        watch_order TEXT NOT NULL DEFAULT 'aired',
        source TEXT,
        updated_at TEXT
    )
    ''',
    'CREATE UNIQUE INDEX ux_watch ON watch_state(title_id, IFNULL(episode_id, 0))',
    '''
    CREATE TABLE ratings (
        id INTEGER PRIMARY KEY,
        title_id INTEGER,
        episode_id INTEGER,
        score INTEGER,
        liked TEXT,
        disliked TEXT,
        tags TEXT,
        rated_at TEXT,
        source TEXT,
        updated_at TEXT
    )
    ''',
    'CREATE UNIQUE INDEX ux_rating ON ratings(title_id, IFNULL(episode_id, 0))',
    '''
    CREATE TABLE lists (
        id INTEGER PRIMARY KEY,
        slug TEXT NOT NULL UNIQUE,
        name TEXT NOT NULL,
        kind TEXT NOT NULL,
        media_filter TEXT NOT NULL,
        sort_default TEXT,
        is_system INTEGER NOT NULL DEFAULT 0,
        show_in_menu INTEGER NOT NULL DEFAULT 1,
        publish_as_channel INTEGER NOT NULL DEFAULT 0,
        import_plugin_path TEXT,
        import_mode TEXT,
        import_label TEXT,
        import_art TEXT,
        last_built_at TEXT
    )
    ''',
    '''
    CREATE TABLE list_items (
        id INTEGER PRIMARY KEY,
        list_id INTEGER NOT NULL REFERENCES lists(id),
        title_id INTEGER,
        episode_id INTEGER,
        position INTEGER NOT NULL,
        reason TEXT,
        graduated_from_list_id INTEGER
    )
    ''',
    '''
    CREATE UNIQUE INDEX ux_list_item
    ON list_items(list_id, IFNULL(title_id, 0), IFNULL(episode_id, 0))
    ''',
    'CREATE INDEX idx_list_items_list ON list_items(list_id)',
    '''
    CREATE TABLE sync_journal (
        id INTEGER PRIMARY KEY,
        created_at TEXT NOT NULL,
        kind TEXT NOT NULL,
        payload TEXT NOT NULL,
        dedupe_key TEXT NOT NULL UNIQUE,
        adapter TEXT,
        state TEXT NOT NULL,
        remote_id TEXT,
        last_error TEXT,
        pushed_at TEXT
    )
    ''',
    '''
    CREATE TABLE network_events (
        id INTEGER PRIMARY KEY,
        timestamp TEXT NOT NULL,
        purpose TEXT,
        method TEXT,
        host TEXT,
        path TEXT,
        allowed INTEGER NOT NULL,
        item_id TEXT
    )
    ''',
    '''
    CREATE TABLE meta (
        key TEXT PRIMARY KEY,
        value TEXT
    )
    '''
)


def current_version(conn):
    row = conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name='schema_version'"
    ).fetchone()
    if row is None:
        return 0
    found = conn.execute('SELECT version FROM schema_version WHERE id = 1').fetchone()
    if found is None:
        return 0
    return int(found[0])


def _set_version(conn, version):
    conn.execute(
        '''
        CREATE TABLE IF NOT EXISTS schema_version (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            version INTEGER NOT NULL
        )
        '''
    )
    conn.execute(
        '''
        INSERT INTO schema_version (id, version) VALUES (1, ?)
        ON CONFLICT(id) DO UPDATE SET version = excluded.version
        ''',
        (version,)
    )


def apply_v1(conn):
    for statement in V1_STATEMENTS:
        conn.execute(statement)
    _set_version(conn, 1)


def apply_v2(conn):
    columns = {row[1] for row in conn.execute('PRAGMA table_info(titles)').fetchall()}
    if 'original_language' not in columns:
        conn.execute('ALTER TABLE titles ADD COLUMN original_language TEXT')
    _set_version(conn, 2)


def apply_v3(conn):
    '''Season ratings sit beside movie and show ratings.'''
    columns = {row[1] for row in conn.execute('PRAGMA table_info(ratings)').fetchall()}
    if 'season' not in columns:
        conn.execute('ALTER TABLE ratings ADD COLUMN season INTEGER')
    conn.execute('DROP INDEX IF EXISTS ux_rating')
    conn.execute(
        '''
        CREATE UNIQUE INDEX IF NOT EXISTS ux_rating_unit
        ON ratings(title_id, IFNULL(episode_id, 0), IFNULL(season, -1))
        '''
    )
    _set_version(conn, 3)


def apply_v4(conn):
    '''One row per play, so a mirror push can send every watched_at.'''
    conn.execute(
        '''
        CREATE TABLE IF NOT EXISTS play_events (
            id INTEGER PRIMARY KEY,
            title_id INTEGER NOT NULL,
            episode_id INTEGER,
            watched_at TEXT NOT NULL
        )
        '''
    )
    conn.execute(
        '''
        CREATE UNIQUE INDEX IF NOT EXISTS ux_play_event
        ON play_events(title_id, IFNULL(episode_id, 0), watched_at)
        '''
    )
    _set_version(conn, 4)


def apply_v5(conn):
    '''Per-show Next Up mode. Existing shows stay Normal.

    rewatch_mode and watch_order stay on the row. Normal mode ignores them
    and uses the latest last_played episode instead.
    '''
    columns = {row[1] for row in conn.execute('PRAGMA table_info(titles)').fetchall()}
    if 'nextup_mode' not in columns:
        conn.execute(
            "ALTER TABLE titles ADD COLUMN nextup_mode TEXT NOT NULL DEFAULT 'normal'"
        )
    conn.execute(
        "UPDATE titles SET nextup_mode = 'normal' WHERE nextup_mode IS NULL OR nextup_mode = ''"
    )
    _set_version(conn, 5)


def apply_v6(conn):
    '''Notes on a rating, recommendation detail, and the taste journal.'''
    columns = {row[1] for row in conn.execute('PRAGMA table_info(ratings)').fetchall()}
    if 'thoughts' not in columns:
        conn.execute('ALTER TABLE ratings ADD COLUMN thoughts TEXT')
    if 'unfinished' not in columns:
        conn.execute('ALTER TABLE ratings ADD COLUMN unfinished INTEGER NOT NULL DEFAULT 0')
    if 'never_ask' not in columns:
        conn.execute('ALTER TABLE ratings ADD COLUMN never_ask INTEGER NOT NULL DEFAULT 0')
    item_columns = {row[1] for row in conn.execute('PRAGMA table_info(list_items)').fetchall()}
    if 'detail' not in item_columns:
        conn.execute('ALTER TABLE list_items ADD COLUMN detail TEXT')
    conn.execute(
        '''
        CREATE TABLE IF NOT EXISTS taste_journal (
            id INTEGER PRIMARY KEY,
            created_at TEXT NOT NULL,
            title_id INTEGER,
            episode_id INTEGER,
            season INTEGER,
            score INTEGER,
            source TEXT,
            liked TEXT,
            disliked TEXT,
            thoughts TEXT,
            note TEXT
        )
        '''
    )
    _set_version(conn, 6)


def migrate(conn, target=SCHEMA_VERSION):
    version = current_version(conn)
    if version < 1 and target >= 1:
        apply_v1(conn)
        version = 1
    if version < 2 and target >= 2:
        apply_v2(conn)
        version = 2
    if version < 3 and target >= 3:
        apply_v3(conn)
        version = 3
    if version < 4 and target >= 4:
        apply_v4(conn)
        version = 4
    if version < 5 and target >= 5:
        apply_v5(conn)
        version = 5
    if version < 6 and target >= 6:
        apply_v6(conn)
        version = 6
    return version
