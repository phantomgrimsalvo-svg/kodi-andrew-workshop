'''Walk watched titles that still have no rating.'''

from __future__ import annotations

from util import dumps, loads

CHOICES = (
    [str(number) for number in range(1, 11)]
    + ['Skip', "Didn't finish", 'Never ask again', 'Add notes']
)


def pending_titles(store, media='all', sort='recent'):
    skipped = set(str(item) for item in (loads(store.meta_get('rate_history_skipped'), []) or []))
    rows = []
    for title in store.all_titles():
        if media == 'movies' and title['media_type'] != 'movie':
            continue
        if media == 'shows' and title['media_type'] != 'show':
            continue
        if not _watched(store, title):
            continue
        if _closed(store, title['id']):
            continue
        if str(title['id']) in skipped:
            continue
        rows.append(title)
    if sort == 'watched':
        rows.sort(key=lambda title: (-_plays(store, title), title['title'] or ''))
    else:
        rows.sort(key=lambda title: (_recent(store, title), title['id']), reverse=True)
    return rows


def rate_history(store, settings, dialog, media='all', sort='recent'):
    '''One sitting. Skip is remembered. Cancel leaves the rest for next time.'''
    kept = pending_titles(store, media, sort)
    if not kept:
        skipped = loads(store.meta_get('rate_history_skipped'), []) or []
        if skipped:
            store.meta_set('rate_history_skipped', '[]')
            kept = pending_titles(store, media, sort)
    if not kept:
        return {'done': True, 'rated': 0, 'message': 'Nothing left to rate.'}
    rated = 0
    total = len(kept)
    index = 0
    while index < len(kept):
        title = kept[index]
        if hasattr(dialog, 'iscanceled') and dialog.iscanceled():
            break
        plot = title['plot'] or 'No plot stored yet.'
        heading = '%s (%s of %s)' % (title['title'], index + 1, total)
        if hasattr(dialog, 'text'):
            dialog.text(heading, plot)
        choice = dialog.select('Rate %s' % title['title'], list(CHOICES))
        if choice is None or choice < 0 or choice >= len(CHOICES):
            break
        label = CHOICES[choice]
        if label == 'Skip':
            _skip(store, title['id'])
            index += 1
            continue
        if label == 'Add notes':
            _save_notes(store, title, _ask_notes(dialog, title['title']))
            continue
        if label == "Didn't finish":
            store.save_rating(
                title['id'], None, source='local', unfinished=True,
                note="Didn't finish"
            )
            index += 1
            continue
        if label == 'Never ask again':
            store.save_rating(
                title['id'], None, source='local', never_ask=True,
                note='Never ask again'
            )
            index += 1
            continue
        score = int(label)
        notes = _existing_notes(store, title['id'])
        store.save_rating(
            title['id'], score, source='local',
            liked=notes.get('liked') or '',
            disliked=notes.get('disliked') or '',
            thoughts=notes.get('thoughts') or ''
        )
        _maybe_push(store, settings, title, score)
        rated += 1
        index += 1
    from recs.profile import export_text_files
    export_text_files(store)
    return {'done': index >= len(kept), 'rated': rated, 'left': max(0, len(kept) - index)}


def rate_history_kodi(store, settings):
    import xbmcgui
    dialog = xbmcgui.Dialog()
    if not pending_titles(store, 'all', 'recent') and not (
        loads(store.meta_get('rate_history_skipped'), []) or []
    ):
        dialog.ok('Rate my history', 'Nothing left to rate. Watched titles with no rating show up here.')
        return {'done': True, 'rated': 0}

    class Adapter:
        def text(self, heading, body):
            dialog.textviewer(heading, (body or '')[:4000])

        def select(self, heading, choices):
            return dialog.select(heading, choices)

        def input(self, heading, default=''):
            typed = dialog.input(heading, default=default or '')
            return typed or ''

        def iscanceled(self):
            return False

    media_index = dialog.select(
        'Rate my history', ['Movies', 'Shows', 'Movies and shows']
    )
    if media_index is None or media_index < 0:
        return {'done': False, 'rated': 0}
    media = ('movies', 'shows', 'all')[media_index]
    sort_index = dialog.select('Sort', ['Most recent', 'Most watched'])
    if sort_index is None or sort_index < 0:
        return {'done': False, 'rated': 0}
    sort = 'recent' if sort_index == 0 else 'watched'
    store.meta_set('rate_history_media', media)
    store.meta_set('rate_history_sort', sort)
    return rate_history(store, settings, Adapter(), media, sort)


def _ask_notes(dialog, title):
    return {
        'liked': dialog.input('What did you like about %s?' % title) or '',
        'disliked': dialog.input('What did you dislike about %s?' % title) or '',
        'thoughts': dialog.input('Any other thoughts on %s?' % title) or ''
    }


def _save_notes(store, title, notes):
    current = store.get_rating(title['id'])
    score = current['score'] if current is not None else None
    store.save_rating(
        title['id'], score, source='local',
        liked=notes.get('liked') or '',
        disliked=notes.get('disliked') or '',
        thoughts=notes.get('thoughts') or '',
        note='Notes'
    )


def _existing_notes(store, title_id):
    current = store.get_rating(title_id)
    if current is None:
        return {}
    return {
        'liked': current['liked'] or '',
        'disliked': current['disliked'] or '',
        'thoughts': current['thoughts'] or ''
    }


def _skip(store, title_id):
    skipped = loads(store.meta_get('rate_history_skipped'), []) or []
    if title_id not in skipped and str(title_id) not in [str(item) for item in skipped]:
        skipped.append(title_id)
    store.meta_set('rate_history_skipped', dumps(skipped))


def _closed(store, title_id):
    rating = store.get_rating(title_id)
    if rating is None:
        return False
    if int(rating['never_ask'] or 0):
        return True
    if int(rating['unfinished'] or 0) and rating['score'] is None:
        return True
    return rating['score'] is not None


def _watched(store, title):
    if title['media_type'] == 'movie':
        watch = store.get_watch(title['id'], None)
        return watch is not None and (watch['play_count'] or 0) > 0
    for episode in store.episodes_for_show(title['id']):
        watch = store.get_watch(title['id'], episode['id'])
        if watch is not None and (watch['play_count'] or 0) > 0:
            return True
    return False


def _plays(store, title):
    if title['media_type'] == 'movie':
        watch = store.get_watch(title['id'], None)
        return int(watch['play_count'] or 0) if watch is not None else 0
    total = 0
    for episode in store.episodes_for_show(title['id']):
        watch = store.get_watch(title['id'], episode['id'])
        if watch is not None:
            total += int(watch['play_count'] or 0)
    return total


def _recent(store, title):
    stamps = []
    watch = store.get_watch(title['id'], None)
    if watch is not None and watch['last_played']:
        stamps.append(watch['last_played'])
    if title['media_type'] == 'show':
        for episode in store.episodes_for_show(title['id']):
            row = store.get_watch(title['id'], episode['id'])
            if row is not None and row['last_played']:
                stamps.append(row['last_played'])
    return max(stamps) if stamps else ''


def _maybe_push(store, settings, title, score):
    if settings is None or not settings.flag('tmdb_write_ratings', False):
        return
    try:
        from network.guard import active_guard
        from tmdb.account import push_rating
        push_rating(store, settings, active_guard(), title, score)
    except Exception:
        return
