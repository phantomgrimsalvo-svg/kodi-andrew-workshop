'''Rating prompts fire only when a whole movie, season, or show is finished.'''

from __future__ import annotations

from nextup.algorithm import fraction

CHIPS = (
    'tone', 'characters', 'pacing', 'ending', 'humor', 'craft',
    'politics', 'romance', 'horror-style', 'comfort/rewatch'
)


def _watched(watch, runtime, threshold):
    if watch is None:
        return False
    total = watch['runtime_seconds'] or runtime or 0
    pct = fraction(watch['resume_seconds'], total)
    if 0.02 <= pct < threshold:
        return False
    if (watch['play_count'] or 0) > 0:
        return True
    return total and pct >= threshold


def prompts_for_completion(store, title_id, episode_id=None, threshold=0.85, settings=None):
    '''Return the prompts to show after a unit just became watched.

    Movies prompt once. Episodes never prompt by themselves. A finished
    season prompts for that season. Finishing the show prompts for the show.
    A one-season show asks for both scores in a single prompt.
    '''
    if settings is not None and (settings.get('recs_ask_level') or 'notes') == 'off':
        return []
    title = store.get_title(title_id)
    if title is None:
        return []
    if title['media_type'] == 'movie':
        if store.get_rating(title_id) is not None:
            return []
        return [{
            'unit': 'movie',
            'title_id': title_id,
            'title': title['title'],
            'season': None
        }]
    if not episode_id:
        return []
    episode = store.get_episode(episode_id)
    if episode is None or int(episode['season']) == 0:
        return []
    season = int(episode['season'])
    if not _season_complete(store, title_id, season, threshold):
        return []
    regulars = _regular_seasons(store, title_id)
    show_done = all(
        _season_complete(store, title_id, number, threshold) for number in regulars
    )
    season_rated = store.get_rating(title_id, season=season) is not None
    show_rated = store.get_rating(title_id) is not None
    if len(regulars) == 1 and show_done and not season_rated and not show_rated:
        return [{
            'unit': 'season_and_show',
            'title_id': title_id,
            'title': title['title'],
            'season': season
        }]
    prompts = []
    if not season_rated:
        prompts.append({
            'unit': 'season',
            'title_id': title_id,
            'title': title['title'],
            'season': season
        })
    if show_done and not show_rated:
        prompts.append({
            'unit': 'show',
            'title_id': title_id,
            'title': title['title'],
            'season': None
        })
    return prompts


def save_prompt_result(store, settings, prompt, result):
    '''Persist one dialog result. Skip stores nothing. Mirror queues an outbox row.'''
    if not result or result.get('skipped'):
        return {'saved': []}
    saved = []
    liked = result.get('liked') or ''
    disliked = result.get('disliked') or ''
    thoughts = result.get('thoughts') or ''
    tags = result.get('tags') or []
    if prompt['unit'] == 'season_and_show':
        if result.get('season_score'):
            _save_one(
                store, settings, prompt, result['season_score'],
                liked, disliked, tags, season=prompt['season'], thoughts=thoughts
            )
            saved.append('season')
        if result.get('show_score'):
            _save_one(
                store, settings, prompt, result['show_score'],
                liked, disliked, tags, season=None, thoughts=thoughts
            )
            saved.append('show')
        return {'saved': saved}
    if not result.get('score'):
        return {'saved': []}
    _save_one(
        store, settings, prompt, result['score'], liked, disliked, tags,
        season=prompt.get('season'), thoughts=thoughts
    )
    return {'saved': [prompt['unit']]}


def _save_one(store, settings, prompt, score, liked, disliked, tags, season, thoughts=''):
    store.save_rating(
        prompt['title_id'], int(score), liked=liked, disliked=disliked,
        thoughts=thoughts, tags=tags, season=season, source='local'
    )
    if not settings.mirror_enabled():
        return
    title = store.get_title(prompt['title_id'])
    unit = 'season:%s' % season if season is not None else prompt['unit']
    store.enqueue_outbox('rating', {
        'title_id': prompt['title_id'],
        'title': prompt.get('title'),
        'media_type': 'show' if season is not None or prompt['unit'] != 'movie' else 'movie',
        'unit': prompt['unit'],
        'season': season,
        'score': int(score),
        'liked': liked,
        'disliked': disliked,
        'thoughts': thoughts,
        'tags': tags,
        'ids': {
            'imdb': title['imdb'] if title is not None else None,
            'tmdb': title['tmdb'] if title is not None else None,
            'tvdb': title['tvdb'] if title is not None else None,
            'trakt': title['trakt_id'] if title is not None else None
        }
    }, 'rating:%s:%s' % (prompt['title_id'], unit), settings.get('cloud_mirror'))


def _regular_seasons(store, show_id):
    seasons = sorted({
        int(episode['season'])
        for episode in store.episodes_for_show(show_id)
        if int(episode['season']) != 0
    })
    return seasons


def _season_complete(store, show_id, season, threshold):
    episodes = [
        episode for episode in store.episodes_for_show(show_id)
        if int(episode['season']) == int(season)
    ]
    if not episodes:
        return False
    for episode in episodes:
        watch = store.get_watch(show_id, episode['id'])
        if not _watched(watch, episode['runtime_seconds'], threshold):
            return False
    return True


class ScoreDialog:
    '''Small dialog protocol. Kodi and tests both implement select/input.'''

    def select(self, heading, choices):
        raise NotImplementedError

    def input(self, heading, default=''):
        raise NotImplementedError

    def multiselect(self, heading, choices):
        raise NotImplementedError


def run_prompt(dialog, prompt, ask='notes'):
    '''Rating first. Notes follow unless the ask level is rating-only or off.'''
    level = (ask or 'notes').strip().lower()
    if level == 'off':
        return {'skipped': True}
    if prompt['unit'] == 'season_and_show':
        season_score = _pick_score(dialog, 'Rate season %s of %s' % (
            prompt['season'], prompt['title']
        ))
        show_score = _pick_score(dialog, 'Rate the show %s' % prompt['title'])
        if season_score is None and show_score is None:
            return {'skipped': True}
        notes = {} if level == 'rating' else _notes(dialog, prompt['title'])
        return {
            'skipped': False,
            'season_score': season_score,
            'show_score': show_score,
            **notes
        }
    heading = {
        'movie': 'Rate %s' % prompt['title'],
        'show': 'Rate the show %s' % prompt['title'],
        'season': 'Rate season %s of %s' % (prompt.get('season'), prompt['title'])
    }.get(prompt['unit'], 'Rate %s' % prompt['title'])
    score = _pick_score(dialog, heading)
    if score is None:
        return {'skipped': True}
    if level == 'rating':
        return {
            'skipped': False, 'score': score,
            'liked': '', 'disliked': '', 'thoughts': '', 'tags': []
        }
    notes = _notes(dialog, prompt['title'])
    return {'skipped': False, 'score': score, **notes}


def _pick_score(dialog, heading):
    choices = ['Skip'] + [str(number) for number in range(1, 11)]
    index = dialog.select(heading, choices)
    if index is None or index <= 0:
        return None
    return index


def _notes(dialog, title):
    liked = dialog.input('What did you like about %s?' % title) or ''
    disliked = dialog.input('What did you dislike about %s?' % title) or ''
    thoughts = dialog.input('Any thoughts on %s?' % title) or ''
    picked = dialog.multiselect('Quick tags', list(CHIPS)) or []
    tags = [CHIPS[index] for index in picked if 0 <= index < len(CHIPS)]
    return {'liked': liked, 'disliked': disliked, 'thoughts': thoughts, 'tags': tags}
