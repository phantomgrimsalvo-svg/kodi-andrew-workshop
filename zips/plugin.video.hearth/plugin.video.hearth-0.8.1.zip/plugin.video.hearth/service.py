'''Hearth service: local player monitor and the weekly file backup.

One process. The backup uses no network. Cloud mirrors and recommendations
are later milestones and are not scheduled here.
'''

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / 'resources' / 'lib'))

import xbmc

from backup.local import run_scheduled_backup
from data.store import open_store
from network.guard import install_runtime_patches
from paths import art_dir, db_path, default_backup_dir
from player.monitor import SAMPLE_SECONDS, HearthMonitor
from settings import load_kodi_settings
from util import iso


class HearthPlayer(xbmc.Player):
    def __init__(self, hearth):
        super().__init__()
        self.hearth = hearth

    def onAVStarted(self):
        self.hearth.on_av_started()
        self._sample('start')

    def onPlayBackPaused(self):
        self._sample('progress')

    def onPlayBackSeek(self, time, seekOffset):
        self._sample('progress', fallback_position=time)

    def onPlayBackStopped(self):
        self._finish('stop')

    def onPlayBackEnded(self):
        self._finish('end')

    def _sample(self, event, fallback_position=None):
        position = None
        runtime = None
        try:
            position = self.getTime()
            runtime = self.getTotalTime()
        except Exception:
            position = fallback_position
        if position is None:
            return
        self.hearth.remember(position, runtime, position)
        result = self.hearth.on_progress(position, runtime or 0, position, event=event)
        if result and result.get('rating_prompts'):
            _show_ratings(self.hearth.store, self.hearth.settings, result['rating_prompts'])

    def _finish(self, event):
        result = self.hearth.finish(event)
        if result and result.get('rating_prompts'):
            _show_ratings(self.hearth.store, self.hearth.settings, result['rating_prompts'])
        self.hearth.clear_session()


def main():
    import time
    from service_run import ServiceRun, request_stop, reset_stop, run_until_abort
    reset_stop()
    install_runtime_patches()
    settings = load_kodi_settings()
    store = open_store(db_path())
    store.ensure_system_lists()
    settings.store = store
    if store.meta_get('wizard_done') != 'true' and not _abort_requested():
        from wizard import run_wizard
        run_wizard(store, settings)
    hearth = HearthMonitor(store, settings)
    HearthPlayer(hearth)
    _start_channel_server(settings)
    workers = ServiceRun()
    workers.start('hearth-artwork', lambda stop: _artwork_loop(store, settings, stop))
    workers.start('hearth-maintenance', lambda stop: _maintenance_loop(store, settings, stop))
    monitor = xbmc.Monitor()
    quiet_ticks = 0
    maintenance_every = max(1, 900 // SAMPLE_SECONDS)
    shutdown_at = None
    try:
        def tick():
            nonlocal quiet_ticks
            quiet_ticks = service_tick(store, settings, hearth, quiet_ticks, maintenance_every)

        run_until_abort(monitor, tick, wait_seconds=1)
    finally:
        shutdown_at = time.monotonic()
        request_stop()
        from channels.server import stop_server
        stop_server()
        workers.join(0.4)
        try:
            store.close()
        except Exception:
            pass
        elapsed = int((time.monotonic() - shutdown_at) * 1000)
        try:
            xbmc.log('Hearth service stopped in %dms' % elapsed, xbmc.LOGINFO)
        except Exception:
            pass


def _start_channel_server(settings):
    try:
        from channels.server import ensure_server
        ensure_server(settings)
    except Exception:
        return None


def _artwork_loop(store, settings, stop):
    from art.backfill import backfill_batch
    from network.guard import active_guard, transport_timeout
    while not stop.is_set():
        if (settings.get('tmdb_api_key') or '').strip():
            try:
                with transport_timeout(3):
                    backfill_batch(
                        store, settings, active_guard(), limit=1, abort=stop.is_set
                    )
            except Exception:
                pass
        if stop.wait(2):
            return


def _maintenance_loop(store, settings, stop):
    from network.guard import transport_timeout
    first = True
    while not stop.is_set():
        try:
            with transport_timeout(3):
                if first:
                    _refresh_live_channels(store, settings, force=True, stop=stop)
                    first = False
                if stop.is_set():
                    return
                _maintenance(store, settings, stop)
        except Exception:
            pass
        if stop.wait(30):
            return


def _refresh_live_channels(store, settings, force, stop=None):
    if stop is not None and stop.is_set():
        return False
    if not settings.flag('channels_enabled', False):
        return False
    try:
        from channels.live import kodi_directory, refresh_published

        def lister(path):
            return kodi_directory(path, stop=stop)

        return refresh_published(store, settings, lister, iso(), force=force)
    except Exception:
        return False


def _show_ratings(store, settings, prompts):
    if _abort_requested() or not prompts:
        return
    from ratings.finish import prompt_finished
    seen = set()
    for prompt in prompts:
        title_id = prompt.get('title_id')
        if title_id in seen:
            continue
        seen.add(title_id)
        if _abort_requested():
            return
        try:
            prompt_finished(store, settings, store.get_title(title_id))
        except Exception as exc:
            from kodi_dialog import _failed
            _failed(exc)


def _abort_requested():
    try:
        import xbmc
        return bool(xbmc.Monitor().abortRequested())
    except Exception:
        return False


def service_tick(store, settings, hearth, quiet_ticks, maintenance_every):
    '''One wake of the service. A failure is recorded and the loop keeps going.'''
    if _abort_requested():
        return quiet_ticks
    try:
        hearth.sample_playback()
        if _abort_requested():
            return quiet_ticks
        quiet_ticks += 1
        if quiet_ticks < maintenance_every:
            return quiet_ticks
        quiet_ticks = 0
        _maintenance(store, settings)
    except Exception as exc:
        from util import redact
        try:
            store.meta_set('last_error', redact(str(exc))[:300])
        except Exception:
            return quiet_ticks
    return quiet_ticks


def _maintenance(store, settings, stop=None):
    if stop is not None and stop.is_set():
        return
    folder = settings.get('backup_folder') or str(default_backup_dir())
    run_scheduled_backup(store, settings, folder, art_dir(), iso())
    if stop is not None and stop.is_set():
        return
    if stop is not None and stop.is_set():
        return
    if settings.flag('channels_enabled', False):
        from channels.export import export_channels
        from paths import channels_export_path
        _refresh_live_channels(store, settings, force=False, stop=stop)
        if stop is None or not stop.is_set():
            export_channels(store, settings, channels_export_path())
    if stop is not None and stop.is_set():
        return
    _brain_maintenance(store, settings, stop)
    if settings.mirror_enabled():
        from mirrors.push import push_outbox
        from network.guard import active_guard as mirror_guard
        try:
            push_outbox(store, settings, mirror_guard())
        except Exception as exc:
            from util import redact
            store.meta_set('last_error', redact(str(exc))[:300])


def _brain_maintenance(store, settings, stop):
    if stop is not None and stop.is_set():
        return
    try:
        from brain.wanted import refresh_wanted
        refresh_wanted(store, settings)
    except Exception:
        return


if __name__ == '__main__':
    main()
