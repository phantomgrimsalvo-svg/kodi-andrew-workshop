'''Guided history fix-up. Writes locally first. Outbox only if a mirror is on.'''

from __future__ import annotations

from util import iso

from nextup.algorithm import rebuild_derived


def describe_fixup(show_title, reasons):
    labels = {
        'multiple_partials': 'more than one episode is only partly watched',
        'earlier_season_gap': 'a later season has progress while an earlier season does not',
        'watched_after_gap': 'watched episodes sit after a gap of unwatched ones',
        'rewatch_like': 'play counts look like a rewatch rather than a first run'
    }
    bits = [labels.get(reason, reason) for reason in reasons]
    if not bits:
        detail = 'the history does not line up with aired order'
    else:
        detail = '; '.join(bits)
    return (
        '%s needs a quick history fix. Hearth saw that %s. '
        'It will not guess the next episode.'
    ) % (show_title, detail)


def preview_mark_before(episodes, season, episode, unwatch_after=False):
    '''episodes are plain rows with season, episode, play_count.'''
    ordered = sorted(episodes, key=lambda item: (item['season'], item['episode']))
    target = (int(season), int(episode))
    watched = 0
    unwatched = 0
    for item in ordered:
        if int(item['season']) == 0:
            continue
        key = (int(item['season']), int(item['episode']))
        if key < target and (item.get('play_count') or 0) < 1:
            watched += 1
        if unwatch_after and key > target and (item.get('play_count') or 0) > 0:
            unwatched += 1
    return {
        'mark_watched': watched,
        'mark_unwatched': unwatched,
        'message': 'This will mark %d episode(s) watched and %d episode(s) unwatched.' % (
            watched, unwatched
        )
    }


def apply_fixup(store, settings, show_id, action, season, episode,
                confirm_unwatch=False, now=None):
    now = now or iso()
    title = store.get_title(show_id)
    if title is None:
        raise KeyError(show_id)
    episodes = [
        ep for ep in store.episodes_for_show(show_id) if int(ep['season']) != 0
    ]
    target = (int(season), int(episode))
    mirror = settings.mirror_enabled()
    adapter = settings.get('cloud_mirror')
    changed = {'watched': [], 'unwatched': [], 'action': action}

    if action == 'skip':
        store.update_title_fields(show_id, nextup_hidden=1, needs_fixup=None)
        rebuild_derived(store, settings)
        return changed

    if action == 'rewatch':
        store.update_title_fields(
            show_id,
            rewatch_mode=1,
            rewatch_from_season=target[0],
            rewatch_from_episode=target[1],
            watch_order='rewatch',
            needs_fixup=None,
            pinned_season=None,
            pinned_episode=None,
            nextup_hidden=0
        )
        _stamp_show_watch(store, show_id, episodes, rewatch=target, now=now)
        rebuild_derived(store, settings)
        return changed

    if action == 'out_of_order':
        store.update_title_fields(
            show_id,
            watch_order='out_of_order',
            pinned_season=target[0],
            pinned_episode=target[1],
            needs_fixup=None,
            nextup_hidden=0,
            nextup_mode='normal'
        )
        _stamp_anchor(store, show_id, episodes, target, now)
        rebuild_derived(store, settings)
        return changed

    if action not in ('on_episode', 'mark_before'):
        raise ValueError('unknown fix-up action %s' % action)

    for ep in episodes:
        key = (int(ep['season']), int(ep['episode']))
        watch = store.get_watch(show_id, ep['id'])
        play_count = int(watch['play_count']) if watch is not None else 0
        resume = float(watch['resume_seconds'] or 0) if watch is not None else 0
        runtime = None
        if watch is not None and watch['runtime_seconds']:
            runtime = watch['runtime_seconds']
        elif ep['runtime_seconds']:
            runtime = ep['runtime_seconds']
        if key < target:
            if play_count < 1:
                store.set_watch(
                    show_id, ep['id'],
                    play_count=1,
                    resume_seconds=0,
                    runtime_seconds=runtime,
                    last_played=watch['last_played'] if watch is not None else now,
                    source='fixup',
                    watch_order='aired',
                    updated_at=now
                )
                changed['watched'].append(ep['id'])
                _queue_history(
                    store, mirror, adapter, 'history_add', title, ep, now
                )
        elif key == target:
            store.set_watch(
                show_id, ep['id'],
                play_count=play_count,
                resume_seconds=resume,
                runtime_seconds=runtime,
                last_played=now,
                source='fixup',
                watch_order='aired',
                updated_at=now
            )
        elif confirm_unwatch and play_count > 0:
            store.set_watch(
                show_id, ep['id'],
                play_count=0,
                resume_seconds=0,
                runtime_seconds=runtime,
                source='fixup',
                watch_order='aired',
                updated_at=now
            )
            changed['unwatched'].append(ep['id'])
            _queue_history(
                store, mirror, adapter, 'history_remove', title, ep, now
            )
    store.update_title_fields(
        show_id,
        needs_fixup=None,
        watch_order='aired',
        pinned_season=None,
        pinned_episode=None,
        rewatch_mode=0,
        nextup_hidden=0
    )
    rebuild_derived(store, settings)
    return changed


def _stamp_anchor(store, show_id, episodes, target, now):
    '''Make this episode the latest play without inventing a play count.'''
    for ep in episodes:
        if (int(ep['season']), int(ep['episode'])) != target:
            continue
        watch = store.get_watch(show_id, ep['id'])
        play_count = int(watch['play_count']) if watch is not None else 0
        resume = float(watch['resume_seconds'] or 0) if watch is not None else 0
        runtime = None
        if watch is not None and watch['runtime_seconds']:
            runtime = watch['runtime_seconds']
        elif ep['runtime_seconds']:
            runtime = ep['runtime_seconds']
        store.set_watch(
            show_id, ep['id'],
            play_count=play_count,
            resume_seconds=resume,
            runtime_seconds=runtime,
            last_played=now,
            source='manual',
            updated_at=now
        )
        return


def _stamp_show_watch(store, show_id, episodes, rewatch, now):
    for ep in episodes:
        watch = store.get_watch(show_id, ep['id'])
        if watch is None:
            continue
        store.set_watch(
            show_id, ep['id'],
            rewatch_mode=1,
            rewatch_from_season=rewatch[0],
            rewatch_from_episode=rewatch[1],
            watch_order='rewatch',
            updated_at=now
        )


def _queue_history(store, mirror, adapter, kind, title, episode, watched_at):
    if not mirror:
        return
    imdb = episode['imdb'] or title['imdb'] or ''
    dedupe = '%s:episode:%s:s%se%s:%s' % (
        kind, imdb or title['id'], episode['season'], episode['episode'], watched_at
    )
    store.enqueue_outbox(kind, {
        'show': {'title': title['title'], 'ids': _ids(title)},
        'episode': {
            'season': episode['season'],
            'number': episode['episode'],
            'title': episode['title'],
            'ids': _ids(episode)
        },
        'watched_at': watched_at
    }, dedupe, adapter)


def _ids(row):
    return {
        'trakt': row['trakt_id'],
        'imdb': row['imdb'],
        'tmdb': row['tmdb'],
        'tvdb': row['tvdb']
    }
