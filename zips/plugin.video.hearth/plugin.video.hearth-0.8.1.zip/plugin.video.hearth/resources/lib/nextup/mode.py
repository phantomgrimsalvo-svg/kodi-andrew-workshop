'''Per-show Next Up mode. Tracking is unchanged; only the tile changes.'''

from __future__ import annotations

from util import iso

from nextup.algorithm import rebuild_derived

MODES = ('normal', 'random', 'pick')


def set_nextup_mode(store, settings, show_id, mode):
    if mode not in MODES:
        raise ValueError('unknown Next Up mode %s' % mode)
    if store.get_title(show_id) is None:
        raise KeyError(show_id)
    store.update_title_fields(show_id, nextup_mode=mode, nextup_hidden=0, needs_fixup=None)
    return rebuild_derived(store, settings)


def set_place(store, settings, show_id, season, episode, now=None):
    '''Stamp this episode as the latest play, then rebuild Normal Next Up.'''
    now = now or iso()
    match = None
    for row in store.episodes_for_show(show_id):
        if int(row['season']) == int(season) and int(row['episode']) == int(episode):
            match = row
            break
    if match is None:
        raise KeyError('episode')
    watch = store.get_watch(show_id, match['id'])
    play_count = int(watch['play_count']) if watch is not None else 0
    resume = float(watch['resume_seconds'] or 0) if watch is not None else 0
    runtime = None
    if watch is not None and watch['runtime_seconds']:
        runtime = watch['runtime_seconds']
    elif match['runtime_seconds']:
        runtime = match['runtime_seconds']
    store.set_watch(
        show_id, match['id'],
        play_count=play_count,
        resume_seconds=resume,
        runtime_seconds=runtime,
        last_played=now,
        source='manual',
        updated_at=now
    )
    store.update_title_fields(
        show_id,
        nextup_mode='normal',
        pinned_season=int(season),
        pinned_episode=int(episode),
        nextup_hidden=0,
        needs_fixup=None
    )
    return rebuild_derived(store, settings)
