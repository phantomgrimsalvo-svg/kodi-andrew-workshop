'''Next Up ordering and the history fix-up.'''
