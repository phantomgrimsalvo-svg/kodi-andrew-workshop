'''Versioned folder: SQLite snapshot + JSON + art, with rotation and restore.'''

from __future__ import annotations

import hashlib
import json
import shutil
import sqlite3
from pathlib import Path

from data.schema import SCHEMA_VERSION
from data.store import Store, close_store
from util import iso


class ConfirmationRequired(Exception):
    pass


class BackupError(Exception):
    pass


def backup_now(store, settings, destination, art_dir=None, include_art=None,
               keep=None, when=None):
    when = when or iso()
    include = settings.flag('include_artwork', True) if include_art is None else include_art
    keep_n = settings.integer('backup_keep', 4) if keep is None else int(keep)
    stamp = when[0:4] + when[5:7] + when[8:10] + '-' + when[11:13] + when[14:16]
    root = Path(destination)
    root.mkdir(parents=True, exist_ok=True)
    folder = root / ('hearth-%s' % stamp)
    suffix = 2
    while folder.exists():
        folder = root / ('hearth-%s-%d' % (stamp, suffix))
        suffix += 1
    folder.mkdir(parents=True)
    db_file = folder / 'hearth.db'
    store.snapshot_to(db_file)
    document = store.export_document(settings)
    json_file = folder / 'hearth.json'
    json_file.write_text(
        json.dumps(document, indent=2, sort_keys=True), encoding='utf-8'
    )
    files = ['hearth.db', 'hearth.json']
    if include and art_dir and Path(art_dir).exists():
        shutil.copytree(art_dir, folder / 'art', dirs_exist_ok=True)
        files.append('art/')
    manifest = {
        'created_at': when,
        'schema_version': SCHEMA_VERSION,
        'addon': 'plugin.video.hearth',
        'files': files,
        'checksums': {
            'hearth.db': _sha256(db_file),
            'hearth.json': _sha256(json_file)
        }
    }
    (folder / 'manifest.json').write_text(
        json.dumps(manifest, indent=2, sort_keys=True), encoding='utf-8'
    )
    store.meta_set('last_local_backup_at', when)
    removed = rotate(root, keep_n)
    return {'folder': str(folder), 'removed': removed, 'files': files}


def list_versions(folder):
    folder = Path(folder)
    if not folder.exists():
        return []
    if _is_version(folder):
        return [folder]
    found = []
    for child in folder.iterdir():
        if child.is_dir() and _is_version(child):
            found.append(child)
    return sorted(found, key=lambda item: item.name)


def restore_backup(db_path, art_dir, chosen, version=None, confirm=False):
    if not confirm:
        raise ConfirmationRequired(
            'Restore replaces the current Hearth library, watch history, and artwork.'
        )
    chosen = Path(chosen)
    versions = list_versions(chosen)
    if not versions:
        raise BackupError('That folder has no Hearth backup Hearth can restore.')
    if len(versions) == 1:
        target = versions[0]
    else:
        if not version:
            names = [item.name for item in versions]
            raise BackupError('Choose a version: ' + ', '.join(names))
        target = next((item for item in versions if item.name == version), None)
        if target is None:
            raise BackupError('No backup named %s in that folder.' % version)
    manifest_path = target / 'manifest.json'
    if not manifest_path.exists() or not (target / 'hearth.db').exists():
        raise BackupError('This backup looks incomplete (missing manifest or database).')
    close_store(db_path)
    db_path = Path(db_path)
    for extra in (str(db_path) + '-wal', str(db_path) + '-shm'):
        extra_path = Path(extra)
        if extra_path.exists():
            extra_path.unlink()
    db_path.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(target / 'hearth.db', db_path)
    if art_dir is not None:
        art_dir = Path(art_dir)
        if art_dir.exists():
            shutil.rmtree(art_dir)
        source_art = target / 'art'
        if source_art.exists():
            shutil.copytree(source_art, art_dir)
        else:
            art_dir.mkdir(parents=True, exist_ok=True)
    # Touch the copy so SQLite can open it, then leave it for the caller.
    check = sqlite3.connect(str(db_path))
    try:
        row = check.execute('PRAGMA integrity_check').fetchone()
        if row[0] != 'ok':
            raise BackupError('Restored database failed integrity check.')
    finally:
        check.close()
    return {'folder': str(target), 'db': str(db_path)}


def rotate(folder, keep):
    versions = list_versions(folder)
    removed = []
    extra = versions[:-keep] if keep >= 0 else []
    if keep == 0:
        extra = versions
    for old in extra:
        shutil.rmtree(old)
        removed.append(old.name)
    return removed


def backup_is_due(last_iso, now_iso, interval_days):
    if not last_iso:
        return True
    from util import parse_iso
    last = parse_iso(last_iso)
    now = parse_iso(now_iso)
    if last is None or now is None:
        return True
    return (now - last).total_seconds() >= int(interval_days) * 86400


def run_scheduled_backup(store, settings, destination, art_dir, now_iso):
    '''One attempt. A failure is recorded once so the service does not spin.'''
    last = store.meta_get('last_local_backup_at')
    if not backup_is_due(last, now_iso, settings.integer('backup_interval_days', 7)):
        return {'ran': False}
    try:
        result = backup_now(
            store, settings, destination, art_dir=art_dir, when=now_iso
        )
        store.meta_set('last_error', '')
        store.meta_set('last_error_notified', '')
        result['ran'] = True
        return result
    except Exception as exc:
        from util import redact
        store.meta_set('last_error', redact(str(exc)))
        notified = store.meta_get('last_error_notified') or ''
        if not notified:
            store.meta_set('last_error_notified', now_iso)
            _notify_once('Hearth backup did not finish. Your library is unchanged.')
        return {'ran': False, 'error': True}


def _is_version(folder):
    return (folder / 'manifest.json').exists() and (folder / 'hearth.db').exists()


def _sha256(path):
    digest = hashlib.sha256()
    with open(path, 'rb') as handle:
        for chunk in iter(lambda: handle.read(65536), b''):
            digest.update(chunk)
    return digest.hexdigest()


def _notify_once(message):
    try:
        import xbmcgui
        xbmcgui.Dialog().notification('Hearth', message, sound=False)
    except Exception:
        return


def open_store_after_restore(db_path):
    return Store(db_path)
