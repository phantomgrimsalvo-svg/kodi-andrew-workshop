'''Local versioned backups. A backup never opens the network.'''
