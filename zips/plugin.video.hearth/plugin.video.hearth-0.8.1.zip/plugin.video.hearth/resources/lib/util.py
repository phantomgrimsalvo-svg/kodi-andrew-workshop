'''Small shared helpers. No network access lives here.'''

from __future__ import annotations

import json
import re
from datetime import datetime, timezone


SECRET_RE = re.compile(
    r'(?i)(api[_-]?key|client[_-]?secret|access[_-]?token|refresh[_-]?token|'
    r'authorization|device[_-]?code|password|bearer)\s*[:=]\s*\S+'
)
QUERY_SECRET_RE = re.compile(
    r'(?i)(api[_-]?key|client[_-]?secret|access[_-]?token|refresh[_-]?token|'
    r'code|token)=([^&\s]+)'
)


def utcnow():
    return datetime.now(timezone.utc).replace(microsecond=0)


def iso(moment=None):
    moment = moment or utcnow()
    if moment.tzinfo is None:
        moment = moment.replace(tzinfo=timezone.utc)
    return moment.astimezone(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')


def parse_iso(value):
    if not value:
        return None
    text = str(value).replace('Z', '+00:00')
    try:
        moment = datetime.fromisoformat(text)
    except ValueError:
        return None
    if moment.tzinfo is None:
        moment = moment.replace(tzinfo=timezone.utc)
    return moment.astimezone(timezone.utc)


def dumps(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), default=str)


def loads(value, default=None):
    if value in (None, ''):
        return default
    if isinstance(value, (dict, list)):
        return value
    try:
        return json.loads(value)
    except (TypeError, ValueError):
        return default


def redact(text):
    if text is None:
        return ''
    cleaned = SECRET_RE.sub(r'\1=[redacted]', str(text))
    return QUERY_SECRET_RE.sub(r'\1=[redacted]', cleaned)


def is_secret_key(key):
    lowered = (key or '').lower()
    needles = (
        'token', 'secret', 'api_key', 'apikey', 'authorization',
        'password', 'device_code', 'client_secret'
    )
    return any(needle in lowered for needle in needles)
