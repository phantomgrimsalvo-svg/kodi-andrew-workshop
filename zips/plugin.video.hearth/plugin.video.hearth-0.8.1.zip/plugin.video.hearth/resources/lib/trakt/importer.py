'''Pull Trakt once. Empty local rows are filled. Newer local state wins.'''

from __future__ import annotations

from util import iso

from nextup.algorithm import rebuild_derived

THRESHOLD_DEFAULT = 0.85
FLOOR = 0.02


def plan_import(client):
    '''Fetch and summarise. Does not write the database.'''
    payload = fetch_payload(client)
    return {
        'movies': len(payload['movies']),
        'shows': len(payload['shows']),
        'playback': len(payload['playback']),
        'ratings': len(payload['ratings']),
        'watchlist': len(payload['watchlist']),
        'favorites': len(payload['favorites']),
        'lists': len(payload['lists']),
        'note': (
            'Trakt drops old playback entries. This import stores what Trakt '
            'still has. It is not a complete history of every resume.'
        )
    }, payload


def import_trakt(store, settings, client, payload=None, now=None, on_stage=None):
    now = now or iso()
    store.ensure_system_lists()
    merge_duplicate_trakt_ids(store)
    if payload is None:
        payload = fetch_payload(client)
    threshold = settings.threshold if settings is not None else THRESHOLD_DEFAULT
    stats = {
        'titles': 0,
        'episodes': 0,
        'kept_local': 0,
        'ratings': 0,
        'watchlist': 0,
        'favorites': 0,
        'lists': 0
    }
    stages = (
        ('Watched movies', payload['movies'], _import_movie_watch),
        ('Watched shows', payload['shows'], _import_show_watch),
        ('History', payload['history'], _import_history),
        ('Playback', payload['playback'], None),
        ('Ratings', payload['ratings'], _import_rating),
        ('Watchlist', payload['watchlist'], None),
        ('Favorites', payload['favorites'], None),
        ('Lists', payload['lists'], _import_user_list),
    )
    total = len(stages)
    for index, (label, rows, writer) in enumerate(stages):
        if on_stage is not None:
            on_stage(index, total, label)
        if label == 'Playback':
            for entry in rows:
                _import_playback(store, entry, threshold, now, stats)
        elif label == 'Watchlist':
            for entry in rows:
                _import_membership(store, entry, 'watchlist', now, stats)
        elif label == 'Favorites':
            for entry in rows:
                _import_membership(store, entry, 'favorites', now, stats)
        elif label == 'Lists':
            for entry in rows:
                writer(store, entry, now, stats)
        else:
            for entry in rows:
                writer(store, entry, now, stats)
    store.meta_set('last_initial_import_at', now)
    if payload.get('user'):
        store.meta_set('trakt_user', payload['user'])
    rebuild_derived(store, settings)
    return stats


def fetch_payload(client):
    history = []
    history.extend(client.history_movies())
    history.extend(client.history_shows())
    lists = []
    for lst in client.user_lists():
        list_id = (lst.get('ids') or {}).get('trakt') or lst.get('id')
        items = client.list_items(list_id) if list_id else []
        copied = dict(lst)
        copied['items'] = items
        lists.append(copied)
    return {
        'movies': client.watched_movies(),
        'shows': client.watched_shows(),
        'history': history,
        'playback': client.playback(),
        'ratings': (
            client.ratings('movies') + client.ratings('shows')
            + client.ratings('seasons') + client.ratings('episodes')
        ),
        'watchlist': client.watchlist('movies') + client.watchlist('shows'),
        'favorites': client.favorites('movies') + client.favorites('shows'),
        'lists': lists,
        'user': ''
    }


def _ids(media):
    ids = (media or {}).get('ids') or {}
    return {
        'imdb': ids.get('imdb') or None,
        'tmdb': None if ids.get('tmdb') in (None, '') else str(ids.get('tmdb')),
        'tvdb': None if ids.get('tvdb') in (None, '') else str(ids.get('tvdb')),
        'trakt_id': None if ids.get('trakt') in (None, '') else str(ids.get('trakt'))
    }


def _upsert_movie(store, media, now):
    info = _ids(media)
    fields = dict(
        media_type='movie',
        title=media.get('title') or 'Untitled',
        year=media.get('year'),
        premiered=media.get('released'),
        now=now,
        **info
    )
    seconds = _runtime_seconds(media)
    if seconds:
        fields['runtime_seconds'] = seconds
    return store.upsert_title(**fields)


def _upsert_show(store, media, now):
    info = _ids(media)
    return store.upsert_title(
        media_type='show',
        title=media.get('title') or 'Untitled',
        year=media.get('year'),
        now=now,
        **info
    )


def _keep_local(local, remote_time, remote_resume):
    if local is None:
        return False
    # A blank row (nothing played, no resume point) must not block a real one.
    if (local['play_count'] or 0) == 0 and not local['resume_seconds']:
        return False
    local_time = local['updated_at'] or local['last_played'] or ''
    source = local['source'] or ''
    if source in ('local_play', 'fixup', 'manual') and local_time and remote_time:
        if local_time >= remote_time:
            return True
    if local['resume_seconds'] and not remote_resume:
        return True
    if source in ('local_play', 'fixup', 'manual') and local['resume_seconds'] not in (None, 0, 0.0):
        if not remote_time or (local_time and local_time >= remote_time):
            return True
    return False


def _import_movie_watch(store, entry, now, stats):
    movie = entry.get('movie') or {}
    title_id = _upsert_movie(store, movie, now)
    stats['titles'] += 1
    remote_time = entry.get('last_watched_at') or ''
    local = store.get_watch(title_id, None)
    if _keep_local(local, remote_time, None):
        stats['kept_local'] += 1
        return
    if remote_time:
        store.record_play(title_id, None, remote_time)
    plays = int(entry.get('plays') or 0)
    current = int(local['play_count']) if local is not None else 0
    known = len(store.list_plays(title_id, None))
    store.set_watch(
        title_id, None,
        play_count=max(current, plays, known),
        last_played=remote_time or (local['last_played'] if local is not None else None),
        resume_seconds=local['resume_seconds'] if local is not None else None,
        runtime_seconds=local['runtime_seconds'] if local is not None else None,
        source='trakt_import',
        updated_at=remote_time or now
    )


def _import_show_watch(store, entry, now, stats):
    show = entry.get('show') or {}
    show_id = _upsert_show(store, show, now)
    stats['titles'] += 1
    for season in entry.get('seasons') or []:
        season_number = int(season.get('number') or 0)
        for episode in season.get('episodes') or []:
            episode_number = int(episode.get('number') or 0)
            episode_id = store.upsert_episode(
                show_id, season_number, episode_number,
                title=episode.get('title')
            )
            stats['episodes'] += 1
            remote_time = episode.get('last_watched_at') or ''
            plays = int(episode.get('plays') or 0)
            local = store.get_watch(show_id, episode_id)
            if _keep_local(local, remote_time, None):
                stats['kept_local'] += 1
                continue
            if plays <= 0 and not remote_time:
                continue
            if remote_time:
                store.record_play(show_id, episode_id, remote_time)
            current = int(local['play_count']) if local is not None else 0
            known = len(store.list_plays(show_id, episode_id))
            store.set_watch(
                show_id, episode_id,
                play_count=max(current, plays, known),
                last_played=remote_time or None,
                resume_seconds=local['resume_seconds'] if local is not None else None,
                runtime_seconds=local['runtime_seconds'] if local is not None else None,
                source='trakt_import',
                updated_at=remote_time or now
            )


def _import_history(store, entry, now, stats):
    '''Each history row is one real watched_at. Missing dates are not invented.'''
    if entry.get('type') == 'movie' or (entry.get('movie') and not entry.get('episode')):
        movie = entry.get('movie') or {}
        if not movie:
            return
        title_id = _upsert_movie(store, movie, now)
        _remember_history_play(store, title_id, None, entry.get('watched_at') or '', now)
        return
    show = entry.get('show') or {}
    episode = entry.get('episode') or {}
    if not show or not episode:
        return
    show_id = _upsert_show(store, show, now)
    episode_id = store.upsert_episode(
        show_id, int(episode.get('season') or 0), int(episode.get('number') or 0),
        title=episode.get('title')
    )
    _remember_history_play(store, show_id, episode_id, entry.get('watched_at') or '', now)


def _remember_history_play(store, title_id, episode_id, watched_at, now):
    if watched_at:
        store.record_play(title_id, episode_id, watched_at)
    known = store.list_plays(title_id, episode_id)
    local = store.get_watch(title_id, episode_id)
    current = int(local['play_count']) if local is not None else 0
    latest = known[-1] if known else (watched_at or None)
    store.set_watch(
        title_id, episode_id,
        play_count=max(current, len(known)),
        last_played=latest or (local['last_played'] if local is not None else None),
        resume_seconds=local['resume_seconds'] if local is not None else None,
        runtime_seconds=local['runtime_seconds'] if local is not None else None,
        source='trakt_import',
        updated_at=now
    )


def _import_playback(store, entry, threshold, now, stats):
    progress = float(entry.get('progress') or 0)
    if progress < FLOOR * 100 or progress >= threshold * 100:
        return
    paused = entry.get('paused_at') or ''
    if entry.get('type') == 'movie' or (entry.get('movie') and not entry.get('episode')):
        movie = entry.get('movie') or {}
        title_id = _upsert_movie(store, movie, now)
        runtime = _known_runtime(store, title_id, None, movie)
        _save_playback(store, title_id, None, progress, runtime, paused, now, stats)
        return
    show = entry.get('show') or {}
    episode = entry.get('episode') or {}
    if not show or not episode:
        return
    show_id = _upsert_show(store, show, now)
    episode_runtime = _runtime_seconds(episode) or _runtime_seconds(show)
    episode_id = store.upsert_episode(
        show_id, int(episode.get('season') or 0), int(episode.get('number') or 0),
        title=episode.get('title'),
        **({'runtime_seconds': episode_runtime} if episode_runtime else {})
    )
    runtime = _known_runtime(store, show_id, episode_id, episode) or _runtime_seconds(show)
    _save_playback(store, show_id, episode_id, progress, runtime, paused, now, stats)


def _save_playback(store, title_id, episode_id, progress, runtime, paused, now, stats):
    resume = (progress / 100.0) * runtime if runtime else None
    local = store.get_watch(title_id, episode_id)
    if _keep_local(local, paused, resume if resume else progress):
        stats['kept_local'] += 1
        return
    store.set_watch(
        title_id, episode_id,
        play_count=int(local['play_count']) if local is not None else 0,
        resume_seconds=resume,
        resume_percent=progress,
        runtime_seconds=runtime,
        last_played=paused or (local['last_played'] if local is not None else None),
        source='trakt_import',
        updated_at=paused or now
    )


def apply_runtime(store, title_id, episode_id, runtime_seconds):
    '''Turn a saved percent into seconds once a runtime is known.'''
    if not runtime_seconds:
        return False
    watch = store.get_watch(title_id, episode_id)
    if watch is None:
        return False
    percent = watch['resume_percent'] if 'resume_percent' in watch.keys() else None
    fields = {}
    if not watch['runtime_seconds']:
        fields['runtime_seconds'] = int(runtime_seconds)
    if percent and not watch['resume_seconds']:
        fields['resume_seconds'] = float(percent) / 100.0 * float(runtime_seconds)
    if not fields:
        return False
    store.set_watch(title_id, episode_id, **fields)
    return True


def _known_runtime(store, title_id, episode_id, media):
    seconds = _runtime_seconds(media)
    if seconds:
        return seconds
    if episode_id:
        episode = store.get_episode(episode_id)
        if episode is not None and episode['runtime_seconds']:
            return int(episode['runtime_seconds'])
    title = store.get_title(title_id)
    if title is not None and title['runtime_seconds']:
        return int(title['runtime_seconds'])
    watch = store.get_watch(title_id, episode_id)
    if watch is not None and watch['runtime_seconds']:
        return int(watch['runtime_seconds'])
    return None


def _runtime_seconds(media):
    runtime = media.get('runtime')
    if not runtime:
        return None
    return int(runtime) * 60


def _import_rating(store, entry, now, stats):
    score = entry.get('rating')
    if score is None:
        return
    remote_time = entry.get('rated_at') or ''
    episode = entry.get('episode')
    season = entry.get('season')
    show = entry.get('show')
    if episode and show:
        show_id = _upsert_show(store, show, now)
        season_number = int(episode.get('season') or 0)
        episode_id = store.upsert_episode(
            show_id, season_number, int(episode.get('number') or 0),
            title=episode.get('title')
        )
        _save_imported_rating(
            store, show_id, int(score), remote_time, now, stats,
            episode_id=episode_id, season=season_number
        )
        return
    if season and show and not episode:
        show_id = _upsert_show(store, show, now)
        _save_imported_rating(
            store, show_id, int(score), remote_time, now, stats,
            season=int(season.get('number') or 0)
        )
        return
    media = entry.get('movie') or show or {}
    if not media:
        return
    if entry.get('movie'):
        title_id = _upsert_movie(store, media, now)
    else:
        title_id = _upsert_show(store, media, now)
    _save_imported_rating(store, title_id, int(score), remote_time, now, stats)


def _save_imported_rating(store, title_id, score, remote_time, now, stats,
                          episode_id=None, season=None):
    local = store.get_rating(title_id, episode_id, season)
    if local is not None and local['source'] in ('local', 'local_play', 'manual'):
        local_time = local['updated_at'] or local['rated_at'] or ''
        if local_time and remote_time and local_time >= remote_time:
            stats['kept_local'] += 1
            return
    store.save_rating(
        title_id, score, source='trakt_import', rated_at=remote_time or now,
        episode_id=episode_id, season=season, keep_notes=True
    )
    stats['ratings'] += 1


def _import_membership(store, entry, slug, now, stats):
    media = entry.get('movie') or entry.get('show') or {}
    if not media:
        return
    if entry.get('movie'):
        title_id = _upsert_movie(store, media, now)
    else:
        title_id = _upsert_show(store, media, now)
    if not store.in_list(slug, title_id, None):
        store.add_list_item(slug, title_id, None)
        stats[slug] += 1


def _import_user_list(store, lst, now, stats):
    name = lst.get('name') or 'List'
    slug_source = (lst.get('ids') or {}).get('slug') or name
    slug = 'user:' + ''.join(
        ch.lower() if ch.isalnum() else '-' for ch in slug_source
    ).strip('-')
    if store.list_row(slug) is None:
        store.create_list(slug, name, 'user', 'mixed')
    stats['lists'] += 1
    for item in lst.get('items') or []:
        media = item.get('movie') or item.get('show') or {}
        if not media:
            continue
        if item.get('movie'):
            title_id = _upsert_movie(store, media, now)
        else:
            title_id = _upsert_show(store, media, now)
        if not store.in_list(slug, title_id, None):
            store.add_list_item(slug, title_id, None)


def resync_playback(store, settings, guard):
    '''Pull only /sync/playback and rebuild In-progress and Next Up.'''
    from nextup.algorithm import rebuild_derived
    from trakt.client import TraktClient
    settings.store = store
    if not settings.get('trakt_client_id'):
        return 'Add a Trakt client id first.'
    if not settings.trakt_authorized() and not settings.get('trakt_access_token'):
        return 'Sign in to Trakt first.'
    client = TraktClient(
        guard,
        settings.get('trakt_client_id'),
        access_token=settings.get('trakt_access_token'),
        client_secret=settings.get('trakt_client_secret'),
        settings=settings
    )
    stats = {'playback': 0, 'kept_local': 0}
    for entry in client.playback():
        _import_playback(store, entry, settings.threshold, iso(), stats)
        stats['playback'] += 1
    rebuild_derived(store, settings)
    return stats


def merge_duplicate_trakt_ids(store):
    '''Collapse titles that share a Trakt id. List items and ratings stay unique.'''
    def write():
        groups = store._conn.execute(
            '''
            SELECT media_type, trakt_id FROM titles
            WHERE trakt_id IS NOT NULL AND trakt_id != ''
            GROUP BY media_type, trakt_id
            HAVING COUNT(*) > 1
            '''
        ).fetchall()
        merged = 0
        for group in groups:
            rows = store._conn.execute(
                '''
                SELECT * FROM titles
                WHERE media_type = ? AND trakt_id = ?
                ORDER BY id
                ''',
                (group['media_type'], group['trakt_id'])
            ).fetchall()
            keeper = rows[0]['id']
            for extra in rows[1:]:
                _fold_title(store, keeper, extra)
                merged += 1
        return merged
    return store._write(write)


def _fold_title(store, keeper_id, extra):
    extra_id = extra['id']
    keeper = store._conn.execute(
        'SELECT * FROM titles WHERE id = ?', (keeper_id,)
    ).fetchone()
    updates = {}
    for key in ('imdb', 'tmdb', 'tvdb', 'plot', 'runtime_seconds', 'year', 'premiered'):
        if keeper[key] in (None, '') and extra[key] not in (None, ''):
            updates[key] = extra[key]
    if updates:
        sql = 'UPDATE titles SET %s WHERE id = ?' % ', '.join(
            '%s = ?' % key for key in updates
        )
        store._conn.execute(sql, list(updates.values()) + [keeper_id])
    episodes = store._conn.execute(
        'SELECT * FROM episodes WHERE show_id = ?', (extra_id,)
    ).fetchall()
    for episode in episodes:
        match = store._conn.execute(
            '''
            SELECT id FROM episodes
            WHERE show_id = ? AND season = ? AND episode = ?
            ''',
            (keeper_id, episode['season'], episode['episode'])
        ).fetchone()
        if match is None:
            store._conn.execute(
                'UPDATE episodes SET show_id = ? WHERE id = ?',
                (keeper_id, episode['id'])
            )
        else:
            _retarget_episode(store, episode['id'], match['id'], extra_id, keeper_id)
            store._conn.execute('DELETE FROM episodes WHERE id = ?', (episode['id'],))
    _retarget_rows(store, 'watch_state', extra_id, keeper_id, 'episode_id')
    _retarget_rows(store, 'ratings', extra_id, keeper_id, 'episode_id')
    _retarget_list_items(store, extra_id, keeper_id)
    store._conn.execute('DELETE FROM titles WHERE id = ?', (extra_id,))


def _retarget_episode(store, old_episode, new_episode, old_title, new_title):
    for table in ('watch_state', 'ratings'):
        store._conn.execute(
            'UPDATE %s SET title_id = ?, episode_id = ? WHERE title_id = ? AND episode_id = ?' % table,
            (new_title, new_episode, old_title, old_episode)
        )


def _retarget_rows(store, table, old_title, new_title, episode_column):
    rows = store._conn.execute(
        'SELECT * FROM %s WHERE title_id = ?' % table, (old_title,)
    ).fetchall()
    for row in rows:
        episode_id = row[episode_column]
        clash = store._conn.execute(
            'SELECT id FROM %s WHERE title_id = ? AND IFNULL(%s, 0) = ?' % (table, episode_column),
            (new_title, int(episode_id or 0))
        ).fetchone()
        if clash is None:
            store._conn.execute(
                'UPDATE %s SET title_id = ? WHERE id = ?' % table,
                (new_title, row['id'])
            )
        else:
            store._conn.execute('DELETE FROM %s WHERE id = ?' % table, (row['id'],))


def _retarget_list_items(store, old_title, new_title):
    rows = store._conn.execute(
        'SELECT * FROM list_items WHERE title_id = ?', (old_title,)
    ).fetchall()
    for row in rows:
        clash = store._conn.execute(
            '''
            SELECT id FROM list_items
            WHERE list_id = ? AND IFNULL(title_id, 0) = ? AND IFNULL(episode_id, 0) = ?
            ''',
            (row['list_id'], new_title, int(row['episode_id'] or 0))
        ).fetchone()
        if clash is None:
            store._conn.execute(
                'UPDATE list_items SET title_id = ? WHERE id = ?',
                (new_title, row['id'])
            )
        else:
            store._conn.execute('DELETE FROM list_items WHERE id = ?', (row['id'],))
