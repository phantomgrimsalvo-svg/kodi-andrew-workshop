'''Trakt device tokens and refresh. A new app has a client id and no secret.'''

from __future__ import annotations

from datetime import datetime, timezone

from util import iso, parse_iso

SIGN_IN_AGAIN = 'Trakt sign-in expired. Run Re-import in Hearth and sign in again.'
DEFAULT_EXPIRES = 7 * 24 * 60 * 60


def device_token_body(client_id, code, client_secret=''):
    '''POST /oauth/device/token. Secret is omitted when the app has none.'''
    body = {'code': code, 'client_id': client_id}
    secret = (client_secret or '').strip()
    if secret:
        body['client_secret'] = secret
    return body


def refresh_token_body(client_id, refresh_token, client_secret=''):
    '''POST /oauth/token. Secret is omitted when the app has none.'''
    body = {
        'grant_type': 'refresh_token',
        'refresh_token': refresh_token,
        'client_id': client_id
    }
    secret = (client_secret or '').strip()
    if secret:
        body['client_secret'] = secret
    return body


AUTH_KEY = 'trakt_auth'


def load_auth(store):
    from util import loads
    data = loads(store.meta_get(AUTH_KEY), {}) or {}
    return data if isinstance(data, dict) else {}


def save_auth(store, data):
    from util import dumps
    store.meta_set(AUTH_KEY, dumps(data or {}))


def read_field(store, field):
    value = load_auth(store).get(field)
    return '' if value is None else str(value)


def write_field(store, field, value):
    data = load_auth(store)
    if value in (None, ''):
        data.pop(field, None)
    else:
        data[field] = value
    save_auth(store, data)


def remember_token(settings, token, now=None):
    now = now or iso()
    created = _created_at(token, now)
    try:
        expires = int(token.get('expires_in') or DEFAULT_EXPIRES)
    except (TypeError, ValueError):
        expires = DEFAULT_EXPIRES
    if expires <= 0:
        expires = DEFAULT_EXPIRES
    settings.set('trakt_access_token', token.get('access_token') or '')
    settings.set(
        'trakt_refresh_token',
        token.get('refresh_token') or settings.get('trakt_refresh_token') or ''
    )
    settings.set('trakt_token_created_at', created)
    settings.set('trakt_token_expires_in', str(expires))
    settings.set('trakt_device_code', '')


def token_is_due(settings, now=None):
    if not (settings.get('trakt_access_token') or '').strip():
        return False
    if not (settings.get('trakt_refresh_token') or '').strip():
        return False
    created = parse_iso(settings.get('trakt_token_created_at'))
    try:
        expires = int(float(settings.get('trakt_token_expires_in') or 0))
    except (TypeError, ValueError):
        expires = 0
    if created is None or expires <= 0:
        return True
    current = parse_iso(now or iso())
    if current is None:
        return True
    margin = 3600 if expires > 7200 else max(60, expires // 10)
    return (current - created).total_seconds() >= (expires - margin)


def ensure_access_token(settings, guard, now=None):
    '''Return a usable access token, refreshing before it expires.'''
    if not (settings.get('trakt_access_token') or '').strip():
        return ''
    if not token_is_due(settings, now):
        return settings.get('trakt_access_token')
    return refresh_access_token(settings, guard, now=now) or ''


def refresh_access_token(settings, guard, now=None):
    refresh = (settings.get('trakt_refresh_token') or '').strip()
    client_id = (settings.get('trakt_client_id') or '').strip()
    if not refresh or not client_id:
        clear_auth(settings)
        return ''
    from trakt.client import TraktClient, TraktError
    client = TraktClient(
        guard, client_id, client_secret=settings.get('trakt_client_secret')
    )
    try:
        token = client.refresh_access_token(refresh) or {}
    except TraktError:
        clear_auth(settings)
        return ''
    if not token.get('access_token'):
        clear_auth(settings)
        return ''
    remember_token(settings, token, now=now)
    return token.get('access_token') or ''


def clear_auth(settings, message=SIGN_IN_AGAIN):
    for key in (
        'trakt_access_token', 'trakt_refresh_token', 'trakt_token_created_at',
        'trakt_token_expires_in', 'trakt_device_code', 'trakt_device_interval',
        'trakt_device_expires_in'
    ):
        settings.set(key, '')
    store = getattr(settings, 'store', None)
    if store is not None:
        save_auth(store, {})
    if message:
        _tell(message)


def _created_at(token, now):
    raw = token.get('created_at')
    if raw in (None, ''):
        return now
    try:
        moment = datetime.fromtimestamp(int(raw), timezone.utc)
    except (TypeError, ValueError, OSError):
        return now
    return moment.strftime('%Y-%m-%dT%H:%M:%SZ')


def _tell(message):
    try:
        import xbmcgui
        xbmcgui.Dialog().notification('Hearth', message, sound=False)
    except Exception:
        return
