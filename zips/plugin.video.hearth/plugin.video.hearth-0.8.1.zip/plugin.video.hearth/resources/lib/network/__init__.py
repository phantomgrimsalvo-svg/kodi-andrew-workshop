'''The only HTTP entry point in the add-on.'''
