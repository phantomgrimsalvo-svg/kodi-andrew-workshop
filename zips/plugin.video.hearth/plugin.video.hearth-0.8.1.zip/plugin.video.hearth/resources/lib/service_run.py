'''Daemon workers for the service. Abort sets one event and nobody joins forever.'''

from __future__ import annotations

import threading
import time

STOP = threading.Event()


def request_stop():
    STOP.set()


def stopped():
    return STOP.is_set()


def reset_stop():
    '''Tests start from a clear event. The running service does not call this.'''
    STOP.clear()


class ServiceRun:
    def __init__(self):
        self.stop = STOP
        self.threads = []

    def start(self, name, target):
        thread = threading.Thread(
            target=self._guard, args=(name, target), name=name, daemon=True
        )
        self.threads.append(thread)
        thread.start()
        return thread

    def _guard(self, name, target):
        try:
            target(self.stop)
        except Exception:
            return

    def join(self, timeout=0.4):
        '''Wait up to timeout seconds for every worker. Returns True if all ended.'''
        deadline = time.monotonic() + float(timeout)
        for thread in self.threads:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            thread.join(remaining)
        return all(not thread.is_alive() for thread in self.threads)


def run_until_abort(monitor, tick, wait_seconds=1):
    '''Main loop. waitForAbort is the only pause, and it is short.'''
    while True:
        if monitor.abortRequested():
            break
        if monitor.waitForAbort(wait_seconds):
            break
        if monitor.abortRequested():
            break
        tick()
    request_stop()
