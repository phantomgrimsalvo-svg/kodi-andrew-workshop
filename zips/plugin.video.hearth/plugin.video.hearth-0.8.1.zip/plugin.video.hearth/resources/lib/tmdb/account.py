'''TMDb v3 sign-in and the account ratings import.

The session lives in the hearth.db meta table. Kodi settings are not used
for the token the device flow just created.
'''

from __future__ import annotations

import time

from art.backfill import remember_remote_art
from tmdb.client import TmdbError, fetch_show, movie_fields, show_fields
from util import dumps, loads

AUTH_KEY = 'tmdb_auth'
API = 'https://api.themoviedb.org/3'
PURPOSE = 'explicit_action'


def auth_blob(store):
    data = loads(store.meta_get(AUTH_KEY), {}) or {}
    return data if isinstance(data, dict) else {}


def session_id(store, settings=None):
    saved = auth_blob(store).get('session_id') or ''
    if saved:
        return saved
    if settings is not None:
        return settings.get('tmdb_session_id') or ''
    return ''


def account_id(store):
    return auth_blob(store).get('account_id') or ''


def sign_out(store, settings):
    store.meta_set(AUTH_KEY, '')
    settings.set('tmdb_session_id', '')
    try:
        from settings import save_kodi_setting
        save_kodi_setting('tmdb_session_id', '')
    except Exception:
        return


def sign_in(store, settings, guard, progress=None, sleep=None, clock=None):
    '''Show the approve URL and wait until TMDb returns a session.'''
    key = (settings.get('tmdb_api_key') or '').strip()
    if not key:
        raise TmdbError('Add a TMDB API key in Hearth settings first.')
    created = _json(guard, '%s/authentication/token/new?api_key=%s' % (API, key))
    request_token = (created or {}).get('request_token') or ''
    if not request_token:
        raise TmdbError('TMDb did not return a request token. Check the API key.')
    url = 'https://www.themoviedb.org/authenticate/%s' % request_token
    try:
        from pairing.qr import write_qr
        from paths import profile_dir
        write_qr(url, profile_dir())
    except Exception:
        url = url
    bar = progress if progress is not None else _progress()
    sleeper = sleep if sleep is not None else time.sleep
    now = clock if clock is not None else time.monotonic
    started = now()
    bar.create('Sign in to TMDb', 'Approve Hearth at %s. A QR code was saved next to the library.' % url)
    session = ''
    try:
        while True:
            if bar.iscanceled():
                return None
            if now() - started > 900:
                raise TmdbError('That TMDb request expired. Run Sign in again.')
            status, body = _status(
                guard,
                '%s/authentication/session/new?api_key=%s' % (API, key),
                method='POST',
                payload={'request_token': request_token}
            )
            if status == 200 and isinstance(body, dict) and body.get('session_id'):
                session = body['session_id']
                break
            sleeper(5)
    finally:
        bar.close()
    account = _json(
        guard,
        '%s/account?api_key=%s&session_id=%s' % (API, key, session)
    )
    store.meta_set(AUTH_KEY, dumps({
        'session_id': session,
        'account_id': (account or {}).get('id'),
        'request_token': request_token
    }))
    return session


def import_account_ratings(store, settings, guard, progress=None):
    key = (settings.get('tmdb_api_key') or '').strip()
    session = session_id(store, settings)
    account = account_id(store)
    if not key:
        return 'Add a TMDB API key in Hearth settings first.'
    if not session or not account:
        return 'Sign in to TMDb first.'
    bar = progress
    if bar is not None:
        bar.create('Import TMDb ratings', 'Movies')
    stats = {'movies': 0, 'shows': 0, 'episodes': 0, 'kept': 0}
    try:
        movies = _pages(guard, key, session, account, 'movies')
        if bar is not None:
            bar.update(30, 'Shows')
        shows = _pages(guard, key, session, account, 'tv')
        if bar is not None:
            bar.update(60, 'Episodes')
        episodes = _pages(guard, key, session, account, 'tv/episodes')
        for row in movies:
            if _import_movie(store, row):
                stats['movies'] += 1
            else:
                stats['kept'] += 1
        for row in shows:
            if _import_show(store, row):
                stats['shows'] += 1
            else:
                stats['kept'] += 1
        for row in episodes:
            if _import_episode(store, settings, guard, key, row):
                stats['episodes'] += 1
            else:
                stats['kept'] += 1
    finally:
        if bar is not None:
            bar.close()
    from recs.profile import export_text_files
    export_text_files(store)
    return stats


def push_rating(store, settings, guard, title, score, season=None, episode_id=None):
    session = session_id(store, settings)
    key = (settings.get('tmdb_api_key') or '').strip()
    if not session or not key or title is None or not title['tmdb'] or score is None:
        return False
    if episode_id:
        episode = store.get_episode(episode_id)
        if episode is None:
            return False
        path = '/tv/%s/season/%s/episode/%s/rating' % (
            title['tmdb'], episode['season'], episode['episode']
        )
    elif season is not None:
        path = '/tv/%s/season/%s/rating' % (title['tmdb'], int(season))
    elif title['media_type'] == 'show':
        path = '/tv/%s/rating' % title['tmdb']
    else:
        path = '/movie/%s/rating' % title['tmdb']
    url = '%s%s?api_key=%s&session_id=%s' % (API, path, key, session)
    guard.post(
        url, PURPOSE,
        headers={'Content-Type': 'application/json'},
        body=dumps({'value': float(score)})
    )
    return True


def _import_movie(store, row):
    score = _score(row)
    if score is None:
        return False
    fields = movie_fields(row)
    images = fields.pop('images', {}) or {}
    title_id = store.upsert_title(**fields)
    remember_remote_art(
        store, title_id,
        poster_path=images.get('poster'), backdrop_path=images.get('fanart')
    )
    return _merge(store, title_id, score, row.get('rated_at') or row.get('created_at'))


def _import_show(store, row):
    score = _score(row)
    if score is None:
        return False
    fields = show_fields(row)
    images = fields.pop('images', {}) or {}
    fields.pop('seasons', None)
    title_id = store.upsert_title(**fields)
    remember_remote_art(
        store, title_id,
        poster_path=images.get('poster'), backdrop_path=images.get('fanart')
    )
    return _merge(store, title_id, score, row.get('rated_at') or row.get('created_at'))


def _import_episode(store, settings, guard, key, row):
    score = _score(row)
    show_id_text = row.get('show_id')
    if score is None or not show_id_text:
        return False
    show = store.find_title(media_type='show', tmdb=str(show_id_text))
    if show is None:
        try:
            payload = fetch_show(guard, key, show_id_text, PURPOSE, str(show_id_text))
        except TmdbError:
            payload = {
                'id': show_id_text,
                'name': row.get('show_name') or 'Show %s' % show_id_text
            }
        fields = show_fields(payload)
        fields.pop('seasons', None)
        fields.pop('images', None)
        title_id = store.upsert_title(**fields)
    else:
        title_id = show['id']
    season = int(row.get('season_number') or 0)
    number = int(row.get('episode_number') or 0)
    episode_id = store.upsert_episode(
        title_id, season, number,
        title=row.get('name') or '',
        tmdb=None if row.get('id') is None else str(row.get('id'))
    )
    episode = store.get_episode(episode_id)
    if row.get('still_path'):
        remember_remote_art(store, title_id, poster_path=row.get('still_path'), episode=episode)
    return _merge(
        store, title_id, score, row.get('rated_at') or row.get('created_at'),
        episode_id=episode_id, season=season
    )


def _merge(store, title_id, score, rated_at, episode_id=None, season=None):
    '''Newest dated rating wins. An undated import does not replace a dated one.'''
    current = store.get_rating(title_id, episode_id, season)
    remote = rated_at or ''
    if current is not None and current['score'] is not None:
        local = current['rated_at'] or ''
        if local and remote and local > remote:
            return False
        if local and not remote:
            return False
    store.save_rating(
        title_id, score, source='tmdb_import', rated_at=remote or None,
        episode_id=episode_id, season=season, keep_notes=True
    )
    return True


def _score(row):
    raw = row.get('account_rating')
    if raw is None:
        raw = row.get('rating')
    if raw is None or raw == '':
        return None
    try:
        number = int(round(float(raw)))
    except (TypeError, ValueError):
        return None
    if number < 1:
        return 1
    if number > 10:
        return 10
    return number


def _pages(guard, key, session, account, kind):
    found = []
    page = 1
    while page <= 40:
        body = _json(guard, (
            '%s/account/%s/rated/%s?api_key=%s&session_id=%s&page=%s'
        ) % (API, account, kind, key, session, page)) or {}
        found.extend(body.get('results') or [])
        try:
            total = int(body.get('total_pages') or 1)
        except (TypeError, ValueError):
            total = 1
        if page >= total:
            break
        page += 1
    return found


def _json(guard, url):
    status, body = _status(guard, url)
    if status >= 400 or not isinstance(body, (dict, list)):
        raise TmdbError('TMDb request failed (%s).' % status)
    return body


def _status(guard, url, method='GET', payload=None):
    headers = {'Content-Type': 'application/json'} if payload is not None else None
    body = dumps(payload) if payload is not None else None
    response = guard.request(method, url, PURPOSE, headers=headers, body=body)
    status = int(getattr(response, 'status', 0) or 0)
    parsed = getattr(response, 'body', None)
    return status, parsed


def _progress():
    import xbmcgui
    return xbmcgui.DialogProgress()
