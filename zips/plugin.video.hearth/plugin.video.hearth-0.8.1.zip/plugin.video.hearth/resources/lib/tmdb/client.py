'''Fetch one title from TMDB. The caller must already be inside a guard purpose.'''

from __future__ import annotations

from urllib.parse import urlencode

API = 'https://api.themoviedb.org/3'


class TmdbError(Exception):
    pass


def _get(guard, path, params, purpose, item_id):
    query = urlencode(params)
    response = guard.get(
        '%s%s?%s' % (API, path, query),
        purpose,
        item_id=item_id
    )
    status = int(getattr(response, 'status', 0) or 0)
    body = getattr(response, 'body', None)
    if status >= 400 or isinstance(body, (bytes, bytearray)):
        raise TmdbError('TMDB %s failed (%s).' % (path, status or 0))
    if body is not None and not isinstance(body, (dict, list)):
        raise TmdbError('TMDB %s returned an unexpected reply (%s).' % (path, status or 0))
    return body or {}


def fetch_movie(guard, api_key, tmdb_id, purpose, item_id):
    return _get(
        guard, '/movie/%s' % tmdb_id,
        {'api_key': api_key},
        purpose, item_id
    )


def fetch_show(guard, api_key, tmdb_id, purpose, item_id):
    return _get(
        guard, '/tv/%s' % tmdb_id,
        {'api_key': api_key},
        purpose, item_id
    )


def fetch_season(guard, api_key, tmdb_id, season, purpose, item_id):
    return _get(
        guard, '/tv/%s/season/%s' % (tmdb_id, season),
        {'api_key': api_key},
        purpose, item_id
    )


def find_external(guard, api_key, external_id, source, purpose, item_id):
    return _get(
        guard, '/find/%s' % external_id,
        {'api_key': api_key, 'external_source': source},
        purpose, item_id
    )


def movie_fields(payload):
    return {
        'media_type': 'movie',
        'title': payload.get('title') or payload.get('name') or 'Untitled',
        'original_title': payload.get('original_title') or payload.get('original_name'),
        'year': _year(payload.get('release_date')),
        'premiered': payload.get('release_date'),
        'runtime_seconds': (int(payload['runtime']) * 60) if payload.get('runtime') else None,
        'plot': payload.get('overview') or '',
        'tagline': payload.get('tagline') or '',
        'status': payload.get('status') or '',
        'tmdb': str(payload.get('id') or ''),
        'imdb': payload.get('imdb_id') or None,
        'genres': [item.get('name') for item in payload.get('genres') or [] if item.get('name')],
        'studio': (payload.get('production_companies') or [{}])[0].get('name'),
        'original_language': payload.get('original_language'),
        'images': {
            'poster': payload.get('poster_path'),
            'fanart': payload.get('backdrop_path')
        }
    }


def show_fields(payload):
    seasons = []
    for season in payload.get('seasons') or []:
        number = season.get('season_number')
        if number is None:
            continue
        seasons.append(int(number))
    return {
        'media_type': 'show',
        'title': payload.get('name') or payload.get('title') or 'Untitled',
        'original_title': payload.get('original_name'),
        'year': _year(payload.get('first_air_date')),
        'premiered': payload.get('first_air_date'),
        'plot': payload.get('overview') or '',
        'tagline': payload.get('tagline') or '',
        'status': payload.get('status') or '',
        'tmdb': str(payload.get('id') or ''),
        'genres': [item.get('name') for item in payload.get('genres') or [] if item.get('name')],
        'studio': (payload.get('networks') or [{}])[0].get('name'),
        'original_language': payload.get('original_language'),
        'seasons': seasons,
        'images': {
            'poster': payload.get('poster_path'),
            'fanart': payload.get('backdrop_path')
        }
    }


def episode_fields(payload):
    return {
        'season': int(payload.get('season_number') or 0),
        'episode': int(payload.get('episode_number') or 0),
        'title': payload.get('name') or '',
        'first_aired': payload.get('air_date'),
        'runtime_seconds': (int(payload['runtime']) * 60) if payload.get('runtime') else None,
        'plot': payload.get('overview') or '',
        'tmdb': None if payload.get('id') is None else str(payload.get('id')),
        'images': {'thumb': payload.get('still_path')}
    }


def _year(date_text):
    if not date_text or len(str(date_text)) < 4:
        return None
    try:
        return int(str(date_text)[:4])
    except ValueError:
        return None
