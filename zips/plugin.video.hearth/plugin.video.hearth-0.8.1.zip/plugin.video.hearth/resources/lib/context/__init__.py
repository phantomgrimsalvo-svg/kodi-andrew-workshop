'''Context-menu actions. Network only when the title is not already local.'''
