'''Choose an MDBList list from the account instead of typing its id.'''

from __future__ import annotations

from urllib.parse import quote


def fetch_lists(guard, api_key):
    guard.allow_host('api.mdblist.com')
    response = guard.get(
        'https://api.mdblist.com/lists/user?apikey=%s' % quote(api_key or ''),
        'explicit_action'
    )
    body = getattr(response, 'body', None)
    if isinstance(body, dict):
        body = body.get('lists') or body.get('items') or []
    if not isinstance(body, list):
        return []
    rows = []
    for item in body:
        if not isinstance(item, dict):
            continue
        list_id = item.get('id') or item.get('list_id')
        name = item.get('name') or item.get('title') or ''
        if list_id in (None, '') or not name:
            continue
        rows.append({'id': str(list_id), 'name': str(name)})
    return rows


def pick(settings, guard, dialog):
    key = (settings.get('mdblist_api_key') or '').strip()
    if not key:
        return {'skipped': 'Add an MDBList API key under Advanced first.'}
    rows = fetch_lists(guard, key)
    if not rows:
        return {'failed': 'MDBList returned no lists.'}
    labels = ['%s (%s)' % (row['name'], row['id']) for row in rows]
    index = dialog.select('Pick my MDBList list', labels)
    if index is None or index < 0 or index >= len(rows):
        return {'skipped': 'No MDBList list was chosen.'}
    chosen = rows[index]
    settings.set('mdblist_list_id', chosen['id'])
    try:
        from settings import save_kodi_setting
        save_kodi_setting('mdblist_list_id', chosen['id'])
    except Exception:
        pass
    return {'message': 'MDBList list is %s.' % chosen['name']}
