'''Write a QR code PNG for a pairing URL.'''

from __future__ import annotations

from pathlib import Path


def write_qr(url, folder):
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / 'hearth-pair.png'
    import segno
    segno.make(url, error='m').save(str(path), scale=8, border=2)
    return str(path)


def activate_url(base, code):
    base = (base or '').rstrip('/')
    code = (code or '').strip()
    if not code:
        return base
    if base.endswith('/' + code) or base.endswith(code):
        return base
    return base + '/' + code
