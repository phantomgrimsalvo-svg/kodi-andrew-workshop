'''Simkl PIN pairing. The access token is stored. The client id stays out of the dialog.'''

from __future__ import annotations

from urllib.parse import quote

from pairing.qr import write_qr


def pair(settings, guard, progress=None, sleep=None, clock=None):
    import time
    client_id = (settings.get('simkl_client_id') or '').strip()
    if not client_id:
        return {'skipped': 'No Simkl client id yet. The built-in key is empty, or set your own under Advanced.'}
    guard.allow_host('api.simkl.com')
    redirect = quote('urn:ietf:wg:oauth:2.0:oob')
    created = guard.get(
        'https://api.simkl.com/oauth/pin?client_id=%s&redirect=%s' % (quote(client_id), redirect),
        'explicit_action'
    )
    body = created.body if isinstance(getattr(created, 'body', None), dict) else {}
    user_code = str(body.get('user_code') or '').strip()
    if not user_code:
        return {'failed': 'Simkl did not return a PIN. Check the client id.'}
    page = 'https://simkl.com/pin'
    direct = str(body.get('verification_url') or (page + '/' + user_code))
    try:
        from paths import profile_dir
        write_qr(direct, profile_dir())
    except Exception:
        direct = direct
    try:
        interval = max(1, int(body.get('interval') or 5))
    except (TypeError, ValueError):
        interval = 5
    try:
        expires = max(interval, int(body.get('expires_in') or 900))
    except (TypeError, ValueError):
        expires = 900
    sleeper = sleep if sleep is not None else time.sleep
    now = clock if clock is not None else time.monotonic
    started = now()
    line = 'PIN %s. Open %s' % (user_code, direct)
    if progress is not None:
        progress.create('Pair with Simkl', line)
    try:
        while True:
            if progress is not None and progress.iscanceled():
                return {'skipped': 'Simkl pairing was cancelled.'}
            if now() - started >= expires:
                return {'failed': 'That Simkl PIN expired. Pair again.'}
            status, payload = _poll(guard, client_id, user_code)
            token = ''
            if isinstance(payload, dict):
                token = payload.get('access_token') or ''
            if status == 200 and token:
                _store(settings, token)
                return {'message': 'Simkl is paired.'}
            sleeper(interval)
            if progress is not None:
                elapsed = now() - started
                progress.update(int(min(99, elapsed * 100 / expires)), line)
    finally:
        if progress is not None:
            progress.close()


def _poll(guard, client_id, user_code):
    response = guard.get(
        'https://api.simkl.com/oauth/pin/%s?client_id=%s' % (quote(user_code), quote(client_id)),
        'explicit_action'
    )
    status = int(getattr(response, 'status', 0) or 0)
    body = getattr(response, 'body', None)
    if not isinstance(body, dict):
        body = {}
    return status, body


def _store(settings, token):
    settings.set('simkl_access_token', token)
    try:
        from settings import save_kodi_setting
        save_kodi_setting('simkl_access_token', token)
    except Exception:
        return
