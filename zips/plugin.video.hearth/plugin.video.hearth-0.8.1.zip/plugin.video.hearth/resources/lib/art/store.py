'''Download artwork once and keep the local path.'''

from __future__ import annotations

from pathlib import Path

from util import dumps

IMAGE_SIZES = {
    'poster': 'w500',
    'fanart': 'w1280',
    'thumb': 'w500',
    'clearlogo': 'w500'
}


def local_art_file(art_root, media_type, item_id, kind, ext='jpg'):
    folder = Path(art_root) / _bucket(media_type)
    folder.mkdir(parents=True, exist_ok=True)
    return folder / ('%s-%s.%s' % (item_id, kind, ext))


def image_url(file_path, kind):
    size = IMAGE_SIZES.get(kind, 'w500')
    path = file_path if str(file_path).startswith('/') else '/' + str(file_path)
    return 'https://image.tmdb.org/t/p/%s%s' % (size, path)


def download_images(guard, art_root, media_type, item_id, images, purpose, id_token):
    '''images: {kind: '/tmdbFile.jpg'}. Returns a map of kind -> local path.'''
    saved = {}
    for kind, file_path in (images or {}).items():
        if not file_path:
            continue
        url = image_url(file_path, kind)
        guard.allow_image(url)
        response = guard.get(url, purpose, item_id=id_token)
        content = response.content or b''
        if isinstance(response.body, bytes) and not content:
            content = response.body
        if not content:
            continue
        ext = 'jpg'
        suffix = Path(str(file_path)).suffix.lower().lstrip('.')
        if suffix in ('jpg', 'jpeg', 'png', 'webp'):
            ext = 'jpg' if suffix == 'jpeg' else suffix
        dest = local_art_file(art_root, media_type, item_id, kind, ext)
        dest.write_bytes(content)
        saved[kind] = str(dest)
        saved[kind + '_url'] = url
    return saved


def art_json(mapping):
    return dumps(mapping or {})


def _bucket(media_type):
    if media_type == 'movie':
        return 'movies'
    if media_type == 'episode':
        return 'episodes'
    if media_type == 'list':
        return 'lists'
    return 'shows'
