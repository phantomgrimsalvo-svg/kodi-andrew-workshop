'''Fill in TMDb metadata and artwork for titles the import stored as names only.

The work is resumable: a title leaves the queue once a poster file is on disk,
or TMDb has confirmed it has no artwork. Failures are retried a few times.
'''

from __future__ import annotations

import time
from pathlib import Path

from art.store import download_images, image_url
from tmdb.client import (
    TmdbError, episode_fields, fetch_movie, fetch_season, fetch_show,
    find_external, movie_fields, show_fields
)
from util import dumps, loads

BATCH = 6
DELAY_SECONDS = 0.3
ATTEMPT_LIMIT = 3
PURPOSE = 'explicit_action'


class Aborted(Exception):
    '''Kodi asked the service to stop. Leave the rest of the queue for next time.'''


def kodi_abort():
    try:
        import xbmc
        return bool(xbmc.Monitor().abortRequested())
    except Exception:
        return False


def backfill_batch(store, settings, guard, limit=BATCH, sleep=None, force=False, abort=None):
    '''One background slice. Returns quietly when there is nothing to do.'''
    if not (settings.get('tmdb_api_key') or '').strip():
        return {'skipped': 'no key', 'filled': 0, 'remaining': 0}
    return _run(
        store, settings, guard, limit=limit, progress=None,
        sleep=sleep, force=force, notify_done=True, abort=abort or kodi_abort
    )


def backfill_all(store, settings, guard, progress=None, sleep=None, abort=None):
    '''Foreground pass. Cancel stops the queue and leaves the rest for later.'''
    if not (settings.get('tmdb_api_key') or '').strip():
        _notify('Hearth', 'Add a TMDB API key, then refresh artwork.')
        return {'skipped': 'no key', 'filled': 0, 'remaining': 0}
    own_dialog = progress is None
    bar = progress
    if own_dialog:
        import xbmcgui
        bar = xbmcgui.DialogProgress()
    result = _run(
        store, settings, guard, limit=None, progress=bar,
        sleep=sleep, force=True, notify_done=False, abort=abort or kodi_abort
    )
    if own_dialog and not result.get('cancelled'):
        import xbmcgui
        xbmcgui.Dialog().ok('Hearth', _done_line(result))
    elif result.get('cancelled'):
        _notify('Hearth', 'Artwork refresh paused. It continues in the background.')
    return result


def _run(store, settings, guard, limit, progress, sleep, force, notify_done, abort):
    from network.guard import transport_timeout
    sleeper = sleep if sleep is not None else time.sleep
    jobs = _jobs(store, force=force)
    if progress is not None:
        progress.create('Refresh all artwork', _done_line({
            'filled': 0, 'remaining': len(jobs)
        }))
    filled = 0
    failed = 0
    total = len(jobs)
    chosen = jobs if limit is None else jobs[:limit]
    cancelled = False
    try:
        with transport_timeout(1):
            for index, job in enumerate(chosen):
                if _stopped(abort) or (progress is not None and progress.iscanceled()):
                    cancelled = True
                    break
                if progress is not None:
                    progress.update(
                        int(index * 100 / max(total, 1)),
                        job['label']
                    )
                try:
                    ok = _fill(store, settings, guard, job, abort)
                except Aborted:
                    cancelled = True
                    break
                if ok:
                    filled += 1
                else:
                    failed += 1
                if index + 1 < len(chosen) and not _pause(sleeper, DELAY_SECONDS, abort):
                    cancelled = True
                    break
    finally:
        if progress is not None:
            progress.close()
    if cancelled:
        return {
            'cancelled': True, 'filled': filled, 'failed': failed,
            'remaining': len(_jobs(store, force=force))
        }
    remaining = len(_jobs(store, force=False))
    result = {'filled': filled, 'failed': failed, 'remaining': remaining}
    if notify_done and filled and remaining == 0:
        _notify('Hearth', _done_line(result))
    return result


def _jobs(store, force):
    attempts = loads(store.meta_get('art_backfill_attempts'), {}) or {}
    relevant = _relevant_show_ids(store)
    ranked = []
    for title in store.all_titles():
        rank = _rank(store, title['id'])
        played = _last_played(store, title)
        if needs_art(title['art']) and _allowed(attempts, 't%s' % title['id'], force):
            ranked.append((rank, played, title['id'], {
                'kind': 'title',
                'title': title,
                'episode': None,
                'label': title['title'] or 'Title'
            }))
        if title['media_type'] != 'show' or title['id'] not in relevant:
            continue
        for episode in _relevant_episodes(store, title['id']):
            if not needs_art(episode['art'], kind='thumb'):
                continue
            if not _allowed(attempts, 'e%s' % episode['id'], force):
                continue
            ranked.append((rank, played, episode['id'], {
                'kind': 'episode',
                'title': title,
                'episode': episode,
                'label': '%s %sx%s' % (
                    title['title'], episode['season'], episode['episode']
                )
            }))
    ranked.sort(key=lambda item: (item[0], item[1], item[2]))
    return [item[3] for item in ranked]


def needs_art(art_text, kind='poster'):
    data = loads(art_text, {}) or {}
    if str(data.get('no_artwork') or '') == '1':
        return False
    local = data.get(kind) or ''
    if local and not str(local).startswith('http') and Path(str(local)).is_file():
        return False
    return True


def _allowed(attempts, key, force):
    if force:
        return True
    try:
        count = int(attempts.get(key) or 0)
    except (TypeError, ValueError):
        count = 0
    return count < ATTEMPT_LIMIT


def _stopped(abort):
    return bool(abort and abort())


def _pause(sleeper, seconds, abort):
    '''Sleep in short slices so quit does not wait out the whole gap.'''
    left = float(seconds)
    while left > 0:
        if _stopped(abort):
            return False
        step = 0.1 if left > 0.1 else left
        sleeper(step)
        left -= step
    return True


def _fill(store, settings, guard, job, abort):
    if _stopped(abort):
        raise Aborted()
    key = (settings.get('tmdb_api_key') or '').strip()
    art_root = settings.get('art_dir') or _art_root()
    title = job['title']
    token = 't%s' % title['id'] if job['kind'] == 'title' else 'e%s' % job['episode']['id']
    try:
        if job['kind'] == 'title':
            ok = _fill_title(store, guard, key, art_root, title, abort)
        else:
            ok = _fill_episode(store, guard, key, art_root, title, job['episode'], abort)
    except Aborted:
        raise
    except (TmdbError, OSError, ValueError):
        ok = False
    _bump(store, token, reset=ok)
    return ok


def _fill_title(store, guard, key, art_root, title, abort):
    if _stopped(abort):
        raise Aborted()
    tmdb_id = title['tmdb'] or ''
    if not tmdb_id and title['imdb']:
        if _stopped(abort):
            raise Aborted()
        found = find_external(
            guard, key, title['imdb'], 'imdb_id', PURPOSE, title['imdb']
        )
        bucket = 'movie_results' if title['media_type'] == 'movie' else 'tv_results'
        hits = found.get(bucket) or []
        if not hits:
            _mark_no_art(store, title['id'], None)
            return True
        tmdb_id = str(hits[0].get('id'))
        store.update_title_fields(title['id'], tmdb=tmdb_id)
    if not tmdb_id:
        _mark_no_art(store, title['id'], None)
        return True
    if _stopped(abort):
        raise Aborted()
    if title['media_type'] == 'movie':
        payload = fetch_movie(guard, key, tmdb_id, PURPOSE, tmdb_id)
        fields = movie_fields(payload)
    else:
        payload = fetch_show(guard, key, tmdb_id, PURPOSE, tmdb_id)
        fields = show_fields(payload)
        fields.pop('seasons', None)
    images = fields.pop('images', {}) or {}
    _write_metadata(store, title['id'], fields)
    remote = _remote_map(images)
    if not remote:
        _mark_no_art(store, title['id'], None)
        return True
    _merge_title_art(store, title['id'], remote)
    if _stopped(abort):
        raise Aborted()
    saved = download_images(
        guard, art_root, title['media_type'], tmdb_id, images, PURPOSE, tmdb_id
    )
    if saved:
        _merge_title_art(store, title['id'], saved)
    return True


def _fill_episode(store, guard, key, art_root, title, episode, abort):
    if _stopped(abort):
        raise Aborted()
    tmdb_id = title['tmdb'] or ''
    if not tmdb_id:
        return False
    if _stopped(abort):
        raise Aborted()
    payload = fetch_season(
        guard, key, tmdb_id, int(episode['season']), PURPOSE, tmdb_id
    )
    match = None
    for row in payload.get('episodes') or []:
        if int(row.get('episode_number') or 0) == int(episode['episode']):
            match = row
            break
    if match is None:
        _mark_no_art(store, title['id'], episode)
        return True
    fields = episode_fields(match)
    images = fields.pop('images', {}) or {}
    updates = {}
    for name in ('title', 'first_aired', 'runtime_seconds', 'plot', 'tmdb'):
        if fields.get(name):
            updates[name] = fields[name]
    remote = {}
    still = images.get('thumb')
    if still:
        remote['thumb_path'] = still
        remote['thumb_url'] = image_url(still, 'thumb')
        remote['poster_url'] = remote['thumb_url']
    if remote:
        _merge_episode_art(store, title['id'], episode, remote)
    if still:
        if _stopped(abort):
            raise Aborted()
        saved = download_images(
            guard, art_root, 'episode',
            '%s-%sx%s' % (tmdb_id, episode['season'], episode['episode']),
            images, PURPOSE, tmdb_id
        )
        if saved:
            _merge_episode_art(store, title['id'], episode, saved)
    if updates or remote or still:
        if updates:
            store.upsert_episode(
                title['id'], int(episode['season']), int(episode['episode']), **updates
            )
        if updates.get('runtime_seconds'):
            from trakt.importer import apply_runtime
            apply_runtime(store, title['id'], episode['id'], updates['runtime_seconds'])
        return True
    _mark_no_art(store, title['id'], episode)
    return True


def _write_metadata(store, title_id, fields):
    updates = {}
    for name in (
        'plot', 'tagline', 'status', 'studio', 'original_language', 'premiered',
        'original_title', 'imdb', 'runtime_seconds'
    ):
        if fields.get(name):
            updates[name] = fields[name]
    if fields.get('year'):
        updates['year'] = fields['year']
    if fields.get('runtime_seconds'):
        updates['runtime_seconds'] = fields['runtime_seconds']
    if fields.get('genres'):
        updates['genres'] = dumps(fields['genres'])
    if updates:
        store.update_title_fields(title_id, **updates)
    if fields.get('runtime_seconds'):
        from trakt.importer import apply_runtime
        apply_runtime(store, title_id, None, fields['runtime_seconds'])


def _remote_map(images):
    remote = {}
    poster = images.get('poster')
    fanart = images.get('fanart')
    if poster:
        remote['poster_path'] = poster
        remote['poster_url'] = image_url(poster, 'poster')
    if fanart:
        remote['fanart_path'] = fanart
        remote['fanart_url'] = image_url(fanart, 'fanart')
    return remote


def remember_remote_art(store, title_id, poster_path=None, backdrop_path=None, episode=None):
    '''Store image URLs before the file download, so lists can show them now.'''
    images = {}
    if poster_path:
        images['poster'] = poster_path
    if backdrop_path:
        images['fanart'] = backdrop_path
    remote = _remote_map(images)
    if not remote:
        return
    if episode is None:
        _merge_title_art(store, title_id, remote)
    else:
        _merge_episode_art(store, title_id, episode, remote)


def _merge_title_art(store, title_id, mapping):
    current = loads(store.get_title(title_id)['art'], {}) or {}
    current.pop('no_artwork', None)
    current.update({key: value for key, value in mapping.items() if value})
    store.update_title_fields(title_id, art=dumps(current))


def _merge_episode_art(store, show_id, episode, mapping):
    fresh = store.get_episode(episode['id'])
    current = loads(fresh['art'], {}) or {}
    current.pop('no_artwork', None)
    current.update({key: value for key, value in mapping.items() if value})
    store.upsert_episode(
        show_id, int(fresh['season']), int(fresh['episode']), art=current
    )


def _mark_no_art(store, title_id, episode):
    if episode is None:
        current = loads(store.get_title(title_id)['art'], {}) or {}
        current['no_artwork'] = '1'
        store.update_title_fields(title_id, art=dumps(current))
        return
    fresh = store.get_episode(episode['id'])
    current = loads(fresh['art'], {}) or {}
    current['no_artwork'] = '1'
    store.upsert_episode(
        store.get_episode(episode['id']) and fresh['show_id'] or title_id,
        int(fresh['season']), int(fresh['episode']), art=current
    )


def _bump(store, token, reset):
    attempts = loads(store.meta_get('art_backfill_attempts'), {}) or {}
    if not isinstance(attempts, dict):
        attempts = {}
    if reset:
        attempts.pop(token, None)
    else:
        try:
            attempts[token] = int(attempts.get(token) or 0) + 1
        except (TypeError, ValueError):
            attempts[token] = 1
    store.meta_set('art_backfill_attempts', dumps(attempts))


def _relevant_show_ids(store):
    found = set()
    for slug in ('next_up', 'in_progress_movies'):
        for item in store.list_items(slug):
            if item['title_id']:
                found.add(item['title_id'])
    for title in store.all_titles('show'):
        for episode in store.episodes_for_show(title['id']):
            watch = store.get_watch(title['id'], episode['id'])
            if watch is None:
                continue
            if (watch['resume_seconds'] or 0) > 0 or (watch['play_count'] or 0) > 0:
                if (watch['resume_seconds'] or 0) > 0 and (watch['play_count'] or 0) == 0:
                    found.add(title['id'])
    return found


def _relevant_episodes(store, show_id):
    wanted = {}
    for item in store.list_items('next_up'):
        if item['title_id'] == show_id and item['episode_id']:
            episode = store.get_episode(item['episode_id'])
            if episode is not None:
                wanted[episode['id']] = episode
    for episode in store.episodes_for_show(show_id):
        watch = store.get_watch(show_id, episode['id'])
        if watch is None:
            continue
        resume = watch['resume_seconds'] or 0
        if resume > 0 and (watch['play_count'] or 0) == 0:
            wanted[episode['id']] = episode
    return list(wanted.values())


def _rank(store, title_id):
    for slug in ('next_up',):
        for item in store.list_items(slug):
            if item['title_id'] == title_id:
                return 0
    if store.in_list('in_progress_movies', title_id, None):
        return 1
    for row in store.all_lists():
        if store.in_list(row['slug'], title_id, None):
            return 2
    return 3


def _last_played(store, title):
    stamps = []
    watch = store.get_watch(title['id'], None)
    if watch is not None and watch['last_played']:
        stamps.append(watch['last_played'])
    if title['media_type'] == 'show':
        for episode in store.episodes_for_show(title['id']):
            row = store.get_watch(title['id'], episode['id'])
            if row is not None and row['last_played']:
                stamps.append(row['last_played'])
    if not stamps:
        return '0000'
    return min(stamps)


def _done_line(result):
    if result.get('remaining'):
        return 'Updated %s. %s still to go.' % (
            result.get('filled', 0), result.get('remaining')
        )
    if not result.get('filled'):
        return 'Artwork is already filled in.'
    return 'Artwork updated for %s titles.' % result.get('filled')


def _art_root():
    from paths import art_dir
    return art_dir()


def _notify(title, message):
    try:
        from plugin.kodiui import notify
        notify(title, message)
    except Exception:
        return
