'''Download TMDb Helper player files into the profile folder.'''

from __future__ import annotations

import io
import json
import zipfile
from pathlib import Path
from urllib.parse import urljoin, urlparse

from player.definitions import _read_player


def update_players(guard, url, dest_dir):
    '''Download a zip or one JSON file. Returns added, updated, and skipped counts.'''
    payload, name = _download(guard, url)
    dest = Path(dest_dir)
    dest.mkdir(parents=True, exist_ok=True)
    files = _files_from_download(payload, name)
    added = updated = skipped = 0
    for filename, raw in files:
        if not filename.lower().endswith('.json'):
            skipped += 1
            continue
        target = dest / Path(filename).name
        if _read_player_bytes(raw, target) is None:
            skipped += 1
            continue
        if target.exists() and target.read_bytes() == raw:
            continue
        existed = target.exists()
        target.write_bytes(raw)
        if existed:
            updated += 1
        else:
            added += 1
    return {'added': added, 'updated': updated, 'skipped': skipped}


def _download(guard, url, limit=5):
    current = url
    response = None
    for _ in range(limit):
        host = (urlparse(current).hostname or '').lower()
        if host:
            guard.allow_host(host)
        from network.guard import with_user_agent
        response = guard.get(current, 'explicit_action', headers=with_user_agent(None))
        status = int(getattr(response, 'status', 0) or 0)
        if status in (301, 302, 303, 307, 308):
            location = (response.headers or {}).get('location') or ''
            if not location:
                raise ValueError('The player download moved without a new address (%s).' % status)
            current = urljoin(current, location)
            continue
        if status < 200 or status >= 300:
            raise ValueError('The player download was refused (%s).' % status)
        content = response.content or b''
        if not content and isinstance(response.body, (bytes, bytearray)):
            content = bytes(response.body)
        if isinstance(response.body, dict):
            content = json.dumps(response.body).encode('utf-8')
        if not content:
            raise ValueError('The player download was empty.')
        name = current.rsplit('/', 1)[-1].split('?', 1)[0] or 'players.json'
        return content, name
    raise ValueError('The player download redirected too many times.')


def _files_from_download(payload, name):
    if payload[:2] == b'PK':
        archive = zipfile.ZipFile(io.BytesIO(payload))
        found = []
        for info in archive.infolist():
            if info.is_dir() or not info.filename.lower().endswith('.json'):
                continue
            found.append((Path(info.filename).name, archive.read(info)))
        return found
    return [(name if name.lower().endswith('.json') else 'player.json', payload)]


def _read_player_bytes(raw, path):
    try:
        text = raw.decode('utf-8')
        json.loads(text)
    except (UnicodeError, ValueError):
        return None
    fake = path
    # Validate through the same reader used at playback, without writing yet.
    folder = path.parent
    folder.mkdir(parents=True, exist_ok=True)
    temporary = folder / ('.' + path.name + '.check')
    try:
        temporary.write_text(text, encoding='utf-8')
        return _read_player(temporary, 'user')
    finally:
        if temporary.exists():
            temporary.unlink()
