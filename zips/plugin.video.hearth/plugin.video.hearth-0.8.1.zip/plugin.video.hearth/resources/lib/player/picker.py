'''Choose a player. A saved default skips the dialog. Last-used only preselects.'''

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class PickerResult:
    show_dialog: bool
    player: object
    choices: list
    preselect: int


def choose_player(players, media_type, default_id='', last_used_id='', installed=None):
    installed = set(installed or [])
    valid = [
        player for player in players
        if player.plugin in installed and player.template_for(media_type)
    ]
    valid.sort(key=lambda player: (-player.priority, player.name.lower()))
    if default_id:
        for player in valid:
            if player.id == default_id or player.plugin == default_id:
                return PickerResult(False, player, valid, 0)
    preselect = 0
    for index, player in enumerate(valid):
        if last_used_id and (player.id == last_used_id or player.plugin == last_used_id):
            preselect = index
            break
    return PickerResult(True, None, valid, preselect)


def resolve_play_url(players, media_type, values, default_id='', last_used_id='',
                     installed=None, picked_id=None):
    '''Return (player, url, showed_dialog). picked_id is the dialog result.'''
    from player.definitions import build_play_url
    result = choose_player(
        players, media_type, default_id, last_used_id, installed
    )
    player = result.player
    showed = result.show_dialog
    if result.show_dialog:
        if not picked_id:
            return None, '', True
        player = next(
            (
                item for item in result.choices
                if item.id == picked_id or item.plugin == picked_id
            ),
            None
        )
        if player is None:
            return None, '', True
    if player is None:
        return None, '', showed
    url = build_play_url(player.template_for(media_type), values)
    return player, url, showed
