'''Track a video that Hearth did not launch, and offer the local resume point.'''

from __future__ import annotations

import threading

from nextup.algorithm import fraction

MIN_RUNTIME_SECONDS = 5 * 60
ALREADY_RESUMED_SECONDS = 10
SKIP_MEDIA = {
    'livetv', 'pvr', 'channel', 'music', 'song', 'audio', 'musicvideo', 'trailer'
}


def format_clock(seconds):
    total = max(0, int(round(float(seconds or 0))))
    minutes, secs = divmod(total, 60)
    hours, minutes = divmod(minutes, 60)
    if hours:
        return '%d:%02d:%02d' % (hours, minutes, secs)
    return '%d:%02d' % (minutes, secs)


def resume_labels(seconds):
    return ['Resume from %s' % format_clock(seconds), 'Start from beginning']


def skip_reason(playing):
    '''None when this playing item should be tracked.'''
    playing = playing or {}
    media = (playing.get('mediatype') or '').strip().lower()
    path = (playing.get('path') or '').strip().lower()
    title = (playing.get('title') or '').strip().lower()
    if media in SKIP_MEDIA:
        return media or 'skipped'
    if path.startswith('pvr://') or path.startswith('rtsp://') or path.startswith('live://'):
        return 'pvr'
    if 'trailer' in path or title == 'trailer' or title.endswith(' trailer'):
        return 'trailer'
    if not any(playing.get(key) for key in ('imdb', 'tmdb', 'tvdb')):
        return 'no-ids'
    runtime = float(playing.get('duration') or 0)
    if 0 < runtime < MIN_RUNTIME_SECONDS:
        return 'short'
    return None


def is_episode(playing):
    media = (playing.get('mediatype') or '').strip().lower()
    if media in ('episode', 'tvshow'):
        return True
    if playing.get('showtitle') and playing.get('episode') is not None:
        return True
    return False


def adopt_playing(store, playing):
    '''Match or create a local title. Returns None when the item should be ignored.'''
    playing = playing or {}
    reason = skip_reason(playing)
    if reason:
        return None
    imdb = playing.get('imdb') or None
    tmdb = playing.get('tmdb') or None
    tvdb = playing.get('tvdb') or None
    episode_mode = is_episode(playing)
    created = False
    episode_id = None
    if episode_mode:
        show = _find_show(store, imdb, tmdb, tvdb)
        if show is None:
            linked = _find_episode_by_ids(store, imdb, tmdb, tvdb)
            if linked is not None:
                show = store.get_title(linked['show_id'])
                episode_id = linked['id']
        if show is None:
            show_id = store.upsert_title(
                media_type='show',
                title=playing.get('showtitle') or playing.get('title') or 'Untitled',
                imdb=imdb,
                tmdb=tmdb,
                tvdb=tvdb,
                runtime_seconds=_runtime(playing)
            )
            created = True
        else:
            show_id = show['id']
        season = int(playing.get('season') or 0)
        number = int(playing.get('episode') or 0)
        if episode_id is None:
            episode_id = store.upsert_episode(
                show_id, season, number,
                title=playing.get('title') or '',
                runtime_seconds=_runtime(playing),
                imdb=imdb,
                tmdb=tmdb,
                tvdb=tvdb
            )
        title_id = show_id
        media_type = 'episode'
    else:
        movie = store.find_title(media_type='movie', imdb=imdb, tmdb=tmdb, tvdb=tvdb)
        if movie is None:
            title_id = store.upsert_title(
                media_type='movie',
                title=playing.get('title') or 'Untitled',
                imdb=imdb,
                tmdb=tmdb,
                tvdb=tvdb,
                runtime_seconds=_runtime(playing)
            )
            created = True
        else:
            title_id = movie['id']
        media_type = 'movie'
    watch = store.get_watch(title_id, episode_id)
    resume = float(watch['resume_seconds'] or 0) if watch is not None else 0
    runtime = 0
    if watch is not None and watch['runtime_seconds']:
        runtime = float(watch['runtime_seconds'])
    if not runtime:
        runtime = float(playing.get('duration') or 0)
    return {
        'title_id': title_id,
        'episode_id': episode_id,
        'resume_seconds': resume,
        'runtime_seconds': runtime,
        'created': created,
        'media_type': media_type,
        'identifiers': {
            'media_type': media_type,
            'title': playing.get('showtitle') or playing.get('title') or '',
            'imdb': imdb,
            'tmdb': tmdb,
            'tvdb': tvdb,
            'season': playing.get('season'),
            'episode': playing.get('episode')
        }
    }


def queue_metadata_fill(store, settings, identifiers, starter=None):
    '''TMDB art and metadata. Returns before any request finishes.'''
    if starter is not None:
        starter(identifiers)
        return {'queued': True}

    if not (settings.get('tmdb_api_key') or '').strip():
        return {'queued': False, 'reason': 'no-key'}

    def run():
        try:
            from context.actions import _fetch_one
            from network.guard import active_guard
            from paths import art_dir
            _fetch_one(store, settings, active_guard(), art_dir(), identifiers)
        except Exception:
            return

    threading.Thread(target=run, daemon=True, name='hearth-metadata').start()
    return {'queued': True}


def resume_action(settings, resume_seconds, runtime):
    '''ask, auto, off, or none when there is nothing above the floor to offer.'''
    behavior = (settings.get('resume_behavior') or 'seek_after_start').strip()
    if behavior in ('let_player', 'off'):
        return 'off'
    resume = float(resume_seconds or 0)
    if resume <= 0:
        return 'none'
    total = float(runtime or 0)
    if total and fraction(resume, total) < settings.floor:
        return 'none'
    if behavior == 'ask':
        return 'ask'
    return 'auto'


def offer_resume(player, settings, resume_seconds, runtime, position, ask):
    '''Seek to the local point, or ask. Skip when playback is already underway.'''
    if position is not None and float(position) > ALREADY_RESUMED_SECONDS:
        return 'skipped'
    action = resume_action(settings, resume_seconds, runtime)
    if action == 'auto' and player is not None:
        player.seekTime(float(resume_seconds))
        return 'seek'
    if action == 'ask':
        choice = ask(float(resume_seconds)) if ask else 'beginning'
        if choice == 'resume' and player is not None:
            player.seekTime(float(resume_seconds))
            return 'seek'
        return 'beginning'
    return action


def _runtime(playing):
    duration = float(playing.get('duration') or 0)
    if duration <= 0:
        return None
    return int(duration)


def _find_show(store, imdb, tmdb, tvdb):
    return store.find_title(media_type='show', imdb=imdb, tmdb=tmdb, tvdb=tvdb)


def _find_episode_by_ids(store, imdb, tmdb, tvdb):
    if not any((imdb, tmdb, tvdb)):
        return None
    finder = getattr(store, 'find_episode_by_ids', None)
    if finder is None:
        return None
    return finder(imdb=imdb, tmdb=tmdb, tvdb=tvdb)
