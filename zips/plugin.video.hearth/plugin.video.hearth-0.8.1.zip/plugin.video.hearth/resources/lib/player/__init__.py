'''Player definitions, the picker, and the local playback monitor.'''
