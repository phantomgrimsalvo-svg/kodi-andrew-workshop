'''Off-device recommendation exchange.'''
