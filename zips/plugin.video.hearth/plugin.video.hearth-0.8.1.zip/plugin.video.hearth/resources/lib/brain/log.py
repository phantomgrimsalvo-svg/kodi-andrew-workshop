'''Local ratings.jsonl. Append-only. Sync uploads lines not yet sent.'''

from __future__ import annotations

import json
import uuid
from pathlib import Path

from paths import profile_dir
from util import iso


def inbox_dir():
    path = profile_dir() / 'inbox'
    path.mkdir(parents=True, exist_ok=True)
    return path


def outbox_dir():
    path = profile_dir() / 'outbox'
    path.mkdir(parents=True, exist_ok=True)
    return path


def ratings_path():
    return inbox_dir() / 'ratings.jsonl'


def wanted_path():
    return inbox_dir() / 'lists_wanted.json'


def synced_path():
    return inbox_dir() / 'synced_ids.txt'


def picks_path():
    return outbox_dir() / 'picks.json'


def taste_path():
    return outbox_dir() / 'taste.md'


def _as_v2(row):
    '''v1 lines stay on disk. Readers see rewatch_ok.'''
    if 'rewatch' in row and 'rewatch_ok' not in row:
        row = dict(row)
        row['rewatch_ok'] = bool(row.get('rewatch'))
    return row


def new_event_id():
    return str(uuid.uuid4())


def append_event(event):
    '''Write one line immediately. Returns the event id.'''
    row = dict(event)
    row['schema'] = 'hearth.ratings.v2'
    if 'rewatch' in row and 'rewatch_ok' not in row:
        row['rewatch_ok'] = bool(row.get('rewatch'))
    row.pop('rewatch', None)
    if not row.get('event_id'):
        row['event_id'] = new_event_id()
    if not row.get('watched_at') and row.get('type') == 'rating':
        row['watched_at'] = iso()
    if row.get('type') == 'never_watched' and not row.get('at'):
        row['at'] = iso()
    line = json.dumps(row, ensure_ascii=False, sort_keys=True)
    path = ratings_path()
    with path.open('a', encoding='utf-8') as handle:
        handle.write(line + '\n')
    return row['event_id']


def read_events():
    path = ratings_path()
    if not path.exists():
        return []
    rows = []
    for line in path.read_text(encoding='utf-8').splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            row = json.loads(line)
        except ValueError:
            continue
        if isinstance(row, dict) and row.get('event_id'):
            rows.append(_as_v2(row))
    return rows


def synced_ids():
    path = synced_path()
    if not path.exists():
        return set()
    return {line.strip() for line in path.read_text(encoding='utf-8').splitlines() if line.strip()}


def mark_synced(event_ids):
    known = synced_ids()
    known.update(str(item) for item in event_ids if item)
    synced_path().write_text('\n'.join(sorted(known)) + ('\n' if known else ''), encoding='utf-8')


def unsynced_events():
    done = synced_ids()
    return [row for row in read_events() if row.get('event_id') not in done]


def write_wanted(document):
    wanted_path().write_text(
        json.dumps(document, ensure_ascii=False, indent=2, sort_keys=True) + '\n',
        encoding='utf-8'
    )
    return wanted_path()


def read_wanted():
    path = wanted_path()
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding='utf-8'))
    except ValueError:
        return None
    return data if isinstance(data, dict) else None


def write_picks(document):
    picks_path().write_text(
        json.dumps(document, ensure_ascii=False, indent=2, sort_keys=True) + '\n',
        encoding='utf-8'
    )


def read_picks():
    path = picks_path()
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding='utf-8'))
    except ValueError:
        return None
    return data if isinstance(data, dict) else None


def write_taste(text):
    taste_path().write_text(text or '', encoding='utf-8')


def read_taste():
    path = taste_path()
    if not path.exists():
        return ''
    return path.read_text(encoding='utf-8')
