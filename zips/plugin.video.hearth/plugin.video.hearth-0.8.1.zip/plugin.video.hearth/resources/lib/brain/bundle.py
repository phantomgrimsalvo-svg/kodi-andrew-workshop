'''Taste bundle v1. The document the Brain reads. No secrets.'''

from __future__ import annotations

from util import iso, loads

SCHEMA_VERSION = 1


def build_bundle(store, settings, now=None, version='dev'):
    now = now or iso()
    document = store.export_document()
    titles = {row['id']: row for row in document['titles']}
    episodes = {row['id']: row for row in document['episodes']}
    ratings = [_rating(row, titles, episodes) for row in document['ratings']]
    ratings = [row for row in ratings if row]
    journal = [_journal(row, titles) for row in store.journal_entries(1000)]
    watches = [_watch(row, titles, episodes) for row in document['watch_state']]
    return {
        'schema_version': SCHEMA_VERSION,
        'generated_at': now,
        'hearth_version': version,
        'settings': {
            'year_min': settings.integer('recs_year_min', 0),
            'year_max': settings.integer('recs_year_max', 0),
            'moods': settings.get('recs_moods') or '',
            'pick_count': settings.integer('recs_pick_count', 60),
            'rewatch_boost': settings.integer('recs_rewatch_boost', 1),
            'unfinished_counts': settings.flag('recs_unfinished_counts', False),
            'rows': {
                'for_you': settings.flag('recs_row_for_you', True),
                'twins': settings.flag('recs_row_twins', True),
                'because': settings.flag('recs_row_because', True),
                'gems': settings.flag('recs_row_gems', True),
                'movies': settings.flag('recs_row_movies', True),
                'shows': settings.flag('recs_row_shows', True),
                'mood': settings.flag('recs_row_mood', True)
            }
        },
        'ratings': ratings,
        'journal': journal,
        'ai_notes': store.meta_get('ai_notes') or '',
        'watch_history': [row for row in watches if row and row.get('play_count')],
        'in_progress': [row for row in watches if row and row.get('in_progress')],
        'watchlist': _list_titles(store, document, 'watchlist'),
        'dismissed': _list_titles(store, document, 'dismissed') + _list_titles(
            store, document, 'never_show'
        ),
        'already_recommended': _recommended(store, document)
    }


def journal_ids(store):
    return [int(row['id']) for row in store.journal_entries(5000)]


def _rating(row, titles, episodes):
    title = titles.get(row['title_id'])
    if title is None or row.get('score') is None:
        return None
    episode = episodes.get(row.get('episode_id'))
    item = {
        'title': title['title'],
        'year': title.get('year'),
        'media_type': title['media_type'],
        'tmdb': title.get('tmdb'),
        'imdb': title.get('imdb'),
        'trakt': title.get('trakt_id'),
        'score': row.get('score'),
        'liked': row.get('liked') or '',
        'disliked': row.get('disliked') or '',
        'thoughts': row.get('thoughts') or '',
        'tags': loads(row.get('tags'), []) or [],
        'season': row.get('season'),
        'rated_at': row.get('rated_at') or '',
        'source': row.get('source') or ''
    }
    if episode is not None:
        item['episode'] = int(episode['episode'])
        item['season'] = int(episode['season'])
    return item


def _journal(row, titles):
    title = titles.get(row['title_id'])
    return {
        'id': row['id'],
        'created_at': row['created_at'],
        'title': title['title'] if title is not None else '',
        'score': row['score'],
        'liked': row['liked'] or '',
        'disliked': row['disliked'] or '',
        'thoughts': row['thoughts'] or '',
        'note': row['note'] or '',
        'source': row['source'] or ''
    }


def _watch(row, titles, episodes):
    title = titles.get(row['title_id'])
    if title is None:
        return None
    episode = episodes.get(row.get('episode_id'))
    play_count = int(row.get('play_count') or 0)
    resume = float(row.get('resume_seconds') or 0)
    return {
        'title': title['title'],
        'year': title.get('year'),
        'media_type': title['media_type'],
        'tmdb': title.get('tmdb'),
        'imdb': title.get('imdb'),
        'play_count': play_count,
        'last_played': row.get('last_played') or '',
        'completed': play_count > 0 and resume <= 0,
        'dropped': bool(title.get('needs_fixup')),
        'rewatches': max(0, play_count - 1),
        'in_progress': resume > 0 and play_count == 0,
        'season': int(episode['season']) if episode is not None else None,
        'episode': int(episode['episode']) if episode is not None else None
    }


def _list_titles(store, document, slug):
    titles = {row['id']: row for row in document['titles']}
    found = []
    try:
        items = store.list_items(slug)
    except Exception:
        return found
    for item in items:
        title = titles.get(item['title_id'])
        if title is None:
            continue
        found.append({
            'title': title['title'],
            'year': title.get('year'),
            'media_type': title['media_type'],
            'tmdb': title.get('tmdb'),
            'reason': item.get('reason') or ''
        })
    return found


def _recommended(store, document):
    titles = {row['id']: row for row in document['titles']}
    found = []
    seen = set()
    for row in document['lists']:
        slug = str(row.get('slug') or '')
        if not slug.startswith('recs'):
            continue
        try:
            items = store.list_items(slug)
        except Exception:
            continue
        for item in items:
            title = titles.get(item['title_id'])
            if title is None:
                continue
            key = (title['media_type'], title.get('tmdb') or title['title'])
            if key in seen:
                continue
            seen.add(key)
            found.append({
                'title': title['title'],
                'year': title.get('year'),
                'media_type': title['media_type'],
                'tmdb': title.get('tmdb'),
                'slug': slug
            })
    return found
