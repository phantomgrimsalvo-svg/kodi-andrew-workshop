'''lists_wanted.json built from the Grok Bot list settings.'''

from __future__ import annotations

import json

from brain.log import read_wanted, write_wanted
from util import iso

LISTS = (
    ('for_you', 'For you', 'both', True, ''),
    ('movies', 'Movies', 'movie', True, ''),
    ('shows', 'Shows', 'tv', True, ''),
    ('gems', 'Hidden gems', 'both', True, ''),
    ('cult_classics', 'Cult classics', 'both', False, ''),
    ('custom_1', 'Custom list 1', 'both', False, ''),
    ('custom_2', 'Custom list 2', 'both', False, '')
)


def lists_wanted(settings, version='0.8.1', now=None):
    rows = []
    for key, default_name, default_media, default_on, _request in LISTS:
        enabled = settings.flag('gl_%s_enabled' % key, default_on)
        name = (settings.get('gl_%s_name' % key) or default_name).strip() or default_name
        media = (settings.get('gl_%s_media' % key) or default_media).strip().lower()
        if media not in ('movie', 'tv', 'both'):
            media = default_media
        kind = 'custom' if key.startswith('custom_') else key
        rows.append({
            'schema': 'hearth.list_request.v1',
            'list_id': key,
            'name': name,
            'enabled': bool(enabled),
            'kind': kind,
            'size': _bound(settings.integer('gl_%s_size' % key, 20), 5, 60),
            'media_type': media,
            'year_from': _year(settings.integer('gl_%s_year_from' % key, 0)),
            'year_to': _year(settings.integer('gl_%s_year_to' % key, 0)),
            'genres_include': _words(settings.get('gl_%s_genres' % key)),
            'genres_exclude': _words(settings.get('gl_%s_genres_exclude' % key)),
            'min_rating': _bound(settings.integer('gl_%s_min_rating' % key, 0), 0, 10),
            'min_vote_count': max(0, settings.integer('gl_%s_min_votes' % key, 0)),
            'language': (settings.get('gl_%s_language' % key) or '').strip().lower(),
            'request': (settings.get('gl_%s_request' % key) or '').strip()
        })
    return {
        'schema': 'hearth.lists_wanted.v1',
        'app_version': version,
        'updated_at': now or iso(),
        'lists': rows
    }


def refresh_wanted(store, settings, version='0.8.1'):
    '''Rewrite the local file when the list settings changed.'''
    document = lists_wanted(settings, version=version)
    fingerprint = json.dumps(document['lists'], sort_keys=True)
    if store.meta_get('lists_wanted_hash') == fingerprint and read_wanted():
        return False
    write_wanted(document)
    store.meta_set('lists_wanted_hash', fingerprint)
    store.meta_set('lists_wanted_at', document['updated_at'])
    return True


def _words(value):
    return [part.strip() for part in (value or '').split(',') if part.strip()]


def _year(value):
    number = int(value or 0)
    if number <= 0:
        return 0
    return number


def _bound(value, low, high):
    try:
        number = int(value)
    except (TypeError, ValueError):
        number = low
    return max(low, min(high, number))
