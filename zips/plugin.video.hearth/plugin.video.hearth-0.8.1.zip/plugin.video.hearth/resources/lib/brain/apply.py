'''Read picks.json into local lists. No model calls. Unknown items are skipped.'''

from __future__ import annotations


def apply_picks(store, document):
    if not isinstance(document, dict) or document.get('schema') != 'hearth.picks.v1':
        return {'failed': 'picks.json is not hearth.picks.v1'}
    placed = 0
    kept_slugs = []
    for row in document.get('lists') or []:
        if not isinstance(row, dict):
            continue
        list_id = str(row.get('list_id') or '').strip()
        if not list_id:
            continue
        slug = 'grok_%s' % _safe(list_id)
        name = str(row.get('name') or list_id)
        items = []
        for item in row.get('items') or []:
            if not isinstance(item, dict):
                continue
            title_id = _title(store, item, list_id)
            if title_id is None:
                continue
            items.append({
                'title_id': title_id,
                'episode_id': None,
                'reason': str(item.get('reason') or ''),
                'detail': {
                    'list_id': list_id,
                    'why': str(item.get('reason') or ''),
                    'tmdb': str(item.get('tmdb_id') or ''),
                    'media_type': _media(item.get('media_type')),
                    'reason_tags': item.get('reason_tags') or [],
                    'source': 'grok'
                }
            })
        store.ensure_list(slug, name, show=True)
        store.replace_list_items(slug, items)
        store.set_list_menu(slug, True, name)
        kept_slugs.append(slug)
        placed += len(items)
    return {
        'placed': placed,
        'lists': len(kept_slugs),
        'generated_at': str(document.get('generated_at') or ''),
        'slugs': kept_slugs
    }


def _title(store, item, list_id):
    media = _media(item.get('media_type'))
    tmdb = str(item.get('tmdb_id') or '').strip()
    title = str(item.get('title') or '').strip()
    if not tmdb or not title or media not in ('movie', 'show'):
        return None
    existing = store.find_title(media_type=media, tmdb=tmdb)
    if existing is not None:
        return existing['id']
    return store.upsert_title(
        media_type=media, title=title, year=item.get('year'), tmdb=tmdb
    )


def _media(value):
    text = str(value or '').strip().lower()
    if text in ('tv', 'show', 'series'):
        return 'show'
    if text == 'movie':
        return 'movie'
    return ''


def _safe(value):
    return ''.join(ch if ch.isalnum() or ch == '_' else '_' for ch in value)[:40]
