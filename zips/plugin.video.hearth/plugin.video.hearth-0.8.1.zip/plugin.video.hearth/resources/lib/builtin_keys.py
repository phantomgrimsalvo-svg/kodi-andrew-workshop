'''Built-in app credentials.

Empty until Andrew registers the apps. A blank user setting falls back to
these. A value typed under Advanced replaces the built-in one.
'''

TRAKT_CLIENT_ID = 'kwwSp-7QX36LaLxdf8bYUdZlws5_YleVIvmbSm4HG1I'
# Trakt public apps use PKCE and do not issue a client secret.
TRAKT_CLIENT_SECRET = ''
SIMKL_CLIENT_ID = ''
TMDB_API_KEY = ''

FALLBACK = {
    'trakt_client_id': TRAKT_CLIENT_ID,
    'trakt_client_secret': TRAKT_CLIENT_SECRET,
    'simkl_client_id': SIMKL_CLIENT_ID,
    'tmdb_api_key': TMDB_API_KEY
}
