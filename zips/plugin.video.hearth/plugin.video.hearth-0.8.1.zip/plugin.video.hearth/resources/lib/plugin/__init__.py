'''Plugin directory builders. Pure data in, payload dicts out.'''
