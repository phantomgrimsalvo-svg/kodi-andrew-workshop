'''Thin Kodi UI wrappers around the pure library.'''

from __future__ import annotations

import secrets

from util import dumps, iso


def directory(handle, payloads, folder=False):
    import xbmcplugin
    if handle is None or int(handle) < 0:
        return payloads
    for payload in payloads:
        item = _listitem(payload)
        is_folder = bool(payload.get('is_folder'))
        xbmcplugin.addDirectoryItem(
            int(handle), payload.get('path') or payload.get('file') or '',
            item, isFolder=is_folder
        )
    xbmcplugin.setContent(int(handle), 'movies' if not folder else 'files')
    xbmcplugin.endOfDirectory(int(handle), succeeded=True, cacheToDisc=False)
    return payloads


def _listitem(payload):
    import xbmcgui
    item = xbmcgui.ListItem(
        label=payload.get('label') or payload.get('title') or '',
        offscreen=True,
        path=payload.get('path') or payload.get('file') or ''
    )
    art = payload.get('art') or {}
    if art:
        item.setArt(art)
    if payload.get('is_playable'):
        item.setProperty('IsPlayable', 'true')
    path = payload.get('path') or ''
    slug = payload.get('list_slug') or ''
    if not slug and '/list/' in path:
        slug = path.rstrip('/').split('/')[-1]
    menus = []
    if slug:
        menus.append((
            'Show this list as an Android TV channel',
            'RunPlugin(plugin://plugin.video.hearth/action/toggle_channel/%s)' % slug
        ))
    if payload.get('can_remove') and slug:
        menus.append((
            'Remove from Hearth',
            'RunPlugin(plugin://plugin.video.hearth/action/remove_list/%s)' % slug
        ))
    for label, command in payload.get('context') or []:
        menus.append((label, command))
    if menus:
        item.addContextMenuItems(menus)
    show_id = _show_id_from_hearth_path(path)
    if show_id is not None and payload.get('mediatype') in ('episode', 'tvshow', 'season'):
        item.addContextMenuItems([
            (
                'Hearth Next Up…',
                'RunPlugin(plugin://plugin.video.hearth/action/nextup_menu/%s)' % show_id
            )
        ])
    tag = item.getVideoInfoTag()
    tag.setTitle(payload.get('title') or '')
    tag.setPlot(payload.get('plot') or '')
    tag.setYear(int(payload.get('year') or 0))
    tag.setPremiered(payload.get('premiered') or '')
    tag.setMpaa(payload.get('mpaa') or '')
    tag.setGenres(list(payload.get('genre') or []))
    tag.setTvShowTitle(payload.get('tvshowtitle') or payload.get('showtitle') or '')
    if payload.get('season') is not None:
        tag.setSeason(int(payload.get('season') or 0))
    if payload.get('episode') is not None:
        tag.setEpisode(int(payload.get('episode') or 0))
    tag.setMediaType(payload.get('mediatype') or '')
    tag.setDuration(int(payload.get('runtime') or 0))
    tag.setPlaycount(int(payload.get('playcount') or 0))
    if payload.get('lastplayed'):
        tag.setLastPlayed(payload.get('lastplayed'))
    resume = payload.get('resume') or {}
    if resume.get('position'):
        position = float(resume.get('position') or 0)
        total = float(resume.get('total') or 0)
        tag.setResumePoint(position, total)
        item.setProperty('ResumeTime', str(int(position)))
        item.setProperty('TotalTime', str(int(total or 0)))
    if payload.get('label2') and hasattr(item, 'setLabel2'):
        item.setLabel2(payload.get('label2'))
    tag.setUniqueIDs(payload.get('uniqueid') or {})
    if payload.get('userrating'):
        tag.setUserRating(int(payload.get('userrating') or 0))
    if payload.get('studio'):
        tag.setStudios([payload.get('studio')])
    return item


def _show_id_from_hearth_path(path):
    if 'plugin.video.hearth' not in (path or ''):
        return None
    bits = [part for part in path.split('/') if part]
    try:
        index = bits.index('plugin.video.hearth')
    except ValueError:
        return None
    rest = bits[index + 1:]
    if len(rest) >= 2 and rest[0] in ('play', 'show') and str(rest[1]).isdigit():
        return int(rest[1])
    return None


def show_nextup_menu(store, settings, show_id):
    import xbmc
    import xbmcgui
    from nextup.mode import MODES, set_nextup_mode, set_place
    title = store.get_title(int(show_id))
    if title is None or title['media_type'] != 'show':
        notify('Hearth', 'Next Up applies to a show.')
        return
    current = (title['nextup_mode'] or 'normal') if 'nextup_mode' in title.keys() else 'normal'
    labels = [
        'Normal' + (' (current)' if current == 'normal' else ''),
        'Random' + (' (current)' if current == 'random' else ''),
        'Pick every time' + (' (current)' if current == 'pick' else ''),
        'Set my place…'
    ]
    index = xbmcgui.Dialog().select('Next Up for %s' % title['title'], labels)
    if index is None or index < 0:
        return
    if index < 3:
        set_nextup_mode(store, settings, title['id'], MODES[index])
        xbmc.executebuiltin('Container.Refresh')
        notify('Hearth', '%s is now %s.' % (title['title'], labels[index].split(' (')[0]))
        return
    season = xbmcgui.Dialog().numeric(0, 'Season number', '1')
    episode = xbmcgui.Dialog().numeric(0, 'Episode number', '1')
    try:
        season_n = int(season or 0)
        episode_n = int(episode or 0)
    except (TypeError, ValueError):
        notify('Hearth', 'Enter a season and episode number.')
        return
    if season_n < 0 or episode_n < 1:
        notify('Hearth', 'Enter a season and episode number.')
        return
    try:
        set_place(store, settings, title['id'], season_n, episode_n)
    except KeyError:
        notify('Hearth', 'That episode is not in Hearth.')
        return
    xbmc.executebuiltin('Container.Refresh')
    notify('Hearth', 'Next Up for %s now starts from S%sE%s.' % (
        title['title'], season_n, episode_n
    ))


def confirm_remove_list(store, settings, slug):
    row = store.list_row(slug)
    if row is None or int(row['is_system'] or 0):
        notify('Hearth', 'That list stays.')
        return
    import xbmc
    import xbmcgui
    allowed = xbmcgui.Dialog().yesno('Hearth', 'Remove %s from Hearth?' % row['name'])
    if not allowed:
        return
    from context.actions import remove_user_list
    remove_user_list(store, settings, slug)
    xbmc.executebuiltin('Container.Refresh')
    notify('Hearth', 'Removed %s.' % row['name'])


def notify(title, message):
    try:
        import xbmcgui
        xbmcgui.Dialog().notification(title, message, sound=False)
    except Exception:
        return


def show_text(title, text):
    import xbmcgui
    xbmcgui.Dialog().textviewer(title, text)


def pick_folder(heading):
    import xbmcgui
    return xbmcgui.Dialog().browse(0, heading, 'files', '', True, False, '')


def pick_version(names):
    import xbmcgui
    index = xbmcgui.Dialog().select('Choose a backup', names)
    if index is None or index < 0:
        return None
    return names[index]


def play_with_picker(store, settings, title_id, episode_id, picked_id):
    from player.definitions import load_players, values_for
    from player.picker import resolve_play_url
    title = store.get_title(title_id)
    if title is None:
        notify('Hearth', 'That title is not in the local library.')
        return
    episode = store.get_episode(episode_id) if episode_id else None
    media_type = 'episode' if episode is not None else title['media_type']
    if media_type == 'show':
        notify('Hearth', 'Open Next Up to play the episode you are on.')
        return
    players = load_players(
        __import__('paths').bundled_players_dir(),
        __import__('paths').user_players_dir()
    )
    installed = _installed([player.plugin for player in players])
    default_key = 'default_player_episode' if media_type == 'episode' else 'default_player_movie'
    last_key = 'last_player_episode' if media_type == 'episode' else 'last_player_movie'
    player, url, showed = resolve_play_url(
        players, media_type, values_for(title, episode),
        default_id=settings.get(default_key),
        last_used_id=_last_player(store, settings, last_key),
        installed=installed,
        picked_id=picked_id
    )
    if showed and not picked_id:
        import xbmcgui
        labels = [item.name for item in load_players(
            __import__('paths').bundled_players_dir(),
            __import__('paths').user_players_dir()
        ) if item.plugin in installed]
        # Recompute choices from the same filter the picker used.
        from player.picker import choose_player
        result = choose_player(
            players, media_type, '', _last_player(store, settings, last_key), installed
        )
        labels = [item.name for item in result.choices]
        if not labels:
            notify('Hearth', 'No player add-on is installed. Add a player JSON file.')
            return
        index = xbmcgui.Dialog().select('Play with', labels, preselect=result.preselect)
        if index is None or index < 0:
            return
        player = result.choices[index]
        from player.definitions import build_play_url
        url = build_play_url(player.template_for(media_type), values_for(title, episode))
    if not player or not url:
        notify('Hearth', 'Hearth could not build a play link for that player.')
        return
    settings.set(last_key, player.id)
    store.meta_set(last_key, player.id)
    watch = store.get_watch(title['id'], episode['id'] if episode is not None else None)
    resume = float(watch['resume_seconds'] or 0) if watch is not None else 0
    store.meta_set('active_session', dumps({
        'title_id': title['id'],
        'episode_id': episode['id'] if episode is not None else None,
        'resume_seconds': resume,
        'player_id': player.id,
        'started_at': iso(),
        'token': secrets.token_hex(8)
    }))
    return url


def show_fixup(store, settings, show_id):
    from nextup.fixup import apply_fixup, describe_fixup
    title = store.get_title(show_id)
    if title is None:
        return
    reasons = [part for part in (title['needs_fixup'] or '').split(',') if part]
    import xbmcgui
    xbmcgui.Dialog().textviewer(title['title'], describe_fixup(title['title'], reasons))
    choice = xbmcgui.Dialog().select(title['title'], [
        "I'm on episode…",
        "I'm rewatching from…",
        'I watched out of order on purpose',
        'Mark everything before… watched',
        'Skip this show for now'
    ])
    actions = ('on_episode', 'rewatch', 'out_of_order', 'mark_before', 'skip')
    if choice is None or choice < 0:
        return
    action = actions[choice]
    if action == 'skip':
        apply_fixup(store, settings, show_id, 'skip', 1, 1)
        return
    season = xbmcgui.Dialog().numeric(0, 'Season number', '1')
    episode = xbmcgui.Dialog().numeric(0, 'Episode number', '1')
    try:
        season_n = int(season or 1)
        episode_n = int(episode or 1)
    except ValueError:
        notify('Hearth', 'Enter a season and episode number.')
        return
    confirm = False
    if action in ('on_episode', 'mark_before'):
        confirm = bool(xbmcgui.Dialog().yesno(
            title['title'],
            'Also clear watched marks after this episode?'
        ))
    apply_fixup(
        store, settings, show_id, action, season_n, episode_n, confirm_unwatch=confirm
    )


def _installed(plugin_ids):
    import xbmcaddon
    ready = set()
    for plugin_id in plugin_ids:
        try:
            xbmcaddon.Addon(plugin_id)
            ready.add(plugin_id)
        except Exception:
            continue
    return ready


def manage_players(store, settings):
    import xbmc
    import xbmcgui
    from paths import user_players_dir
    choice = xbmcgui.Dialog().select('Manage players', [
        'Choose default movie player',
        'Choose default episode player',
        'Update players from URL',
        'Open players folder'
    ])
    if choice == 0:
        _choose_default_player(settings, 'movie', 'default_player_movie')
    elif choice == 1:
        _choose_default_player(settings, 'episode', 'default_player_episode')
    elif choice == 2:
        update_players_now(settings)
    elif choice == 3:
        user_players_dir()
        xbmc.executebuiltin(
            'ActivateWindow(files,special://profile/addon_data/plugin.video.hearth/players/,return)'
        )


def update_players_now(settings):
    from network.guard import active_guard
    from paths import user_players_dir
    from player.library import update_players
    url = (settings.get('players_url') or 'https://bit.ly/Gplayers').strip()
    try:
        result = update_players(active_guard(), url, user_players_dir())
    except Exception as exc:
        from util import redact
        notify('Hearth', redact(str(exc))[:180] or 'Player update failed.')
        return
    notify('Hearth', 'Players: %d added, %d updated, %d skipped.' % (
        result['added'], result['updated'], result['skipped']
    ))


def _choose_default_player(settings, media_type, setting_id):
    import xbmcgui
    from paths import bundled_players_dir, user_players_dir
    from player.definitions import load_players
    from settings import save_kodi_setting
    players = [
        player for player in load_players(bundled_players_dir(), user_players_dir())
        if _plugin_installed(player.plugin) and player.template_for(media_type)
    ]
    labels = ['Ask every time'] + [player.name for player in players]
    current = settings.get(setting_id) or ''
    preselect = 0
    for index, player in enumerate(players, start=1):
        if player.id == current:
            preselect = index
            break
    choice = xbmcgui.Dialog().select('Default %s player' % media_type, labels, preselect=preselect)
    if choice is None or choice < 0:
        return
    value = '' if choice == 0 else players[choice - 1].id
    settings.set(setting_id, value)
    save_kodi_setting(setting_id, value)
    notify('Hearth', labels[choice])


def _plugin_installed(plugin_id):
    import xbmc
    try:
        if xbmc.getCondVisibility('System.HasAddon(%s)' % plugin_id):
            return True
    except Exception:
        pass
    try:
        import xbmcaddon
        xbmcaddon.Addon(plugin_id)
        return True
    except Exception:
        return False


def _last_player(store, settings, key):
    saved = store.meta_get(key) if store is not None else None
    if saved:
        return saved
    return settings.get(key) or ''
