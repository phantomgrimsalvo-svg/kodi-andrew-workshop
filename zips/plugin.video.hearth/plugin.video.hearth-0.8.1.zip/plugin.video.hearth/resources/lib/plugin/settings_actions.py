'''Every settings RunPlugin action enters through jobs.run.'''

from __future__ import annotations

from jobs import ACTIONS, action, recent_text, run


def dispatch_settings_action(name, store, settings, notify, show_text):
    spec = ACTIONS.get(name)
    if spec is None:
        return False

    def work(progress):
        return spec['fn'](store, settings, progress, notify, show_text) or {}

    run(
        spec['feature'], name, work, store,
        threaded=spec['threaded'], background=spec['background'],
        notify=notify, show_text=show_text
    )
    return True


@action('backup_now', 'Backup', threaded=True)
def _backup_now(store, settings, progress, notify, show_text):
    from backup.local import backup_now
    from paths import art_dir, default_backup_dir
    from util import iso
    progress.update(10, 'Writing the backup zip')
    folder = settings.get('backup_folder') or str(default_backup_dir())
    result = backup_now(store, settings, folder, art_dir=art_dir(), when=iso())
    return {'message': 'Saved in %s.' % result.get('folder', folder)}


@action('restore', 'Restore')
def _restore(store, settings, progress, notify, show_text):
    from backup.local import list_versions, restore_backup
    from paths import art_dir, db_path
    from plugin.kodiui import pick_folder, pick_version
    progress.update(10, 'Looking for backup folders')
    progress.release()
    chosen = pick_folder('Restore Hearth from a backup folder')
    if not chosen:
        return {'skipped': 'No backup folder was chosen.'}
    versions = list_versions(chosen)
    version = None
    if len(versions) > 1:
        version = pick_version([item.name for item in versions])
        if not version:
            return {'skipped': 'No backup version was chosen.'}
    restore_backup(db_path(), art_dir(), chosen, version=version, confirm=True)
    return {'message': 'The local library was replaced.'}


@action('manage_players', 'Players')
def _manage_players(store, settings, progress, notify, show_text):
    from plugin.kodiui import manage_players
    progress.update(15, 'Reading installed player files')
    progress.release()
    manage_players(store, settings)
    return {'message': 'Player picker closed.'}


@action('update_players', 'Update players')
def _update_players(store, settings, progress, notify, show_text):
    from plugin.kodiui import update_players_now
    progress.update(10, 'Downloading the player file')
    progress.release()
    update_players_now(settings)
    return {'message': 'Player update finished.'}


@action('pair_trakt', 'Pair with Trakt')
def _pair_trakt(store, settings, progress, notify, show_text):
    from network.guard import active_guard
    from trakt.client import TraktClient
    from trakt.flow import sign_in
    client_id = (settings.get('trakt_client_id') or '').strip()
    if not client_id:
        return {'skipped': 'No Trakt client id yet. The built-in key is empty, or set your own under Advanced.'}
    progress.update(10, 'Asking Trakt for a device code')
    progress.release()
    settings.store = store
    client = TraktClient(
        active_guard(), client_id,
        client_secret=settings.get('trakt_client_secret') or '',
        settings=settings
    )
    token = sign_in(client, settings)
    if not token:
        return {'skipped': 'Trakt pairing was cancelled.'}
    return {'message': 'Trakt is paired.'}


@action('pair_simkl', 'Pair with Simkl')
def _pair_simkl(store, settings, progress, notify, show_text):
    from network.guard import active_guard
    from pairing.simkl import pair
    progress.update(10, 'Asking Simkl for a PIN')
    return pair(settings, active_guard(), progress=progress.adapter())


@action('pick_mdblist', 'Pick my MDBList list')
def _pick_mdblist(store, settings, progress, notify, show_text):
    from network.guard import active_guard
    from pairing.mdblist import pick
    import xbmcgui
    progress.update(20, 'Loading your MDBList lists')
    progress.release()
    return pick(settings, active_guard(), xbmcgui.Dialog())


@action('trakt_sign_out', 'Trakt')
def _trakt_sign_out(store, settings, progress, notify, show_text):
    from trakt.auth import clear_auth
    progress.update(20, 'Forgetting the saved token')
    settings.store = store
    clear_auth(settings, message='Signed out of Trakt.')
    return {'message': 'Signed out. The Hearth library was not deleted.'}


@action('run_wizard', 'Setup')
def _run_wizard(store, settings, progress, notify, show_text):
    from wizard import run_wizard
    progress.update(10, 'Opening setup')
    progress.release()
    run_wizard(store, settings)
    return {'message': 'Setup closed.'}


@action('import_dry_run', 'Import from Trakt')
def _import_trakt(store, settings, progress, notify, show_text):
    from network.guard import active_guard
    from trakt.flow import import_from_trakt
    progress.update(5, 'Checking the Trakt account')
    summary = import_from_trakt(
        store, settings, active_guard(), progress=progress.adapter()
    )
    if not summary:
        return {'skipped': 'Trakt did not return a result.'}
    text = str(summary)
    if 'Nothing was imported' in text or 'cancelled' in text.lower() or 'client id' in text.lower():
        return {'skipped': text[:300]}
    if text.lower().startswith('imported'):
        return {'message': text[:300]}
    return {'message': text[:300]}


@action('resync_playback', 'Re-sync playback', threaded=True)
def _resync(store, settings, progress, notify, show_text):
    from network.guard import active_guard
    from trakt.importer import resync_playback
    progress.update(15, 'Reading Trakt playback')
    result = resync_playback(store, settings, active_guard())
    if isinstance(result, str):
        low = result.lower()
        if 'no ' in low or 'not ' in low or 'sign' in low:
            return {'skipped': result[:300]}
        return {'message': result[:300]}
    return {'message': 'Playback progress updated.'}


@action('push_mirror', 'Cloud push', threaded=True)
def _push_mirror(store, settings, progress, notify, show_text):
    from mirrors.push import push_outbox
    from network.guard import active_guard
    if not settings.mirror_enabled():
        return {'skipped': 'Cloud source is None. Nothing is sent.'}
    progress.update(20, 'Sending queued changes')
    result = push_outbox(store, settings, active_guard())
    return {'message': 'Pushed %s. Skipped %s.' % (
        result.get('pushed', 0), result.get('skipped', 0)
    )}


@action('sync_grok', 'Sync with Grok Bot', threaded=True)
def _sync_grok(store, settings, progress, notify, show_text):
    from brain.service import sync_with_bot
    from network.guard import active_guard
    if not settings.flag('brain_enabled', False):
        return {'skipped': 'Turn on Grok Bot in settings first.'}
    return sync_with_bot(store, settings, active_guard(), progress, want_picks=True)


@action('send_ratings', 'Just send ratings', threaded=True)
def _send_only(store, settings, progress, notify, show_text):
    from brain.service import sync_with_bot
    from network.guard import active_guard
    if not settings.flag('brain_enabled', False):
        return {'skipped': 'Turn on Grok Bot in settings first.'}
    return sync_with_bot(store, settings, active_guard(), progress, want_picks=False)


@action('view_taste', 'What Grok Bot thinks you like', threaded=True)
def _view_taste(store, settings, progress, notify, show_text):
    from brain.service import taste_text
    progress.update(30, 'Opening the taste note')
    return {
        'message': 'Showing the taste note.',
        'heading': 'What Grok Bot thinks you like',
        'text': taste_text()
    }


@action('grok_status', 'Grok Bot status', threaded=True)
def _grok_status(store, settings, progress, notify, show_text):
    from brain.service import status_text
    progress.update(40, 'Reading sync status')
    return {'message': 'Showing sync status.', 'heading': 'Grok Bot', 'text': status_text(store, settings)}


@action('view_journal', 'Taste journal', threaded=True)
def _view_journal(store, settings, progress, notify, show_text):
    from recs.profile import journal_markdown
    progress.update(30, 'Reading the taste journal')
    text = journal_markdown(store)[:12000]
    return {'message': 'Showing the taste journal.', 'heading': 'Taste journal', 'text': text}


@action('rate_history', 'Rate my history')
def _rate_history(store, settings, progress, notify, show_text):
    from ratings.history import rate_history_kodi
    progress.update(10, 'Finding watched titles with no rating')
    progress.release()
    result = rate_history_kodi(store, settings) or {}
    if result.get('message'):
        return {'skipped': result['message']}
    return {'message': 'Rated %s. %s still open.' % (
        result.get('rated', 0), result.get('left', 0)
    )}


@action('refresh_artwork', 'Refresh artwork', threaded=True)
def _artwork(store, settings, progress, notify, show_text):
    from art.backfill import backfill_all
    from network.guard import active_guard
    if not (settings.get('tmdb_api_key') or '').strip():
        return {'skipped': 'Add a TMDB API key, then refresh artwork.'}
    progress.update(5, 'Looking for titles without art')
    result = backfill_all(
        store, settings, active_guard(),
        progress=progress.adapter(), abort=progress.cancelled
    )
    if result.get('cancelled'):
        return {'skipped': 'Cancelled. The rest continues in the background.'}
    if result.get('skipped'):
        return {'skipped': result['skipped']}
    return {'message': 'Filled %s. %s still waiting.' % (
        result.get('filled', 0), result.get('remaining', 0)
    )}


@action('tmdb_sign_in', 'TMDb sign-in')
def _tmdb_sign_in(store, settings, progress, notify, show_text):
    from network.guard import active_guard
    from tmdb.account import import_account_ratings, sign_in
    import xbmcgui
    progress.update(10, 'Asking TMDb to approve this device')
    progress.release()
    session = sign_in(store, settings, active_guard())
    if not session:
        return {'skipped': 'Sign-in cancelled.'}
    if xbmcgui.Dialog().yesno('TMDb', 'Import your TMDb ratings now?'):
        stats = import_account_ratings(store, settings, active_guard())
        if isinstance(stats, str):
            return {'skipped': stats[:300]}
        return {'message': 'Imported %s movies, %s shows, %s episodes.' % (
            stats.get('movies', 0), stats.get('shows', 0), stats.get('episodes', 0)
        )}
    return {'message': 'Signed in. Ratings stay on TMDb until you import them.'}


@action('tmdb_sign_out', 'TMDb')
def _tmdb_sign_out(store, settings, progress, notify, show_text):
    from tmdb.account import sign_out
    progress.update(20, 'Forgetting the TMDb session')
    sign_out(store, settings)
    return {'message': 'Signed out of TMDb. The API key is still saved.'}


@action('tmdb_import_ratings', 'TMDb ratings', threaded=True)
def _tmdb_import(store, settings, progress, notify, show_text):
    from network.guard import active_guard
    from tmdb.account import import_account_ratings
    progress.update(10, 'Reading ratings from TMDb')
    stats = import_account_ratings(
        store, settings, active_guard(), progress=progress.adapter()
    )
    if isinstance(stats, str):
        return {'skipped': stats[:300]}
    extra = ''
    if not store.meta_get('trakt_rating_backfill_done'):
        from network.guard import active_guard
        from ratings.sync import sync_ratings_to_trakt, wants_trakt_ratings
        if wants_trakt_ratings(settings):
            progress.update(70, 'Sending ratings Trakt does not have yet')
            pushed = sync_ratings_to_trakt(store, settings, active_guard(), progress)
            store.meta_set('trakt_rating_backfill_done', 'true')
            extra = ' ' + (pushed.get('message') or '')
    return {'message': ('Imported %s movies, %s shows, %s episodes.%s' % (
        stats.get('movies', 0), stats.get('shows', 0), stats.get('episodes', 0), extra
    )).strip()}


@action('refresh_live_channels', 'Live channels', threaded=True)
def _refresh_live(store, settings, progress, notify, show_text):
    from channels.export import export_channels
    from channels.live import kodi_directory, refresh_published
    from paths import channels_export_path
    progress.update(20, 'Re-reading published live folders')
    refresh_published(store, settings, kodi_directory, force=True)
    if settings.flag('channels_enabled', False):
        progress.update(80, 'Writing the channel export')
        export_channels(store, settings, channels_export_path())
    return {'message': 'Live channels were refreshed.'}


@action('send_tmdb_ratings', 'Send TMDb ratings to Trakt', threaded=True)
def _send_ratings(store, settings, progress, notify, show_text):
    from network.guard import active_guard
    from ratings.sync import sync_ratings_to_trakt
    result = sync_ratings_to_trakt(store, settings, active_guard(), progress)
    if result.get('skipped'):
        return {'skipped': result['skipped']}
    return {'message': result.get('message') or 'Finished.'}


@action('refresh_widgets', 'Widgets')
def _refresh_widgets(store, settings, progress, notify, show_text):
    import xbmc
    progress.update(50, 'Asking Home to reload')
    xbmc.executebuiltin('Container.Refresh')
    return {'message': 'Widgets refresh the next time Home opens this list.'}


@action('recent_activity', 'Recent activity', threaded=True)
def _recent(store, settings, progress, notify, show_text):
    progress.update(40, 'Reading the job log')
    return {
        'message': 'Showing recent jobs.',
        'heading': 'Recent activity',
        'text': recent_text(store)
    }


