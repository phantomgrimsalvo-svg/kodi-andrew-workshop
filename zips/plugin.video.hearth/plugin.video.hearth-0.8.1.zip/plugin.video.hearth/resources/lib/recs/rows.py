'''Show the Grok Bot lists that are turned on. No generation.'''

from __future__ import annotations

from brain.wanted import LISTS


def apply_row_visibility(store, settings):
    for key, default_name, _media, default_on, _request in LISTS:
        slug = 'grok_%s' % key
        shown = settings.flag('gl_%s_enabled' % key, default_on)
        name = (settings.get('gl_%s_name' % key) or default_name).strip() or default_name
        if store.list_row(slug) is None:
            continue
        store.set_list_menu(slug, shown, name if shown else None)
