'''Weekly recommendations. The model runs on a schedule, not on every scroll.'''
