'''Local journal text. Hearth does not write a taste profile.'''

from __future__ import annotations

from pathlib import Path

from paths import profile_dir


def journal_markdown(store):
    lines = ['# Journal', '']
    for entry in store.journal_entries(400):
        title = store.get_title(entry['title_id'])
        name = title['title'] if title is not None else 'Unknown'
        score = entry['score']
        score_text = '%s/10' % score if score is not None else 'no score'
        lines.append('- %s · %s · %s' % ((entry['created_at'] or '')[:10], name, score_text))
        if entry['thoughts']:
            lines.append('  - %s' % entry['thoughts'])
        if entry['note']:
            lines.append('  - %s' % entry['note'])
    return '\n'.join(lines) + '\n'


def export_text_files(store, folder=None):
    root = Path(folder) if folder is not None else profile_dir()
    root.mkdir(parents=True, exist_ok=True)
    path = root / 'taste_journal.md'
    path.write_text(journal_markdown(store), encoding='utf-8')
    return {'journal': str(path)}


def render_profile(store, settings=None):
    return 'Taste profiles are written by Grok Bot. Open What Grok Bot thinks you like.'
