'''Turn Kodi image:// paths into URLs the channel app can load.'''

from __future__ import annotations

import base64
from pathlib import Path
from urllib.parse import quote, unquote, urlsplit, urlunsplit

CONTENT_TYPES = {
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.webp': 'image/webp',
    '.gif': 'image/gif'
}


def unwrap_image(value):
    '''Strip image://, a trailing slash, and a Kodi |header suffix.'''
    text = str(value or '').strip()
    for _ in range(4):
        if not text.startswith('image://'):
            break
        text = text[len('image://'):]
        if text.endswith('/'):
            text = text[:-1]
        text = unquote(text)
    if '|' in text:
        text = text.split('|', 1)[0]
    return text.strip()


def encode_http_url(value):
    '''Percent-encode spaces and other unsafe characters in an http URL path.'''
    text = str(value or '').strip()
    parts = urlsplit(text)
    if parts.scheme not in ('http', 'https') or not parts.netloc:
        return text
    path = quote(unquote(parts.path), safe='/%')
    return urlunsplit((parts.scheme, parts.netloc, path, parts.query, parts.fragment))


def encode_path(path):
    raw = base64.urlsafe_b64encode(str(path).encode('utf-8')).decode('ascii')
    return raw.rstrip('=')


def decode_path(token):
    text = str(token or '').strip()
    if not text:
        return ''
    pad = '=' * (-len(text) % 4)
    try:
        return base64.urlsafe_b64decode(text + pad).decode('utf-8')
    except (ValueError, UnicodeError):
        return ''


def content_type(path):
    return CONTENT_TYPES.get(Path(str(path)).suffix.lower(), 'application/octet-stream')


def safe_kodi_file(path, home):
    '''Absolute file under Kodi's home. Rejects .., /data/data, and anything outside.'''
    if not path or not home:
        return None
    raw = str(path)
    if raw.startswith(('plugin://', 'special://', 'http://', 'https://', 'image://')):
        return None
    if '\x00' in raw:
        return None
    parts = [part for part in raw.replace('\\', '/').split('/') if part not in ('', '.')]
    if '..' in parts:
        return None
    try:
        resolved = Path(raw).resolve()
        root = Path(home).resolve()
        resolved.relative_to(root)
    except (OSError, ValueError):
        return None
    text = str(resolved)
    if text == '/data/data' or text.startswith('/data/data/'):
        return None
    return resolved


def kodi_home():
    try:
        import xbmcvfs
        translated = xbmcvfs.translatePath('special://home')
    except Exception:
        return None
    if not translated or str(translated).startswith('special://'):
        return None
    return str(translated)


def translate_special(path):
    text = str(path or '')
    if not text.startswith('special://'):
        return text
    try:
        import xbmcvfs
        translated = xbmcvfs.translatePath(text)
    except Exception:
        return ''
    if not translated or str(translated).startswith('special://'):
        return ''
    return str(translated)


def public_image_url(path, port, token):
    return 'http://127.0.0.1:%s/img/%s/%s' % (
        int(port), token or 'hearth', encode_path(path)
    )


def server_port(settings):
    if settings is None:
        return 52849
    port = settings.integer('channel_server_port', 52849)
    if port < 1 or port > 65535:
        return 52849
    return port


def server_token(settings):
    if settings is None:
        return 'hearth'
    token = (settings.get('channel_server_token') or '').strip()
    return token or 'hearth'


def channel_image(value, home, settings):
    '''http(s) URL, or a local file served by Hearth. plugin:// art is skipped.'''
    text = unwrap_image(value)
    if not text or text.startswith('plugin://'):
        return ''
    if text.startswith(('http://', 'https://')):
        return encode_http_url(text)
    if text.startswith('special://'):
        text = translate_special(text)
        if not text:
            return ''
    if text.startswith('file://'):
        text = text[7:]
    allowed = safe_kodi_file(text, home)
    if allowed is None or not allowed.is_file():
        return ''
    return public_image_url(str(allowed), server_port(settings), server_token(settings))


def addon_id_from_plugin(plugin_path):
    text = str(plugin_path or '')
    if not text.startswith('plugin://'):
        return ''
    rest = text[len('plugin://'):]
    return rest.split('/', 1)[0].split('?', 1)[0]


def addon_icon(plugin_path, home, settings):
    '''icon.png, then fanart.jpg, from the add-on inside Kodi's home.'''
    addon = addon_id_from_plugin(plugin_path)
    if not addon or not home:
        return ''
    base = Path(home) / 'addons' / addon
    for name in ('icon.png', 'fanart.jpg', 'resources/icon.png'):
        url = channel_image(str(base / name), home, settings)
        if url:
            return url
    return ''
