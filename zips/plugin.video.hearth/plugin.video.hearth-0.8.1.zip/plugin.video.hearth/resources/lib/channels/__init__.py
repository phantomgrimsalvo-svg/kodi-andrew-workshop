'''Preview channel export for the Projectivy companion app. Local files only.'''
