'''Profile paths. Tests set HEARTH_PROFILE; Kodi uses special://profile.'''

from __future__ import annotations

import os
from pathlib import Path

from settings import ADDON_ID


def profile_dir():
    override = os.environ.get('HEARTH_PROFILE')
    if override:
        path = Path(override)
        path.mkdir(parents=True, exist_ok=True)
        return path
    try:
        import xbmcvfs
        translated = xbmcvfs.translatePath(
            'special://profile/addon_data/%s/' % ADDON_ID
        )
        path = Path(translated)
    except Exception:
        path = Path.home() / '.kodi' / 'userdata' / 'addon_data' / ADDON_ID
    path.mkdir(parents=True, exist_ok=True)
    return path


def db_path():
    return profile_dir() / 'hearth.db'


def art_dir():
    path = profile_dir() / 'art'
    path.mkdir(parents=True, exist_ok=True)
    return path


def default_backup_dir():
    path = profile_dir() / 'backups'
    path.mkdir(parents=True, exist_ok=True)
    return path


def user_players_dir():
    path = profile_dir() / 'players'
    path.mkdir(parents=True, exist_ok=True)
    return path


def addon_root():
    return Path(__file__).resolve().parents[2]


def bundled_players_dir():
    return addon_root() / 'resources' / 'players'


def channels_export_path():
    return profile_dir() / 'channels-export.json'


def placeholder_art():
    return addon_root() / 'resources' / 'media' / 'placeholder.png'
