'''Local SQLite source of truth.'''
