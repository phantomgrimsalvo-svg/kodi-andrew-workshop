'''When to ask for a rating, and how a score is saved. No network.'''
