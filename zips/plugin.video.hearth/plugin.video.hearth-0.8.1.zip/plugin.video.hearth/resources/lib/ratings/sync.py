'''Queue and batch-push Hearth ratings to Trakt.

Trakt keeps the newer rated_at when the scores disagree. Nothing is
overwritten without being counted in the summary.
'''

from __future__ import annotations

from util import iso


def wants_trakt_ratings(settings):
    '''On for a Trakt mirror, and for a signed-in Trakt account when no other mirror is selected.'''
    if settings is None or not settings.flag('trakt_push_ratings', True):
        return False
    mirror = (settings.get('cloud_mirror') or 'none').strip().lower()
    if mirror not in ('', 'none', 'trakt'):
        return False
    if mirror == 'trakt':
        return True
    return settings.trakt_authorized()


def queue_rating(store, settings, title_id, score, season=None, episode_id=None,
                 liked='', disliked='', thoughts='', rated_at=None):
    if score is None or not wants_trakt_ratings(settings):
        return False
    payload = rating_payload(
        store, title_id, score, season=season, episode_id=episode_id,
        liked=liked, disliked=disliked, thoughts=thoughts, rated_at=rated_at
    )
    if payload is None:
        return False
    dedupe = 'rating:%s:%s:%s' % (
        title_id, int(episode_id or 0), -1 if season is None else int(season)
    )
    store.enqueue_outbox('rating', payload, dedupe, 'trakt')
    _count_new_for_brain(store, settings)
    return True


def rating_payload(store, title_id, score, season=None, episode_id=None,
                   liked='', disliked='', thoughts='', rated_at=None):
    title = store.get_title(title_id)
    if title is None:
        return None
    moment = rated_at or iso()
    payload = {
        'title_id': title_id,
        'title': title['title'],
        'year': title['year'],
        'media_type': title['media_type'],
        'score': int(score),
        'rating': int(score),
        'liked': liked or '',
        'disliked': disliked or '',
        'thoughts': thoughts or '',
        'rated_at': moment,
        'season': season,
        'ids': {
            'imdb': title['imdb'],
            'tmdb': title['tmdb'],
            'tvdb': title['tvdb'],
            'trakt': title['trakt_id']
        }
    }
    if episode_id:
        episode = store.get_episode(episode_id)
        if episode is not None:
            payload['episode'] = {
                'season': int(episode['season']),
                'number': int(episode['episode'])
            }
            payload['season'] = int(episode['season'])
    return payload


def sync_ratings_to_trakt(store, settings, guard, progress=None, client=None):
    '''Compare with Trakt, send the newer local scores in batches, and count the rest.'''
    if progress is not None:
        progress.update(5, 'Reading ratings saved in Hearth')
    if not settings.trakt_authorized():
        return {'skipped': 'Sign in to Trakt first. Nothing was sent.'}
    local = _local_rows(store)
    if progress is not None:
        progress.update(25, 'Reading ratings already on Trakt')
    remote = _remote_index(settings, guard, client)
    send, kept_remote, matched = compare_ratings(local, remote)
    if progress is not None:
        progress.update(55, 'Sending %s ratings' % len(send))
    pushed = _post_batches(settings, guard, send)
    if progress is not None:
        progress.update(100, 'Done')
    return {
        'message': (
            'Sent %s. Trakt already had the newer score for %s, left those. '
            '%s already matched.'
        ) % (pushed, kept_remote, matched),
        'sent': pushed,
        'kept_trakt': kept_remote,
        'matched': matched,
        'queued': len(send)
    }


def compare_ratings(local_rows, remote_index):
    '''local wins only when it is newer. Equal scores are left alone.'''
    send = []
    kept_remote = 0
    matched = 0
    for row in local_rows:
        key = _identity(row)
        if key is None:
            continue
        other = remote_index.get(key)
        if other is None:
            send.append(row)
            continue
        if int(other.get('rating') or 0) == int(row.get('score') or 0):
            matched += 1
            continue
        local_at = row.get('rated_at') or ''
        remote_at = other.get('rated_at') or ''
        if remote_at and (not local_at or remote_at > local_at):
            kept_remote += 1
            continue
        send.append(row)
    return send, kept_remote, matched


def trakt_body(rows):
    movies = []
    shows = []
    for row in rows:
        item = {
            'rating': int(row['score']),
            'rated_at': row.get('rated_at') or iso(),
            'title': row.get('title') or '',
            'ids': {key: value for key, value in (row.get('ids') or {}).items() if value}
        }
        episode = row.get('episode') or {}
        if episode:
            shows.append({
                'title': row.get('title') or '',
                'ids': item['ids'],
                'seasons': [{
                    'number': int(episode.get('season') or row.get('season') or 1),
                    'episodes': [{
                        'number': int(episode.get('number') or 1),
                        'rating': item['rating'],
                        'rated_at': item['rated_at']
                    }]
                }]
            })
        elif row.get('season') not in (None, ''):
            shows.append({
                'title': row.get('title') or '',
                'ids': item['ids'],
                'seasons': [{
                    'number': int(row['season']),
                    'rating': item['rating'],
                    'rated_at': item['rated_at']
                }]
            })
        elif (row.get('media_type') or 'movie') == 'movie':
            movies.append(item)
        else:
            shows.append(item)
    return {'movies': movies, 'shows': shows}


def _local_rows(store):
    rows = []
    document = store.export_document()
    titles = {row['id']: row for row in document['titles']}
    episodes = {row['id']: row for row in document['episodes']}
    for rating in document['ratings']:
        if rating.get('score') is None:
            continue
        title = titles.get(rating['title_id'])
        if title is None:
            continue
        episode = episodes.get(rating.get('episode_id'))
        row = {
            'title_id': rating['title_id'],
            'title': title['title'],
            'media_type': title['media_type'],
            'score': int(rating['score']),
            'rated_at': rating.get('rated_at') or '',
            'source': rating.get('source') or '',
            'season': rating.get('season'),
            'ids': {
                'imdb': title.get('imdb'),
                'tmdb': title.get('tmdb'),
                'tvdb': title.get('tvdb'),
                'trakt': title.get('trakt_id')
            }
        }
        if episode is not None:
            row['episode'] = {
                'season': int(episode['season']),
                'number': int(episode['episode'])
            }
        rows.append(row)
    return rows


def _remote_index(settings, guard, client):
    if client is None:
        from trakt.client import TraktClient
        client = TraktClient(
            guard,
            settings.get('trakt_client_id'),
            access_token=settings.get('trakt_access_token'),
            client_secret=settings.get('trakt_client_secret'),
            settings=settings
        )
    index = {}
    for media, bucket in (
        ('movies', 'movie'), ('shows', 'show'),
        ('seasons', 'season'), ('episodes', 'episode')
    ):
        try:
            rows = client.ratings(media)
        except Exception:
            rows = []
        for row in rows or []:
            if not isinstance(row, dict):
                continue
            target = row.get(bucket) or row.get('movie') or row.get('show') or row
            ids = (target.get('ids') if isinstance(target, dict) else None) or row.get('ids') or {}
            key = _identity({'ids': ids, 'media_type': 'movie' if media == 'movies' else 'show'})
            if key is None:
                continue
            index[key] = {
                'rating': row.get('rating'),
                'rated_at': row.get('rated_at') or ''
            }
    return index


def _identity(row):
    ids = row.get('ids') or {}
    tmdb = ids.get('tmdb')
    imdb = ids.get('imdb')
    if tmdb:
        return ('tmdb', str(tmdb))
    if imdb:
        return ('imdb', str(imdb))
    return None


def _post_batches(settings, guard, rows):
    if not rows:
        return 0
    from mirrors.adapters import TraktMirror
    mirror = TraktMirror(settings)
    pushed = 0
    chunk = []
    for row in rows:
        chunk.append(row)
        if len(chunk) >= 40:
            mirror._post(guard, '/sync/ratings', trakt_body(chunk))
            pushed += len(chunk)
            chunk = []
    if chunk:
        mirror._post(guard, '/sync/ratings', trakt_body(chunk))
        pushed += len(chunk)
    return pushed


def _count_new_for_brain(store, settings):
    try:
        count = int(store.meta_get('brain_new_count') or 0) + 1
    except (TypeError, ValueError):
        count = 1
    store.meta_set('brain_new_count', str(count))
    every = 5
    if settings is not None:
        every = max(1, settings.integer('brain_upload_every', 5))
    if count >= every:
        store.meta_set('brain_upload_due', 'true')
