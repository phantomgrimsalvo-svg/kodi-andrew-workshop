'''Walk watched titles that still have no rating.'''

from __future__ import annotations

from util import loads

CHOICES = (
    [str(number) for number in range(10, 0, -1)]
    + ['Show plot', 'Skip', 'I never watched this', 'Stop']
)
PRESELECT = CHOICES.index('8')


def pending_titles(store, media='all', sort='recent'):
    rows = []
    for title in store.all_titles():
        if media == 'movies' and title['media_type'] != 'movie':
            continue
        if media == 'shows' and title['media_type'] != 'show':
            continue
        if not _watched(store, title):
            continue
        if _closed(store, title['id']):
            continue
        rows.append(title)
    if sort == 'watched':
        rows.sort(key=lambda title: (-_plays(store, title), title['title'] or ''))
    else:
        rows.sort(key=lambda title: (_recent(store, title), title['id']), reverse=True)
    return rows


def rate_history(store, settings, dialog, media='all', sort='recent'):
    '''One sitting. Skip and Back save nothing and do not change the queue.'''
    kept = pending_titles(store, media, sort)
    if not kept:
        return {'done': True, 'rated': 0, 'message': 'Nothing left to rate.'}
    rated = 0
    total = len(kept)
    index = 0
    while index < len(kept):
        title = kept[index]
        if hasattr(dialog, 'iscanceled') and dialog.iscanceled():
            break
        year = title['year'] or 'year unknown'
        heading = '%s (%s) - %s of %s' % (title['title'], year, index + 1, total)
        from kodi_dialog import kodi_select, kodi_yesno
        choice = kodi_select(dialog, heading, CHOICES, PRESELECT)
        if choice is None or choice < 0 or choice >= len(CHOICES) or CHOICES[choice] == 'Skip':
            from ratings.finish import feedback
            feedback('Nothing was saved.')
            index += 1
            continue
        label = CHOICES[choice]
        if label == 'Stop':
            if kodi_yesno(dialog, 'Rate my history', 'Stop rating the rest?'):
                break
            continue
        if label == 'Show plot':
            plot = title['plot'] or 'No plot stored yet.'
            if hasattr(dialog, 'text'):
                dialog.text(title['title'], plot)
            continue
        if label == 'I never watched this':
            from ratings.finish import never_watched
            never_watched(store, settings, title)
            index += 1
            continue
        score = int(label)
        from ratings.finish import ask_notes, save_played_rating
        detail = ask_notes(dialog, title['title'])
        save_played_rating(store, settings, title, score, detail)
        _maybe_push(store, settings, title, score)
        rated += 1
        index += 1
    from recs.profile import export_text_files
    export_text_files(store)
    return {'done': index >= len(kept), 'rated': rated, 'left': max(0, len(kept) - index)}


def rate_history_kodi(store, settings):
    import xbmcgui
    dialog = xbmcgui.Dialog()
    if not pending_titles(store, 'all', 'recent') and not (
        loads(store.meta_get('rate_history_skipped'), []) or []
    ):
        dialog.ok('Rate my history', 'Nothing left to rate. Watched titles with no rating show up here.')
        return {'done': True, 'rated': 0}

    class Adapter:
        def text(self, heading, body):
            dialog.textviewer(heading, (body or '')[:4000])

        def select(self, heading, choices, preselect=0):
            from kodi_dialog import kodi_select
            return kodi_select(dialog, heading, choices, preselect)

        def multiselect(self, heading, choices):
            from kodi_dialog import kodi_multiselect
            return kodi_multiselect(dialog, heading, choices)

        def input(self, heading, default=''):
            from kodi_dialog import kodi_input
            return kodi_input(dialog, heading, default)

        def yesno(self, heading, message):
            from kodi_dialog import kodi_yesno
            return kodi_yesno(dialog, heading, message)

        def iscanceled(self):
            return False

    media_index = dialog.select(
        'Rate my history', ['Movies', 'Shows', 'Movies and shows']
    )
    if media_index is None or media_index < 0:
        return {'done': False, 'rated': 0}
    media = ('movies', 'shows', 'all')[media_index]
    sort_index = dialog.select('Sort', ['Most recent', 'Most watched'])
    if sort_index is None or sort_index < 0:
        return {'done': False, 'rated': 0}
    sort = 'recent' if sort_index == 0 else 'watched'
    store.meta_set('rate_history_media', media)
    store.meta_set('rate_history_sort', sort)
    return rate_history(store, settings, Adapter(), media, sort)


def _closed(store, title_id):
    rating = store.get_rating(title_id)
    if rating is None:
        return False
    if int(rating['never_ask'] or 0):
        return True
    if int(rating['unfinished'] or 0) and rating['score'] is None:
        return True
    return rating['score'] is not None


def _watched(store, title):
    if title['media_type'] == 'movie':
        watch = store.get_watch(title['id'], None)
        return watch is not None and (watch['play_count'] or 0) > 0
    for episode in store.episodes_for_show(title['id']):
        watch = store.get_watch(title['id'], episode['id'])
        if watch is not None and (watch['play_count'] or 0) > 0:
            return True
    return False


def _plays(store, title):
    if title['media_type'] == 'movie':
        watch = store.get_watch(title['id'], None)
        return int(watch['play_count'] or 0) if watch is not None else 0
    total = 0
    for episode in store.episodes_for_show(title['id']):
        watch = store.get_watch(title['id'], episode['id'])
        if watch is not None:
            total += int(watch['play_count'] or 0)
    return total


def _recent(store, title):
    stamps = []
    watch = store.get_watch(title['id'], None)
    if watch is not None and watch['last_played']:
        stamps.append(watch['last_played'])
    if title['media_type'] == 'show':
        for episode in store.episodes_for_show(title['id']):
            row = store.get_watch(title['id'], episode['id'])
            if row is not None and row['last_played']:
                stamps.append(row['last_played'])
    return max(stamps) if stamps else ''


def _maybe_push(store, settings, title, score):
    if settings is None or not settings.flag('tmdb_write_ratings', False):
        return
    try:
        from network.guard import active_guard
        from tmdb.account import push_rating
        push_rating(store, settings, active_guard(), title, score)
    except Exception:
        return
