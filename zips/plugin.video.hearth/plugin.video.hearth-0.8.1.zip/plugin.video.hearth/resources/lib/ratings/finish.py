'''Rating after a real Kodi play. Skip writes nothing.'''

from __future__ import annotations

from brain.log import append_event
from kodi_dialog import kodi_input, kodi_multiselect, kodi_select, kodi_yesno
from util import iso

# Tags matter more than genre. Loved and hated are asked separately so the remote stays fast.
TAGS = (
    ('dialogue', 'Dialogue'),
    ('acting', 'Acting'),
    ('story', 'Story / writing'),
    ('characters', 'Characters'),
    ('emotional', 'Made me cry / emotional'),
    ('personal', 'Related to it / personal'),
    ('cinematography', 'Cinematography / visuals'),
    ('music', 'Music / score'),
    ('tension', 'Scares / tension'),
    ('humor', 'Humor'),
    ('pacing', 'Pacing'),
    ('ending', 'Ending'),
    ('originality', 'Originality'),
    ('genre_elements', 'Genre elements')
)

# Shown on the tag dialog and in the Rate titles setting help.
TAG_HELP = (
    'Tags drive recommendations more than genre does. '
    'Genre elements is the vampire, horror, or rom-com part itself, '
    'so you can separate how the genre felt from what made the movie good or bad.'
)

PROMPT_AT = 0.90


def prompt_finished(store, settings, title, watched_at=None, dialog=None):
    '''Ask only after this process played the file. Returns None when nothing is written.'''
    if title is None:
        return None
    if dialog is None:
        import xbmcgui
        dialog = xbmcgui.Dialog()
    choices = [str(number) for number in range(10, 0, -1)] + ['I never watched this', 'Skip']
    index = kodi_select(dialog, 'Rate %s' % (title['title'] or 'this title'), choices, 2)
    if index is None or index < 0 or index >= len(choices) or choices[index] == 'Skip':
        feedback('Nothing was saved.')
        return None
    if choices[index] == 'I never watched this':
        return never_watched(store, settings, title)
    rating = int(choices[index])
    detail = ask_notes(dialog, title['title'])
    return save_played_rating(store, settings, title, rating, detail, watched_at)


def ask_notes(dialog, title):
    '''Loved tags, hated tags, a note, then the watch-again checkbox.'''
    labels = [label for _key, label in TAGS]
    loved = set(kodi_multiselect(
        dialog, 'Loved in %s. %s Leave empty if none.' % (title, TAG_HELP), labels
    ))
    hated = set(kodi_multiselect(
        dialog, 'Hated in %s. %s Leave empty if none.' % (title, TAG_HELP), labels
    ))
    notes = kodi_input(dialog, 'Note for %s. Leave blank if you have nothing to add.' % title)
    rewatch_ok = kodi_yesno(dialog, title, "I'd watch this again")
    tags = []
    for index, (key, _label) in enumerate(TAGS):
        if index in loved:
            tags.append({'tag': key, 'sentiment': 'loved'})
        elif index in hated:
            tags.append({'tag': key, 'sentiment': 'hated'})
    return {'tags': tags, 'notes': notes, 'rewatch_ok': bool(rewatch_ok)}


def save_played_rating(store, settings, title, rating, detail, watched_at=None):
    moment = watched_at or iso()
    event = {
        'schema': 'hearth.ratings.v2',
        'type': 'rating',
        'tmdb_id': title['tmdb'] or '',
        'imdb_id': title['imdb'] or '',
        'media_type': 'tv' if title['media_type'] == 'show' else 'movie',
        'title': title['title'] or '',
        'year': title['year'],
        'rating': int(rating),
        'notes': detail.get('notes') or '',
        'tags': detail.get('tags') or [],
        'rewatch_ok': bool(detail.get('rewatch_ok')),
        'watched_at': moment
    }
    append_event(event)
    try:
        store.save_rating(
            title['id'], int(rating), thoughts=event['notes'], tags=event['tags'],
            source='local_play', rated_at=moment
        )
    except Exception:
        pass
    try:
        from ratings.sync import queue_rating
        queue_rating(store, settings, title['id'], int(rating), thoughts=event['notes'], rated_at=moment)
    except Exception:
        pass
    feedback('Saved %s out of 10.' % int(rating))
    return event


def feedback(message):
    try:
        from plugin.kodiui import notify
        notify('Hearth', message)
    except Exception:
        return


def never_watched(store, settings, title):
    '''Clear the local watch, ask Trakt to drop it, and tell Grok Bot.'''
    if title is None:
        feedback('That title is not in the library.')
        return None
    _clear_local(store, title)
    _drop_from_rate_queue(store, title['id'])
    if settings is not None and settings.trakt_authorized():
        _remove_trakt_history(store, settings, title)
    event = {
        'schema': 'hearth.ratings.v2',
        'type': 'never_watched',
        'tmdb_id': title['tmdb'] or '',
        'media_type': 'tv' if title['media_type'] == 'show' else 'movie',
        'title': title['title'] or '',
        'year': title['year'],
        'at': iso()
    }
    event['event_id'] = append_event(event)
    feedback('Cleared. Grok Bot can recommend it again.')
    return event


def _clear_local(store, title):
    store.set_watch(
        title['id'], None, play_count=0, resume_seconds=0, source='never_watched'
    )
    if title['media_type'] == 'show':
        for episode in store.episodes_for_show(title['id']):
            store.set_watch(
                title['id'], episode['id'], play_count=0, resume_seconds=0,
                source='never_watched'
            )


def _drop_from_rate_queue(store, title_id):
    from util import dumps, loads
    skipped = loads(store.meta_get('rate_history_skipped'), []) or []
    kept = [item for item in skipped if str(item) != str(title_id)]
    if len(kept) != len(skipped):
        store.meta_set('rate_history_skipped', dumps(kept))


def _remove_trakt_history(store, settings, title):
    payload = {
        'media_type': title['media_type'],
        'title': title['title'],
        'ids': {
            'imdb': title['imdb'],
            'tmdb': title['tmdb'],
            'tvdb': title['tvdb'],
            'trakt': title['trakt_id']
        }
    }
    store.enqueue_outbox(
        'history_remove', payload,
        'history_remove:%s' % title['id'], 'trakt'
    )
