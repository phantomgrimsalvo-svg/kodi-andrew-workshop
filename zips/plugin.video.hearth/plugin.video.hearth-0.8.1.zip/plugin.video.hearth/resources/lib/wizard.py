'''First-run steps. Each page is one action and names the add-on.'''

from __future__ import annotations


def run_wizard(store, settings, dialog=None):
    '''Show each first-run step. Trakt sign-in waits on one screen, then previews the import.'''
    if dialog is None:
        import xbmcgui
        dialog = xbmcgui.Dialog()
    settings.store = store
    for title, body in wizard_pages():
        if title == 'Import from Trakt':
            dialog.ok(
                title,
                'Hearth will show a Trakt code if you are not signed in, then ask before it writes.'
            )
            if hasattr(settings, 'reload_from_kodi'):
                settings.reload_from_kodi()
            settings.store = store
            from network.guard import active_guard
            from trakt.flow import import_from_trakt
            import_from_trakt(store, settings, active_guard(), dialog=dialog)
            continue
        if title in ('Import from Trakt again', 'Enter the Trakt device code') and settings.trakt_authorized():
            continue
        dialog.ok(title, body)
    if store is not None:
        store.meta_set('wizard_done', 'true')


def wizard_pages():
    umbrella = 'Add-ons > My add-ons > Video add-ons > Umbrella > Configure'
    hearth = 'Add-ons > My add-ons > Video add-ons > Hearth > Configure'
    services = umbrella + ' > Online Services > Service Selection'
    return [
        (
            'Uninstall script.trakt',
            'script.trakt would record the same plays as Hearth, and play counts drift. '
            'Open Add-ons > My add-ons > Program add-ons. If script.trakt is in that list, '
            'select script.trakt, open the context menu, and choose Uninstall.'
        ),
        (
            'Create a Trakt app for Hearth',
            'A new Trakt app has a client id and no client secret. '
            'Open trakt.tv > https://trakt.tv/oauth/applications/new, set the redirect URI to urn:ietf:wg:oauth:2.0:oob, and leave the client secret blank.'
        ),
        (
            'Set Umbrella watch history to Trakt',
            'Umbrella should read the marks Hearth writes to Trakt. '
            'In Umbrella\'s settings, open %s > Watch History & Indicators, and choose Trakt.' % services
        ),
        (
            'Turn on Read-only integration in Umbrella',
            'Read-only integration lets Umbrella read Trakt indicators, lists, and resume, and Umbrella never scrobbles. Hearth writes Trakt live. '
            'In Umbrella\'s settings, open %s > Accounts > Trakt > Read-only integration, and turn Read-only integration on.' % umbrella
        ),
        (
            'Turn off Resume Playback in Umbrella',
            'Hearth is the only resume prompt. '
            'In Umbrella\'s settings, open %s > Playback > Resume Playback, and turn Resume Playback off.' % umbrella
        ),
        (
            'Turn off Also mark watched on Simkl in Umbrella',
            'Simkl should stay unused until Hearth writes Simkl. '
            'In Umbrella\'s settings, open %s > Also mark watched on Simkl, and turn Also mark watched on Simkl off.' % services
        ),
        (
            'Turn off Also mark watched on MDBList in Umbrella',
            'MDBList should stay unused until Hearth writes MDBList. '
            'In Umbrella\'s settings, open %s > Also mark watched on MDBList, and turn Also mark watched on MDBList off.' % services
        ),
        (
            'Do not run Force Trakt Sync in Umbrella',
            'Force Trakt Sync to local database fills Umbrella\'s own database, not Hearth\'s, and skips ratings. '
            'In Umbrella\'s settings, open %s > Shortcuts > Force Trakt Sync to local database, and leave Force Trakt Sync to local database unselected.' % umbrella
        ),
        (
            'Leave Seren disabled',
            'Seren\'s defaults would scrobble to Trakt, Simkl, and MDBList if Seren is authorized. '
            'Open Add-ons > My add-ons > Video add-ons > Seren. If Seren is enabled, open the context menu on Seren and choose Disable.'
        ),
        (
            'Enter Hearth\'s Trakt client id',
            'Hearth signs in with Hearth\'s own Trakt application, separate from Umbrella. '
            'In Hearth\'s settings, open %s > Trakt > One-time import > Trakt client id, and paste the client id from Hearth\'s Trakt application.' % hearth
        ),
        (
            'Leave Hearth\'s Trakt client secret blank',
            'Apps created at trakt.tv > oauth/applications/new do not have a client secret. '
            'In Hearth\'s settings, open %s > Trakt > One-time import > Trakt client secret, and leave Trakt client secret blank unless this is an older app that still shows one.' % hearth
        ),
        (
            'Import from Trakt',
            'Import from Trakt fills Hearth, and Hearth asks before it writes. '
            'In Hearth\'s settings, open %s > Trakt > One-time import > Import from Trakt, and select Import from Trakt.' % hearth
        ),
        (
            'Enter the Trakt device code',
            'Trakt has to approve Hearth\'s application before the import can run. '
            'On trakt.tv > activate, enter the device code Hearth showed.'
        ),
        (
            'Import from Trakt again',
            'Run Import from Trakt again later if you want a newer copy. Hearth still asks first, and collection is never imported. '
            'In Hearth\'s settings, open %s > Trakt > One-time import > Import from Trakt.' % hearth
        ),
        (
            'Keep Umbrella signed in to Trakt',
            'Read-only integration needs Umbrella\'s Trakt login so Umbrella can read indicators, lists, and resume. '
            'In Umbrella\'s settings, open %s > Revoke Authorization, and do not select Revoke Authorization.' % services
        ),
        (
            'Leave Hearth\'s network policy on Strict',
            'After the import, Hearth reads lists from this device and does not call Trakt while you browse. '
            'In Hearth\'s settings, open %s > Network policy > Network policy, and leave Network policy on Strict.' % hearth
        ),
        (
            'Leave Hearth\'s movie player empty',
            'An empty player id makes Hearth ask which player to use, and Umbrella is one of the choices. '
            'In Hearth\'s settings, open %s > Playback > Playback > Default movie player, and leave Default movie player empty.' % hearth
        ),
        (
            'Leave Hearth\'s episode player empty',
            'Episodes use a separate player id from movies. '
            'In Hearth\'s settings, open %s > Playback > Playback > Default episode player, and leave Default episode player empty.' % hearth
        ),
        (
            'Pin Next Up from Hearth in Lucent',
            'Lucent does not show Hearth until a widget is added from Hearth. '
            'Open Settings > Lucent > Customise menu and widgets > Widgets on this tab > Add a widget > Browse an add-on > Hearth > Next Up, and add Next Up.'
        ),
        (
            'Sort the Lucent widget as Hearth gives it',
            'A skin sort would reorder Next Up away from Hearth\'s order. '
            'In Lucent\'s widget editor, open the Hearth widget > Sort, and set Sort to As the source gives it.'
        ),
        (
            'Keep Projectivy as the Home launcher',
            'Stock Google TV Home will not show these channel rows. '
            'On the Google TV Streamer, open Settings > Apps > See all apps > Projectivy, and leave Projectivy as the Home launcher.'
        ),
        (
            'Choose Hearth\'s backup folder',
            'Hearth\'s default backup folder is inside the Kodi profile and can disappear if Kodi is uninstalled. '
            'On the next screen, choose a folder on an SD card or a network share. '
            'You can change the folder later under %s > Backup > Backup folder.' % hearth
        ),
    ]
