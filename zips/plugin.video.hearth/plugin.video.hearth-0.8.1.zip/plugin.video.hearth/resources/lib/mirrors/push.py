'''Push the outbox through the one enabled adapter. One try per row, then stop on 429.'''

from __future__ import annotations

from urllib.parse import urlparse

from mirrors.adapters import adapter_for, host_of
from util import iso


def push_outbox(store, settings, guard):
    if not settings.mirror_enabled():
        return {'pushed': 0, 'skipped': 'mirror off'}
    adapter = adapter_for(settings)
    if adapter is None:
        return {'pushed': 0, 'skipped': 'no adapter'}
    guard.set_mirror_host(host_of(adapter))
    rows = store.pending_outbox(settings.get('cloud_mirror'))
    if not rows and settings.get('mirror_base_url'):
        rows = store.pending_outbox()
    pushed = 0
    skipped = 0
    for row in rows:
        if row['state'] != 'pending':
            continue
        try:
            result = adapter.push_row(guard, row)
        except Exception as exc:
            from util import redact
            if str(row['kind']).startswith('scrobble_'):
                store.mark_outbox(row['id'], 'pending', last_error=redact(str(exc))[:300])
                continue
            store.mark_outbox(row['id'], 'error', last_error=redact(str(exc))[:300])
            break
        response = guard.calls[-1] if guard.calls else None
        status = getattr(response, 'status', None)
        # The guard returns the transport response from push_row, not via calls.
        outcome = result if isinstance(result, dict) else {}
        transport_status = outcome.get('status')
        if outcome.get('retry'):
            state = 'pending' if str(row['kind']).startswith('scrobble_') else 'error'
            store.mark_outbox(
                row['id'], state, last_error='retry after %s' % outcome.get('retry')
            )
            break
        if outcome.get('skipped'):
            store.mark_outbox(row['id'], 'skipped', last_error=outcome.get('reason'))
            skipped += 1
            continue
        store.mark_outbox(row['id'], 'pushed')
        pushed += 1
        _ = status, transport_status
    store.meta_set('last_mirror_at', iso())
    return {'pushed': pushed, 'skipped': skipped}


def post_and_backoff(guard, method_caller):
    '''Call an adapter post and turn HTTP 429 into a stop signal.'''
    response = method_caller()
    status = getattr(response, 'status', 200) or 200
    if int(status) == 429 or int(status) >= 500:
        retry = '60'
        headers = getattr(response, 'headers', {}) or {}
        retry = headers.get('retry-after') or retry
        return {'retry': retry, 'status': int(status), 'skipped': False}
    return {'skipped': False, 'status': int(status)}
