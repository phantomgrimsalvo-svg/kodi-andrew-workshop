'''Background scrobble during playback. Menus never call this.'''

from __future__ import annotations

import threading

from mirrors.adapters import adapter_for, host_of
from network.guard import Guard, active_guard
from util import iso


def scrobble_enabled(settings):
    if not settings.flag('scrobble_during_playback', True):
        return False
    if not settings.mirror_enabled():
        return False
    return (settings.get('cloud_mirror') or '').lower() in ('trakt', 'simkl')


def queue_live_scrobble(store, settings, action, payload, now=None, background=True):
    '''Record the event, then send it without blocking the caller.

    action is start, pause, or stop. On failure the outbox row stays pending
    for a later retry. The watched_at on the payload is the real event time.
    '''
    if action not in ('start', 'pause', 'stop'):
        return {'queued': False}
    if not scrobble_enabled(settings):
        return {'queued': False}
    moment = now or payload.get('watched_at') or iso()
    payload = dict(payload)
    payload['watched_at'] = moment
    payload['action'] = action
    adapter = settings.get('cloud_mirror')
    dedupe = 'scrobble_%s:%s:%s:%s' % (
        action, payload.get('title_id'), payload.get('episode_id') or 0, moment
    )
    store.enqueue_outbox('scrobble_' + action, payload, dedupe, adapter)
    if background:
        thread = threading.Thread(
            target=flush_scrobbles,
            args=(store, settings, None),
            daemon=True
        )
        thread.start()
        return {'queued': True, 'background': True}
    result = flush_scrobbles(store, settings, None)
    result['queued'] = True
    result['background'] = False
    return result


def flush_scrobbles(store, settings, guard):
    '''Send pending live scrobble rows. Safe to call from a background thread.'''
    if guard is None:
        guard = active_guard()
        if settings is not None:
            guard.settings = settings
    adapter = adapter_for(settings)
    if adapter is None:
        return {'pushed': 0}
    guard.set_mirror_host(host_of(adapter))
    from network.guard import transport_timeout
    from service_run import stopped
    pushed = 0
    rows = store.pending_outbox(settings.get('cloud_mirror'))
    with transport_timeout(3):
        for row in rows:
            if stopped():
                break
            if not str(row['kind']).startswith('scrobble_'):
                continue
            try:
                outcome = adapter.push_row(guard, row)
            except Exception as exc:
                from util import redact
                store.mark_outbox(row['id'], 'pending', last_error=redact(str(exc))[:300])
                break
            if outcome.get('retry'):
                store.mark_outbox(row['id'], 'pending', last_error='retry after %s' % outcome['retry'])
                break
            if outcome.get('skipped'):
                store.mark_outbox(row['id'], 'skipped', last_error=outcome.get('reason'))
                continue
            store.mark_outbox(row['id'], 'pushed')
            pushed += 1
    return {'pushed': pushed}


def payload_for(store, title_id, episode_id, progress, position, runtime):
    title = store.get_title(title_id)
    body = {
        'title_id': title_id,
        'episode_id': episode_id,
        'media_type': title['media_type'] if title is not None else 'movie',
        'title': title['title'] if title is not None else '',
        'progress': progress,
        'resume_seconds': position,
        'runtime_seconds': runtime,
        'ids': {
            'imdb': title['imdb'] if title is not None else None,
            'tmdb': title['tmdb'] if title is not None else None,
            'tvdb': title['tvdb'] if title is not None else None,
            'trakt': title['trakt_id'] if title is not None else None
        }
    }
    if episode_id:
        episode = store.get_episode(episode_id)
        if episode is not None:
            body['episode'] = {'season': episode['season'], 'number': episode['episode']}
            body['show'] = {'title': body['title'], 'ids': body['ids']}
    return body
