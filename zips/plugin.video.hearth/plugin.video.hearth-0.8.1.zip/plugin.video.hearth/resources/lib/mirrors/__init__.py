'''Outbox push for an already enabled adapter. Milestone 1 does not ship service adapters.'''
