'''Changing the cloud source offers one full local push. Decline leaves it empty.'''

from __future__ import annotations

from util import iso


def plan_full_push(store):
    watches = 0
    for title in store.all_titles():
        if title['media_type'] == 'movie':
            watch = store.get_watch(title['id'], None)
            if watch is not None and (watch['play_count'] or 0) > 0:
                watches += 1
        else:
            for episode in store.episodes_for_show(title['id']):
                watch = store.get_watch(title['id'], episode['id'])
                if watch is not None and (watch['play_count'] or 0) > 0:
                    watches += 1
    ratings = 0
    # Count via export to avoid a new query helper.
    document = store.export_document()
    ratings = len(document['ratings'])
    return {
        'history': watches,
        'ratings': ratings,
        'watchlist': len(store.list_items('watchlist')),
        'favorites': len(store.list_items('favorites')),
        'lists': len([row for row in document['lists'] if row['kind'] == 'user'])
    }


def switch_source(store, settings, new_source, confirm=False):
    plan = plan_full_push(store)
    previous = settings.get('cloud_mirror') or 'none'
    if not confirm:
        return {'needs_confirm': True, 'from': previous, 'to': new_source, 'plan': plan}
    settings.set('cloud_mirror', new_source or 'none')
    if (new_source or 'none') in ('', 'none', 'off'):
        return {'needs_confirm': False, 'queued': 0, 'plan': plan}
    queued = enqueue_full_state(store, settings, new_source)
    return {'needs_confirm': False, 'queued': queued, 'plan': plan}


def enqueue_full_state(store, settings, adapter):
    now = iso()
    queued = 0
    document = store.export_document()
    titles = {row['id']: row for row in document['titles']}
    for watch in document['watch_state']:
        if not watch['play_count'] and not watch['resume_seconds']:
            continue
        title = titles.get(watch['title_id']) or {}
        episode = None
        if watch['episode_id']:
            episode = next(
                (row for row in document['episodes'] if row['id'] == watch['episode_id']),
                None
            )
        if watch['play_count']:
            played = _real_plays(store, watch, title)
            payload = {
                'media_type': title.get('media_type') or 'movie',
                'title': title.get('title'),
                'ids': _title_ids(title),
                'play_count': int(watch['play_count'] or 0),
                'plays': [{'watched_at': stamp} for stamp in played],
                'watched_at': played[-1] if played else (watch['last_played'] or '')
            }
            if episode:
                payload['episode'] = {
                    'season': episode['season'],
                    'number': episode['episode']
                }
                payload['show'] = {'ids': _title_ids(title), 'title': title.get('title')}
            key = 'history_add:%s:%s:%s' % (
                title.get('media_type'), title.get('tmdb') or title.get('id'),
                watch['episode_id'] or 0
            )
            store.enqueue_outbox('history_add', payload, key, adapter)
            queued += 1
    for rating in document['ratings']:
        title = titles.get(rating['title_id']) or {}
        payload = {
            'media_type': title.get('media_type') or 'movie',
            'title': title.get('title'),
            'ids': _title_ids(title),
            'score': rating['score'],
            'season': rating.get('season'),
            'liked': rating.get('liked') or '',
            'disliked': rating.get('disliked') or ''
        }
        key = 'rating:%s:%s' % (rating['title_id'], rating.get('season') if rating.get('season') is not None else 'title')
        store.enqueue_outbox('rating', payload, key, adapter)
        queued += 1
    queued += _enqueue_list(store, document, 'watchlist', 'watchlist_add', adapter)
    queued += _enqueue_list(store, document, 'favorites', 'favorites_add', adapter)
    for lst in document['lists']:
        if lst['kind'] != 'user':
            continue
        for item in document['list_items']:
            if item['list_id'] != lst['id']:
                continue
            title = titles.get(item['title_id']) or {}
            payload = {
                'media_type': title.get('media_type') or 'movie',
                'title': title.get('title'),
                'ids': _title_ids(title),
                'list_id': lst['slug'].split(':', 1)[-1],
                'slug': lst['slug']
            }
            key = 'list_add:%s:%s' % (lst['slug'], item['title_id'])
            store.enqueue_outbox('list_add', payload, key, adapter)
            queued += 1
    return queued


def _enqueue_list(store, document, slug, kind, adapter):
    titles = {row['id']: row for row in document['titles']}
    lists = {row['slug']: row for row in document['lists']}
    lst = lists.get(slug)
    if lst is None:
        return 0
    count = 0
    for item in document['list_items']:
        if item['list_id'] != lst['id'] or item['episode_id']:
            continue
        title = titles.get(item['title_id']) or {}
        payload = {
            'media_type': title.get('media_type') or 'movie',
            'title': title.get('title'),
            'ids': _title_ids(title)
        }
        store.enqueue_outbox(kind, payload, '%s:%s' % (kind, item['title_id']), adapter)
        count += 1
    return count


def _real_plays(store, watch, title):
    '''Only timestamps Hearth actually stored. Never invent earlier plays.'''
    stamps = store.list_plays(watch['title_id'], watch['episode_id'])
    if not stamps and watch.get('last_played'):
        store.record_play(watch['title_id'], watch['episode_id'], watch['last_played'])
        stamps = [watch['last_played']]
    return stamps


def _title_ids(title):
    return {
        'imdb': title.get('imdb'),
        'tmdb': title.get('tmdb'),
        'tvdb': title.get('tvdb'),
        'trakt': title.get('trakt_id')
    }
