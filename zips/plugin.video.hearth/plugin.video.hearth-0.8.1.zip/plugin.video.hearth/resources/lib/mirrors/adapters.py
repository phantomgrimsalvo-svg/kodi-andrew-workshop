'''Cloud mirror adapters. Hearth pushes. It does not pull plays from a phone.

Live scrobbles happen in the background during playback, one event at a time.
A sync job sends /sync/history with the real watched_at values. It does not
batch-pause every resume point. Collection is never sent.
'''

from __future__ import annotations

import json
from urllib.parse import urlparse

from util import loads

SIMKL = 'https://api.simkl.com'
MDBLIST = 'https://api.mdblist.com'
TMDB = 'https://api.themoviedb.org'
TRAKT = 'https://api.trakt.tv'


class MirrorError(Exception):
    pass


def adapter_for(settings):
    name = (settings.get('cloud_mirror') or 'none').strip().lower()
    base = (settings.get('mirror_base_url') or '').strip()
    if base and urlparse(base).hostname not in (
        'api.simkl.com', 'api.mdblist.com', 'api.themoviedb.org', 'api.trakt.tv'
    ):
        return GenericMirror(base)
    if name == 'simkl':
        return SimklMirror(settings)
    if name in ('mdblist', 'mdb'):
        return MdbListMirror(settings)
    if name in ('tmdb', 'tmdb lists', 'tmdb_lists'):
        return TmdbListsMirror(settings)
    if name == 'trakt':
        return TraktMirror(settings)
    if base:
        return GenericMirror(base)
    return None


def host_of(adapter):
    return urlparse(adapter.base).hostname or ''


class _Adapter:
    name = ''
    base = ''

    def __init__(self, settings):
        self.settings = settings

    def headers(self):
        return {'Content-Type': 'application/json'}

    def push_row(self, guard, row):
        kind = row['kind']
        payload = loads(row['payload'], {})
        if kind == 'playback_progress':
            return {'skipped': True, 'reason': 'resume points are scrobbled live, not dumped in a sync'}
        if kind in ('scrobble_start', 'scrobble_pause', 'scrobble_stop'):
            return self.push_scrobble(guard, kind.split('_', 1)[1], payload)
        sender = {
            'history_add': self.push_history,
            'history_remove': self.push_history_remove,
            'rating': self.push_ratings,
            'watchlist_add': self.push_watchlist,
            'watchlist_remove': self.push_watchlist_remove,
            'favorites_add': self.push_favorites,
            'favorites_remove': self.push_favorites_remove,
            'list_add': self.push_lists,
            'list_remove': self.push_lists_remove
        }.get(kind)
        if sender is None:
            return {'skipped': True, 'reason': 'unsupported outbox kind %s' % kind}
        return sender(guard, payload)

    def push_scrobble(self, guard, action, payload):
        return {'skipped': True, 'reason': 'this mirror has no playback scrobble'}

    def push_history(self, guard, payload):
        raise NotImplementedError

    def push_history_remove(self, guard, payload):
        raise NotImplementedError

    def push_ratings(self, guard, payload):
        raise NotImplementedError

    def push_watchlist(self, guard, payload):
        raise NotImplementedError

    def push_watchlist_remove(self, guard, payload):
        raise NotImplementedError

    def push_favorites(self, guard, payload):
        raise NotImplementedError

    def push_favorites_remove(self, guard, payload):
        raise NotImplementedError

    def push_lists(self, guard, payload):
        raise NotImplementedError

    def push_lists_remove(self, guard, payload):
        raise NotImplementedError

    def _post(self, guard, path, body, headers=None, purpose='cloud_mirror'):
        sent = headers
        retried = False
        if self.name == 'trakt':
            from trakt.auth import SIGN_IN_AGAIN, ensure_access_token
            if not ensure_access_token(self.settings, guard):
                return {'skipped': True, 'status': 401, 'reason': SIGN_IN_AGAIN}
        while True:
            response = guard.post(
                self.base + path,
                purpose,
                headers=sent or self.headers(),
                body=json.dumps(body)
            )
            status = int(getattr(response, 'status', 200) or 200)
            if status == 401 and self.name == 'trakt' and not retried:
                from trakt.auth import SIGN_IN_AGAIN, refresh_access_token
                retried = True
                if refresh_access_token(self.settings, guard):
                    sent = None
                    continue
                return {'skipped': True, 'status': 401, 'reason': SIGN_IN_AGAIN}
            break
        if status == 429 or status >= 500:
            retry = (getattr(response, 'headers', {}) or {}).get('retry-after') or '60'
            return {'retry': retry, 'status': status, 'skipped': False}
        body = getattr(response, 'body', None)
        if isinstance(body, (bytes, bytearray)) or status < 200 or status >= 300:
            if self.name == 'trakt':
                from trakt.client import TraktError, trakt_refusal
                raise TraktError(trakt_refusal(status))
            return {
                'skipped': True,
                'status': status,
                'reason': 'The request was refused (%s).' % status
            }
        return {'skipped': False, 'status': status}


class GenericMirror(_Adapter):
    '''Test double and any future adapter that only has a base URL.'''

    name = 'custom'

    def __init__(self, base):
        self.base = base.rstrip('/')
        self.settings = None

    def push_row(self, guard, row):
        payload = loads(row['payload'], {})
        return self._post(guard, '/outbox', {'kind': row['kind'], 'payload': payload})


class SimklMirror(_Adapter):
    name = 'simkl'
    base = SIMKL

    def headers(self):
        return {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + (self.settings.get('simkl_access_token') or ''),
            'simkl-api-key': self.settings.get('simkl_client_id') or ''
        }

    def push_scrobble(self, guard, action, payload):
        return self._post(
            guard, '/scrobble/%s' % action, _scrobble_body(payload), purpose='playback_scrobble'
        )

    def push_history(self, guard, payload):
        return self._post(guard, '/sync/history', _simkl_history(payload))

    def push_history_remove(self, guard, payload):
        return self._post(guard, '/sync/history/remove', _simkl_history(payload, watched=False))

    def push_ratings(self, guard, payload):
        return self._post(guard, '/sync/ratings', _simkl_rating(payload))

    def push_watchlist(self, guard, payload):
        return self._post(guard, '/sync/add-to-list', _simkl_list(payload, 'plantowatch'))

    def push_watchlist_remove(self, guard, payload):
        return self._post(guard, '/sync/history/remove', _simkl_ids_only(payload))

    def push_favorites(self, guard, payload):
        # Simkl's list statuses are watching / plantowatch / hold / completed / dropped.
        # There is no favorites list. Keep the row local and do not invent a call.
        return {'skipped': True, 'reason': 'Simkl has no favorites list'}

    def push_favorites_remove(self, guard, payload):
        return {'skipped': True, 'reason': 'Simkl has no favorites list'}

    def push_lists(self, guard, payload):
        return {'skipped': True, 'reason': 'Simkl user lists are not a Hearth target'}

    def push_lists_remove(self, guard, payload):
        return {'skipped': True, 'reason': 'Simkl user lists are not a Hearth target'}


class MdbListMirror(_Adapter):
    name = 'mdblist'
    base = MDBLIST

    def push_history(self, guard, payload):
        return {'skipped': True, 'reason': 'MDBList stores named lists, not play history'}

    def push_history_remove(self, guard, payload):
        return {'skipped': True, 'reason': 'MDBList stores named lists, not play history'}

    def push_ratings(self, guard, payload):
        return {'skipped': True, 'reason': 'MDBList does not store Hearth ratings'}

    def push_watchlist(self, guard, payload):
        return self._add(guard, payload)

    def push_watchlist_remove(self, guard, payload):
        return self._remove(guard, payload)

    def push_favorites(self, guard, payload):
        return self._add(guard, payload)

    def push_favorites_remove(self, guard, payload):
        return self._remove(guard, payload)

    def push_lists(self, guard, payload):
        return self._add(guard, payload)

    def push_lists_remove(self, guard, payload):
        return self._remove(guard, payload)

    def _add(self, guard, payload):
        list_id = payload.get('mdblist_id') or self.settings.get('mdblist_list_id')
        if not list_id:
            return {'skipped': True, 'reason': 'Set an MDBList list id'}
        key = self.settings.get('mdblist_api_key') or ''
        return self._post(
            guard, '/lists/%s/items?apikey=%s' % (list_id, key), _mdblist_body(payload)
        )

    def _remove(self, guard, payload):
        list_id = payload.get('mdblist_id') or self.settings.get('mdblist_list_id')
        if not list_id:
            return {'skipped': True, 'reason': 'Set an MDBList list id'}
        key = self.settings.get('mdblist_api_key') or ''
        return self._post(
            guard, '/lists/%s/items/remove?apikey=%s' % (list_id, key), _mdblist_body(payload)
        )


class TmdbListsMirror(_Adapter):
    name = 'tmdb'
    base = TMDB

    def push_history(self, guard, payload):
        return {'skipped': True, 'reason': 'TMDB lists are not a watch history'}

    def push_history_remove(self, guard, payload):
        return self.push_history(guard, payload)

    def push_ratings(self, guard, payload):
        return {'skipped': True, 'reason': 'TMDB lists do not store Hearth ratings'}

    def push_watchlist(self, guard, payload):
        return self._add(guard, payload)

    def push_watchlist_remove(self, guard, payload):
        return self._remove(guard, payload)

    def push_favorites(self, guard, payload):
        return self._add(guard, payload)

    def push_favorites_remove(self, guard, payload):
        return self._remove(guard, payload)

    def push_lists(self, guard, payload):
        return self._add(guard, payload)

    def push_lists_remove(self, guard, payload):
        return self._remove(guard, payload)

    def _add(self, guard, payload):
        return self._mutate(guard, payload, add=True)

    def _remove(self, guard, payload):
        return self._mutate(guard, payload, add=False)

    def _mutate(self, guard, payload, add):
        media_id = (payload.get('ids') or {}).get('tmdb') or payload.get('tmdb')
        media_type = payload.get('media_type') or 'movie'
        if not media_id:
            return {'skipped': True, 'reason': 'TMDB list item needs a tmdb id'}
        if str(media_type) == 'show':
            media_type = 'tv'
        token = self.settings.get('tmdb_v4_token') or ''
        list_id = payload.get('tmdb_list_id') or self.settings.get('tmdb_list_id')
        if not list_id:
            return {'skipped': True, 'reason': 'Set a TMDB list id'}
        if token:
            path = '/4/list/%s/items' % list_id
            body = {'items': [{'media_type': media_type, 'media_id': int(media_id)}]}
            headers = dict(self.headers())
            headers['Authorization'] = 'Bearer ' + token
            return self._post(guard, path, body, headers=headers)
        if media_type != 'movie':
            return {'skipped': True, 'reason': 'TMDB v3 lists are movies only; set a v4 token for shows'}
        key = self.settings.get('tmdb_api_key') or ''
        session = self.settings.get('tmdb_session_id') or ''
        action = 'add_item' if add else 'remove_item'
        path = '/3/list/%s/%s?api_key=%s&session_id=%s' % (list_id, action, key, session)
        return self._post(guard, path, {'media_id': int(media_id)})


class TraktMirror(_Adapter):
    name = 'trakt'
    base = TRAKT

    def headers(self):
        return {
            'Content-Type': 'application/json',
            'trakt-api-version': '2',
            'trakt-api-key': self.settings.get('trakt_client_id') or '',
            'Authorization': 'Bearer ' + (self.settings.get('trakt_access_token') or '')
        }

    def push_scrobble(self, guard, action, payload):
        return self._post(
            guard, '/scrobble/%s' % action, _scrobble_body(payload), purpose='playback_scrobble'
        )

    def push_history(self, guard, payload):
        return self._post(guard, '/sync/history', _trakt_history(payload))

    def push_history_remove(self, guard, payload):
        return self._post(guard, '/sync/history/remove', _trakt_history(payload, watched=False))

    def push_ratings(self, guard, payload):
        return self._post(guard, '/sync/ratings', _trakt_rating(payload))

    def push_watchlist(self, guard, payload):
        return self._post(guard, '/sync/watchlist', _trakt_ids(payload))

    def push_watchlist_remove(self, guard, payload):
        return self._post(guard, '/sync/watchlist/remove', _trakt_ids(payload))

    def push_favorites(self, guard, payload):
        return self._post(guard, '/sync/favorites', _trakt_ids(payload))

    def push_favorites_remove(self, guard, payload):
        return self._post(guard, '/sync/favorites/remove', _trakt_ids(payload))

    def push_lists(self, guard, payload):
        list_id = payload.get('list_id') or payload.get('slug') or 'hearth'
        return self._post(guard, '/users/me/lists/%s/items' % list_id, _trakt_ids(payload))

    def push_lists_remove(self, guard, payload):
        list_id = payload.get('list_id') or payload.get('slug') or 'hearth'
        return self._post(guard, '/users/me/lists/%s/items/remove' % list_id, _trakt_ids(payload))


def _ids(payload):
    raw = payload.get('ids') or {}
    cleaned = {}
    for key in ('imdb', 'tmdb', 'tvdb', 'trakt'):
        if raw.get(key) not in (None, ''):
            cleaned[key] = raw.get(key)
    if payload.get('tmdb') and 'tmdb' not in cleaned:
        cleaned['tmdb'] = payload.get('tmdb')
    if payload.get('imdb') and 'imdb' not in cleaned:
        cleaned['imdb'] = payload.get('imdb')
    return cleaned


def _bucket(payload):
    if payload.get('episode') or payload.get('season'):
        return 'episodes'
    media = payload.get('media_type') or ''
    if media in ('show', 'tv'):
        return 'shows'
    return 'movies'


def _known_times(payload):
    stamps = []
    for play in payload.get('plays') or []:
        if isinstance(play, dict) and play.get('watched_at'):
            stamps.append(play['watched_at'])
    if not stamps and payload.get('watched_at'):
        stamps.append(payload['watched_at'])
    return stamps


def _simkl_history(payload, watched=True):
    ids = _ids(payload)
    episode = payload.get('episode') or {}
    stamps = _known_times(payload) if watched else [None]
    if episode:
        show_ids = _ids(payload.get('show') or payload)
        episodes = []
        for stamp in stamps:
            item = {'number': episode.get('number') or episode.get('episode')}
            if stamp:
                item['watched_at'] = stamp
            episodes.append(item)
        return {'shows': [{
            'ids': show_ids,
            'seasons': [{'number': episode.get('season'), 'episodes': episodes}]
        }]}
    items = []
    for stamp in stamps:
        item = {'ids': ids}
        if stamp:
            item['watched_at'] = stamp
        items.append(item)
    key = 'movies' if _bucket(payload) == 'movies' else 'shows'
    return {key: items}


def _simkl_ids_only(payload):
    return _simkl_history(payload, watched=False)


def _simkl_rating(payload):
    item = {'rating': int(payload.get('score') or payload.get('rating') or 0), 'ids': _ids(payload)}
    if payload.get('season') and not payload.get('episode'):
        return {'shows': [item]}
    return {'movies': [item]} if _bucket(payload) == 'movies' else {'shows': [item]}


def _simkl_list(payload, status):
    item = {'to': status, 'ids': _ids(payload)}
    return {'movies': [item]} if _bucket(payload) == 'movies' else {'shows': [item]}


def _mdblist_body(payload):
    ids = _ids(payload)
    item = {}
    if ids.get('imdb'):
        item['imdb'] = ids['imdb']
    if ids.get('tmdb'):
        item['tmdb'] = ids['tmdb']
    if _bucket(payload) == 'movies':
        return {'movies': [item]}
    return {'shows': [item]}


def _trakt_history(payload, watched=True):
    ids = _ids(payload)
    episode = payload.get('episode') or {}
    stamps = _known_times(payload) if watched else [None]
    if episode:
        episodes = []
        for stamp in stamps:
            item = {'number': episode.get('number') or episode.get('episode')}
            if stamp:
                item['watched_at'] = stamp
            episodes.append(item)
        return {'shows': [{
            'ids': _ids(payload.get('show') or payload) or ids,
            'seasons': [{'number': episode.get('season'), 'episodes': episodes}]
        }]}
    items = []
    for stamp in stamps:
        item = {'ids': ids}
        if stamp:
            item['watched_at'] = stamp
        items.append(item)
    key = 'movies' if _bucket(payload) == 'movies' else 'shows'
    return {key: items}


def _progress_percent(payload):
    resume = payload.get('resume_seconds')
    runtime = payload.get('runtime_seconds')
    if resume and runtime:
        return round(100.0 * float(resume) / float(runtime), 2)
    value = float(payload.get('progress') or 0)
    if value <= 1:
        return round(value * 100.0, 2)
    return value


def _scrobble_body(payload):
    '''One live playback event. progress is where the video is right now.'''
    progress = _progress_percent(payload)
    episode = payload.get('episode') or {}
    if episode:
        return {
            'progress': progress,
            'show': {'ids': _ids(payload.get('show') or payload)},
            'episode': {
                'season': episode.get('season'),
                'number': episode.get('number') or episode.get('episode')
            }
        }
    return {'progress': progress, 'movie': {'ids': _ids(payload)}}


def _trakt_ids(payload):
    item = {'ids': _ids(payload)}
    key = 'movies' if _bucket(payload) == 'movies' else 'shows'
    return {key: [item]}


def _trakt_rating(payload):
    item = {
        'ids': _ids(payload),
        'rating': int(payload.get('score') or payload.get('rating') or 0)
    }
    if payload.get('season') and not payload.get('episode'):
        item['seasons'] = [{'number': payload['season'], 'rating': item['rating']}]
        return {'shows': [item]}
    key = 'movies' if _bucket(payload) == 'movies' else 'shows'
    return {key: [item]}
