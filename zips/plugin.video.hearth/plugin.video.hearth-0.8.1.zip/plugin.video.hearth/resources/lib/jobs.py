'''One door for every settings action.

The dialog opens before the work starts. A second press names the job
already running. The last 30 results stay in the library for Recent activity.
'''

from __future__ import annotations

import threading
import time

from util import dumps, iso, loads, redact

_LOCK = threading.Lock()
_RUNNING = {}
ACTIONS = {}


def action(name, feature, threaded=False, background=False):
    def decorate(fn):
        ACTIONS[name] = {
            'feature': feature,
            'fn': fn,
            'threaded': threaded,
            'background': background
        }
        return fn
    return decorate


class Progress:
    def __init__(self, feature, dialog, started, threaded, background):
        self.feature = feature
        self.dialog = dialog
        self.started = started
        self.threaded = threaded
        self.background = background
        self.stage = 'starting'
        self.percent = 0
        self.stop = threading.Event()

    def update(self, percent=None, stage=None):
        if percent is not None:
            try:
                self.percent = max(0, min(100, int(percent)))
            except (TypeError, ValueError):
                self.percent = 0
        if stage:
            self.stage = str(stage)
        if not self.threaded:
            self.paint()

    def paint(self):
        if self.dialog is None:
            return
        elapsed = max(0, int(time.monotonic() - self.started))
        text = '%s: %s  %s s' % (self.feature, self.stage, elapsed)
        try:
            if self.background:
                self.dialog.update(self.percent, self.feature, text)
            else:
                self.dialog.update(self.percent, text)
        except TypeError:
            self.dialog.update(self.percent, text)
        except Exception:
            return

    def cancelled(self):
        if self.stop.is_set():
            return True
        dialog = self.dialog
        if dialog is None or not hasattr(dialog, 'iscanceled'):
            return False
        try:
            return bool(dialog.iscanceled())
        except Exception:
            return False

    def release(self):
        '''Close the busy dialog so a picker or yes/no can take the screen.'''
        dialog = self.dialog
        self.dialog = None
        if dialog is not None:
            try:
                dialog.close()
            except Exception:
                return

    def adapter(self):
        '''DialogProgress-shaped object that writes into this job.'''
        progress = self

        class Bar:
            def create(self, heading, message=''):
                progress.update(1, message or heading)

            def update(self, percent, message=''):
                progress.update(percent, message or heading if False else message)

            def iscanceled(self):
                return progress.cancelled()

            def close(self):
                return None

        return Bar()


def run(feature, key, work, store=None, threaded=False, background=False,
        notify=None, show_text=None, dialog_factory=None):
    '''Run one named job. work(progress) returns a dict.'''
    with _LOCK:
        current = _RUNNING.get(key)
        if current is not None:
            ago = max(0, int(time.time() - current['wall']))
            message = '%s is already running (started %s s ago)' % (feature, ago)
            _notify(notify, feature, message)
            _record(store, feature, 'skipped', message, 0)
            return {'skipped': message, 'already_running': True, 'message': message}
        _RUNNING[key] = {'wall': time.time(), 'feature': feature}
    started = time.monotonic()
    dialog = _open_dialog(feature, background, dialog_factory)
    progress = Progress(feature, dialog, started, threaded, background)
    progress.paint()
    try:
        result = _execute(work, progress, threaded)
    finally:
        progress.release()
        with _LOCK:
            _RUNNING.pop(key, None)
    if not isinstance(result, dict):
        result = {'message': str(result or '')}
    status, message = _outcome(feature, result)
    duration_ms = max(0, int((time.monotonic() - started) * 1000))
    _record(store, feature, status, message, duration_ms)
    if not (background and status != 'failed'):
        _notify(notify, feature, message)
    if show_text is not None and result.get('text'):
        show_text(result.get('heading') or feature, result['text'])
    result['message'] = message
    result['status'] = status
    return result


def recent_text(store):
    rows = loads(store.meta_get('recent_jobs'), []) or []
    if not rows:
        return 'No jobs yet. Settings actions and scheduled rebuilds are listed here.'
    lines = ['Recent activity', '']
    for row in rows[:30]:
        seconds = int(row.get('duration_ms') or 0) // 1000
        lines.append(row.get('feature') or 'Job')
        lines.append('%s    %s s    %s' % (
            row.get('started') or '', seconds, row.get('status') or ''
        ))
        if row.get('message'):
            lines.append(row['message'])
        lines.append('')
    return '\n'.join(lines).strip()


def _execute(work, progress, threaded):
    if not threaded:
        try:
            return work(progress) or {}
        except Exception as exc:
            return {'failed': redact(str(exc))[:300]}
    box = {}

    def runner():
        try:
            box['result'] = work(progress) or {}
        except Exception as exc:
            box['error'] = exc

    thread = threading.Thread(target=runner, name='hearth-job', daemon=True)
    thread.start()
    while thread.is_alive():
        if progress.cancelled():
            progress.stop.set()
        progress.paint()
        thread.join(0.2)
    progress.paint()
    if box.get('error') is not None:
        return {'failed': redact(str(box['error']))[:300]}
    return box.get('result') or {}


def _outcome(feature, result):
    if result.get('already_running'):
        return 'skipped', result.get('message') or result.get('skipped')
    failed = result.get('failed')
    if failed:
        return 'failed', _named(feature, 'failed', failed)
    skipped = result.get('skipped')
    if skipped:
        return 'skipped', _named(feature, 'skipped', skipped)
    if result.get('cancelled'):
        return 'skipped', _named(feature, 'skipped', 'Cancelled.')
    return 'ok', _named(feature, 'ok', result.get('message') or 'Finished.')


def _named(feature, status, detail):
    text = str(detail or '').strip()
    head = feature.lower()
    if text.lower().startswith(head):
        return text[:300]
    if status == 'failed':
        return ('%s failed: %s' % (feature, text or 'something went wrong'))[:300]
    if status == 'skipped':
        return ('%s skipped: %s' % (feature, text or 'nothing to do'))[:300]
    return ('%s: %s' % (feature, text or 'Finished.'))[:300]


def _record(store, feature, status, message, duration_ms):
    if store is None:
        return
    try:
        rows = loads(store.meta_get('recent_jobs'), []) or []
        if not isinstance(rows, list):
            rows = []
        rows.insert(0, {
            'feature': feature,
            'started': iso(),
            'duration_ms': int(duration_ms),
            'status': status,
            'message': message[:300]
        })
        store.meta_set('recent_jobs', dumps(rows[:30]))
    except Exception:
        return


def _notify(notify, feature, message):
    if notify is None:
        try:
            import xbmc
            safe = message.replace(',', ' ').replace('"', "'")[:160]
            xbmc.executebuiltin('Notification(%s, %s, 5000)' % (feature, safe))
        except Exception:
            return
        return
    try:
        notify(feature, message[:180])
    except Exception:
        return


def _open_dialog(feature, background, dialog_factory):
    if dialog_factory is not None:
        try:
            return dialog_factory(background)
        except Exception:
            return None
    try:
        import xbmcgui
    except Exception:
        return None
    try:
        if background and hasattr(xbmcgui, 'DialogProgressBG'):
            dialog = xbmcgui.DialogProgressBG()
        else:
            dialog = xbmcgui.DialogProgress()
        dialog.create(feature, '%s: starting  0 s' % feature)
        return dialog
    except Exception:
        return None
