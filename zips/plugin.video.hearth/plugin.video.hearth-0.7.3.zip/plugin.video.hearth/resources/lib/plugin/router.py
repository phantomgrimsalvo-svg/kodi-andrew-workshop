'''Plugin entry. Directory building stays local; play hands off to a player add-on.'''

from __future__ import annotations

from urllib.parse import parse_qsl, urlparse

from paths import art_dir, bundled_players_dir, db_path, default_backup_dir, user_players_dir
from settings import Settings, load_kodi_settings


def run(argv=None):
    import sys
    argv = list(argv if argv is not None else sys.argv)
    url = argv[0] if argv else ''
    handle = int(argv[1]) if len(argv) > 1 and str(argv[1]).lstrip('-').isdigit() else -1
    query = {}
    if len(argv) > 2 and argv[2]:
        query = dict(parse_qsl(argv[2].lstrip('?')))
    parsed = urlparse(url)
    parts = [part for part in parsed.path.split('/') if part]
    if parsed.query:
        query.update(dict(parse_qsl(parsed.query)))
    settings = load_kodi_settings()
    from data.store import open_store
    store = open_store(db_path())
    store.ensure_system_lists()
    settings.store = store
    from recs.rows import apply_row_visibility
    apply_row_visibility(store, settings)
    _dispatch(handle, parts, query, store, settings)


def _dispatch(handle, parts, query, store, settings):
    from plugin.kodiui import (
        directory, notify, play_with_picker, show_fixup, show_text
    )
    from plugin.listings import build_info, build_list, build_root
    action = parts[0] if parts else ''
    if not parts:
        directory(handle, build_root(store), folder=True)
        return
    if action == 'lists':
        directory(handle, build_root(store), folder=True)
        return
    if action == 'list' and len(parts) > 1:
        directory(handle, build_list(store, parts[1], settings))
        return
    if action == 'show' and len(parts) > 1:
        from plugin.listings import build_season_episodes, build_show_seasons
        if len(parts) > 3 and parts[2] == 'season':
            directory(handle, build_season_episodes(store, parts[1], parts[3]), folder=True)
        else:
            directory(handle, build_show_seasons(store, parts[1]), folder=True)
        return
    if action == 'play' and len(parts) > 1:
        episode_id = int(parts[2]) if len(parts) > 2 else None
        url = play_with_picker(store, settings, int(parts[1]), episode_id, query.get('player'))
        from plugin.playback import play_or_resolve
        play_or_resolve(handle, url)
        return
    if action == 'info' and len(parts) > 1:
        info = build_info(store, parts[1])
        if info:
            show_text(info['title'], info['text'])
        _end(handle, False)
        return
    if action == 'fixup' and len(parts) > 1:
        show_fixup(store, settings, int(parts[1]))
        _end(handle, False)
        return
    if action == 'action' and len(parts) > 1:
        _action(handle, parts, store, settings, query)
        return
    directory(handle, build_root(store), folder=True)


def _action(handle, parts, store, settings, query=None):
    query = query or {}
    name = parts[1] if len(parts) > 1 else ''
    from backup.local import backup_now, list_versions, restore_backup
    from paths import art_dir as art_root
    from paths import db_path as database_path
    from plugin.kodiui import notify, pick_folder, pick_version, show_text
    from util import iso
    if name == 'backup_now':
        folder = settings.get('backup_folder') or str(default_backup_dir())
        result = backup_now(store, settings, folder, art_dir=art_root(), when=iso())
        notify('Backup saved', result['folder'])
    elif name == 'restore':
        chosen = pick_folder('Restore Hearth from a backup folder')
        if not chosen:
            _end(handle, False)
            return
        versions = list_versions(chosen)
        version = None
        if len(versions) > 1:
            version = pick_version([item.name for item in versions])
            if not version:
                _end(handle, False)
                return
        restore_backup(
            database_path(), art_root(), chosen, version=version, confirm=True
        )
        notify('Hearth restored', 'The local library was replaced.')
    elif name == 'manage_players':
        from plugin.kodiui import manage_players
        manage_players(store, settings)
    elif name == 'update_players':
        from plugin.kodiui import update_players_now
        update_players_now(settings)
    elif name == 'trakt_sign_out':
        from trakt.auth import clear_auth
        settings.store = store
        clear_auth(settings, message='Signed out of Trakt.')
    elif name == 'run_wizard':
        from wizard import run_wizard
        run_wizard(store, settings)
    elif name == 'import_dry_run':
        from network.guard import active_guard
        from trakt.flow import import_from_trakt
        try:
            summary = import_from_trakt(store, settings, active_guard())
        except Exception as exc:
            from util import redact
            notify('Trakt import', redact(str(exc))[:180] or 'The import did not run.')
            _end(handle, False)
            return
        if summary:
            notify('Hearth', summary[:180])
    elif name == 'resync_playback':
        from network.guard import active_guard
        from trakt.importer import resync_playback
        try:
            result = resync_playback(store, settings, active_guard())
        except Exception as exc:
            from util import redact
            notify('Trakt', redact(str(exc))[:180])
            _end(handle, False)
            return
        if isinstance(result, str):
            notify('Trakt', result[:180])
        else:
            notify('Trakt', 'Playback progress updated.')
    elif name == 'push_mirror':
        from mirrors.push import push_outbox
        from network.guard import active_guard
        if not settings.mirror_enabled():
            notify('Hearth', 'Cloud source is None. Nothing is sent.')
        else:
            result = push_outbox(store, settings, active_guard())
            notify('Hearth', 'Pushed %s. Skipped %s.' % (
                result.get('pushed', 0), result.get('skipped', 0)
            ))
    elif name == 'rebuild_recs':
        from recs.engine import rebuild_recommendations
        from network.guard import active_guard
        result = rebuild_recommendations(store, settings, active_guard())
        notify('Hearth', result.get('skipped') or ('Added %s' % result.get('inserted', 0)))
    elif name == 'recs_dry_run':
        from recs.engine import rebuild_recommendations
        from network.guard import active_guard
        result = rebuild_recommendations(store, settings, active_guard(), dry_run=True)
        show_text('Recommendations dry run', 'Candidates: %s\n\n%s' % (
            result.get('candidates', 0), (result.get('prompt') or result.get('skipped') or '')[:4000]
        ))
    elif name == 'view_profile':
        from recs.profile import render_profile
        show_text('Taste profile', render_profile(store, settings)[:12000])
    elif name == 'test_recs':
        from recs.engine import test_connection
        from network.guard import active_guard
        try:
            test_connection(settings, active_guard())
            notify('Hearth', 'The AI provider answered.')
        except Exception as exc:
            from util import redact
            notify('Hearth', redact(str(exc))[:180] or 'The connection failed.')
    elif name == 'launch':
        from plugin.playback import open_folder, play_or_resolve
        target = query.get('target') or ''
        mode = query.get('mode') or 'play'
        if mode == 'folder':
            open_folder(handle, target)
        else:
            play_or_resolve(handle, target)
        return
    elif name == 'remove_list' and len(parts) > 2:
        from plugin.kodiui import confirm_remove_list
        confirm_remove_list(store, settings, parts[2])
    elif name == 'refresh_live_channels':
        from channels.export import export_channels
        from channels.live import kodi_directory, refresh_published
        from paths import channels_export_path
        refresh_published(store, settings, kodi_directory, force=True)
        if settings.flag('channels_enabled', False):
            export_channels(store, settings, channels_export_path())
        notify('Hearth', 'Live channels were refreshed.')
    elif name == 'toggle_channel' and len(parts) > 2:
        from channels.export import export_channels, toggle_channel
        from paths import channels_export_path
        row = store.list_row(parts[2])
        if row is not None:
            enabled = not bool(row['publish_as_channel'])
            toggle_channel(store, parts[2], enabled)
            if enabled and (row['import_mode'] or '') == 'live':
                from channels.live import kodi_directory, refresh_one
                refresh_one(store, parts[2], kodi_directory)
            export_channels(store, settings, channels_export_path())
            notify('Hearth', '%s will %s as a channel.' % (
                row['name'], 'show' if enabled else 'not show'
            ))
    elif name == 'nextup_menu' and len(parts) > 2:
        from plugin.kodiui import show_nextup_menu
        show_nextup_menu(store, settings, int(parts[2]))
    elif name == 'refresh_artwork':
        from art.backfill import backfill_all
        from network.guard import active_guard
        backfill_all(store, settings, active_guard())
    elif name == 'tmdb_sign_in':
        from network.guard import active_guard
        from tmdb.account import import_account_ratings, sign_in
        import xbmcgui
        try:
            session = sign_in(store, settings, active_guard())
        except Exception as exc:
            from util import redact
            notify('TMDb', redact(str(exc))[:180])
            _end(handle, False)
            return
        if not session:
            notify('TMDb', 'Sign-in cancelled.')
        elif xbmcgui.Dialog().yesno('TMDb', 'Import your TMDb ratings now?'):
            stats = import_account_ratings(store, settings, active_guard())
            if isinstance(stats, str):
                notify('TMDb', stats[:180])
            else:
                notify('TMDb', 'Imported %s movies, %s shows, %s episodes.' % (
                    stats.get('movies', 0), stats.get('shows', 0), stats.get('episodes', 0)
                ))
        else:
            notify('TMDb', 'Signed in. Ratings stay on TMDb until you import them.')
    elif name == 'tmdb_sign_out':
        from tmdb.account import sign_out
        sign_out(store, settings)
        notify('TMDb', 'Signed out of TMDb.')
    elif name == 'tmdb_import_ratings':
        from network.guard import active_guard
        from tmdb.account import import_account_ratings
        try:
            stats = import_account_ratings(store, settings, active_guard())
        except Exception as exc:
            from util import redact
            notify('TMDb', redact(str(exc))[:180])
            _end(handle, False)
            return
        if isinstance(stats, str):
            notify('TMDb', stats[:180])
        else:
            notify('TMDb', 'Imported %s movies, %s shows, %s episodes.' % (
                stats.get('movies', 0), stats.get('shows', 0), stats.get('episodes', 0)
            ))
    elif name == 'rate_history':
        from ratings.history import rate_history_kodi
        rate_history_kodi(store, settings)
    elif name == 'view_journal':
        from recs.profile import journal_markdown
        show_text('Taste journal', journal_markdown(store)[:12000])
    elif name in (
        'deep_research', 'view_ai_notes', 'edit_ai_notes', 'clear_ai_notes',
        'view_twins', 'pick_mood', 'more_like', 'not_interested', 'never_show',
        'already_seen', 'why_pick', 'trailer'
    ):
        from recs.actions import run_rec_action
        run_rec_action(name, parts, store, settings, notify, show_text)
    elif name == 'refresh_widgets':
        import xbmc
        xbmc.executebuiltin('Container.Refresh')
        notify('Hearth', 'Widgets refresh the next time Home opens this list.')
    _end(handle, False)


def _launch_external(target, mode):
    from plugin.kodiui import notify
    if not str(target).startswith('plugin://'):
        notify('Hearth', 'That item has no plugin path.')
        return
    import xbmc
    quoted = '"%s"' % target.replace('"', '')
    if mode == 'folder':
        xbmc.executebuiltin('ActivateWindow(Videos,%s,return)' % quoted)
    else:
        xbmc.executebuiltin('PlayMedia(%s)' % quoted)


def _end(handle, succeeded):
    if handle is None or int(handle) < 0:
        return
    import xbmcplugin
    xbmcplugin.endOfDirectory(int(handle), succeeded=succeeded)
