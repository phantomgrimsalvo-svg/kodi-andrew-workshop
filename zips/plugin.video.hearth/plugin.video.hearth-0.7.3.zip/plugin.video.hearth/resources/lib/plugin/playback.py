'''Finish a Kodi play resolve, then hand off if the stream belongs to another add-on.

Projectivy sends every channel tile as a play. A folder is not a stream, and a
Hearth play URL only builds a link for Umbrella or whichever player is chosen.
setResolvedUrl has to answer before Kodi gives up, and the real window or
player starts a moment later.
'''

from __future__ import annotations


def is_resolve(handle):
    try:
        return int(handle) >= 0
    except (TypeError, ValueError):
        return False


def is_direct_stream(url):
    return str(url or '').startswith(('http://', 'https://'))


def play_or_resolve(handle, url, plugin=None, schedule=None, play=None):
    '''Play now, resolve a direct stream, or fail the resolve and play later.'''
    plugin = plugin if plugin is not None else _plugin()
    play = play if play is not None else _play
    schedule = schedule if schedule is not None else _schedule
    if not is_resolve(handle):
        if url:
            play(url)
        return {'mode': 'click', 'url': url or ''}
    if not url:
        plugin.setResolvedUrl(int(handle), False, _blank(plugin))
        return {'mode': 'failed', 'url': ''}
    if is_direct_stream(url):
        plugin.setResolvedUrl(int(handle), True, _blank(plugin, url))
        return {'mode': 'resolved', 'url': url}
    plugin.setResolvedUrl(int(handle), False, _blank(plugin))
    schedule(lambda: play(url))
    return {'mode': 'handoff', 'url': url}


def open_folder(handle, target, plugin=None, schedule=None, activate=None, stop_player=None):
    '''Open a folder. A resolve is failed first so Kodi stops treating it as a play.'''
    plugin = plugin if plugin is not None else _plugin()
    schedule = schedule if schedule is not None else _schedule
    activate = activate if activate is not None else _activate
    stop_player = stop_player if stop_player is not None else _stop_if_playing

    def go():
        stop_player()
        activate(target)

    if not is_resolve(handle):
        go()
        return {'mode': 'folder', 'url': target or ''}
    plugin.setResolvedUrl(int(handle), False, _blank(plugin))
    schedule(go)
    return {'mode': 'folder-handoff', 'url': target or ''}


def _blank(plugin, path=''):
    import xbmcgui
    item = xbmcgui.ListItem(path=path)
    if path and hasattr(item, 'setPath'):
        item.setPath(path)
    return item


def _plugin():
    import xbmcplugin
    return xbmcplugin


def _play(url):
    import xbmc
    quoted = '"%s"' % str(url).replace('"', '')
    xbmc.executebuiltin('PlayMedia(%s)' % quoted)


def _activate(target):
    import xbmc
    quoted = '"%s"' % str(target).replace('"', '')
    xbmc.executebuiltin('ActivateWindow(Videos,%s,return)' % quoted)


def _stop_if_playing():
    import xbmc
    player = xbmc.Player()
    if player.isPlaying():
        player.stop()


def _schedule(action):
    import threading
    import time

    def run():
        time.sleep(0.5)
        try:
            action()
        except Exception:
            return

    threading.Thread(target=run, name='hearth-handoff', daemon=True).start()
