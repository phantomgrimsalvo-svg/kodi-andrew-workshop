'''Localhost export for the channel app.

Kodi's /vfs/ path only serves configured media sources, so addon_data
returns 401 even with the right web-server password. This server binds
127.0.0.1 and checks a shared token.
'''

from __future__ import annotations

import hmac
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from threading import Thread
from urllib.parse import unquote, urlparse

_SERVER = None
_POLL_SECONDS = 0.2


class _ChannelServer(ThreadingHTTPServer):
    '''Request threads are daemons, and the accept loop wakes often enough to stop.'''

    daemon_threads = True
    timeout = _POLL_SECONDS

    def handle_error(self, request, client_address):
        import sys
        exc = sys.exc_info()[1]
        if isinstance(exc, (BrokenPipeError, ConnectionResetError)):
            return
        super().handle_error(request, client_address)


def ensure_server(settings):
    '''Start once per process. A second call leaves the running server alone.'''
    global _SERVER
    if _SERVER is not None:
        return _SERVER
    port = _port(settings)
    token = _token(settings)
    from paths import art_dir, channels_export_path
    from channels.images import kodi_home
    try:
        httpd = start_server(port, token, channels_export_path(), art_dir(), kodi_home())
    except OSError:
        return None
    _SERVER = httpd
    return httpd


def start_server(port, token, export_path, art_root, home=None):
    handler = _handler(token or '', Path(export_path), Path(art_root), home)
    httpd = _ChannelServer(('127.0.0.1', int(port)), handler)
    httpd.socket.settimeout(_POLL_SECONDS)

    def serve():
        httpd.serve_forever(poll_interval=_POLL_SECONDS)

    thread = Thread(target=serve, name='hearth-channels', daemon=True)
    httpd.hearth_thread = thread
    thread.start()
    return httpd


def stop_server(httpd=None):
    '''Unblock serve_forever and close the socket. Safe to call twice.'''
    global _SERVER
    server = httpd if httpd is not None else _SERVER
    if server is None:
        return
    thread = getattr(server, 'hearth_thread', None)
    try:
        server.shutdown()
    except Exception:
        pass
    try:
        server.server_close()
    except Exception:
        pass
    if thread is not None and thread.is_alive():
        thread.join(timeout=0.8)
    if server is _SERVER:
        _SERVER = None


def _handler(token, export_path, art_root, home):
    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            try:
                self._do_get()
            except (BrokenPipeError, ConnectionResetError):
                return

        def _do_get(self):
            parsed = urlparse(self.path)
            parts = [unquote(part) for part in parsed.path.split('/') if part]
            header = self.headers.get('X-Hearth-Token') or ''
            if len(parts) >= 2 and parts[0] == 'export':
                if not _matches(token, parts[1]) and not _matches(token, header):
                    self._reply(401, b'{"error":"bad token"}')
                    return
                if not export_path.is_file():
                    self._reply(404, b'{"error":"export not written yet"}')
                    return
                self._reply(200, export_path.read_bytes(), 'application/json; charset=utf-8')
                return
            if len(parts) >= 3 and parts[0] == 'art':
                if not _matches(token, parts[1]) and not _matches(token, header):
                    self._reply(401, b'{"error":"bad token"}')
                    return
                target = _safe_art(art_root, parts[2:])
                if target is None or not target.is_file():
                    self._reply(404, b'{"error":"no artwork"}')
                    return
                kind = 'image/jpeg'
                if target.suffix.lower() == '.png':
                    kind = 'image/png'
                elif target.suffix.lower() == '.webp':
                    kind = 'image/webp'
                self._reply(200, target.read_bytes(), kind, cache='public, max-age=86400')
                return
            if len(parts) >= 3 and parts[0] == 'img':
                if not _matches(token, parts[1]) and not _matches(token, header):
                    self._reply(401, b'{"error":"bad token"}')
                    return
                from channels.images import content_type, decode_path, safe_kodi_file
                decoded = decode_path(parts[2])
                target = safe_kodi_file(decoded, home)
                if target is None or not target.is_file():
                    self._reply(404, b'{"error":"no artwork"}')
                    return
                self._reply(
                    200, target.read_bytes(), content_type(target),
                    cache='public, max-age=86400'
                )
                return
            self._reply(404, b'{"error":"not found"}')

        def log_message(self, fmt, *args):
            return

        def _reply(self, status, body, content_type='application/json', cache='no-store'):
            try:
                self.send_response(status)
                self.send_header('Content-Type', content_type)
                self.send_header('Content-Length', str(len(body)))
                self.send_header('Cache-Control', cache)
                self.end_headers()
                self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError):
                return

    return Handler


def _matches(expected, got):
    if not expected or not got:
        return False
    return hmac.compare_digest(str(expected), str(got))


def _safe_art(root, parts):
    if any(part in ('', '.', '..') for part in parts):
        return None
    root = root.resolve()
    target = root.joinpath(*parts).resolve()
    try:
        target.relative_to(root)
    except ValueError:
        return None
    return target


def _port(settings):
    port = settings.integer('channel_server_port', 52849)
    if port < 1 or port > 65535:
        return 52849
    return port


def _token(settings):
    token = (settings.get('channel_server_token') or '').strip()
    return token or 'hearth'
