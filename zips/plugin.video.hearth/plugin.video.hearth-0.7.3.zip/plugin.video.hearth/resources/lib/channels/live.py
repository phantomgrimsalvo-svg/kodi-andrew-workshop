'''Live folder shortcuts and the channel-card cache.

A live list is the other add-on's plugin path. Hearth does not match those
items to TMDB. When the list is also an Android TV channel, a background
refresh stores the first playable rows so the channel app can draw cards.
'''

from __future__ import annotations

import threading
from urllib.parse import quote

from util import dumps, iso, loads, parse_iso

CACHE_LIMIT = 25
DIRECTORY_TIMEOUT = 20


def default_folder_mode(entries):
    '''Live when the folder has no IMDb, TMDB, or TVDB ids.'''
    for entry in entries or []:
        if entry.get('imdb') or entry.get('tmdb') or entry.get('tvdb'):
            return 'snapshot'
    return 'live'


def cache_key(slug):
    return 'live_cache:' + slug


def load_cache(store, slug):
    rows = loads(store.meta_get(cache_key(slug)), [])
    return list(rows or [])


def save_cache(store, slug, rows):
    store.meta_set(cache_key(slug), dumps(list(rows or [])))


def clear_cache(store, slug):
    store.meta_set(cache_key(slug), '')


def skip_label(label):
    text = ' '.join((label or '').lower().split())
    if not text:
        return True
    if text in ('next', 'next page', 'nextpage', 'settings', 'hidden', '..', 'back'):
        return True
    if 'next page' in text or text.startswith('next page'):
        return True
    return False


def normalize_entry(entry):
    art = entry.get('art') or {}
    label = entry.get('label') or entry.get('title') or ''
    path = entry.get('file') or entry.get('path') or ''
    folder = (entry.get('filetype') or '') == 'directory' or bool(entry.get('is_folder'))
    return {
        'label': label,
        'plot': entry.get('plot') or '',
        'thumb': entry.get('thumbnail') or art.get('thumb') or '',
        'poster': art.get('poster') or entry.get('thumbnail') or '',
        'fanart': art.get('fanart') or '',
        'path': path,
        'file': path,
        'is_folder': folder
    }


def select_rows(entries, limit=CACHE_LIMIT):
    chosen = []
    for entry in entries or []:
        label = entry.get('label') or entry.get('title') or ''
        if skip_label(label):
            continue
        path = entry.get('file') or entry.get('path') or ''
        if not path:
            continue
        chosen.append(normalize_entry(entry))
        if len(chosen) >= limit:
            break
    return chosen


def refresh_one(store, slug, lister):
    '''Replace the cache. A failed read (None or an exception) keeps the last rows.'''
    row = store.list_row(slug)
    previous = load_cache(store, slug)
    if row is None:
        return {'slug': slug, 'kept': True, 'count': len(previous)}
    try:
        entries = lister(row['import_plugin_path'])
    except Exception:
        entries = None
    if entries is None:
        return {'slug': slug, 'kept': True, 'count': len(previous)}
    chosen = select_rows(entries)
    save_cache(store, slug, chosen)
    store.touch_list(slug, iso())
    return {'slug': slug, 'kept': False, 'count': len(chosen)}


def refresh_due(last, now, hours):
    if not last:
        return True
    started = parse_iso(last)
    current = parse_iso(now)
    if started is None or current is None:
        return True
    return (current - started).total_seconds() >= max(1, int(hours)) * 3600


def refresh_published(store, settings, lister, now=None, force=False):
    now = now or iso()
    hours = settings.integer('live_channel_hours', 6)
    if not force and not refresh_due(store.meta_get('last_live_channel_refresh'), now, hours):
        return False
    touched = False
    for row in store.lists_in_menu():
        if (row['import_mode'] or '') != 'live' or not row['publish_as_channel']:
            continue
        refresh_one(store, row['slug'], lister)
        touched = True
    store.meta_set('last_live_channel_refresh', now)
    return touched


def launch_url(path, folder):
    if folder:
        return 'plugin://plugin.video.hearth/action/launch?mode=folder&target=%s' % quote(
            path or '', safe=''
        )
    return path or ''


def program_from_live(item, plugin_path='', home=None, settings=None):
    from channels.export import program_from_item
    from channels.images import addon_icon, channel_image
    folder = bool(item.get('is_folder'))
    path = item.get('file') or item.get('path') or ''
    poster = channel_image(item.get('poster'), home, settings)
    thumb = channel_image(item.get('thumb'), home, settings)
    fanart = channel_image(item.get('fanart'), home, settings)
    if not poster and not thumb and not fanart:
        poster = addon_icon(plugin_path, home, settings)
        fanart = poster
    art = {
        'poster': poster,
        'thumb': thumb or poster,
        'fanart': fanart or poster,
        'poster_url': poster,
        'thumb_url': thumb or poster,
        'fanart_url': fanart or poster
    }
    return program_from_item({
        'mediatype': 'movie',
        'label': item.get('label') or '',
        'title': item.get('label') or '',
        'plot': item.get('plot') or '',
        'art': art,
        'file': path if folder else launch_url(path, False),
        'path': path if folder else launch_url(path, False),
        'is_playable': not folder,
        'is_folder': folder,
        'uniqueid': {}
    })


def kodi_directory(path, timeout=DIRECTORY_TIMEOUT):
    '''Files.GetDirectory. None means the read failed and the cache must stay.'''
    box = {}

    def run():
        try:
            box['rows'] = _directory_now(path)
        except Exception as exc:
            box['error'] = exc

    worker = threading.Thread(target=run, daemon=True, name='hearth-live-directory')
    worker.start()
    worker.join(timeout)
    if worker.is_alive() or box.get('error') is not None:
        return None
    return box.get('rows') or []


def _directory_now(path):
    import json
    import xbmc
    raw = xbmc.executeJSONRPC(json.dumps({
        'jsonrpc': '2.0',
        'id': 1,
        'method': 'Files.GetDirectory',
        'params': {
            'directory': path,
            'media': 'files',
            'properties': ['title', 'plot', 'thumbnail', 'art', 'file']
        }
    }))
    payload = json.loads(raw or '{}')
    if payload.get('error'):
        raise RuntimeError(payload['error'].get('message') or 'directory failed')
    return (payload.get('result') or {}).get('files') or []


def _http(value):
    from channels.images import channel_image, unwrap_image
    text = unwrap_image(value)
    if text.startswith(('https://', 'http://')):
        return channel_image(text, None, None)
    return ''
