'''Next Up: one tile per show. Normal mode anchors on the latest play.'''

from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Optional

from util import iso

FLOOR = 0.02


@dataclass
class EpisodeState:
    episode_id: int
    season: int
    episode: int
    title: str = ''
    first_aired: str = ''
    runtime_seconds: int = 0
    play_count: int = 0
    resume_seconds: float = 0
    last_played: str = ''


@dataclass
class ShowState:
    title_id: int
    title: str
    episodes: list = field(default_factory=list)
    rewatch_mode: bool = False
    rewatch_from_season: int = 1
    rewatch_from_episode: int = 1
    watch_order: str = 'aired'
    nextup_mode: str = 'normal'
    pinned_season: Optional[int] = None
    pinned_episode: Optional[int] = None
    hidden: bool = False
    needs_fixup: str = ''


@dataclass
class Decision:
    kind: str
    episode: Optional[EpisodeState] = None
    show_id: Optional[int] = None
    mode: str = ''
    reasons: list = field(default_factory=list)
    minutes_left: Optional[int] = None
    label: str = ''
    sort_played: str = ''
    sort_aired: str = ''


def fraction(resume, runtime):
    if not runtime or runtime <= 0:
        return 0.0
    return max(0.0, float(resume or 0) / float(runtime))


def is_partial(ep, threshold, floor=FLOOR):
    pct = fraction(ep.resume_seconds, ep.runtime_seconds)
    return floor <= pct < threshold


def is_watched(ep, threshold, floor=FLOOR):
    if is_partial(ep, threshold, floor):
        return False
    if (ep.play_count or 0) > 0:
        return True
    return fraction(ep.resume_seconds, ep.runtime_seconds) >= threshold


def minutes_remaining(ep):
    runtime = ep.runtime_seconds or 0
    resume = ep.resume_seconds or 0
    if runtime <= resume:
        return None
    return max(1, int(round((runtime - resume) / 60.0)))


def evaluate_show(show, threshold=0.85, exclude_specials=True, floor=FLOOR, rng=None, today=None):
    if show.hidden:
        return Decision(kind='omit', reasons=['hidden'])
    episodes = [
        ep for ep in show.episodes
        if not (exclude_specials and ep.season == 0)
    ]
    episodes.sort(key=lambda ep: (ep.season, ep.episode))
    if not episodes:
        return Decision(kind='omit', reasons=['no-episodes'])
    mode = (show.nextup_mode or 'normal').strip().lower()
    latest = _latest_played(episodes)
    if mode == 'pick':
        return Decision(
            kind='pick', show_id=show.title_id, mode='Pick', label=show.title,
            sort_played=latest, sort_aired=''
        )
    if mode == 'random':
        choice = _choose_random(episodes, rng or random)
        decision = _tile(show, choice, 'Random', threshold)
        decision.sort_played = latest or choice.last_played or ''
        return decision
    return _normal_tile(show, episodes, threshold, floor, today or iso()[:10])


def _normal_tile(show, episodes, threshold, floor, today):
    played = [ep for ep in episodes if ep.last_played]
    if not played:
        return Decision(kind='omit', reasons=['unplayed'])
    anchor = max(played, key=lambda ep: (ep.last_played, ep.season, ep.episode))
    if is_partial(anchor, threshold, floor):
        return _tile(show, anchor, 'Continue', threshold)
    if _is_finished(anchor, threshold, floor):
        nxt = _episode_after(episodes, anchor)
        if nxt is None:
            return Decision(kind='omit', reasons=['finale'], sort_played=anchor.last_played)
        if nxt.first_aired and nxt.first_aired[:10] > today:
            return Decision(kind='omit', reasons=['unaired'], sort_played=anchor.last_played)
        decision = _tile(show, nxt, 'Next', threshold)
        decision.sort_played = anchor.last_played or decision.sort_played
        return decision
    return _tile(show, anchor, 'Next', threshold)


def _is_finished(ep, threshold, floor):
    if is_partial(ep, threshold, floor):
        return False
    if (ep.play_count or 0) > 0:
        return True
    return fraction(ep.resume_seconds, ep.runtime_seconds) >= threshold


def _episode_after(episodes, anchor):
    key = (anchor.season, anchor.episode)
    for ep in episodes:
        if (ep.season, ep.episode) > key:
            return ep
    return None


def _latest_played(episodes):
    played = [ep.last_played for ep in episodes if ep.last_played]
    return max(played) if played else ''


def _choose_random(episodes, rng):
    fresh = [ep for ep in episodes if not ep.last_played]
    if fresh:
        return rng.choice(fresh)
    latest = _latest_played(episodes)
    older = [ep for ep in episodes if ep.last_played != latest]
    return rng.choice(older or episodes)


def _heuristics(episodes, threshold, floor, rewatch_mode):
    reasons = []
    partials = [ep for ep in episodes if is_partial(ep, threshold, floor)]
    if len(partials) >= 2:
        reasons.append('multiple_partials')
    if _earlier_season_empty(episodes, threshold, floor):
        reasons.append('earlier_season_gap')
    if _watched_after_gap(episodes, threshold, floor):
        reasons.append('watched_after_gap')
    if not rewatch_mode and _looks_like_rewatch(episodes, threshold, floor):
        reasons.append('rewatch_like')
    return reasons


def _earlier_season_empty(episodes, threshold, floor):
    by_season = {}
    for ep in episodes:
        by_season.setdefault(ep.season, []).append(ep)
    active = set()
    for season, rows in by_season.items():
        if any(is_watched(ep, threshold, floor) or is_partial(ep, threshold, floor) for ep in rows):
            active.add(season)
    for season in sorted(by_season):
        if season not in active:
            continue
        for earlier in sorted(by_season):
            if earlier < season and earlier not in active:
                return True
    return False


def _watched_after_gap(episodes, threshold, floor):
    seen_hole = False
    for ep in episodes:
        if is_watched(ep, threshold, floor):
            if seen_hole:
                return True
        else:
            seen_hole = True
    return False


def _looks_like_rewatch(episodes, threshold, floor):
    for index, ep in enumerate(episodes):
        if (ep.play_count or 0) >= 2:
            later = episodes[index + 1:]
            if any((item.play_count or 0) == 0 for item in later):
                return True
    watched = [ep for ep in episodes if is_watched(ep, threshold, floor) and ep.last_played]
    times = [ep.last_played for ep in watched]
    return times != sorted(times)


def _tile(show, episode, mode, threshold):
    left = minutes_remaining(episode) if mode == 'Continue' else None
    code = 'S%02dE%02d' % (episode.season, episode.episode)
    if mode == 'Continue' and left:
        label = '%s — %s, %d minutes left' % (show.title, code, left)
    else:
        label = '%s — %s' % (show.title, code)
    played = episode.last_played or ''
    if mode == 'Next':
        played_values = [ep.last_played for ep in show.episodes if ep.last_played]
        played = max(played_values) if played_values else ''
    return Decision(
        kind='tile',
        episode=episode,
        show_id=show.title_id,
        mode=mode,
        minutes_left=left,
        label=label,
        sort_played=played,
        sort_aired=episode.first_aired or ''
    )


def order_tiles(decisions):
    visible = [item for item in decisions if item.kind in ('tile', 'pick')]
    visible.sort(key=lambda item: item.sort_played or '', reverse=True)
    return visible


def show_state_from_rows(title, episodes, watches):
    '''watches: map of episode_id -> watch row.'''
    states = []
    for ep in episodes:
        watch = watches.get(ep['id'])
        runtime = 0
        if watch is not None and watch['runtime_seconds']:
            runtime = int(watch['runtime_seconds'])
        elif ep['runtime_seconds']:
            runtime = int(ep['runtime_seconds'])
        states.append(EpisodeState(
            episode_id=ep['id'],
            season=int(ep['season']),
            episode=int(ep['episode']),
            title=ep['title'] or '',
            first_aired=ep['first_aired'] or '',
            runtime_seconds=runtime,
            play_count=int(watch['play_count']) if watch is not None else 0,
            resume_seconds=float(watch['resume_seconds'] or 0) if watch is not None else 0,
            last_played=(watch['last_played'] or '') if watch is not None else ''
        ))
    return ShowState(
        title_id=title['id'],
        title=title['title'],
        episodes=states,
        rewatch_mode=bool(title['rewatch_mode']),
        rewatch_from_season=title['rewatch_from_season'] or 1,
        rewatch_from_episode=title['rewatch_from_episode'] or 1,
        watch_order=title['watch_order'] or 'aired',
        nextup_mode=(title['nextup_mode'] or 'normal') if 'nextup_mode' in title.keys() else 'normal',
        pinned_season=title['pinned_season'],
        pinned_episode=title['pinned_episode'],
        hidden=bool(title['nextup_hidden']),
        needs_fixup=title['needs_fixup'] or ''
    )


def rebuild_derived(store, settings, rng=None):
    '''Rebuild Next Up, in-progress movies, and the recent-movies ordering.

    Recent movies keeps every watched row. The display limit is applied later.
    Random tiles are re-rolled on every rebuild, including after a play.
    '''
    store.ensure_system_lists()
    threshold = settings.threshold
    floor = settings.floor
    exclude_specials = settings.flag('exclude_specials', True)
    tiles = []
    for title in store.all_titles('show'):
        episodes = store.episodes_for_show(title['id'])
        watches = {}
        for ep in episodes:
            watch = store.get_watch(title['id'], ep['id'])
            if watch is not None:
                watches[ep['id']] = watch
        show = show_state_from_rows(title, episodes, watches)
        decision = evaluate_show(
            show, threshold=threshold, exclude_specials=exclude_specials, floor=floor,
            rng=rng
        )
        if decision.kind in ('tile', 'pick'):
            tiles.append(decision)
        if title['needs_fixup']:
            store.update_title_fields(title['id'], needs_fixup=None)
    ordered = order_tiles(tiles)
    fixed_rows = []
    for decision in ordered:
        if decision.kind == 'pick':
            fixed_rows.append({
                'title_id': decision.show_id,
                'episode_id': None,
                'reason': decision.label
            })
            continue
        episode = store.get_episode(decision.episode.episode_id)
        fixed_rows.append({
            'title_id': episode['show_id'],
            'episode_id': decision.episode.episode_id,
            'reason': decision.label
        })
    store.replace_list_items('next_up', fixed_rows)

    movie_rows = []
    recent_rows = []
    for title in store.all_titles('movie'):
        watch = store.get_watch(title['id'], None)
        if watch is None:
            continue
        runtime = watch['runtime_seconds'] or title['runtime_seconds'] or 0
        resume = watch['resume_seconds'] or 0
        percent = watch['resume_percent'] if 'resume_percent' in watch.keys() else None
        if resume and runtime:
            pct = fraction(resume, runtime)
        elif percent:
            pct = float(percent) / 100.0
            if runtime and not resume:
                resume = pct * float(runtime)
        else:
            pct = fraction(resume, runtime)
        if floor <= pct < threshold:
            movie_rows.append({
                'title_id': title['id'],
                'episode_id': None,
                'reason': 'in-progress',
                'sort': watch['last_played'] or ''
            })
        if (watch['play_count'] or 0) > 0:
            recent_rows.append({
                'title_id': title['id'],
                'episode_id': None,
                'reason': 'recent',
                'sort': watch['last_played'] or ''
            })
    movie_rows.sort(key=lambda row: row['sort'], reverse=True)
    recent_rows.sort(key=lambda row: row['sort'], reverse=True)
    store.replace_list_items('in_progress_movies', [
        {'title_id': row['title_id'], 'episode_id': None, 'reason': row['reason']}
        for row in movie_rows
    ])
    store.replace_list_items('recent_movies', [
        {'title_id': row['title_id'], 'episode_id': None, 'reason': row['reason']}
        for row in recent_rows
    ])
    return {'next_up': len(fixed_rows), 'fixups': 0, 'in_progress': len(movie_rows)}

