'''Hearth service: local player monitor and the weekly file backup.

One process. The backup uses no network. Cloud mirrors and recommendations
are later milestones and are not scheduled here.
'''

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / 'resources' / 'lib'))

import xbmc

from backup.local import run_scheduled_backup
from data.store import open_store
from network.guard import install_runtime_patches
from paths import art_dir, db_path, default_backup_dir
from player.monitor import SAMPLE_SECONDS, HearthMonitor
from settings import load_kodi_settings
from util import iso


class HearthPlayer(xbmc.Player):
    def __init__(self, hearth):
        super().__init__()
        self.hearth = hearth

    def onAVStarted(self):
        self.hearth.on_av_started()
        self._sample('start')

    def onPlayBackPaused(self):
        self._sample('progress')

    def onPlayBackSeek(self, time, seekOffset):
        self._sample('progress', fallback_position=time)

    def onPlayBackStopped(self):
        self._finish('stop')

    def onPlayBackEnded(self):
        self._finish('end')

    def _sample(self, event, fallback_position=None):
        position = None
        runtime = None
        try:
            position = self.getTime()
            runtime = self.getTotalTime()
        except Exception:
            position = fallback_position
        if position is None:
            return
        self.hearth.remember(position, runtime, position)
        result = self.hearth.on_progress(position, runtime or 0, position, event=event)
        if result and result.get('rating_prompts'):
            _show_ratings(self.hearth.store, self.hearth.settings, result['rating_prompts'])

    def _finish(self, event):
        result = self.hearth.finish(event)
        if result and result.get('rating_prompts'):
            _show_ratings(self.hearth.store, self.hearth.settings, result['rating_prompts'])
        self.hearth.clear_session()


def main():
    install_runtime_patches()
    settings = load_kodi_settings()
    store = open_store(db_path())
    store.ensure_system_lists()
    settings.store = store
    if store.meta_get('wizard_done') != 'true':
        from wizard import run_wizard
        run_wizard(store, settings)
    hearth = HearthMonitor(store, settings)
    HearthPlayer(hearth)
    _refresh_live_channels(store, settings, force=True)
    monitor = xbmc.Monitor()
    quiet_ticks = 0
    maintenance_every = max(1, 900 // SAMPLE_SECONDS)
    while not monitor.waitForAbort(SAMPLE_SECONDS):
        quiet_ticks = service_tick(store, settings, hearth, quiet_ticks, maintenance_every)


def _refresh_live_channels(store, settings, force):
    if not settings.flag('channels_enabled', False):
        return False
    try:
        from channels.live import kodi_directory, refresh_published
        return refresh_published(store, settings, kodi_directory, iso(), force=force)
    except Exception:
        return False


def _show_ratings(store, settings, prompts):
    import xbmcgui
    from ratings.triggers import run_prompt, save_prompt_result
    dialog = xbmcgui.Dialog()

    class Adapter:
        def select(self, heading, choices):
            return dialog.select(heading, choices)

        def input(self, heading, default=''):
            return dialog.input(heading, default=default) or ''

        def multiselect(self, heading, choices):
            if hasattr(dialog, 'multiselect'):
                picked = dialog.multiselect(heading, choices)
                return picked or []
            return []

    for prompt in prompts:
        answer = run_prompt(Adapter(), prompt)
        save_prompt_result(store, settings, prompt, answer)


def service_tick(store, settings, hearth, quiet_ticks, maintenance_every):
    '''One wake of the service. A failure is recorded and the loop keeps going.'''
    try:
        hearth.sample_playback()
        quiet_ticks += 1
        if quiet_ticks < maintenance_every:
            return quiet_ticks
        quiet_ticks = 0
        _maintenance(store, settings)
    except Exception as exc:
        from util import redact
        try:
            store.meta_set('last_error', redact(str(exc))[:300])
        except Exception:
            return quiet_ticks
    return quiet_ticks


def _maintenance(store, settings):
    folder = settings.get('backup_folder') or str(default_backup_dir())
    run_scheduled_backup(store, settings, folder, art_dir(), iso())
    from recs.engine import rebuild_recommendations
    from backup.local import backup_is_due
    from network.guard import active_guard
    if backup_is_due(
        store.meta_get('last_recs_at'), iso(), settings.integer('recs_interval_days', 7)
    ) and settings.get('recs_api_key'):
        try:
            rebuild_recommendations(store, settings, active_guard())
        except Exception as exc:
            from util import redact
            if not store.meta_get('last_error_notified'):
                store.meta_set('last_error', redact(str(exc))[:300])
                store.meta_set('last_error_notified', iso())
    if settings.flag('channels_enabled', False):
        from channels.export import export_channels
        from paths import channels_export_path
        _refresh_live_channels(store, settings, force=False)
        export_channels(store, settings, channels_export_path())
    if settings.mirror_enabled():
        from mirrors.push import push_outbox
        from network.guard import active_guard as mirror_guard
        try:
            push_outbox(store, settings, mirror_guard())
        except Exception as exc:
            from util import redact
            store.meta_set('last_error', redact(str(exc))[:300])


if __name__ == '__main__':
    main()
