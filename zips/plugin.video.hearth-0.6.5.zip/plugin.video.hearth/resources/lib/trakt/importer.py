'''Pull Trakt once. Empty local rows are filled. Newer local state wins.'''

from __future__ import annotations

from util import iso

from nextup.algorithm import rebuild_derived

THRESHOLD_DEFAULT = 0.85
FLOOR = 0.02


def plan_import(client):
    '''Fetch and summarise. Does not write the database.'''
    payload = fetch_payload(client)
    return {
        'movies': len(payload['movies']),
        'shows': len(payload['shows']),
        'playback': len(payload['playback']),
        'ratings': len(payload['ratings']),
        'watchlist': len(payload['watchlist']),
        'favorites': len(payload['favorites']),
        'lists': len(payload['lists']),
        'note': (
            'Trakt drops old playback entries. This import stores what Trakt '
            'still has. It is not a complete history of every resume.'
        )
    }, payload


def import_trakt(store, settings, client, payload=None, now=None, on_stage=None):
    now = now or iso()
    store.ensure_system_lists()
    if payload is None:
        payload = fetch_payload(client)
    threshold = settings.threshold if settings is not None else THRESHOLD_DEFAULT
    stats = {
        'titles': 0,
        'episodes': 0,
        'kept_local': 0,
        'ratings': 0,
        'watchlist': 0,
        'favorites': 0,
        'lists': 0
    }
    stages = (
        ('Watched movies', payload['movies'], _import_movie_watch),
        ('Watched shows', payload['shows'], _import_show_watch),
        ('History', payload['history'], _import_history),
        ('Playback', payload['playback'], None),
        ('Ratings', payload['ratings'], _import_rating),
        ('Watchlist', payload['watchlist'], None),
        ('Favorites', payload['favorites'], None),
        ('Lists', payload['lists'], _import_user_list),
    )
    total = len(stages)
    for index, (label, rows, writer) in enumerate(stages):
        if on_stage is not None:
            on_stage(index, total, label)
        if label == 'Playback':
            for entry in rows:
                _import_playback(store, entry, threshold, now, stats)
        elif label == 'Watchlist':
            for entry in rows:
                _import_membership(store, entry, 'watchlist', now, stats)
        elif label == 'Favorites':
            for entry in rows:
                _import_membership(store, entry, 'favorites', now, stats)
        elif label == 'Lists':
            for entry in rows:
                writer(store, entry, now, stats)
        else:
            for entry in rows:
                writer(store, entry, now, stats)
    store.meta_set('last_initial_import_at', now)
    if payload.get('user'):
        store.meta_set('trakt_user', payload['user'])
    rebuild_derived(store, settings)
    return stats


def fetch_payload(client):
    history = []
    history.extend(client.history_movies())
    history.extend(client.history_shows())
    lists = []
    for lst in client.user_lists():
        list_id = (lst.get('ids') or {}).get('trakt') or lst.get('id')
        items = client.list_items(list_id) if list_id else []
        copied = dict(lst)
        copied['items'] = items
        lists.append(copied)
    return {
        'movies': client.watched_movies(),
        'shows': client.watched_shows(),
        'history': history,
        'playback': client.playback(),
        'ratings': (
            client.ratings('movies') + client.ratings('shows')
            + client.ratings('seasons') + client.ratings('episodes')
        ),
        'watchlist': client.watchlist('movies') + client.watchlist('shows'),
        'favorites': client.favorites('movies') + client.favorites('shows'),
        'lists': lists,
        'user': ''
    }


def _ids(media):
    ids = (media or {}).get('ids') or {}
    return {
        'imdb': ids.get('imdb') or None,
        'tmdb': None if ids.get('tmdb') in (None, '') else str(ids.get('tmdb')),
        'tvdb': None if ids.get('tvdb') in (None, '') else str(ids.get('tvdb')),
        'trakt_id': None if ids.get('trakt') in (None, '') else str(ids.get('trakt'))
    }


def _upsert_movie(store, media, now):
    info = _ids(media)
    runtime = media.get('runtime')
    seconds = int(runtime) * 60 if runtime else None
    return store.upsert_title(
        media_type='movie',
        title=media.get('title') or 'Untitled',
        year=media.get('year'),
        premiered=media.get('released'),
        runtime_seconds=seconds,
        now=now,
        **info
    )


def _upsert_show(store, media, now):
    info = _ids(media)
    return store.upsert_title(
        media_type='show',
        title=media.get('title') or 'Untitled',
        year=media.get('year'),
        now=now,
        **info
    )


def _keep_local(local, remote_time, remote_resume):
    if local is None:
        return False
    local_time = local['updated_at'] or local['last_played'] or ''
    source = local['source'] or ''
    if source in ('local_play', 'fixup', 'manual') and local_time and remote_time:
        if local_time >= remote_time:
            return True
    if local['resume_seconds'] and not remote_resume:
        return True
    if source in ('local_play', 'fixup', 'manual') and local['resume_seconds'] not in (None, 0, 0.0):
        if not remote_time or (local_time and local_time >= remote_time):
            return True
    return False


def _import_movie_watch(store, entry, now, stats):
    movie = entry.get('movie') or {}
    title_id = _upsert_movie(store, movie, now)
    stats['titles'] += 1
    remote_time = entry.get('last_watched_at') or ''
    local = store.get_watch(title_id, None)
    if _keep_local(local, remote_time, None):
        stats['kept_local'] += 1
        return
    if remote_time:
        store.record_play(title_id, None, remote_time)
    plays = int(entry.get('plays') or 0)
    current = int(local['play_count']) if local is not None else 0
    known = len(store.list_plays(title_id, None))
    store.set_watch(
        title_id, None,
        play_count=max(current, plays, known),
        last_played=remote_time or (local['last_played'] if local is not None else None),
        resume_seconds=local['resume_seconds'] if local is not None else None,
        runtime_seconds=local['runtime_seconds'] if local is not None else None,
        source='trakt_import',
        updated_at=remote_time or now
    )


def _import_show_watch(store, entry, now, stats):
    show = entry.get('show') or {}
    show_id = _upsert_show(store, show, now)
    stats['titles'] += 1
    for season in entry.get('seasons') or []:
        season_number = int(season.get('number') or 0)
        for episode in season.get('episodes') or []:
            episode_number = int(episode.get('number') or 0)
            episode_id = store.upsert_episode(
                show_id, season_number, episode_number,
                title=episode.get('title')
            )
            stats['episodes'] += 1
            remote_time = episode.get('last_watched_at') or ''
            plays = int(episode.get('plays') or 0)
            local = store.get_watch(show_id, episode_id)
            if _keep_local(local, remote_time, None):
                stats['kept_local'] += 1
                continue
            if plays <= 0 and not remote_time:
                continue
            if remote_time:
                store.record_play(show_id, episode_id, remote_time)
            current = int(local['play_count']) if local is not None else 0
            known = len(store.list_plays(show_id, episode_id))
            store.set_watch(
                show_id, episode_id,
                play_count=max(current, plays, known),
                last_played=remote_time or None,
                resume_seconds=local['resume_seconds'] if local is not None else None,
                runtime_seconds=local['runtime_seconds'] if local is not None else None,
                source='trakt_import',
                updated_at=remote_time or now
            )


def _import_history(store, entry, now, stats):
    '''Each history row is one real watched_at. Missing dates are not invented.'''
    if entry.get('type') == 'movie' or (entry.get('movie') and not entry.get('episode')):
        movie = entry.get('movie') or {}
        if not movie:
            return
        title_id = _upsert_movie(store, movie, now)
        _remember_history_play(store, title_id, None, entry.get('watched_at') or '', now)
        return
    show = entry.get('show') or {}
    episode = entry.get('episode') or {}
    if not show or not episode:
        return
    show_id = _upsert_show(store, show, now)
    episode_id = store.upsert_episode(
        show_id, int(episode.get('season') or 0), int(episode.get('number') or 0),
        title=episode.get('title')
    )
    _remember_history_play(store, show_id, episode_id, entry.get('watched_at') or '', now)


def _remember_history_play(store, title_id, episode_id, watched_at, now):
    if watched_at:
        store.record_play(title_id, episode_id, watched_at)
    known = store.list_plays(title_id, episode_id)
    local = store.get_watch(title_id, episode_id)
    current = int(local['play_count']) if local is not None else 0
    latest = known[-1] if known else (watched_at or None)
    store.set_watch(
        title_id, episode_id,
        play_count=max(current, len(known)),
        last_played=latest or (local['last_played'] if local is not None else None),
        resume_seconds=local['resume_seconds'] if local is not None else None,
        runtime_seconds=local['runtime_seconds'] if local is not None else None,
        source='trakt_import',
        updated_at=now
    )


def _import_playback(store, entry, threshold, now, stats):
    progress = float(entry.get('progress') or 0)
    if progress < FLOOR * 100 or progress >= threshold * 100:
        return
    paused = entry.get('paused_at') or ''
    if entry.get('type') == 'movie' or (entry.get('movie') and not entry.get('episode')):
        movie = entry.get('movie') or {}
        title_id = _upsert_movie(store, movie, now)
        runtime = _runtime_seconds(movie)
        resume = (progress / 100.0) * runtime if runtime else None
        local = store.get_watch(title_id, None)
        if _keep_local(local, paused, resume):
            stats['kept_local'] += 1
            return
        store.set_watch(
            title_id, None,
            play_count=int(local['play_count']) if local is not None else 0,
            resume_seconds=resume,
            runtime_seconds=runtime,
            last_played=paused or (local['last_played'] if local is not None else None),
            source='trakt_import',
            updated_at=paused or now
        )
        return
    show = entry.get('show') or {}
    episode = entry.get('episode') or {}
    if not show or not episode:
        return
    show_id = _upsert_show(store, show, now)
    episode_id = store.upsert_episode(
        show_id, int(episode.get('season') or 0), int(episode.get('number') or 0),
        title=episode.get('title'),
        runtime_seconds=_runtime_seconds(episode)
    )
    runtime = _runtime_seconds(episode)
    resume = (progress / 100.0) * runtime if runtime else None
    local = store.get_watch(show_id, episode_id)
    if _keep_local(local, paused, resume):
        stats['kept_local'] += 1
        return
    store.set_watch(
        show_id, episode_id,
        play_count=int(local['play_count']) if local is not None else 0,
        resume_seconds=resume,
        runtime_seconds=runtime,
        last_played=paused or None,
        source='trakt_import',
        updated_at=paused or now
    )


def _runtime_seconds(media):
    runtime = media.get('runtime')
    if not runtime:
        return None
    return int(runtime) * 60


def _import_rating(store, entry, now, stats):
    score = entry.get('rating')
    if score is None:
        return
    remote_time = entry.get('rated_at') or ''
    episode = entry.get('episode')
    season = entry.get('season')
    show = entry.get('show')
    if episode and show:
        show_id = _upsert_show(store, show, now)
        season_number = int(episode.get('season') or 0)
        episode_id = store.upsert_episode(
            show_id, season_number, int(episode.get('number') or 0),
            title=episode.get('title')
        )
        _save_imported_rating(
            store, show_id, int(score), remote_time, now, stats,
            episode_id=episode_id, season=season_number
        )
        return
    if season and show and not episode:
        show_id = _upsert_show(store, show, now)
        _save_imported_rating(
            store, show_id, int(score), remote_time, now, stats,
            season=int(season.get('number') or 0)
        )
        return
    media = entry.get('movie') or show or {}
    if not media:
        return
    if entry.get('movie'):
        title_id = _upsert_movie(store, media, now)
    else:
        title_id = _upsert_show(store, media, now)
    _save_imported_rating(store, title_id, int(score), remote_time, now, stats)


def _save_imported_rating(store, title_id, score, remote_time, now, stats,
                          episode_id=None, season=None):
    local = store.get_rating(title_id, episode_id, season)
    if local is not None and local['source'] in ('local', 'local_play', 'manual'):
        local_time = local['updated_at'] or local['rated_at'] or ''
        if local_time and remote_time and local_time >= remote_time:
            stats['kept_local'] += 1
            return
    store.save_rating(
        title_id, score, source='trakt_import', rated_at=remote_time or now,
        episode_id=episode_id, season=season
    )
    stats['ratings'] += 1


def _import_membership(store, entry, slug, now, stats):
    media = entry.get('movie') or entry.get('show') or {}
    if not media:
        return
    if entry.get('movie'):
        title_id = _upsert_movie(store, media, now)
    else:
        title_id = _upsert_show(store, media, now)
    if not store.in_list(slug, title_id, None):
        store.add_list_item(slug, title_id, None)
        stats[slug] += 1


def _import_user_list(store, lst, now, stats):
    name = lst.get('name') or 'List'
    slug_source = (lst.get('ids') or {}).get('slug') or name
    slug = 'user:' + ''.join(
        ch.lower() if ch.isalnum() else '-' for ch in slug_source
    ).strip('-')
    if store.list_row(slug) is None:
        store.create_list(slug, name, 'user', 'mixed')
    stats['lists'] += 1
    for item in lst.get('items') or []:
        media = item.get('movie') or item.get('show') or {}
        if not media:
            continue
        if item.get('movie'):
            title_id = _upsert_movie(store, media, now)
        else:
            title_id = _upsert_show(store, media, now)
        store.add_list_item(slug, title_id, None)
