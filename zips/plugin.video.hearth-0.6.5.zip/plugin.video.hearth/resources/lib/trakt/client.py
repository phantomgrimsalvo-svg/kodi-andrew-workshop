'''Official Trakt API client. Every call goes through the network guard.'''

from __future__ import annotations

import json
from urllib.parse import urlencode

API = 'https://api.trakt.tv'


class TraktError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


# Device-token polling uses these statuses while the code is still in play.
# 400 means the user has not approved it yet. The others are Trakt's own outcomes.
POLL_STATUS = {
    400: 'Trakt has not confirmed the code yet. Finish the page, then run Import again.',
    404: 'That Trakt code is not valid. Run Import again.',
    409: 'That Trakt code was already used. Run Import again.',
    410: 'That Trakt code expired. Run Import again.',
    418: 'Trakt asked Hearth to wait before checking the code again.',
    429: 'Trakt is busy. Run Import again in a moment.'
}


def trakt_refusal(status, body=None):
    if isinstance(body, dict):
        detail = body.get('error_description') or body.get('error') or ''
        if detail and status not in (400,):
            return 'Trakt refused the request (%s). %s' % (status, detail)
    return 'Trakt refused the request (%s). Check the client id.' % (status or 0)


def read_trakt(response, poll=False):
    '''Return a JSON body, or raise when Trakt or Cloudflare did not.'''
    status = int(getattr(response, 'status', 200) or 200)
    body = getattr(response, 'body', None)
    if isinstance(body, (bytes, bytearray)):
        raise TraktError(trakt_refusal(status), status=status)
    if poll and status in POLL_STATUS:
        if status == 400 and isinstance(body, dict):
            return body
        if status == 400:
            raise TraktError(trakt_refusal(status), status=status)
        raise TraktError(POLL_STATUS[status], status=status)
    if status < 200 or status >= 300:
        raise TraktError(
            trakt_refusal(status, body if isinstance(body, dict) else None),
            status=status
        )
    if body is not None and not isinstance(body, (dict, list)):
        raise TraktError(trakt_refusal(status), status=status)
    return body


class TraktClient:
    def __init__(self, guard, client_id, access_token='', client_secret='', settings=None):
        self.guard = guard
        self.client_id = client_id or ''
        self.access_token = access_token or ''
        self.client_secret = client_secret or ''
        self.settings = settings

    def headers(self, auth=True):
        headers = {
            'Content-Type': 'application/json',
            'trakt-api-version': '2',
            'trakt-api-key': self.client_id
        }
        if auth and self.access_token:
            headers['Authorization'] = 'Bearer ' + self.access_token
        return headers

    def request_device_code(self):
        response = self.guard.post(
            API + '/oauth/device/code',
            'explicit_action',
            headers=self.headers(auth=False),
            body=json.dumps({'client_id': self.client_id})
        )
        body = read_trakt(response)
        return body if isinstance(body, dict) else {}

    def poll_device_token(self, device_code):
        from trakt.auth import device_token_body
        response = self.guard.post(
            API + '/oauth/device/token',
            'explicit_action',
            headers=self.headers(auth=False),
            body=json.dumps(device_token_body(
                self.client_id, device_code, self.client_secret
            ))
        )
        body = read_trakt(response, poll=True)
        return body if isinstance(body, dict) else {}

    def poll_device_result(self, device_code):
        '''Status plus JSON body. The sign-in loop decides what each status means.'''
        from trakt.auth import device_token_body
        response = self.guard.post(
            API + '/oauth/device/token',
            'explicit_action',
            headers=self.headers(auth=False),
            body=json.dumps(device_token_body(
                self.client_id, device_code, self.client_secret
            ))
        )
        status = int(getattr(response, 'status', 200) or 200)
        body = getattr(response, 'body', None)
        if isinstance(body, (bytes, bytearray)):
            raise TraktError(trakt_refusal(status), status=status)
        if not isinstance(body, dict):
            body = {}
        return status, body

    def refresh_access_token(self, refresh_token):
        from trakt.auth import refresh_token_body
        response = self.guard.post(
            API + '/oauth/token',
            'explicit_action',
            headers=self.headers(auth=False),
            body=json.dumps(refresh_token_body(
                self.client_id, refresh_token, self.client_secret
            ))
        )
        body = read_trakt(response)
        return body if isinstance(body, dict) else {}

    def get(self, path, params=None, purpose='initial_import', item_id=None):
        query = ('?' + urlencode(params)) if params else ''
        self._prepare()
        response = self.guard.get(
            API + path + query,
            purpose,
            item_id=item_id,
            headers=self.headers()
        )
        status = int(getattr(response, 'status', 200) or 200)
        if status == 401 and self.settings is not None:
            from trakt.auth import refresh_access_token
            renewed = refresh_access_token(self.settings, self.guard)
            if renewed:
                self.access_token = renewed
                response = self.guard.get(
                    API + path + query,
                    purpose,
                    item_id=item_id,
                    headers=self.headers()
                )
        read_trakt(response)
        return response

    def _prepare(self):
        if self.settings is None:
            return
        from trakt.auth import ensure_access_token
        token = ensure_access_token(self.settings, self.guard)
        if token:
            self.access_token = token

    def get_paginated(self, path, params=None, purpose='initial_import', item_id=None):
        page = 1
        items = []
        while page < 500:
            query = dict(params or {})
            query['page'] = page
            query['limit'] = query.get('limit') or 100
            response = self.get(path, query, purpose=purpose, item_id=item_id)
            body = response.body or []
            if isinstance(body, dict):
                body = body.get('items') or body.get('list') or []
            items.extend(body)
            page_count = int(response.headers.get('x-pagination-page-count') or 1)
            if page >= page_count or not body:
                break
            page += 1
        return items

    def watched_movies(self):
        return self.get_paginated('/sync/watched/movies')

    def watched_shows(self):
        return self.get_paginated('/sync/watched/shows')

    def history_movies(self):
        return self.get_paginated('/sync/history/movies')

    def history_shows(self):
        return self.get_paginated('/sync/history/shows')

    def playback(self):
        response = self.get('/sync/playback')
        body = response.body or []
        return body if isinstance(body, list) else []

    def ratings(self, media):
        return self.get_paginated('/sync/ratings/' + media)

    def watchlist(self, media):
        return self.get_paginated('/sync/watchlist/' + media)

    def favorites(self, media):
        return self.get_paginated('/users/me/favorites/' + media)

    def user_lists(self):
        return self.get_paginated('/users/me/lists')

    def list_items(self, list_id):
        return self.get_paginated('/users/me/lists/%s/items' % list_id)

    def lookup_tmdb(self, tmdb_id, media_type, item_id):
        kind = 'movie' if media_type == 'movie' else 'show'
        response = self.get(
            '/search/tmdb/%s' % tmdb_id,
            {'type': kind},
            purpose='manual_add',
            item_id=item_id
        )
        body = response.body or []
        return body[0] if body else None
