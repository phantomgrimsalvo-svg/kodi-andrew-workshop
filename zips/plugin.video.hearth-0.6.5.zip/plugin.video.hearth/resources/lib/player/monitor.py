'''Local playback progress. Lists never wait here.

A live scrobble, when the mirror setting is on, is queued and sent on a
background thread. This function returns before that request finishes.
'''

from __future__ import annotations

from util import iso, parse_iso

from nextup.algorithm import fraction, rebuild_derived


def note_progress(store, settings, title_id, position, runtime, elapsed,
                  event='progress', episode_id=None, now=None):
    '''Record resume locally. Ignore scrapes that never really started.

    A watchlist row graduates once playback passes the 2% floor or 30 seconds.
    Crossing the watched threshold on stop/end marks the item watched.
    '''
    now = now or iso()
    floor = settings.floor
    threshold = settings.threshold
    position = float(position or 0)
    runtime = float(runtime or 0)
    elapsed = float(elapsed if elapsed is not None else position)
    pct = fraction(position, runtime)
    if elapsed < 30 and pct < floor:
        return {'ignored': True, 'graduated': False, 'watched': False}
    existing = store.get_watch(title_id, episode_id)
    play_count = int(existing['play_count']) if existing is not None else 0
    watched = False
    if event in ('stop', 'end', 'ended', 'watched') and runtime and pct >= threshold:
        store.record_play(title_id, episode_id, now)
        play_count = max(play_count + 1, len(store.list_plays(title_id, episode_id)))
        position = 0
        watched = True
    store.set_watch(
        title_id,
        episode_id,
        play_count=play_count,
        resume_seconds=position,
        runtime_seconds=runtime or (existing['runtime_seconds'] if existing else None),
        last_played=now,
        source='local_play',
        updated_at=now
    )
    graduated = _graduate(store, settings, title_id, episode_id, now)
    _scrobble_live(store, settings, title_id, episode_id, event, pct, position, runtime, now, watched)
    rebuild_derived(store, settings)
    prompts = []
    if watched:
        from ratings.triggers import prompts_for_completion
        prompts = prompts_for_completion(
            store, title_id, episode_id, threshold=threshold
        )
    _touch_home()
    return {
        'ignored': False, 'graduated': graduated, 'watched': watched,
        'percent': pct, 'rating_prompts': prompts
    }


def mark_watched(store, settings, title_id, episode_id=None, now=None):
    now = now or iso()
    existing = store.get_watch(title_id, episode_id)
    previous = int(existing['play_count']) if existing is not None else 0
    store.record_play(title_id, episode_id, now)
    play_count = max(previous + 1, len(store.list_plays(title_id, episode_id)))
    runtime = None
    if existing is not None:
        runtime = existing['runtime_seconds']
    store.set_watch(
        title_id,
        episode_id,
        play_count=play_count,
        resume_seconds=0,
        runtime_seconds=runtime,
        last_played=now,
        source='local_play',
        updated_at=now
    )
    graduated = _graduate(store, settings, title_id, episode_id, now)
    rebuild_derived(store, settings)
    from ratings.triggers import prompts_for_completion
    prompts = prompts_for_completion(
        store, title_id, episode_id, threshold=settings.threshold
    )
    _touch_home()
    return {
        'watched': True, 'graduated': graduated, 'play_count': play_count,
        'rating_prompts': prompts
    }


def _scrobble_live(store, settings, title_id, episode_id, event, pct, position, runtime, now, watched):
    '''Fire a scrobble without waiting. A failure stays in the outbox.'''
    if watched or event in ('end', 'ended', 'watched'):
        action = 'stop'
    elif event in ('start', 'started'):
        action = 'start'
    elif event in ('pause', 'progress', 'stop'):
        action = 'pause' if event != 'stop' else 'stop'
    else:
        return
    try:
        from mirrors.scrobble import payload_for, queue_live_scrobble
        queue_live_scrobble(
            store, settings, action,
            payload_for(store, title_id, episode_id, pct, position, runtime),
            now=now
        )
    except Exception:
        return


def should_seek(settings, resume_seconds):
    behavior = (settings.get('resume_behavior') or 'seek_after_start').strip()
    return behavior != 'let_player' and float(resume_seconds or 0) > 0


def _graduate(store, settings, title_id, episode_id, now):
    if not store.in_list('watchlist', title_id, None):
        return False
    store.remove_list_item('watchlist', title_id, None)
    if settings.mirror_enabled():
        title = store.get_title(title_id)
        store.enqueue_outbox('watchlist_remove', {
            'title': title['title'] if title is not None else '',
            'ids': {
                'imdb': title['imdb'] if title is not None else None,
                'tmdb': title['tmdb'] if title is not None else None,
                'trakt': title['trakt_id'] if title is not None else None
            },
            'removed_at': now
        }, 'watchlist_remove:%s' % title_id, settings.get('cloud_mirror'))
    return True


def _touch_home():
    try:
        import xbmc
        xbmc.executebuiltin('SetProperty(hearth.changed,%s,home)' % iso())
    except Exception:
        return


# A handoff that never reaches playback is not a play. A few minutes is enough
# for Umbrella to scrape and start, and short enough that a later add-on does
# not inherit the title.
HANDOFF_WINDOW_SECONDS = 180
# Andrew's interval. The service loop wakes this often and samples only while
# a Hearth session is actually playing.
SAMPLE_SECONDS = 60


class HearthMonitor:
    '''xbmc.Player subclass used by service.py. Safe to construct under the stubs.'''

    def __init__(self, store, settings):
        self.store = store
        self.settings = settings
        self._started = None
        self._last_sample = None
        try:
            import xbmc
            self._player = xbmc.Player()
        except Exception:
            self._player = None

    def on_av_started(self, now=None):
        now = now or iso()
        playing = self._playing()
        session = self._session()
        if session and not session.get('av_started_at'):
            if session_expired(session, now) or item_matches(self.store, session, playing) is False:
                self.clear_session()
                session = None
            else:
                session['av_started_at'] = now
                self._save_session(session)
                self._offer_resume(session, playing)
                return
        if session and session.get('av_started_at'):
            if item_matches(self.store, session, playing) is not True:
                self.clear_session()
            return
        if not self.settings.flag('track_other_addons', True):
            return
        self._adopt_foreign(playing, now)

    def on_progress(self, position, runtime, elapsed, event='progress', now=None):
        now = now or iso()
        session = self._session()
        if not session:
            return None
        if not session.get('av_started_at'):
            if session_expired(session, now) or item_matches(self.store, session, self._playing()) is False:
                self.clear_session()
            return None
        if item_matches(self.store, session, self._playing()) is False:
            self.clear_session()
            return None
        self.remember(position, runtime, elapsed)
        result = note_progress(
            self.store,
            self.settings,
            int(session['title_id']),
            position,
            runtime,
            elapsed,
            event=event,
            episode_id=session.get('episode_id'),
            now=now
        )
        if event in ('stop', 'end', 'ended'):
            self.clear_session()
        return result

    def sample_playback(self, now=None):
        '''One reading from the player. The service calls this every SAMPLE_SECONDS.

        No Hearth session, or a session that has not started, writes nothing.
        '''
        session = self._session()
        if not session or not session.get('av_started_at'):
            return None
        if item_matches(self.store, session, self._playing()) is False:
            self.clear_session()
            return None
        reading = self._player_clock()
        if reading is None:
            return None
        position, runtime, elapsed = reading
        return self.on_progress(position, runtime, elapsed, event='progress', now=now)

    def finish(self, event, now=None):
        '''Stop keeps the last good sample. End is a completed play.

        getTime() is not called. Kodi has already torn the player down.
        '''
        cached = self._last_sample
        if event in ('end', 'ended'):
            runtime = cached[1] if cached else 0
            position = runtime
            elapsed = runtime
        elif not cached:
            return None
        else:
            position, runtime, elapsed = cached
        return self.on_progress(position, runtime, elapsed, event=event, now=now)

    def remember(self, position, runtime, elapsed=None):
        try:
            position = float(position or 0)
            runtime = float(runtime or 0)
            elapsed = float(position if elapsed is None else elapsed)
        except (TypeError, ValueError):
            return
        if position < 0:
            return
        if runtime <= 0 and self._last_sample:
            runtime = self._last_sample[1]
        if runtime <= 0:
            return
        self._last_sample = (position, runtime, elapsed)

    def _adopt_foreign(self, playing, now):
        from player.capture import adopt_playing, queue_metadata_fill
        runtime = self._known_runtime(playing)
        if runtime and not playing.get('duration'):
            playing = dict(playing)
            playing['duration'] = runtime
        adopted = adopt_playing(self.store, playing)
        if not adopted:
            return None
        session = {
            'title_id': adopted['title_id'],
            'episode_id': adopted['episode_id'],
            'resume_seconds': adopted['resume_seconds'],
            'player_id': 'other',
            'started_at': now,
            'av_started_at': now,
            'token': 'foreign',
            'origin': 'foreign'
        }
        self._save_session(session)
        if adopted['created']:
            queue_metadata_fill(
                self.store, self.settings, adopted['identifiers'],
                starter=getattr(self, 'metadata_starter', None)
            )
        self._offer_resume(session, playing, runtime or adopted.get('runtime_seconds') or 0)
        return session

    def _offer_resume(self, session, playing, runtime=None):
        from player.capture import offer_resume
        if runtime is None:
            runtime = self._known_runtime(playing)
        position = 0
        if self._player is not None and hasattr(self._player, 'getTime'):
            try:
                position = float(self._player.getTime())
            except Exception:
                position = 0
        try:
            offer_resume(
                self._player,
                self.settings,
                session.get('resume_seconds'),
                runtime,
                position,
                self._ask_resume
            )
        except Exception:
            return

    def _ask_resume(self, seconds):
        forced = getattr(self, 'resume_answer', None)
        if forced is not None:
            return forced
        from player.capture import resume_labels
        import xbmcgui
        index = xbmcgui.Dialog().select('Hearth', resume_labels(seconds))
        if index == 0:
            return 'resume'
        return 'beginning'

    def _known_runtime(self, playing):
        duration = float((playing or {}).get('duration') or 0)
        clock = self._player_clock()
        player_runtime = clock[1] if clock else 0
        return duration or player_runtime or 0

    def clear_session(self):
        self.store.meta_set('active_session', '')
        self._last_sample = None

    def _player_clock(self):
        player = self._player
        if player is None or not hasattr(player, 'getTime'):
            return None
        try:
            position = float(player.getTime())
            runtime = float(player.getTotalTime())
        except Exception:
            return None
        if position < 0 or runtime <= 0:
            return None
        return (position, runtime, position)

    def _session(self):
        from util import loads
        raw = self.store.meta_get('active_session')
        return loads(raw, None)

    def _save_session(self, session):
        from util import dumps
        self.store.meta_set('active_session', dumps(session))

    def _playing(self):
        player = self._player
        if player is None:
            return {}
        tag = None
        item = None
        if hasattr(player, 'getPlayingItem'):
            try:
                item = player.getPlayingItem()
            except Exception:
                item = None
        if item is not None and hasattr(item, 'getVideoInfoTag'):
            try:
                tag = item.getVideoInfoTag()
            except Exception:
                tag = None
        if tag is None and hasattr(player, 'getVideoInfoTag'):
            try:
                tag = player.getVideoInfoTag()
            except Exception:
                tag = None
        if tag is None:
            return {}
        unique = {}
        if hasattr(tag, 'getUniqueIDs'):
            try:
                unique = tag.getUniqueIDs() or {}
            except Exception:
                unique = {}
        season = _tag_number(tag, 'getSeason')
        episode = _tag_number(tag, 'getEpisode')
        path = _tag_text(tag, 'getFilenameAndPath') or _tag_text(tag, 'getPath')
        if not path and player is not None and hasattr(player, 'getPlayingFile'):
            try:
                path = player.getPlayingFile() or ''
            except Exception:
                path = ''
        duration = _tag_number(tag, 'getDuration')
        return {
            'imdb': _norm_id(unique.get('imdb') or unique.get('imdb_id')),
            'tmdb': _norm_id(unique.get('tmdb') or unique.get('tmdb_id')),
            'tvdb': _norm_id(unique.get('tvdb') or unique.get('tvdb_id')),
            'season': season,
            'episode': episode,
            'mediatype': _tag_text(tag, 'getMediaType'),
            'title': _tag_text(tag, 'getTitle'),
            'showtitle': _tag_text(tag, 'getTVShowTitle'),
            'path': path or '',
            'duration': duration or 0
        }


def session_expired(session, now):
    if session.get('av_started_at'):
        return False
    started = parse_iso(session.get('started_at'))
    current = parse_iso(now) if not hasattr(now, 'tzinfo') else now
    if started is None or current is None:
        return True
    return (current - started).total_seconds() > HANDOFF_WINDOW_SECONDS


def item_matches(store, session, playing):
    '''True when the playing item is this handoff, False when it is another, None when the player has no ids yet.'''
    title = store.get_title(int(session['title_id']))
    if title is None:
        return False
    episode = None
    if session.get('episode_id'):
        episode = store.get_episode(int(session['episode_id']))
        if episode is None:
            return False
    expected = {}
    source = episode if episode is not None else title
    for key in ('imdb', 'tmdb', 'tvdb'):
        value = _norm_id(source[key])
        if not value and episode is not None:
            value = _norm_id(title[key])
        if value:
            expected[key] = value
    playing = playing or {}
    matched = False
    for key in ('imdb', 'tmdb', 'tvdb'):
        got = _norm_id(playing.get(key))
        if not got:
            continue
        want = expected.get(key)
        if want and got != want:
            return False
        if want and got == want:
            matched = True
    season = playing.get('season')
    number = playing.get('episode')
    if episode is not None and season is not None and number is not None:
        if int(season) != int(episode['season']) or int(number) != int(episode['episode']):
            return False
        matched = True
    elif episode is None and season is not None and number is not None and int(number) > 0:
        return False
    if matched:
        return True
    return None


def _norm_id(value):
    if value is None:
        return ''
    text = str(value).strip().lower()
    if text in ('', 'none', '0'):
        return ''
    return text


def _tag_text(tag, method):
    getter = getattr(tag, method, None)
    if getter is None:
        return ''
    try:
        value = getter()
    except Exception:
        return ''
    if value is None:
        return ''
    return str(value).strip()


def _tag_number(tag, method):
    getter = getattr(tag, method, None)
    if getter is None:
        return None
    try:
        value = getter()
    except Exception:
        return None
    if value is None or value == '':
        return None
    try:
        number = int(value)
    except (TypeError, ValueError):
        return None
    if number < 0:
        return None
    return number
