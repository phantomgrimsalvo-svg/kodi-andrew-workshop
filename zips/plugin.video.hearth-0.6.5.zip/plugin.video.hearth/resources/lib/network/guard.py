'''Network policy. Strict mode refuses anything outside the allowed windows.

No other module may call urllib or requests. This module is the session factory.
'''

from __future__ import annotations

from urllib.parse import urlparse

from util import redact

class NetworkGuardError(Exception):
    pass


class LiveNetworkDisabled(NetworkGuardError):
    '''Raised when code tries to open a real socket. Tests and dev stay offline.'''


# Purposes that may open a socket, and the hosts they may touch.
PURPOSE_HOSTS = {
    'initial_import': ('api.trakt.tv', 'api.themoviedb.org', 'image.tmdb.org'),
    'manual_add': ('api.themoviedb.org', 'image.tmdb.org', 'api.trakt.tv'),
    'cloud_mirror': (),
    'weekly_recs': ('api.themoviedb.org', 'image.tmdb.org'),
    'explicit_action': (
        'api.trakt.tv', 'api.themoviedb.org', 'image.tmdb.org', 'trakt.tv'
    ),
    'local_backup': (),
    'playback_scrobble': (),
    'blocked': ()
}

BLOCKED_PATH_MARKERS = ('/sync/collection',)


class Response:
    def __init__(self, status, body, headers=None, content=None):
        self.status = status
        self.body = body
        self.headers = {str(k).lower(): v for k, v in (headers or {}).items()}
        if content is None and isinstance(body, bytes):
            content = body
        self.content = content or b''


class ForbiddenTransport:
    def __call__(self, method, url, headers=None, body=None):
        raise LiveNetworkDisabled(
            'Live HTTP is disabled. Inject a transport. Refused %s %s' % (
                method, redact(url)
            )
        )


class Guard:
    def __init__(self, policy='strict', transport=None, store=None, settings=None):
        self.policy = _normalize_policy(policy)
        self.transport = transport or ForbiddenTransport()
        self.store = store
        self.settings = settings
        self.calls = []
        self.allowed_images = set()
        self.mirror_host = ''
        self.extra_hosts = set()

    def set_policy(self, policy):
        self.policy = _normalize_policy(policy)

    def allow_image(self, path):
        self.allowed_images.add(_image_key(path))

    def set_mirror_host(self, host):
        self.mirror_host = (host or '').lower()

    def allow_host(self, host):
        if host:
            self.extra_hosts.add(host.lower())

    def request(self, method, url, purpose, item_id=None, headers=None, body=None):
        method = (method or 'GET').upper()
        parsed = urlparse(url)
        host = (parsed.hostname or '').lower()
        path = parsed.path or '/'
        allowed, why = self.decide(method, host, path, purpose, item_id)
        record = {
            'method': method,
            'url': url,
            'host': host,
            'path': path,
            'purpose': purpose,
            'item_id': item_id,
            'allowed': allowed
        }
        self.calls.append(record)
        if self.store is not None:
            try:
                self.store.record_network_event(
                    purpose, method, host, path, allowed, item_id
                )
            except Exception:
                pass
        if not allowed and self.policy == 'strict':
            raise NetworkGuardError(why or 'blocked %s %s' % (method, path))
        if purpose == 'local_backup' and self.policy != 'allow_all':
            raise NetworkGuardError('local backup must not use the network')
        return self.transport(method, url, headers=headers, body=body)

    def decide(self, method, host, path, purpose, item_id):
        purpose = purpose or 'blocked'
        if any(marker in path for marker in BLOCKED_PATH_MARKERS):
            return False, 'collection is out of scope'
        if '/scrobble/' in path:
            action = path.rstrip('/').split('/')[-1]
            if purpose != 'playback_scrobble' or action not in ('start', 'pause', 'stop'):
                return False, 'scrobble is only sent in the background during playback'
        if self.policy == 'allow_all':
            return True, 'allow_all'
        if purpose not in PURPOSE_HOSTS:
            return False, 'unknown purpose %s' % purpose
        if purpose in ('local_backup', 'blocked'):
            return False, 'purpose %s cannot open the network' % purpose
        if purpose == 'cloud_mirror':
            if host == 'image.tmdb.org':
                return False, 'cloud mirror does not rescan art'
            expected = self.mirror_host
            if self.settings is not None and not expected:
                from urllib.parse import urlparse as parse
                base = self.settings.get('mirror_base_url') or ''
                expected = (parse(base).hostname or '').lower()
                if not expected and (self.settings.get('cloud_mirror') or '') in (
                    'tmdb', 'tmdb_lists'
                ):
                    expected = 'api.themoviedb.org'
            if host == 'api.themoviedb.org' and expected != 'api.themoviedb.org':
                return False, 'cloud mirror must not call TMDB'
            if not expected or host != expected:
                return False, 'cloud mirror host %s is not the enabled adapter' % host
            if host == 'api.themoviedb.org' and '/list/' not in path:
                return False, 'TMDB mirror only writes lists'
            return True, 'mirror'
        if purpose == 'playback_scrobble':
            expected = self.mirror_host
            if self.settings is not None and not expected:
                name = (self.settings.get('cloud_mirror') or '').lower()
                expected = {
                    'trakt': 'api.trakt.tv',
                    'simkl': 'api.simkl.com'
                }.get(name, '')
            if not expected or host != expected:
                return False, 'scrobble host %s is not the selected mirror' % host
            return True, 'playback scrobble'
        allowed_hosts = PURPOSE_HOSTS.get(purpose, ())
        if host not in allowed_hosts and host not in self.extra_hosts:
            return False, 'host %s is not allowed for %s' % (host, purpose)
        if host in self.extra_hosts and purpose not in ('weekly_recs', 'explicit_action'):
            return False, 'extra host is only for recommendations or an explicit action'
        if purpose == 'manual_add':
            return self._manual_add_ok(host, path, item_id)
        if purpose == 'weekly_recs' and host == 'image.tmdb.org':
            if _image_key(path) not in self.allowed_images:
                return False, 'image was not part of this recs fetch'
        return True, 'ok'

    def _manual_add_ok(self, host, path, item_id):
        item = str(item_id or '')
        ids = [part for part in item.split('|') if part]
        if host == 'image.tmdb.org':
            if _image_key(path) in self.allowed_images:
                return True, 'art for this title'
            return False, 'image was not returned for this title'
        if host == 'api.themoviedb.org':
            if any(part and part in path for part in ids):
                return True, 'tmdb for this id'
            if '/find/' in path and any(part and part in path for part in ids):
                return True, 'tmdb find'
            return False, 'tmdb path is not this title'
        if host == 'api.trakt.tv':
            authorized = True
            if self.settings is not None:
                authorized = self.settings.trakt_authorized()
            if not authorized:
                return False, 'trakt is not authorized'
            if any(part and part in path for part in ids):
                return True, 'trakt for this id'
            return False, 'trakt path is not this title'
        return False, 'manual add host refused'

    def get(self, url, purpose, item_id=None, headers=None):
        return self.request('GET', url, purpose, item_id=item_id, headers=headers)

    def post(self, url, purpose, item_id=None, headers=None, body=None):
        return self.request(
            'POST', url, purpose, item_id=item_id, headers=headers, body=body
        )


def _image_key(path):
    text = path or ''
    if '://' in text:
        text = urlparse(text).path
    return text


def _normalize_policy(policy):
    value = (policy or 'strict').strip().lower()
    if value in ('debug', 'debug log only'):
        return 'debug'
    if value in ('allow_all', 'allow all', 'allow all (developer)'):
        return 'allow_all'
    return 'strict'


_INSTALLED = False
_ACTIVE = None


def active_guard():
    global _ACTIVE
    if _ACTIVE is None:
        policy = 'strict'
        settings = None
        try:
            from settings import load_kodi_settings
            settings = load_kodi_settings()
            policy = settings.policy()
        except Exception:
            settings = None
        _ACTIVE = Guard(
            policy=policy, transport=default_transport(), settings=settings
        )
    return _ACTIVE


def set_active_guard(guard):
    global _ACTIVE
    _ACTIVE = guard


def install_runtime_patches(guard=None):
    '''Route urllib and requests through the guard so a stray call fails closed.'''
    global _INSTALLED
    guard = guard or active_guard()
    set_active_guard(guard)
    _patch_urllib(guard)
    _patch_requests(guard)
    _INSTALLED = True
    return guard


def _patch_urllib(guard):
    import urllib.request

    def urlopen(url, data=None, timeout=None, *args, **kwargs):
        target = url.get_full_url() if hasattr(url, 'get_full_url') else str(url)
        method = 'POST' if data is not None else 'GET'
        raise NetworkGuardError(
            'raw urllib is not allowed (%s %s). Use network.guard' % (method, redact(target))
        )

    urllib.request.urlopen = urlopen


def default_transport():
    '''Real sockets only inside Kodi. Tests and this workspace stay offline.'''
    try:
        import xbmc
        if getattr(xbmc, '__hearth_stub__', False):
            return ForbiddenTransport()
    except Exception:
        return ForbiddenTransport()
    return kodi_transport


def hearth_user_agent():
    version = 'dev'
    try:
        import xml.etree.ElementTree as ET
        from pathlib import Path
        root = Path(__file__).resolve().parents[3] / 'addon.xml'
        version = ET.parse(root).getroot().attrib.get('version') or version
    except Exception:
        version = 'dev'
    return 'Hearth/%s (Kodi; plugin.video.hearth)' % version


def with_user_agent(headers):
    outgoing = dict(headers or {})
    if not any(str(key).lower() == 'user-agent' for key in outgoing):
        outgoing['User-Agent'] = hearth_user_agent()
    return outgoing


def kodi_transport(method, url, headers=None, body=None):
    '''HTTP implementation used on device. Kept in this module so nothing else opens a socket.'''
    import http.client
    import json as json_lib
    parsed = urlparse(url)
    port = parsed.port or (443 if parsed.scheme == 'https' else 80)
    if parsed.scheme == 'https':
        connection = http.client.HTTPSConnection(parsed.hostname, port, timeout=30)
    else:
        connection = http.client.HTTPConnection(parsed.hostname, port, timeout=30)
    path = parsed.path or '/'
    if parsed.query:
        path = path + '?' + parsed.query
    payload = body.encode('utf-8') if isinstance(body, str) else body
    # Authorization is sent. The guard records the path only, never the header.
    # Cloudflare in front of Trakt rejects requests that have no User-Agent.
    outgoing = with_user_agent(headers)
    try:
        connection.request(method, path, body=payload, headers=outgoing)
        remote = connection.getresponse()
        raw = remote.read()
        header_map = {key: value for key, value in remote.getheaders()}
        status = remote.status
    finally:
        connection.close()
    try:
        parsed_body = json_lib.loads(raw.decode('utf-8')) if raw else None
    except ValueError:
        parsed_body = raw
    return Response(status, parsed_body, header_map, content=raw)


def _patch_requests(guard):
    try:
        import requests
    except ImportError:
        return

    def blocked_get(url, *args, **kwargs):
        raise NetworkGuardError(
            'raw requests.get is not allowed (%s). Use network.guard' % redact(url)
        )

    def blocked_request(self, method, url, *args, **kwargs):
        raise NetworkGuardError(
            'raw requests is not allowed (%s %s). Use network.guard' % (
                method, redact(url)
            )
        )

    requests.get = blocked_get
    requests.sessions.Session.request = blocked_request
