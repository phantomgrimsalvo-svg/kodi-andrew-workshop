'''Taste profile, candidate search, and a structured recommendation list.'''

from __future__ import annotations

import json
from urllib.parse import quote, urlparse

from art.store import download_images
from tmdb.client import fetch_movie, fetch_show, movie_fields, show_fields
from util import dumps, iso, loads

PROVIDERS = {
    'openai': 'https://api.openai.com/v1/chat/completions',
    'anthropic': 'https://api.anthropic.com/v1/messages',
    'gemini': 'https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent',
    'grok': 'https://api.x.ai/v1/chat/completions',
    'openrouter': 'https://openrouter.ai/api/v1/chat/completions',
    'custom': ''
}

DEFAULT_MODELS = {
    'openai': 'gpt-4o-mini',
    'anthropic': 'claude-sonnet-4-6',
    'gemini': 'gemini-2.5-flash-lite',
    'grok': 'grok-4.7',
    'openrouter': 'openai/gpt-4o-mini',
    'custom': ''
}


def provider_url(settings):
    name = (settings.get('recs_provider') or 'openai').strip().lower()
    if name == 'custom':
        base = (settings.get('recs_base_url') or '').rstrip('/')
        return base + '/chat/completions' if base else ''
    template = PROVIDERS.get(name, '')
    model = settings.get('recs_model') or DEFAULT_MODELS.get(name, '')
    return template.replace('{model}', quote(model, safe=''))


def build_taste_profile(store):
    document = store.export_document()
    titles = {row['id']: row for row in document['titles']}
    rated = []
    for rating in document['ratings']:
        if rating.get('season') not in (None, ''):
            continue
        title = titles.get(rating['title_id'])
        if title is None or rating.get('score') is None:
            continue
        genres = loads(title.get('genres'), []) or []
        rated.append({
            'title': title['title'],
            'year': title.get('year'),
            'media_type': title['media_type'],
            'score': rating['score'],
            'genres': genres,
            'liked': rating.get('liked') or '',
            'disliked': rating.get('disliked') or '',
            'tags': loads(rating.get('tags'), []) or [],
            'plot': (title.get('plot') or '')[:400],
            'tmdb': title.get('tmdb')
        })
    pairs = _contrastive_pairs(rated)
    keywords = []
    for row in rated:
        if row['score'] and int(row['score']) >= 8:
            keywords.extend(row['tags'])
            keywords.extend(row['genres'][:1])
    keywords = list(dict.fromkeys([item for item in keywords if item]))[:12]
    lines = [
        'Taste profile built only from local ratings.',
        'Look for theme, tone, moral stance, craft, and audience.',
        'Do not recommend more of a surface genre just because two titles share it.'
    ]
    for pair in pairs:
        lines.append(
            'Contrast: "%s" (%s) was rated %s and "%s" (%s) was rated %s. '
            'They share %s. Do not recommend more %s from this pair. '
            'Look for what the high title shares with other highs, and what the low title shares with other lows.'
            % (
                pair['high_title'], pair['high_score'], pair['high_score'],
                pair['low_title'], pair['low_score'], pair['low_score'],
                pair['genre'], pair['genre']
            )
        )
    # The format above repeats scores. Rewrite the sentence cleanly.
    lines = lines[:3]
    for pair in pairs:
        lines.append(
            'Contrast inside %s: high "%s" (%s) versus low "%s" (%s). '
            'Do not recommend more %s from that pair.'
            % (
                pair['genre'], pair['high_title'], pair['high_score'],
                pair['low_title'], pair['low_score'], pair['genre']
            )
        )
    highs = [row for row in rated if int(row['score']) >= 8][:8]
    lows = [row for row in rated if int(row['score']) <= 4][:8]
    if highs:
        lines.append('High: ' + '; '.join(
            '%s (%s) %s' % (row['title'], row['score'], row['liked']) for row in highs
        ))
    if lows:
        lines.append('Low: ' + '; '.join(
            '%s (%s) %s' % (row['title'], row['score'], row['disliked']) for row in lows
        ))
    return {
        'text': '\n'.join(lines),
        'keywords': keywords,
        'pairs': pairs,
        'rating_count': len(document['ratings'])
    }


def _contrastive_pairs(rated):
    pairs = []
    by_genre = {}
    for row in rated:
        for genre in row['genres'] or ['unknown']:
            by_genre.setdefault(genre, []).append(row)
    for genre, rows in by_genre.items():
        high = [row for row in rows if int(row['score']) >= 8]
        low = [row for row in rows if int(row['score']) <= 4]
        if high and low:
            pairs.append({
                'genre': genre,
                'high_title': high[0]['title'],
                'high_score': high[0]['score'],
                'low_title': low[0]['title'],
                'low_score': low[0]['score']
            })
    return pairs[:6]


def rebuild_recommendations(store, settings, guard, dry_run=False, now=None):
    now = now or iso()
    store.ensure_system_lists()
    _ensure_dismissed(store)
    if not (settings.get('recs_api_key') or ''):
        return {'skipped': 'configure AI provider', 'calls': 0}
    profile = build_taste_profile(store)
    previous = loads(store.meta_get('taste_profile'), {}) or {}
    cheaper = previous.get('rating_count') == profile['rating_count'] and previous.get('text')
    if cheaper:
        profile = dict(previous)
        profile['text'] = previous['text'] + '\nNew releases only. No new ratings since the last profile.'
    else:
        store.meta_set('taste_profile', dumps(profile))
        store.meta_set('taste_profile_at', now)
    if not _within_budget(store, settings, now):
        return {'skipped': 'monthly budget', 'profile': profile['text'], 'calls': 0}
    guard.allow_host(_host(provider_url(settings)))
    search_url = settings.get('recs_search_url') or ''
    if search_url:
        guard.allow_host(_host(search_url))
    candidates = collect_candidates(store, settings, guard, profile, cheaper=cheaper)
    limit = settings.integer('recs_max_titles', 30)
    prompt = _prompt(profile, candidates[:limit], cheaper=cheaper)
    if dry_run:
        return {
            'dry_run': True,
            'prompt': prompt,
            'candidates': len(candidates),
            'profile': profile['text'],
            'calls': 0
        }
    raw = call_model(settings, guard, prompt)
    _count_call(store, now)
    chosen = parse_recommendations(raw, cap=settings.integer('recs_max_output', 20))
    chosen = _drop_known(store, chosen)
    inserted = _persist_new(store, settings, guard, chosen)
    store.meta_set('last_recs_at', now)
    return {'inserted': inserted, 'prompt': prompt, 'candidates': len(candidates)}


def collect_candidates(store, settings, guard, profile, cheaper=False):
    key = settings.get('tmdb_api_key') or ''
    if not key:
        return []
    found = []
    seen = set()
    year = (iso()[:4] if cheaper else '')
    queries = [year] if cheaper else (profile.get('keywords') or ['drama'])[:3]
    for query in queries:
        if not query:
            continue
        path = '/3/search/multi?api_key=%s&query=%s' % (key, quote(str(query)))
        response = guard.get('https://api.themoviedb.org' + path, 'weekly_recs')
        for item in (response.body or {}).get('results') or []:
            media = item.get('media_type')
            if media not in ('movie', 'tv'):
                continue
            tmdb_id = str(item.get('id'))
            if tmdb_id in seen:
                continue
            seen.add(tmdb_id)
            found.append({
                'media_type': 'show' if media == 'tv' else 'movie',
                'title': item.get('title') or item.get('name'),
                'year': _year(item.get('release_date') or item.get('first_air_date')),
                'tmdb_id': tmdb_id,
                'plot': item.get('overview') or ''
            })
            if len(found) >= settings.integer('recs_max_candidates', 40):
                return _filter_known(store, found)
    search_url = settings.get('recs_search_url') or ''
    if search_url and not cheaper:
        response = guard.get(search_url, 'weekly_recs')
        for item in response.body or []:
            if not isinstance(item, dict):
                continue
            tmdb_id = str(item.get('tmdb_id') or '')
            if not tmdb_id or tmdb_id in seen:
                continue
            seen.add(tmdb_id)
            found.append({
                'media_type': item.get('media_type') or 'movie',
                'title': item.get('title'),
                'year': item.get('year'),
                'tmdb_id': tmdb_id,
                'plot': item.get('plot') or ''
            })
    return _filter_known(store, found)


class ProviderError(Exception):
    '''The model call did not return a usable reply.'''


def call_model(settings, guard, prompt):
    url = provider_url(settings)
    name = (settings.get('recs_provider') or 'openai').strip().lower()
    key = (settings.get('recs_api_key') or '').strip()
    if not key:
        raise ProviderError('No API key set')
    if not url:
        raise ProviderError('No API address set')
    if name == 'anthropic':
        headers = {
            'Content-Type': 'application/json',
            'x-api-key': key,
            'anthropic-version': '2023-06-01'
        }
        body = {
            'model': settings.get('recs_model') or DEFAULT_MODELS['anthropic'],
            'max_tokens': 1200,
            'messages': [{'role': 'user', 'content': prompt}]
        }
    elif name == 'gemini':
        headers = {'Content-Type': 'application/json'}
        url = url + ('&' if '?' in url else '?') + 'key=' + key
        body = {'contents': [{'parts': [{'text': prompt}]}]}
    else:
        headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer ' + key}
        body = {
            'model': settings.get('recs_model') or DEFAULT_MODELS.get(name, ''),
            'messages': [{'role': 'user', 'content': prompt}],
            'temperature': 0.4
        }
    response = guard.post(url, 'weekly_recs', headers=headers, body=json.dumps(body))
    status = int(getattr(response, 'status', 0) or 0)
    if isinstance(getattr(response, 'body', None), (bytes, bytearray)):
        raise ProviderError('The provider returned a page instead of data (%s).' % (status or 0))
    if status < 200 or status >= 300:
        from util import redact
        detail = redact(_error_text(getattr(response, 'body', None)))
        if key and key in detail:
            detail = detail.replace(key, '[redacted]')
        raise ProviderError(detail or ('The provider returned HTTP %s' % status))
    text = (_message_text(name, response.body) or '').strip()
    if not text:
        raise ProviderError('The provider returned an empty reply')
    return text


def test_connection(settings, guard):
    if not (settings.get('recs_api_key') or '').strip():
        raise ProviderError('No API key set')
    url = provider_url(settings)
    if not url:
        raise ProviderError('No API address set')
    guard.allow_host(_host(url))
    call_model(settings, guard, 'Reply with []')
    return {'ok': True, 'host': _host(url)}


def parse_recommendations(raw, cap=20):
    text = (raw or '').strip()
    if not text:
        return []
    start = text.find('[')
    end = text.rfind(']')
    if start < 0 or end < start:
        return []
    try:
        data = json.loads(text[start:end + 1])
    except ValueError:
        return []
    chosen = []
    for item in data:
        if not isinstance(item, dict):
            continue
        title = item.get('title')
        media = item.get('media_type')
        if media == 'tv':
            media = 'show'
        if not title or media not in ('movie', 'show'):
            continue
        chosen.append({
            'media_type': media,
            'title': title,
            'year': item.get('year'),
            'tmdb_id': None if item.get('tmdb_id') in (None, '') else str(item.get('tmdb_id')),
            'imdb_id': item.get('imdb_id') or None,
            'reason': item.get('reason') or ''
        })
        if len(chosen) >= cap:
            break
    return chosen


def _prompt(profile, candidates, cheaper=False):
    slim = [
        {
            'media_type': item['media_type'],
            'title': item['title'],
            'year': item.get('year'),
            'tmdb_id': item.get('tmdb_id'),
            'plot': (item.get('plot') or '')[:280]
        }
        for item in candidates
    ]
    return (
        profile['text']
        + '\nReturn JSON only, a list of {media_type, title, year, tmdb_id, imdb_id, reason}. '
        + 'Mix movies and shows. Exclude anything already watched. '
        + ('This is a new-releases pass.\n' if cheaper else '\n')
        + 'Candidates:\n' + json.dumps(slim)
    )


def _error_text(body):
    if isinstance(body, dict):
        err = body.get('error')
        if isinstance(err, dict):
            return str(err.get('message') or err.get('status') or '')
        if isinstance(err, str):
            return err
        return str(body.get('message') or '')
    if isinstance(body, str):
        return body[:300]
    return ''


def _message_text(provider, body):
    if not isinstance(body, dict):
        return body if isinstance(body, str) else ''
    if provider == 'anthropic':
        parts = body.get('content') or []
        return ''.join(part.get('text', '') for part in parts if isinstance(part, dict))
    if provider == 'gemini':
        candidates = body.get('candidates') or []
        if not candidates:
            return ''
        parts = ((candidates[0].get('content') or {}).get('parts')) or []
        return ''.join(part.get('text', '') for part in parts if isinstance(part, dict))
    choices = body.get('choices') or []
    if choices:
        return ((choices[0].get('message') or {}).get('content')) or ''
    return body.get('text') or ''


def _filter_known(store, found):
    kept = []
    for item in found:
        if _is_blocked(store, item['tmdb_id'], item['media_type']):
            continue
        kept.append(item)
    return kept


def _drop_known(store, chosen):
    kept = []
    seen = set()
    for item in chosen:
        key = (item['media_type'], item.get('tmdb_id') or item['title'])
        if key in seen:
            continue
        seen.add(key)
        if item.get('tmdb_id') and _is_blocked(store, item['tmdb_id'], item['media_type']):
            continue
        kept.append(item)
    return kept


def _is_blocked(store, tmdb_id, media_type):
    title = store.find_title(media_type=media_type, tmdb=str(tmdb_id))
    if title is None:
        return False
    if store.in_list('dismissed', title['id'], None):
        return True
    if media_type == 'movie':
        watch = store.get_watch(title['id'], None)
        return watch is not None and (watch['play_count'] or 0) > 0
    for episode in store.episodes_for_show(title['id']):
        watch = store.get_watch(title['id'], episode['id'])
        if watch is not None and (watch['play_count'] or 0) > 0:
            return True
    return False


def _persist_new(store, settings, guard, chosen):
    inserted = 0
    rows = []
    for item in chosen:
        if not item.get('tmdb_id'):
            continue
        existing = store.find_title(media_type=item['media_type'], tmdb=item['tmdb_id'])
        if existing is None:
            title_id = _fetch_new(store, settings, guard, item)
        else:
            title_id = existing['id']
        if title_id is None:
            continue
        rows.append({
            'title_id': title_id,
            'episode_id': None,
            'reason': item.get('reason') or ''
        })
        inserted += 1
    store.replace_list_items('recs', rows)
    return inserted


def _fetch_new(store, settings, guard, item):
    key = settings.get('tmdb_api_key') or ''
    if not key:
        return None
    token = str(item['tmdb_id'])
    if item['media_type'] == 'movie':
        payload = fetch_movie(guard, key, token, 'weekly_recs', token)
        fields = movie_fields(payload)
    else:
        payload = fetch_show(guard, key, token, 'weekly_recs', token)
        fields = show_fields(payload)
        fields.pop('seasons', None)
    images = fields.pop('images', {})
    saved = download_images(
        guard, settings.get('art_dir') or _default_art(), item['media_type'],
        token, images, 'weekly_recs', token
    )
    fields['art'] = saved
    fields['tmdb'] = token
    if item.get('imdb_id'):
        fields['imdb'] = item['imdb_id']
    return store.upsert_title(**fields)


def _default_art():
    from paths import art_dir
    return art_dir()


def _within_budget(store, settings, now):
    month = now[:7]
    used_month = store.meta_get('recs_budget_month') or ''
    used = 0 if used_month != month else int(store.meta_get('recs_budget_calls') or 0)
    return used < settings.integer('recs_monthly_budget', 4)


def _count_call(store, now):
    month = now[:7]
    used_month = store.meta_get('recs_budget_month') or ''
    used = 0 if used_month != month else int(store.meta_get('recs_budget_calls') or 0)
    store.meta_set('recs_budget_month', month)
    store.meta_set('recs_budget_calls', str(used + 1))


def _ensure_dismissed(store):
    if store.list_row('dismissed') is None:
        store.create_list('dismissed', 'Dismissed', 'auto', 'mixed')
        # create_list forces show_in_menu 1. Hide it.
        def hide():
            store._conn.execute(
                'UPDATE lists SET show_in_menu = 0, is_system = 1 WHERE slug = ?',
                ('dismissed',)
            )
        store._write(hide)


def _host(url):
    return (urlparse(url).hostname or '').lower()


def _year(value):
    if not value:
        return None
    try:
        return int(str(value)[:4])
    except ValueError:
        return None


def dismiss_title(store, title_id):
    _ensure_dismissed(store)
    store.add_list_item('dismissed', title_id, None)
    store.remove_list_item('recs', title_id, None)
