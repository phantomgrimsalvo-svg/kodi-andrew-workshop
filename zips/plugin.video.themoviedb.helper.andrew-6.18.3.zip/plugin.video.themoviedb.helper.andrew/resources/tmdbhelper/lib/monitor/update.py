import xbmc


class UpdateMonitor(xbmc.Monitor):
    """
    Monitors updating Kodi library
    """

    def __init__(self):
        xbmc.Monitor.__init__(self)
        self.settings_dirty = False

    @staticmethod
    def run_library_tagger():
        from tmdbhelper.lib.addon.thread import SafeThread
        from tmdbhelper.lib.update.builder.tags import library_tagger
        SafeThread(target=library_tagger).start()

    def onScanFinished(self, library):
        if library == 'video':
            self.run_library_tagger()

    def onSettingsChanged(self):
        # Kodi holds the settings lock here. get_setting/set_setting deadlock.
        self.settings_dirty = True
