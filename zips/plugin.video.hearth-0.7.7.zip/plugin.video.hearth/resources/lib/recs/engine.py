'''Taste profile, candidate search, and a structured recommendation list.'''

from __future__ import annotations

import json
import threading
import time
from urllib.parse import quote, urlparse

from art.store import download_images
from tmdb.client import fetch_movie, fetch_show, movie_fields, show_fields
from util import dumps, iso, loads

PROVIDERS = {
    'openai': 'https://api.openai.com/v1/chat/completions',
    'anthropic': 'https://api.anthropic.com/v1/messages',
    'gemini': 'https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent',
    'grok': 'https://api.x.ai/v1/chat/completions',
    'openrouter': 'https://openrouter.ai/api/v1/chat/completions',
    'custom': ''
}

DEFAULT_MODELS = {
    'openai': 'gpt-4o-mini',
    'anthropic': 'claude-sonnet-4-6',
    'gemini': 'gemini-2.5-flash-lite',
    'grok': 'grok-4.7',
    'openrouter': 'openai/gpt-4o-mini',
    'custom': ''
}

AI_TIMEOUT = 90
RESEARCH_TIMEOUT = 120
RETRY_PAUSE = 2
BATCH_SIZE = 40


def provider_url(settings):
    name = (settings.get('recs_provider') or 'openai').strip().lower()
    if name == 'custom':
        base = (settings.get('recs_base_url') or '').rstrip('/')
        return base + '/chat/completions' if base else ''
    template = PROVIDERS.get(name, '')
    model = settings.get('recs_model') or DEFAULT_MODELS.get(name, '')
    return template.replace('{model}', quote(model, safe=''))


def build_taste_profile(store, settings=None):
    document = store.export_document()
    titles = {row['id']: row for row in document['titles']}
    boost = 1 if settings is None else max(0, settings.integer('recs_rewatch_boost', 1))
    count_dropped = settings is not None and settings.flag('recs_unfinished_counts', False)
    rated = []
    dropped = []
    for rating in document['ratings']:
        if rating.get('season') not in (None, ''):
            continue
        title = titles.get(rating['title_id'])
        if title is None:
            continue
        if rating.get('score') is None:
            if count_dropped and int(rating.get('unfinished') or 0):
                dropped.append(title['title'])
            continue
        genres = loads(title.get('genres'), []) or []
        rated.append({
            'title': title['title'],
            'year': title.get('year'),
            'media_type': title['media_type'],
            'score': rating['score'],
            'genres': genres,
            'liked': rating.get('liked') or '',
            'disliked': rating.get('disliked') or '',
            'tags': loads(rating.get('tags'), []) or [],
            'plot': (title.get('plot') or '')[:400],
            'tmdb': title.get('tmdb')
        })
    pairs = _contrastive_pairs(rated)
    keywords = []
    for row in rated:
        if row['score'] and int(row['score']) >= 8:
            keywords.extend(row['tags'])
            keywords.extend(row['genres'][:1])
    keywords = list(dict.fromkeys([item for item in keywords if item]))[:12]
    lines = [
        'Taste profile built only from local ratings.',
        'Look for theme, tone, moral stance, craft, and audience.',
        'Do not recommend more of a surface genre just because two titles share it.'
    ]
    for pair in pairs:
        lines.append(
            'Contrast: "%s" (%s) was rated %s and "%s" (%s) was rated %s. '
            'They share %s. Do not recommend more %s from this pair. '
            'Look for what the high title shares with other highs, and what the low title shares with other lows.'
            % (
                pair['high_title'], pair['high_score'], pair['high_score'],
                pair['low_title'], pair['low_score'], pair['low_score'],
                pair['genre'], pair['genre']
            )
        )
    # The format above repeats scores. Rewrite the sentence cleanly.
    lines = lines[:3]
    for pair in pairs:
        lines.append(
            'Contrast inside %s: high "%s" (%s) versus low "%s" (%s). '
            'Do not recommend more %s from that pair.'
            % (
                pair['genre'], pair['high_title'], pair['high_score'],
                pair['low_title'], pair['low_score'], pair['genre']
            )
        )
    highs = [row for row in rated if int(row['score']) >= 8][:8]
    lows = [row for row in rated if int(row['score']) <= 4][:8]
    if highs:
        lines.append('High: ' + '; '.join(
            '%s (%s) %s' % (row['title'], row['score'], row['liked']) for row in highs
        ))
    if lows:
        lines.append('Low: ' + '; '.join(
            '%s (%s) %s' % (row['title'], row['score'], row['disliked']) for row in lows
        ))
    lines.append(
        'Ratings decide taste. Each extra full play adds %s. '
        'A watch with no rating adds nothing.' % boost
    )
    for name in dropped[:8]:
        lines.append('Dropped without a rating: %s' % name)
    return {
        'text': '\n'.join(lines),
        'keywords': keywords,
        'pairs': pairs,
        'rating_count': len(rated)
    }


def _contrastive_pairs(rated):
    pairs = []
    by_genre = {}
    for row in rated:
        for genre in row['genres'] or ['unknown']:
            by_genre.setdefault(genre, []).append(row)
    for genre, rows in by_genre.items():
        high = [row for row in rows if int(row['score']) >= 8]
        low = [row for row in rows if int(row['score']) <= 4]
        if high and low:
            pairs.append({
                'genre': genre,
                'high_title': high[0]['title'],
                'high_score': high[0]['score'],
                'low_title': low[0]['title'],
                'low_score': low[0]['score']
            })
    return pairs[:6]


def rebuild_recommendations(store, settings, guard, dry_run=False, now=None, stop=None, on_progress=None):
    now = now or iso()
    if on_progress is not None:
        on_progress(5, 'Building the taste profile')
    store.ensure_system_lists()
    _ensure_dismissed(store)
    if not (settings.get('recs_api_key') or ''):
        return {'skipped': 'configure AI provider', 'calls': 0}
    profile = build_taste_profile(store, settings)
    notes = store.meta_get('ai_notes') or ''
    if notes:
        profile = dict(profile)
        profile['text'] = profile['text'] + '\n\nNotes already written:\n' + notes[:3000]
    store.meta_set('taste_profile', dumps({
        'text': profile['text'],
        'keywords': profile.get('keywords') or [],
        'pairs': profile.get('pairs') or [],
        'rating_count': profile.get('rating_count')
    }))
    store.meta_set('taste_profile_at', now)
    if _should_stop(stop):
        return {'skipped': 'Cancelled.', 'calls': 0}
    if not _within_budget(store, settings, now):
        return {'skipped': 'monthly budget', 'profile': profile['text'], 'calls': 0}
    guard.allow_host(_host(provider_url(settings)))
    search_url = settings.get('recs_search_url') or ''
    if search_url:
        guard.allow_host(_host(search_url))
    candidates = collect_candidates(store, settings, guard, profile, stop=stop)
    cap = _pick_cap(settings)
    prompt = _prompt(profile, candidates[:40], ask=min(BATCH_SIZE, cap))
    if dry_run:
        return {
            'dry_run': True,
            'prompt': prompt,
            'candidates': len(candidates),
            'profile': profile['text'],
            'calls': 0
        }
    if _should_stop(stop):
        return {'skipped': 'Cancelled.', 'calls': 0}
    try:
        chosen, calls = _generate_picks(
            store, settings, guard, profile, candidates, cap, now, stop
        )
    except Exception as exc:
        report_ai_failure(store, 'Recommendations', exc, settings.get('recs_api_key'))
        return {'failed': friendly_ai_error(exc), 'calls': 0, 'candidates': len(candidates)}
    if _should_stop(stop) and not chosen:
        return {'skipped': 'Cancelled.', 'calls': calls, 'candidates': len(candidates)}
    chosen = [_resolve_tmdb(settings, guard, item) for item in chosen]
    chosen = _drop_known(store, settings, chosen)
    moods = _mood_names(settings)
    for item in chosen:
        item['mood'] = normalize_mood(item.get('mood'), moods)
        item['media_type'] = _canon_media(item.get('media_type'))
    merged = _merge_picks(chosen, candidates, cap)
    _attach_votes(merged, candidates)
    merged = [item for item in merged if _keep_quality(item)]
    merged = _ensure_gems(merged, candidates)
    merged = _ensure_shows(merged, candidates, cap)
    merged = _ensure_moods(merged, candidates, settings, store)
    inserted = _persist_rows(store, settings, guard, merged, stop=stop)
    store.meta_set('last_recs_at', now)
    clear_ai_error(store)
    from recs.rows import apply_row_visibility
    apply_row_visibility(store, settings)
    return {
        'inserted': inserted, 'prompt': prompt, 'candidates': len(candidates), 'calls': calls
    }


GENRE_IDS = {
    'action': 28, 'adventure': 12, 'animation': 16, 'comedy': 35, 'crime': 80,
    'documentary': 99, 'drama': 18, 'family': 10751, 'fantasy': 14, 'history': 36,
    'horror': 27, 'music': 10402, 'mystery': 9648, 'romance': 10749,
    'science fiction': 878, 'thriller': 53, 'war': 10752, 'western': 37
}


def collect_candidates(store, settings, guard, profile, cheaper=False, stop=None):
    '''TMDB recommendations, similar titles, and discover. The year-text search is gone.'''
    found = []
    seen = set()

    def halted():
        return _should_stop(stop)

    def add(item):
        tmdb_id = str(item.get('tmdb_id') or '')
        media = item.get('media_type') or 'movie'
        if media == 'tv':
            media = 'show'
        if not tmdb_id or tmdb_id in seen or media not in ('movie', 'show'):
            return
        if block_reason(store, tmdb_id, media):
            return
        if not year_allowed(settings, item.get('year')):
            return
        seen.add(tmdb_id)
        item['tmdb_id'] = tmdb_id
        item['media_type'] = media
        found.append(item)

    for pick in loads(store.meta_get('taste_twin_picks'), []) or []:
        if isinstance(pick, dict):
            add({
                'media_type': pick.get('media_type') or 'movie',
                'title': pick.get('title'),
                'year': pick.get('year'),
                'tmdb_id': pick.get('tmdb_id'),
                'plot': pick.get('why') or '',
                'source': 'twin',
                'credit': pick.get('name') or pick.get('credit') or '',
                'reason': pick.get('why') or ''
            })
    key = settings.get('tmdb_api_key') or ''
    if key:
        for seed in _seeds(store)[:5]:
            if halted():
                return found
            media = 'movie' if seed['media_type'] == 'movie' else 'tv'
            for kind in ('recommendations', 'similar'):
                path = '/3/%s/%s/%s?api_key=%s' % (media, seed['tmdb'], kind, key)
                response = guard.get('https://api.themoviedb.org' + path, 'weekly_recs')
                for row in (response.body or {}).get('results') or []:
                    add(_from_tmdb(row, seed['title']))
                    if len(found) >= 80:
                        break
        if not halted():
            for kind in ('movie', 'tv'):
                path = (
                    '/3/discover/%s?api_key=%s&sort_by=vote_average.desc'
                    '&vote_average.gte=7&vote_count.gte=40&vote_count.lte=2000'
                ) % (kind, key)
                response = guard.get('https://api.themoviedb.org' + path, 'weekly_recs')
                for row in (response.body or {}).get('results') or []:
                    add(_from_tmdb(row, ''))
        genre_id = _genre_id(profile)
        if genre_id and not halted():
            for kind in ('movie', 'tv'):
                path = '/3/discover/%s?api_key=%s&with_genres=%s&sort_by=popularity.desc' % (
                    kind, key, genre_id
                )
                response = guard.get('https://api.themoviedb.org' + path, 'weekly_recs')
                for row in (response.body or {}).get('results') or []:
                    add(_from_tmdb(row, ''))
    search_url = settings.get('recs_search_url') or ''
    if search_url:
        response = guard.get(search_url, 'weekly_recs')
        for item in response.body or []:
            if isinstance(item, dict):
                add(item)
    return found


def _from_tmdb(row, seed_title):
    media = row.get('media_type')
    if media not in ('movie', 'tv'):
        media = 'movie' if row.get('title') else 'tv'
    return {
        'media_type': 'show' if media == 'tv' else 'movie',
        'title': row.get('title') or row.get('name'),
        'year': _year(row.get('release_date') or row.get('first_air_date')),
        'tmdb_id': row.get('id'),
        'plot': row.get('overview') or '',
        'source': 'tmdb',
        'because': seed_title or '',
        'tmdb_rating': row.get('vote_average'),
        'vote_count': row.get('vote_count'),
        'popularity': row.get('popularity'),
        'reason': ('Because you rated %s highly.' % seed_title) if seed_title else ''
    }


def _seeds(store):
    rows = []
    for rating in store.export_document()['ratings']:
        if rating.get('season') not in (None, '') or rating.get('episode_id'):
            continue
        if rating.get('score') is None or int(rating['score']) < 8:
            continue
        title = store.get_title(rating['title_id'])
        if title is None or not title['tmdb']:
            continue
        rows.append(title)
    rows.sort(
        key=lambda title: int((store.get_rating(title['id']) or {'score': 0})['score'] or 0),
        reverse=True
    )
    return rows


def _genre_id(profile):
    for word in profile.get('keywords') or []:
        genre_id = GENRE_IDS.get(str(word).strip().lower())
        if genre_id:
            return genre_id
    return None


class ProviderError(Exception):
    '''The model call did not return a usable reply.'''


def call_model(settings, guard, prompt, max_tokens=1200, stop=None, timeout=None,
               store=None, now=None):
    '''Ask the configured model. None means the stop signal fired mid-call.

    The HTTP work runs on a daemon thread with its own long timeout, so a
    1 second artwork cap on the caller cannot apply, and abort does not wait
    out the socket.
    '''
    url = provider_url(settings)
    name = (settings.get('recs_provider') or 'openai').strip().lower()
    key = (settings.get('recs_api_key') or '').strip()
    if not key:
        raise ProviderError('No API key set')
    if not url:
        raise ProviderError('No API address set')
    if name == 'anthropic':
        headers = {
            'Content-Type': 'application/json',
            'x-api-key': key,
            'anthropic-version': '2023-06-01'
        }
        body = {
            'model': settings.get('recs_model') or DEFAULT_MODELS['anthropic'],
            'max_tokens': max_tokens,
            'messages': [{'role': 'user', 'content': prompt}]
        }
    elif name == 'gemini':
        headers = {'Content-Type': 'application/json'}
        url = url + ('&' if '?' in url else '?') + 'key=' + key
        body = {
            'contents': [{'parts': [{'text': prompt}]}],
            'generationConfig': {
                'maxOutputTokens': int(max_tokens),
                'responseMimeType': 'application/json',
                'temperature': 0.4,
                'responseSchema': _gemini_schema(settings)
            }
        }
    else:
        headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer ' + key}
        body = {
            'model': settings.get('recs_model') or DEFAULT_MODELS.get(name, ''),
            'messages': [{'role': 'user', 'content': prompt}],
            'temperature': 0.4,
            'max_tokens': int(max_tokens),
            'response_format': {'type': 'json_object'}
        }
    response = guarded_post(
        guard, url, headers, json.dumps(body),
        timeout or AI_TIMEOUT, stop=stop, store=store, now=now
    )
    if response is None:
        return None
    status = int(getattr(response, 'status', 0) or 0)
    if isinstance(getattr(response, 'body', None), (bytes, bytearray)):
        raise ProviderError('The provider returned a page instead of data (%s).' % (status or 0))
    if status < 200 or status >= 300:
        from util import redact
        detail = redact(_error_text(getattr(response, 'body', None)))
        if key and key in detail:
            detail = detail.replace(key, '[redacted]')
        if status == 429:
            detail = detail or 'Gemini is rate limiting (429).'
        elif status == 503:
            detail = detail or 'Gemini is unavailable (503).'
        raise ProviderError(detail or ('The provider returned HTTP %s' % status))
    text = (_message_text(name, response.body) or '').strip()
    if not text:
        raise ProviderError('The provider returned an empty reply')
    return text


def guarded_post(guard, url, headers, body, timeout, stop=None, store=None, now=None, purpose='weekly_recs'):
    '''POST with one retry on 429 or 503. Each attempt counts against the budget.'''
    response = None
    for attempt in (1, 2):
        if _should_stop(stop):
            return None
        response = _abandon_request(
            lambda: guard.post(url, purpose, headers=headers, body=body),
            timeout, stop
        )
        if response is None:
            return None
        if store is not None and now is not None:
            _count_call(store, now)
        status = int(getattr(response, 'status', 0) or 0)
        if status in (429, 503) and attempt == 1:
            if not _pause(stop):
                return None
            continue
        break
    return response


def _abandon_request(fn, timeout, stop):
    '''Run fn on a daemon thread. Abort returns without waiting for the socket.'''
    from network.guard import transport_timeout
    box = {}

    def run():
        try:
            with transport_timeout(timeout):
                box['value'] = fn()
        except Exception as exc:
            box['error'] = exc

    thread = threading.Thread(target=run, name='hearth-ai-http', daemon=True)
    thread.start()
    deadline = time.monotonic() + float(timeout) + 1
    while thread.is_alive():
        if _should_stop(stop):
            return None
        if time.monotonic() > deadline:
            raise ProviderError('The AI call timed out.')
        thread.join(0.2)
    if box.get('error') is not None:
        exc = box['error']
        if _is_timeout(exc):
            raise ProviderError('The AI call timed out.')
        raise exc
    return box.get('value')


def _pause(stop):
    deadline = time.monotonic() + float(RETRY_PAUSE)
    while time.monotonic() < deadline:
        if _should_stop(stop):
            return False
        time.sleep(0.05)
    return True


def _should_stop(stop):
    if stop is not None and stop.is_set():
        return True
    try:
        from service_run import stopped
        return stopped()
    except Exception:
        return False


def _is_timeout(exc):
    name = type(exc).__name__.lower()
    text = str(exc).lower()
    return 'timeout' in name or 'timed out' in text or 'timeout' in text


def test_connection(settings, guard):
    if not (settings.get('recs_api_key') or '').strip():
        raise ProviderError('No API key set')
    url = provider_url(settings)
    if not url:
        raise ProviderError('No API address set')
    guard.allow_host(_host(url))
    call_model(settings, guard, 'Reply with the JSON {"ok": true}')
    research_key = (settings.get('recs_research_key') or '').strip()
    provider_key = (settings.get('recs_api_key') or '').strip()
    if research_key and research_key != provider_key:
        _probe_gemini(settings, guard, research_key)
    return {'ok': True, 'host': _host(url)}


def _probe_gemini(settings, guard, key):
    model = (settings.get('recs_research_model') or '').strip() or 'gemini-2.5-flash'
    url = (
        'https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent?key=%s'
        % (quote(model, safe=''), key)
    )
    guard.allow_host('generativelanguage.googleapis.com')
    response = guarded_post(
        guard, url, {'Content-Type': 'application/json'},
        json.dumps({'contents': [{'parts': [{'text': 'Reply with the JSON {"ok": true}'}]}]}),
        20
    )
    status = int(getattr(response, 'status', 0) or 0) if response is not None else 0
    if response is None or status < 200 or status >= 300:
        raise ProviderError('Deep research key was rejected (%s).' % (status or 0))


def parse_recommendations(raw, cap=20):
    text = _strip_fence(raw)
    if not text:
        return []
    data = _load_pick_list(text)
    if data is None:
        data = _salvage_objects(text)
    chosen = []
    for item in data or []:
        if not isinstance(item, dict):
            continue
        title = item.get('title')
        media = item.get('media_type')
        if media == 'tv':
            media = 'show'
        if not title or media not in ('movie', 'show'):
            continue
        chosen.append({
            'media_type': media,
            'title': title,
            'year': item.get('year'),
            'tmdb_id': None if item.get('tmdb_id') in (None, '') else str(item.get('tmdb_id')),
            'imdb_id': item.get('imdb_id') or None,
            'reason': item.get('reason') or '',
            'source': (item.get('source') or 'ai').lower(),
            'match': item.get('match'),
            'row': item.get('row') or item.get('kind') or '',
            'because': item.get('because') or '',
            'mood': item.get('mood') or '',
            'credit': item.get('credit') or '',
            'trailer': item.get('trailer') or '',
            'tmdb_rating': item.get('vote_average') if item.get('vote_average') not in (None, '') else item.get('tmdb_rating'),
            'vote_count': item.get('vote_count'),
            'popularity': item.get('popularity')
        })
        if len(chosen) >= cap:
            break
    return chosen


def _prompt(profile, candidates, cheaper=False, ask=40, already=None, moods=None):
    slim = [
        {
            'media_type': item['media_type'],
            'title': item['title'],
            'year': item.get('year'),
            'tmdb_id': item.get('tmdb_id'),
            'plot': (item.get('plot') or '')[:280],
            'source': item.get('source') or '',
            'vote_average': item.get('tmdb_rating'),
            'vote_count': item.get('vote_count'),
            'popularity': item.get('popularity')
        }
        for item in candidates
    ]
    prior = ''
    if already:
        prior = 'Already chosen, do not repeat: ' + ', '.join(already[:80]) + '\n'
    return (
        profile['text']
        + '\nReturn JSON only as {"picks": [ up to %s items ]}. ' % int(ask)
        + 'Each item is {media_type, title, year, tmdb_id, imdb_id, reason, source, match, because, mood, credit, row}. '
        + 'row is for_you, gem, twin, or mood. '
        + 'gem means a hidden gem: vote_average at least 7 and vote_count under about 2000, or clearly low popularity. Not a blockbuster. '
        + 'twin is a title a taste twin loved. mood fits a named mood. for_you is a main pick. Include several gems. '
        + 'Propose titles from your own knowledge as well as the candidate list. '
        + 'source is ai, twin, or tmdb. reason must name the rated titles it comes from. '
        + 'Return exactly up to %s picks in this batch, not a short sample. ' % int(ask)
        + 'About 40 percent of the picks must be shows (media_type show, never tv). '
        + 'row must be one of for_you, gem, twin. '
        + 'mood must be exactly one of: %s. Do not invent mood phrases. ' % ', '.join(
            moods or _mood_names(None)
        )
        + 'because is only the seed title, not a sentence. '
        + 'Mix movies and shows. Exclude anything already watched or rated.\n'
        + prior
        + 'Candidates:\n' + json.dumps(slim)
    )


def _generate_picks(store, settings, guard, profile, candidates, cap, now, stop):
    chosen = []
    seen = set()
    calls = 0
    while len(chosen) < cap:
        if _should_stop(stop):
            break
        if not _within_budget(store, settings, now):
            break
        ask = min(BATCH_SIZE, cap - len(chosen))
        prompt = _prompt(
            profile, candidates, ask=ask, moods=_mood_names(settings),
            already=[item['title'] for item in chosen if item.get('title')]
        )
        raw = call_model(
            settings, guard, prompt, max_tokens=_output_tokens(ask),
            stop=stop, timeout=AI_TIMEOUT, store=store, now=now
        )
        if raw is None:
            break
        _log_raw(raw)
        calls += 1
        batch = parse_recommendations(raw, cap=ask)
        if not batch and _looks_truncated(raw):
            raise ProviderError('The reply was cut off before the JSON finished.')
        fresh = []
        for item in batch:
            key = (item['media_type'], str(item.get('tmdb_id') or item['title']))
            if key in seen:
                continue
            seen.add(key)
            fresh.append(item)
        chosen.extend(fresh)
        if not fresh:
            break
    return chosen, calls


def _output_tokens(count):
    return min(8192, max(2048, int(count) * 220))


def _mood_names(settings):
    raw = ''
    if settings is not None:
        raw = settings.get('recs_moods') or ''
    names = [part.strip() for part in raw.split(',') if part.strip()]
    if not names:
        names = ['tense', 'funny', 'comfort', 'mind-bending', 'dark', 'epic', 'romantic']
    return names


def _gemini_schema(settings):
    moods = _mood_names(settings)
    return {
        'type': 'OBJECT',
        'properties': {
            'picks': {
                'type': 'ARRAY',
                'items': {
                    'type': 'OBJECT',
                    'properties': {
                        'media_type': {'type': 'STRING', 'enum': ['movie', 'show']},
                        'title': {'type': 'STRING'},
                        'year': {'type': 'INTEGER'},
                        'tmdb_id': {'type': 'STRING'},
                        'reason': {'type': 'STRING'},
                        'source': {'type': 'STRING', 'enum': ['ai', 'twin', 'tmdb']},
                        'row': {'type': 'STRING', 'enum': ['for_you', 'gem', 'twin']},
                        'mood': {'type': 'STRING', 'enum': moods},
                        'because': {'type': 'STRING'}
                    },
                    'required': ['media_type', 'title', 'row', 'mood', 'reason']
                }
            }
        },
        'required': ['picks']
    }


def _log_raw(raw):
    try:
        import xbmc
        xbmc.log('Hearth recommendations raw reply: %s' % (raw or '')[:1200], xbmc.LOGDEBUG)
    except Exception:
        return


def normalize_mood(value, moods):
    '''Map a free-text mood onto one configured word.'''
    text = str(value or '').strip().lower()
    names = list(moods or [])
    if not text:
        return ''
    for mood in names:
        if text == mood.lower():
            return mood
    synonyms = {
        'atmospheric': 'dark', 'foreboding': 'dark', 'noir': 'dark', 'bleak': 'dark',
        'comedy': 'funny', 'humorous': 'funny', 'comic': 'funny',
        'cozy': 'comfort', 'warm': 'comfort', 'feel-good': 'comfort',
        'surreal': 'mind-bending', 'twist': 'mind-bending', 'mindbending': 'mind-bending',
        'romance': 'romantic', 'love': 'romantic',
        'suspense': 'tense', 'thriller': 'tense',
        'grand': 'epic', 'spectacle': 'epic'
    }
    for word in text.replace(',', ' ').replace('-', ' ').split():
        target = synonyms.get(word, word)
        for mood in names:
            if mood.lower() == target or mood.lower().startswith(word):
                return mood
    return ''


def _keep_quality(item):
    '''Drop empty scores, tiny runtimes, and vote-less filler. Gems may be obscure.'''
    rating = item.get('tmdb_rating')
    if rating in (None, ''):
        rating = item.get('vote_average')
    try:
        average = float(rating)
    except (TypeError, ValueError):
        average = None
    if average == 0:
        return False
    runtime = item.get('runtime_seconds') or item.get('runtime')
    try:
        if runtime is not None and int(runtime) and int(runtime) < 40 * 60:
            return False
    except (TypeError, ValueError):
        pass
    if is_hidden_gem(item):
        return True
    try:
        votes = int(item.get('vote_count'))
    except (TypeError, ValueError):
        return True
    return votes >= 15


def _looks_truncated(raw):
    text = _strip_fence(raw)
    if not text:
        return False
    return text[-1] not in ']}'


def _strip_fence(raw):
    text = (raw or '').strip()
    if text.startswith('```'):
        text = text.split('\n', 1)[-1]
        if text.endswith('```'):
            text = text[:-3]
    return text.strip()


def _load_pick_list(text):
    start = text.find('[')
    end = text.rfind(']')
    if start >= 0 and end > start:
        try:
            data = json.loads(text[start:end + 1])
        except ValueError:
            data = None
        if isinstance(data, list):
            return data
    obj_start = text.find('{')
    obj_end = text.rfind('}')
    if obj_start >= 0 and obj_end > obj_start:
        try:
            obj = json.loads(text[obj_start:obj_end + 1])
        except ValueError:
            return None
        if isinstance(obj, dict):
            for key in ('picks', 'recommendations', 'items'):
                if isinstance(obj.get(key), list):
                    return obj[key]
    return None


def _salvage_objects(text):
    found = []
    index = 0
    while index < len(text):
        if text[index] != '{':
            index += 1
            continue
        chunk, index = _balanced_object(text, index)
        if not chunk:
            break
        try:
            item = json.loads(chunk)
        except ValueError:
            continue
        if isinstance(item, dict) and item.get('title'):
            found.append(item)
    return found


def _balanced_object(text, start):
    depth = 0
    in_string = False
    escaped = False
    for index in range(start, len(text)):
        char = text[index]
        if in_string:
            if escaped:
                escaped = False
            elif char == '\\':
                escaped = True
            elif char == '"':
                in_string = False
            continue
        if char == '"':
            in_string = True
        elif char == '{':
            depth += 1
        elif char == '}':
            depth -= 1
            if depth == 0:
                return text[start:index + 1], index + 1
    return None, len(text)


def is_hidden_gem(item):
    '''A quiet title: strongly rated, and not already famous.'''
    row = str(item.get('row') or '').lower()
    source = str(item.get('source') or '').lower()
    if row in ('gem', 'gems', 'hidden_gems') or source == 'gem':
        return True
    rating = item.get('tmdb_rating')
    if rating in (None, ''):
        rating = item.get('vote_average')
    try:
        average = float(rating)
    except (TypeError, ValueError):
        return False
    if average < 7:
        return False
    try:
        if int(item.get('vote_count')) < 2000:
            return True
    except (TypeError, ValueError):
        pass
    try:
        if float(item.get('popularity')) < 20:
            return True
    except (TypeError, ValueError):
        pass
    return False


def _attach_votes(chosen, candidates):
    by_id = {}
    for item in candidates:
        if item.get('tmdb_id'):
            by_id[(item.get('media_type'), str(item['tmdb_id']))] = item
    for item in chosen:
        source = by_id.get((item.get('media_type'), str(item.get('tmdb_id') or '')))
        if source is None:
            continue
        for field in ('tmdb_rating', 'vote_count', 'popularity'):
            if item.get(field) in (None, '') and source.get(field) not in (None, ''):
                item[field] = source[field]


def _ensure_gems(chosen, candidates):
    '''Hidden gems has to have titles whenever any recommendation exists.'''
    extras = _gem_pool(list(chosen) + list(candidates))
    have = set()
    for item in chosen:
        if str(item.get('row') or '').lower() in ('gem', 'gems', 'hidden_gems') or str(item.get('source') or '') == 'gem':
            if item.get('tmdb_id'):
                have.add((item.get('media_type'), str(item['tmdb_id'])))
    for item in extras:
        key = (item.get('media_type'), str(item.get('tmdb_id')))
        if key in have:
            continue
        chosen.append(item)
        have.add(key)
        if len(have) >= 12:
            break
    if have or not chosen:
        return chosen
    donor = next((item for item in chosen if item.get('tmdb_id')), None)
    if donor is not None:
        copy = dict(donor)
        copy['row'] = 'gem'
        copy['source'] = 'gem'
        copy['reason'] = copy.get('reason') or 'A quieter title from this batch.'
        chosen.append(copy)
    return chosen


def _gem_pool(items):
    strict = []
    rated = []
    seen = set()

    def take(item, into):
        if not item.get('tmdb_id'):
            return
        key = (item.get('media_type'), str(item['tmdb_id']))
        if key in seen:
            return
        seen.add(key)
        copy = dict(item)
        copy['row'] = 'gem'
        copy['source'] = 'gem'
        if not copy.get('reason'):
            copy['reason'] = 'Well rated, and almost nobody is talking about it.'
        into.append(copy)

    for item in items:
        if is_hidden_gem(item):
            take(item, strict)
        if len(strict) >= 12:
            break
    if strict:
        return strict
    ranked = []
    for item in items:
        if not item.get('tmdb_id'):
            continue
        rating = item.get('tmdb_rating')
        if rating in (None, ''):
            rating = item.get('vote_average')
        try:
            average = float(rating)
        except (TypeError, ValueError):
            continue
        if average < 7:
            continue
        try:
            votes = int(item.get('vote_count'))
        except (TypeError, ValueError):
            votes = 10 ** 9
        ranked.append((votes, item))
    ranked.sort(key=lambda pair: pair[0])
    for _votes, item in ranked[:8]:
        take(item, rated)
    return rated


def _error_text(body):
    if isinstance(body, dict):
        err = body.get('error')
        if isinstance(err, dict):
            return str(err.get('message') or err.get('status') or '')
        if isinstance(err, str):
            return err
        return str(body.get('message') or '')
    if isinstance(body, str):
        return body[:300]
    return ''


def _message_text(provider, body):
    if not isinstance(body, dict):
        return body if isinstance(body, str) else ''
    if provider == 'anthropic':
        parts = body.get('content') or []
        return ''.join(part.get('text', '') for part in parts if isinstance(part, dict))
    if provider == 'gemini':
        candidates = body.get('candidates') or []
        if not candidates:
            return ''
        parts = ((candidates[0].get('content') or {}).get('parts')) or []
        return ''.join(part.get('text', '') for part in parts if isinstance(part, dict))
    choices = body.get('choices') or []
    if choices:
        return ((choices[0].get('message') or {}).get('content')) or ''
    return body.get('text') or ''


def block_reason(store, tmdb_id, media_type):
    '''Why a title cannot be recommended, or an empty string when it can.'''
    if not tmdb_id:
        return ''
    title = store.find_title(media_type=media_type, tmdb=str(tmdb_id))
    if title is None:
        return ''
    if store.in_list('never_show', title['id'], None):
        return 'never'
    if store.in_list('dismissed', title['id'], None):
        return 'dismissed'
    rating = store.get_rating(title['id'], None)
    if rating is not None and rating['score'] is not None:
        return 'rated'
    if media_type == 'movie':
        watch = store.get_watch(title['id'], None)
        if watch is not None and (watch['play_count'] or 0) > 0:
            return 'watched'
        return ''
    for episode in store.episodes_for_show(title['id']):
        watch = store.get_watch(title['id'], episode['id'])
        if watch is not None and (watch['play_count'] or 0) > 0:
            return 'watched'
    return ''


def year_allowed(settings, year):
    lo = settings.integer('recs_year_min', 0) if settings is not None else 0
    hi = settings.integer('recs_year_max', 0) if settings is not None else 0
    if not lo and not hi:
        return True
    try:
        number = int(year)
    except (TypeError, ValueError):
        return False
    if lo and number < lo:
        return False
    if hi and number > hi:
        return False
    return True


def _is_blocked(store, tmdb_id, media_type):
    return bool(block_reason(store, tmdb_id, media_type))


def _pick_cap(settings):
    cap = settings.integer('recs_pick_count', 60)
    if cap < 1:
        cap = 60
    return min(cap, 150)


def _resolve_tmdb(settings, guard, item):
    if item.get('tmdb_id') or not item.get('title'):
        return item
    key = settings.get('tmdb_api_key') or ''
    if not key:
        return item
    kind = 'movie' if item['media_type'] == 'movie' else 'tv'
    url = 'https://api.themoviedb.org/3/search/%s?api_key=%s&query=%s' % (
        kind, key, quote(item['title'])
    )
    if item.get('year'):
        url += '&year=%s' % item['year']
    body = guard.get(url, 'weekly_recs').body or {}
    results = body.get('results') or []
    if results:
        item['tmdb_id'] = str(results[0].get('id'))
        if not item.get('year'):
            item['year'] = _year(results[0].get('release_date') or results[0].get('first_air_date'))
    return item


def _drop_known(store, settings, chosen):
    kept = []
    seen = set()
    for item in chosen:
        key = (item['media_type'], item.get('tmdb_id') or item['title'])
        if key in seen:
            continue
        seen.add(key)
        if item.get('tmdb_id') and _is_blocked(store, item['tmdb_id'], item['media_type']):
            continue
        if not year_allowed(settings, item.get('year')):
            continue
        kept.append(item)
    return kept


def _merge_picks(model_picks, candidates, cap):
    chosen = []
    seen = set()

    def take(item):
        if not item.get('tmdb_id'):
            return
        key = (item['media_type'], str(item['tmdb_id']))
        if key in seen:
            return
        seen.add(key)
        chosen.append(item)

    for item in model_picks:
        take(item)
        if len(chosen) >= cap:
            return chosen
    for item in candidates:
        if (item.get('source') or '') == 'twin':
            take(item)
        if len(chosen) >= cap:
            return chosen
    for item in candidates:
        take(item)
        if len(chosen) >= cap:
            break
    return chosen


def _persist_rows(store, settings, guard, chosen, stop=None):
    placed = []
    for item in chosen:
        if _should_stop(stop):
            break
        if not item.get('tmdb_id'):
            continue
        item['media_type'] = _canon_media(item.get('media_type'))
        try:
            existing = store.find_title(media_type=item['media_type'], tmdb=item['tmdb_id'])
        except Exception as exc:
            _remember_item_error(store, item, exc)
            continue
        if existing is None:
            try:
                title_id = _fetch_new(store, settings, guard, item)
            except Exception as exc:
                _remember_item_error(store, item, exc)
                continue
            title = store.get_title(title_id) if title_id else None
        else:
            title_id = existing['id']
            title = existing
        if title_id is None or title is None:
            continue
        source = (item.get('source') or 'ai').lower()
        reason = item.get('reason') or ''
        detail = {
            'source': source,
            'match': item.get('match'),
            'credit': item.get('credit') or '',
            'why': reason,
            'mood': item.get('mood') or '',
            'because': item.get('because') or '',
            'year': title['year'],
            'runtime': title['runtime_seconds'],
            'tmdb_rating': item.get('tmdb_rating'),
            'trailer': item.get('trailer') or ''
        }
        placed.append({
            'title_id': title_id,
            'episode_id': None,
            'reason': reason,
            'detail': detail,
            'media_type': item['media_type'],
            'source': source,
            'row': (item.get('row') or '').lower(),
            'mood': detail['mood'],
            'because': detail['because']
        })
    _fill_rows(store, settings, placed)
    return len([row for row in placed if row['source'] == 'ai' or row['row'] in ('', 'for_you', 'foryou')])


def _fill_rows(store, settings, placed):
    def pack(rows):
        return [{
            'title_id': row['title_id'],
            'episode_id': None,
            'reason': row['reason'],
            'detail': row['detail']
        } for row in rows]

    for_you = []
    twins = []
    gems = []
    movies = []
    shows = []
    moods = []
    because = {}
    for row in placed:
        source = row['source']
        kind = row['row']
        if source == 'ai' or kind in ('for_you', 'foryou'):
            for_you.append(row)
        if source == 'twin' or kind in ('twin', 'twins'):
            twins.append(row)
        if kind in ('gem', 'gems', 'hidden_gems') or source == 'gem':
            gems.append(row)
        if row['media_type'] == 'movie':
            movies.append(row)
        if row['media_type'] == 'show':
            shows.append(row)
        if row['mood']:
            moods.append(row)
        seed = _because_name(row['because'])
        if seed:
            because.setdefault(seed, []).append(row)
    _put_row(store, settings, 'recs', 'recs_row_for_you', pack(for_you))
    _put_row(store, settings, 'recs_twins', 'recs_row_twins', pack(twins))
    _put_row(store, settings, 'recs_gems', 'recs_row_gems', pack(gems))
    _put_row(store, settings, 'recs_movies', 'recs_row_movies', pack(movies))
    _put_row(store, settings, 'recs_shows', 'recs_row_shows', pack(shows))
    _put_row(store, settings, 'recs_mood', 'recs_row_mood', pack(moods))
    keep = set()
    show_because = settings.flag('recs_row_because', True)
    for index, (name, group) in enumerate(list(because.items())[:4]):
        slug = 'recs_loved_%s' % index
        store.ensure_list(slug, 'Because you loved %s' % name, show=show_because)
        if show_because:
            packed = pack(group)[:12]
            seen = set()
            unique = []
            for row in packed:
                if row['title_id'] in seen:
                    continue
                seen.add(row['title_id'])
                unique.append(row)
            store.replace_list_items(slug, unique)
            if settings.flag('channels_enabled', False):
                store.set_publish_channel(slug, True)
        else:
            store.clear_list(slug)
            store.set_publish_channel(slug, False)
        keep.add(slug)
    for row in store.all_lists():
        slug = row['slug']
        if str(slug).startswith('recs_loved_') and slug not in keep:
            store.set_list_menu(slug, False)
            store.clear_list(slug)
            store.set_publish_channel(slug, False)


def _put_row(store, settings, slug, key, rows):
    seen = set()
    unique = []
    for row in rows:
        title_id = row.get('title_id')
        if title_id in seen:
            continue
        seen.add(title_id)
        unique.append(row)
    if settings.flag(key, True):
        store.replace_list_items(slug, unique)
    else:
        store.clear_list(slug)


def _fetch_new(store, settings, guard, item):
    key = settings.get('tmdb_api_key') or ''
    if not key:
        return None
    token = str(item['tmdb_id'])
    if item['media_type'] == 'movie':
        payload = fetch_movie(guard, key, token, 'weekly_recs', token)
        fields = movie_fields(payload)
    else:
        payload = fetch_show(guard, key, token, 'weekly_recs', token)
        fields = show_fields(payload)
        fields.pop('seasons', None)
    images = fields.pop('images', {})
    item['tmdb_rating'] = payload.get('vote_average')
    saved = download_images(
        guard, settings.get('art_dir') or _default_art(), item['media_type'],
        token, images, 'weekly_recs', token
    )
    fields['art'] = saved
    fields['tmdb'] = token
    if item.get('imdb_id'):
        fields['imdb'] = item['imdb_id']
    return store.upsert_title(**fields)


def _default_art():
    from paths import art_dir
    return art_dir()


def clear_ai_error(store):
    store.meta_set('last_error', '')
    store.meta_set('last_error_notified', '')


def friendly_ai_error(exc):
    text = str(exc or '')
    low = text.lower()
    if 'timed out' in low or 'timeout' in low:
        return 'The AI call timed out.'
    if '429' in text or 'quota' in low or 'rate limit' in low or 'resource exhausted' in low:
        return 'Gemini is rate limiting (429).'
    if '503' in text or 'unavailable' in low:
        return 'Gemini is unavailable (503).'
    if 'api key' in low or 'api_key' in low or 'unauthenticated' in low:
        return 'The API key was rejected.'
    if 'cut off' in low or 'truncated' in low:
        return 'The reply was cut off before the JSON finished.'
    return text[:300]


def report_ai_failure(store, action, exc, secret=''):
    '''Log a redacted Hearth line, remember it, and show a notification.'''
    from util import redact
    message = friendly_ai_error(exc)
    if secret and secret in message:
        message = message.replace(secret, '[redacted]')
    redacted = redact(message)[:300]
    if store is not None:
        store.meta_set('last_error', redacted)
        store.meta_set('last_error_notified', iso())
    try:
        import xbmc
        xbmc.log('Hearth: %s failed: %s' % (action, redacted), xbmc.LOGERROR)
        safe = redacted.replace(',', ' ').replace('"', "'")[:120]
        xbmc.executebuiltin('Notification(Hearth, %s, 6000)' % safe)
    except Exception:
        return redacted
    return redacted


def _canon_media(value):
    text = str(value or '').strip().lower()
    if text in ('tv', 'show', 'tvshow', 'series'):
        return 'show'
    return 'movie'


def _because_name(text):
    raw = str(text or '').strip()
    if not raw or len(raw) > 60 or '.' in raw or raw.lower().startswith('because'):
        return ''
    return raw


def _ensure_shows(chosen, candidates, cap):
    shows = [item for item in chosen if _canon_media(item.get('media_type')) == 'show']
    target = max(1, int(cap * 0.4)) if chosen else 0
    if len(shows) >= target:
        return chosen
    seen = {(_canon_media(item.get('media_type')), str(item.get('tmdb_id'))) for item in chosen}
    for item in candidates:
        if _canon_media(item.get('media_type')) != 'show' or not item.get('tmdb_id'):
            continue
        key = ('show', str(item['tmdb_id']))
        if key in seen or not _keep_quality(item):
            continue
        copy = dict(item)
        copy['media_type'] = 'show'
        copy['row'] = copy.get('row') or 'for_you'
        chosen.append(copy)
        seen.add(key)
        shows.append(copy)
        if len(shows) >= target:
            break
    return chosen


def _ensure_moods(chosen, candidates, settings, store):
    moods = _mood_names(settings)
    current = (store.meta_get('recs_mood') or '').strip() or moods[0]
    wanted = normalize_mood(current, moods) or moods[0]
    if any(normalize_mood(item.get('mood'), moods) == wanted and item.get('tmdb_id') for item in chosen):
        return chosen
    seen = {(_canon_media(item.get('media_type')), str(item.get('tmdb_id'))) for item in chosen}
    added = 0
    for item in candidates:
        if normalize_mood(item.get('mood'), moods) != wanted or not item.get('tmdb_id'):
            continue
        key = (_canon_media(item.get('media_type')), str(item['tmdb_id']))
        if key in seen:
            continue
        copy = dict(item)
        copy['mood'] = wanted
        copy['row'] = 'mood'
        chosen.append(copy)
        seen.add(key)
        added += 1
        if added >= 8:
            break
    return chosen


def _remember_item_error(store, item, exc):
    from util import redact
    message = 'Skipped %s (%s): %s' % (
        item.get('title') or item.get('tmdb_id'), item.get('tmdb_id'), redact(str(exc))[:180]
    )
    try:
        store.meta_set('last_error', message[:300])
        import xbmc
        xbmc.log('Hearth: %s' % message, xbmc.LOGWARNING)
    except Exception:
        return


def _within_budget(store, settings, now):
    month = now[:7]
    used_month = store.meta_get('recs_budget_month') or ''
    used = 0 if used_month != month else int(store.meta_get('recs_budget_calls') or 0)
    return used < settings.integer('recs_monthly_budget', 4)


def _count_call(store, now):
    month = now[:7]
    used_month = store.meta_get('recs_budget_month') or ''
    used = 0 if used_month != month else int(store.meta_get('recs_budget_calls') or 0)
    store.meta_set('recs_budget_month', month)
    store.meta_set('recs_budget_calls', str(used + 1))


def _ensure_dismissed(store):
    if store.list_row('dismissed') is None:
        store.create_list('dismissed', 'Dismissed', 'auto', 'mixed')
        # create_list forces show_in_menu 1. Hide it.
        def hide():
            store._conn.execute(
                'UPDATE lists SET show_in_menu = 0, is_system = 1 WHERE slug = ?',
                ('dismissed',)
            )
        store._write(hide)


def _host(url):
    return (urlparse(url).hostname or '').lower()


def _year(value):
    if not value:
        return None
    try:
        return int(str(value)[:4])
    except ValueError:
        return None


def dismiss_title(store, title_id):
    _ensure_dismissed(store)
    store.add_list_item('dismissed', title_id, None)
    store.add_journal(title_id, 'Not interested', source='local')
    for row in store.all_lists():
        if str(row['slug']).startswith('recs'):
            store.remove_list_item(row['slug'], title_id, None)
