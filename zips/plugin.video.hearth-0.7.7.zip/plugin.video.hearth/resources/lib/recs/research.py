'''One Gemini call with Google Search grounding. It updates notes and taste twins.'''

from __future__ import annotations

import json
from urllib.parse import quote

from recs.engine import _message_text, _within_budget
from recs.profile import andrew_text, journal_markdown, save_research
from util import iso


def deep_research(store, settings, guard, now=None, stop=None):
    now = now or iso()
    if _research_stopped(stop):
        return {'skipped': 'stopped'}
    key, model = _gemini(settings)
    if not key:
        return {
            'skipped': 'Add a Gemini key. Deep research uses Google Search grounding.'
        }
    if not _within_budget(store, settings, now):
        return {'skipped': 'monthly budget'}
    url = (
        'https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent?key=%s'
        % (quote(model, safe=''), key)
    )
    from recs.engine import RESEARCH_TIMEOUT, guarded_post
    from service_run import stopped
    if stopped():
        return {'skipped': 'stopped'}
    guard.allow_host('generativelanguage.googleapis.com')
    prompt = _prompt(store)
    body = {
        'contents': [{'role': 'user', 'parts': [{'text': prompt}]}],
        'tools': [{'google_search': {}}],
        'generationConfig': {'maxOutputTokens': 8192, 'temperature': 0.4}
    }
    if _research_stopped(stop):
        return {'skipped': 'stopped'}
    response = guarded_post(
        guard, url, {'Content-Type': 'application/json'}, json.dumps(body),
        RESEARCH_TIMEOUT, stop=stop, store=store, now=now
    )
    if response is None or _research_stopped(stop):
        return {'skipped': 'stopped'}
    status = int(getattr(response, 'status', 0) or 0)
    if status < 200 or status >= 300 or isinstance(getattr(response, 'body', None), (bytes, bytearray)):
        from recs.engine import ProviderError, report_ai_failure
        exc = ProviderError('Deep research failed (%s).' % (status or 0))
        report_ai_failure(store, 'Deep research', exc, key)
        raise exc
    text = _message_text('gemini', response.body)
    parsed = _object(text)
    insights = [str(item) for item in (parsed.get('insights') or []) if str(item).strip()]
    notes = parsed.get('notes') or ''
    twins = _valid_twins(parsed.get('twins') or [])
    picks = _valid_picks(parsed.get('picks') or [])
    if andrew_text(store.meta_get('ai_notes') or ''):
        notes = notes  # save_research keeps the Andrew block
    save_research(store, insights, notes, twins, picks)
    from recs.engine import clear_ai_error
    clear_ai_error(store)
    return {
        'insights': len(insights) if isinstance(insights, list) else 0,
        'twins': len(twins) if isinstance(twins, list) else 0
    }


def _research_stopped(stop):
    if stop is not None and getattr(stop, 'is_set', None) and stop.is_set():
        return True
    if callable(stop) and not hasattr(stop, 'is_set'):
        try:
            return bool(stop())
        except Exception:
            return False
    try:
        from service_run import stopped
        return bool(stopped())
    except Exception:
        return False


def _gemini(settings):
    provider = (settings.get('recs_provider') or '').strip().lower()
    key = ''
    if provider == 'gemini':
        key = (settings.get('recs_api_key') or '').strip()
    if not key:
        key = (settings.get('recs_research_key') or '').strip()
    model = (settings.get('recs_research_model') or '').strip() or 'gemini-2.5-flash'
    return key, model


def _prompt(store):
    kept = andrew_text(store.meta_get('ai_notes') or '')
    return (
        'Read this taste journal and write what it shows about the person.\n'
        + journal_markdown(store)[:8000]
        + '\nAndrew wrote this. Keep it. Do not contradict it:\n'
        + (kept or '(nothing yet)')
        + '\nReturn JSON only with keys insights (list of strings), notes (markdown), '
        + 'twins (list of {name, where, why, link} for critics, YouTubers, bloggers, '
        + 'Letterboxd or Trakt users), and picks (list of {name, media_type, title, year, tmdb_id, why} '
        + 'for titles those people loved that he has not). '
        + 'Look for patterns in theme, tone, craft and characters, and contrasts inside a genre.'
    )


def _valid_twins(rows):
    kept = []
    for twin in rows:
        if not isinstance(twin, dict):
            continue
        name = str(twin.get('name') or '').strip()
        where = str(twin.get('where') or '').strip()
        why = str(twin.get('why') or '').strip()
        link = str(twin.get('link') or '').strip()
        if name and where and why and link.startswith('http'):
            kept.append({'name': name, 'where': where, 'why': why, 'link': link})
    return kept


def _valid_picks(rows):
    kept = []
    for pick in rows:
        if not isinstance(pick, dict):
            continue
        media = str(pick.get('media_type') or '').strip().lower()
        if media == 'tv':
            media = 'show'
        title = str(pick.get('title') or '').strip()
        if media not in ('movie', 'show') or not title or not pick.get('tmdb_id'):
            continue
        if title.lower() in ('andrew', 'letterboxd', 'trakt'):
            continue
        kept.append(dict(pick, media_type=media, title=title))
    return kept


def _object(text):
    raw = (text or '').strip()
    start = raw.find('{')
    end = raw.rfind('}')
    if start < 0 or end < start:
        return {}
    try:
        data = json.loads(raw[start:end + 1])
    except ValueError:
        return {}
    return data if isinstance(data, dict) else {}
