'''
    Cumination
    Copyright (C) 2016 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import os.path
import sys
import socket
import six

from kodi_six import xbmc, xbmcplugin, xbmcaddon, xbmcvfs

from resources.lib import basics
from resources.lib.url_dispatcher import URL_Dispatcher
from resources.lib import utils
from resources.lib import favorites
from resources.lib import pin
from resources.lib.adultsite import AdultSite
from resources.lib import gsearch  # noqa: F401  # aggregated search + skin_search handlers
from resources.lib import siteflags  # noqa: F401  # site enable/disable settings actions
from resources.lib import precache  # noqa: F401  # image/list precache actions
from resources.lib import siteload
from resources.lib import textio

socket.setdefaulttimeout(60)

addon = basics.addon
content = 'movies' if addon.getSetting('content') == '0' else 'videos'
xbmcplugin.setContent(basics.addon_handle, content)
addon = xbmcaddon.Addon()
TRANSLATEPATH = xbmcvfs.translatePath if six.PY3 else xbmc.translatePath
progress = utils.progress
dialog = utils.dialog

url_dispatcher = URL_Dispatcher('main')
AdultSite.set_enabled_check(siteflags.is_enabled)


@url_dispatcher.register()
def INDEX():
    url_dispatcher.add_dir('[COLOR white]{}[/COLOR]'.format(utils.i18n('sites')), '', 'site_list',
                           basics.cum_image('cum-sites.png'), '', list_avail=False)
    url_dispatcher.add_dir('[COLOR white]Sites manager[/COLOR]', '', 'siteflags.menu',
                           basics.cum_image('cum-sites.png'), '', list_avail=False)
    url_dispatcher.add_dir('[COLOR hotpink]Search all sites[/COLOR]', '', 'global_search',
                           basics.cum_image('cum-search.png'), '', list_avail=False)
    url_dispatcher.add_dir('[COLOR white]Precache[/COLOR]', '', 'precache.menu',
                           basics.cum_image('cum-downloads.png'), '', list_avail=False)
    url_dispatcher.add_dir('[COLOR white]{}[/COLOR]'.format(utils.i18n('fav_videos')), '1', 'favorites.List',
                           basics.cum_image('cum-fav.png'), '', list_avail=False)
    download_path = addon.getSetting('download_path')
    if download_path != '' and xbmcvfs.exists(download_path):
        url_dispatcher.add_dir('[COLOR white]{}[/COLOR]'.format(utils.i18n('dnld_folder')), download_path, 'OpenDownloadFolder',
                               basics.cum_image('cum-downloads.png'), '', list_avail=False)

    url_dispatcher.add_dir('[COLOR white]{}[/COLOR]'.format(utils.i18n('custom_list')), '', 'favorites.create_custom_list', Folder=False, list_avail=False)
    for row in favorites.get_custom_lists():
        rowid, name = row[0], row[1]
        thumb = row[2] if len(row) > 2 else None
        url_dispatcher.add_dir(name, str(rowid), 'favorites.load_custom_list',
                               iconimage=thumb or None, list_avail=False, custom_list=True)
    favorites.load_custom_list('main')
    url_dispatcher.add_dir('[COLOR white]{}[/COLOR]'.format(utils.i18n('clear_cache')), '', 'utils.clear_cache',
                           basics.cuminationicon, '', Folder=False, list_avail=False)

    utils.eod(basics.addon_handle, False)


@url_dispatcher.register()
def site_list():
    if not any(AdultSite.get_sites()):
        siteload.import_all_sites(addon)
    custom_listitems = favorites.get_custom_listitems()
    custom_listitems_dict = {}
    for x in custom_listitems:
        custom_listitems_dict[x[0]] = x[1]
    for x in sorted(AdultSite.get_sites(), key=lambda y: y.get_clean_title().lower(), reverse=False):
        if x.custom:
            utils.kodilog('{0}: {1}'.format(utils.i18n('list_custom'), x.title), xbmc.LOGDEBUG)
        title = x.title
        if title in custom_listitems_dict.keys():
            title = '{} [COLOR red]{}[/COLOR]'.format(title, ''.ljust(custom_listitems_dict[title], '*'))
        url_dispatcher.add_dir(title, x.url, x.default_mode, x.image, about=x.about, custom=x.custom)
    utils.eod(basics.addon_handle, False)


@url_dispatcher.register()
def global_search(url='', keyword=None, sort=None, query=None, q=None, widget=None):
    """Search all sites: one combined results list (keyboard if no keyword)."""
    as_widget = str(widget).lower() in ('1', 'true', 'yes')
    gsearch.run(keyword=keyword or query or q, sort=sort, prompt=not as_widget, widget=as_widget)


@url_dispatcher.register()
def skin_search(url='', keyword=None, sort=None, query=None, q=None, widget=None):
    """AF3 / skin search box: never pop the keyboard; keyword comes from the URL."""
    gsearch.run(keyword=keyword or query or q, sort=sort, prompt=False, widget=True)


@url_dispatcher.register()
def search(url='', keyword=None, sort=None, query=None, q=None, widget=None):
    """Alias of skin_search for plugin://...?mode=search&keyword=."""
    gsearch.run(keyword=keyword or query or q, sort=sort, prompt=False, widget=True)


@url_dispatcher.register()
def OpenDownloadFolder(url):
    xbmc.executebuiltin('Dialog.Close(busydialog, true)')
    xbmc.sleep(100)
    xbmc.executebuiltin('ActivateWindow(Videos, ' + url + ')')


@url_dispatcher.register()
def smrSettings():
    import resolveurl
    resolveurl.display_settings()


@url_dispatcher.register()
def openLogUploader():
    from resources.lib.jsonrpc import check_addon
    if check_addon('script.kodi.loguploader'):
        xbmc.executebuiltin("RunScript(script.kodi.loguploader)")
    else:
        dialog.ok('Kodi Logfile Uploader', 'Installing Kodi Logfile Uploader unsuccesful\nPlease install it manually from the Kodi repository')


@url_dispatcher.register()
def about_site(name, about, custom):
    heading = '{0} {1}'.format(utils.i18n('about'), name)
    dir = basics.customSitesDir if custom else basics.aboutDir
    announce = textio.read_utf8(TRANSLATEPATH(os.path.join(dir, '{}.txt'.format(about))))
    utils.textBox(heading, announce)


def change():
    version = addon.getAddonInfo('version')
    if not os.path.isfile(basics.changelog):
        return
    marker = os.path.join(basics.profileDir, 'changelog_seen.txt')
    try:
        if textio.read_utf8(marker).strip() == version:
            return
    except Exception:
        pass
    try:
        with open(marker, 'w') as f:
            f.write(version)
    except Exception:
        return
    heading = '[B][COLOR hotpink]Cumination[/COLOR] [COLOR white]Changelog[/COLOR][/B]'
    cl_lines = textio.read_utf8_lines(basics.changelog)
    announce = ''
    for line in cl_lines:
        if not line.strip():
            break
        announce += line
    utils.textBox(heading, announce)


if not addon.getSetting('cuminationage') == 'true':
    age = dialog.yesno(utils.i18n('warn'), utils.i18n('warn_msg'),
                       nolabel=utils.i18n('exit'), yeslabel=utils.i18n('enter'))
    if age:
        addon.setSetting('cuminationage', 'true')
else:
    age = True


def process_queries(argv):
    if sys.argv:
        argv = sys.argv
    queries = utils.parse_query(argv[2] if len(argv) > 2 else '')
    queries = gsearch.normalize_plugin_queries(queries)
    mode = queries.get('mode', None)
    siteload.prepare(mode, addon)
    widget = bool(queries.get('widget', ''))
    if widget and mode and '.' in str(mode):
        ins = AdultSite.get_site_by_name(mode.split('.')[0])
        if ins:
            ins.widget = True
    try:
        url_dispatcher.dispatch(mode, queries)
    except Exception as exc:
        if not siteload.should_retry(exc):
            raise
        siteload.import_all_sites(addon)
        url_dispatcher.dispatch(mode, queries)


def main(argv=None):
    if addon.getSetting('enh_debug') == 'true':
        from resources.lib import exception_logger
        with exception_logger.log_exception():
            process_queries(argv)
    else:
        process_queries(argv)


if __name__ == '__main__':
    if pin.CheckPin():
        if age:
            change()
            sys.exit(main())
