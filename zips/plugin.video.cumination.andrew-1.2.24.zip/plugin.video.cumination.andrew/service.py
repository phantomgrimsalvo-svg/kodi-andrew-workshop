# -*- coding: utf-8 -*-
"""Kodi service entry: background Precache only. No pan, no listing downloads."""
from resources.lib.pan_service import run

if __name__ == '__main__':
    run()
