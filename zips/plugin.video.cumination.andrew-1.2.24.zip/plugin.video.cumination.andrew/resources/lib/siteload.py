# -*- coding: utf-8 -*-
"""Load only the site module a directory call needs.

Importing every site on every folder open is what makes Cumination menus and
listings slow. The mode prefix names the site. A text scan maps that name to
the module file (some files register a different name than the filename).
"""
from __future__ import absolute_import

import importlib
import os
import re

_ALL = False
_MAP = None
_SITE_RE = re.compile(r"""AdultSite\(\s*['"]([^'"]+)['"]""")

# These modes need every registered site. Everything else is one site, or a
# builtin handler that loads sites itself when it actually lists them.
_ALL_MODES = (
    'main.site_list',
    'main.global_search',
    'main.skin_search',
    'main.search',
    'global_search',
    'skin_search',
    'search',
    'site_list',
)


def mode_map():
    """Map AdultSite name (and filename stem) to the importable module stem."""
    global _MAP
    if _MAP is not None:
        return _MAP
    mapping = {}
    sites_dir = os.path.join(os.path.dirname(__file__), 'sites')
    try:
        names = os.listdir(sites_dir)
    except Exception:
        _MAP = mapping
        return _MAP
    for filename in names:
        if filename.startswith('__') or not filename.endswith('.py'):
            continue
        stem = filename[:-3]
        path = os.path.join(sites_dir, filename)
        try:
            with open(path, 'r', encoding='utf-8', errors='replace') as handle:
                found = _SITE_RE.findall(handle.read())
        except Exception:
            found = []
        for site_name in found or (stem,):
            mapping[site_name] = stem
        mapping.setdefault(stem, stem)
    _MAP = mapping
    return _MAP


def import_all_sites(addon):
    """Import every built-in site, then any enabled custom sites."""
    global _ALL
    if _ALL:
        return
    from resources.lib.sites import load_all
    load_all()
    try:
        if addon.getSetting('custom_sites') == 'true':
            import sys
            from resources.lib import basics
            from resources.lib import favorites
            from resources.lib import utils
            sys.path.append(basics.customSitesDir)
            for module_name in favorites.enabled_custom_sites():
                try:
                    importlib.import_module(module_name)
                except Exception as exc:
                    utils.kodilog('{0} {1}: {2}'.format(utils.i18n('err_custom'), module_name, exc))
                    favorites.disable_custom_site_by_module(module_name)
                    title = favorites.get_custom_site_title_by_module(module_name)
                    utils.textBox(utils.i18n('disable_custom'), '{0}:[CR]{1}'.format(utils.i18n('custom_msg'), title))
    except Exception:
        pass
    _ALL = True


def prepare(mode, addon):
    """Import the modules required before this mode is dispatched."""
    if _ALL:
        return
    try:
        fast = addon.getSetting('fast_listings') != 'false'
    except Exception:
        fast = True
    if not fast:
        import_all_sites(addon)
        return
    mode = mode or ''
    if mode in _ALL_MODES:
        import_all_sites(addon)
        return
    if '.' not in mode:
        return
    head = mode.split('.', 1)[0]
    # These screens list every site. Fast listings must not leave the registry empty.
    if head in ('precache', 'siteflags', 'gsearch'):
        import_all_sites(addon)
        return
    if head in ('main', 'favorites', 'utils', 'pin'):
        return
    stem = mode_map().get(head)
    if not stem:
        import_all_sites(addon)
        return
    try:
        importlib.import_module('resources.lib.sites.{0}'.format(stem))
    except Exception:
        import_all_sites(addon)


def should_retry(exc):
    """True when the mode was missing because its site module was not loaded."""
    if _ALL:
        return False
    return 'unregistered mode' in str(exc)
