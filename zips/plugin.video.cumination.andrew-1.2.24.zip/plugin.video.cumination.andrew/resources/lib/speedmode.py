# -*- coding: utf-8 -*-
"""Speed mode presets for the heavy Cumination settings.

Max Quality, Balanced, Fast, and Max Speed write the switches below.
Custom does not write them. Changing one of those switches sets Custom.
The service applies a preset only when Speed mode itself changes, so an
upgrade does not overwrite settings Andrew already saved.
"""
from __future__ import absolute_import

MODE_QUALITY = '0'
MODE_BALANCED = '1'
MODE_FAST = '2'
MODE_MAX = '3'
MODE_CUSTOM = '4'

# Kodi stores bools and enums as these strings.
PRESETS = {
    MODE_QUALITY: {
        'fast_listings': 'true',
        'posterfanart': 'true',
        'portrait_fanart_extras': 'true',
        'portrait_fanart_mode': '0',
        'landscape_fanart_mode': '1',
        'frame_thumbs': 'true',
    },
    MODE_BALANCED: {
        'fast_listings': 'true',
        'posterfanart': 'false',
        'portrait_fanart_extras': 'true',
        'portrait_fanart_mode': '0',
        'landscape_fanart_mode': '0',
        'frame_thumbs': 'true',
    },
    MODE_FAST: {
        'fast_listings': 'true',
        'posterfanart': 'true',
        'portrait_fanart_extras': 'true',
        'portrait_fanart_mode': '0',
        'landscape_fanart_mode': '0',
        'frame_thumbs': 'false',
    },
    MODE_MAX: {
        'fast_listings': 'true',
        'posterfanart': 'false',
        'portrait_fanart_extras': 'false',
        'portrait_fanart_mode': '0',
        'landscape_fanart_mode': '0',
        'frame_thumbs': 'false',
    },
}

_BOOLS = (
    'fast_listings',
    'posterfanart',
    'portrait_fanart_extras',
    'frame_thumbs',
)
_DEFAULTS = {
    'fast_listings': 'true',
    'posterfanart': 'false',
    'portrait_fanart_extras': 'true',
    'portrait_fanart_mode': '0',
    'landscape_fanart_mode': '0',
    'frame_thumbs': 'true',
}

_busy = False
_last = None
_skip_once = False


def read_state(addon):
    state = {}
    for key, default in _DEFAULTS.items():
        try:
            raw = addon.getSetting(key)
        except Exception:
            raw = ''
        if raw is None or raw == '':
            state[key] = default
        elif key in _BOOLS:
            state[key] = 'true' if str(raw).lower() == 'true' else 'false'
        else:
            state[key] = str(raw)
    return state


def _mode(addon):
    try:
        raw = addon.getSetting('speed_mode')
    except Exception:
        raw = ''
    raw = '' if raw is None else str(raw)
    return raw if raw in PRESETS or raw == MODE_CUSTOM else MODE_CUSTOM


def capture(addon):
    """Remember the current preset without writing any setting."""
    global _last
    _last = _mode(addon)


def on_settings_changed(addon):
    """Apply a newly chosen preset, or mark Custom when a switch changes.

    Call this from the service loop, never from Monitor.onSettingsChanged.
    Kodi holds the settings lock inside that callback.
    """
    global _busy, _last, _skip_once
    if _busy:
        return
    if _last is None:
        capture(addon)
        return
    if _skip_once:
        _skip_once = False
        _last = _mode(addon)
        return
    mode = _mode(addon)
    if mode != _last:
        _last = mode
        if mode not in PRESETS:
            return
        _busy = True
        try:
            current = read_state(addon)
            for key, value in PRESETS[mode].items():
                if current.get(key) != value:
                    addon.setSetting(key, value)
            _skip_once = True
        finally:
            _busy = False
        return
    if mode in PRESETS and read_state(addon) != PRESETS[mode]:
        _busy = True
        try:
            addon.setSetting('speed_mode', MODE_CUSTOM)
            _skip_once = True
        finally:
            _busy = False
        _last = MODE_CUSTOM
