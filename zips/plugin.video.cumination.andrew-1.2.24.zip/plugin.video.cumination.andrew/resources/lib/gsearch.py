# -*- coding: utf-8 -*-
"""Aggregated 'Search all sites' for Cumination (Andrew)."""
from __future__ import absolute_import

import inspect
import socket
import sys
import threading
import time
import traceback

try:
    from inspect import getargspec
except ImportError:
    from inspect import getfullargspec as getargspec

from six.moves import urllib_parse
from kodi_six import xbmc, xbmcgui, xbmcplugin

from resources.lib import basics
from resources.lib import utils
from resources.lib.adultsite import AdultSite
from resources.lib.url_dispatcher import URL_Dispatcher
from resources.lib.gsearch_lib import (
    clean_video_title, decorate_title, enrich_item, extract_search_url_from_source,
    is_search_mode, keyword_from_result_title, keyword_is_provided,
    normalize_plugin_queries, normalize_sort, parse_csv_names, site_allowed, sort_items,
    strip_colors, url_looks_complete,
)

url_dispatcher = URL_Dispatcher('gsearch')

_tls = threading.local()
_PATCHED = False
_PATCH_LOCK = threading.Lock()
_ORIG = {}
# hold: site threads must not touch the plugin directory while results are collected.
# owner: the thread allowed to add the combined listing.
# committed: endOfDirectory has been called for this search; later calls are ignored.
_gate = {'hold': False, 'committed': False, 'owner': None}
SORT_LABELS = {
    'relevance': 'Relevance',
    'date': 'Newest',
    'views': 'Most viewed',
    'rating': 'Top rated',
}
SORT_INDEX = {'relevance': '0', 'date': '1', 'views': '2', 'rating': '3'}


def _setting(key, default=''):
    try:
        val = basics.addon.getSetting(key)
    except Exception:
        val = ''
    return val if val not in (None, '') else default


def _setting_int(key, default):
    try:
        return int(_setting(key, str(default)))
    except Exception:
        return default


def _setting_bool(key, default=False):
    val = _setting(key, 'true' if default else 'false')
    return str(val).lower() == 'true'


def _kodilog(msg, level=None):
    try:
        utils.kodilog(u'gsearch: {0}'.format(msg), level if level is not None else xbmc.LOGDEBUG)
    except Exception:
        pass


def _is_collecting():
    return bool(
        getattr(_tls, 'collecting', False)
        or getattr(_tls, 'harvest', False)
        or getattr(_tls, 'precache', False)
    )


def _plugin_calls_blocked():
    """Keep site threads from committing the plugin directory.

    Each site Search/List calls endOfDirectory when its own page is done.
    Those calls run on worker threads. If they reach Kodi, the container is
    committed empty (or with succeeded false) while the progress dialog is
    still counting videos, and the combined list is never shown.
    """
    if _gate['committed']:
        return True
    if _gate['hold'] and threading.current_thread() is not _gate['owner']:
        return True
    return _is_collecting()


def _capturing_addDownLink(name, url, mode, iconimage, desc='', stream=None, fav='add',
                           noDownload=False, contextm=None, fanart=None, duration='', quality=''):
    buf = getattr(_tls, 'items', None)
    if buf is not None:
        limit = getattr(_tls, 'limit', 9999)
        if len(buf) < limit:
            buf.append({
                'name': name,
                'url': url,
                'mode': mode,
                'iconimage': iconimage,
                'desc': desc or '',
                'stream': stream,
                'duration': duration or '',
                'quality': quality or '',
                'fanart': fanart,
            })
        return True
    return _ORIG['addDownLink'](name, url, mode, iconimage, desc, stream, fav, noDownload,
                                contextm, fanart, duration, quality)


def _dir_payload(name, url, mode, iconimage, page, channel, section, keyword, Folder, site=''):
    return {
        'name': name,
        'url': url,
        'mode': mode,
        'iconimage': iconimage,
        'page': page,
        'channel': channel,
        'section': section,
        'keyword': keyword,
        'Folder': Folder,
        'site': site,
    }


def _capturing_addDir(name, url, mode, iconimage=None, page=None, channel=None, section=None,
                      keyword='', Folder=True, about=None, custom=False, list_avail=True,
                      listitem_id=None, custom_list=False, contextm=None, desc=''):
    if getattr(_tls, 'harvest', False) or getattr(_tls, 'precache', False):
        buf = getattr(_tls, 'dirs', None)
        if buf is not None:
            buf.append(_dir_payload(name, url, mode, iconimage, page, channel, section,
                                    keyword, Folder))
        return True
    if getattr(_tls, 'collecting', False):
        return True
    return _ORIG['addDir'](name, url, mode, iconimage, page, channel, section, keyword, Folder,
                           about, custom, list_avail, listitem_id, custom_list, contextm, desc)


def _capturing_eod(*args, **kwargs):
    if _is_collecting():
        return
    return _ORIG['eod'](*args, **kwargs)


def _capturing_notify(*args, **kwargs):
    if _is_collecting():
        return
    return _ORIG['notify'](*args, **kwargs)


def _capturing_addDirectoryItem(*args, **kwargs):
    if _plugin_calls_blocked():
        return True
    return _ORIG['addDirectoryItem'](*args, **kwargs)


def _capturing_endOfDirectory(*args, **kwargs):
    if _plugin_calls_blocked():
        return None
    return _ORIG['endOfDirectory'](*args, **kwargs)


def _capturing_addSortMethod(*args, **kwargs):
    if _plugin_calls_blocked():
        return None
    fn = _ORIG.get('addSortMethod')
    if fn:
        return fn(*args, **kwargs)
    return None


def _install_patches():
    global _PATCHED
    with _PATCH_LOCK:
        if _PATCHED:
            return
        from resources.lib import basics as basics_mod
        from resources.lib import utils as utils_mod
        from resources.lib import url_dispatcher as ud_mod

        _ORIG['addDownLink'] = basics_mod.addDownLink
        _ORIG['addDir'] = basics_mod.addDir
        _ORIG['eod'] = basics_mod.eod
        _ORIG['notify'] = utils_mod.notify
        _ORIG['ud_addDownLink'] = ud_mod.addDownLink
        _ORIG['ud_addDir'] = ud_mod.addDir
        _ORIG['ud_eod'] = getattr(ud_mod, 'eod', None)
        _ORIG['utils_eod'] = utils_mod.eod
        _ORIG['URL_add_dir'] = URL_Dispatcher.add_dir
        _ORIG['addDirectoryItem'] = xbmcplugin.addDirectoryItem
        _ORIG['endOfDirectory'] = xbmcplugin.endOfDirectory
        _ORIG['addSortMethod'] = getattr(xbmcplugin, 'addSortMethod', None)
        _ORIG['setContent'] = getattr(xbmcplugin, 'setContent', None)

        basics_mod.addDownLink = _capturing_addDownLink
        basics_mod.addDir = _capturing_addDir
        basics_mod.eod = _capturing_eod
        ud_mod.addDownLink = _capturing_addDownLink
        ud_mod.addDir = _capturing_addDir
        utils_mod.eod = _capturing_eod
        utils_mod.notify = _capturing_notify
        URL_Dispatcher.add_dir = _patched_add_dir
        xbmcplugin.addDirectoryItem = _capturing_addDirectoryItem
        xbmcplugin.endOfDirectory = _capturing_endOfDirectory
        if _ORIG['addSortMethod']:
            xbmcplugin.addSortMethod = _capturing_addSortMethod
        _PATCHED = True


def _patched_add_dir(self, name, url, mode, iconimage=None, page=None, channel=None, section=None,
                     keyword='', Folder=True, about=None, custom=False, list_avail=True,
                     listitem_id=None, custom_list=False, contextm=None, desc=''):
    mode = self.get_full_mode(mode)
    if getattr(_tls, 'harvest', False) or getattr(_tls, 'precache', False):
        buf = getattr(_tls, 'dirs', None)
        if buf is not None:
            buf.append(_dir_payload(
                name, url, mode, iconimage, page, channel, section, keyword, Folder,
                site=getattr(self, 'name', ''),
            ))
        return True
    if getattr(_tls, 'collecting', False):
        return True
    return _ORIG['URL_add_dir'](
        self, name, url, mode, iconimage, page, channel, section, keyword, Folder, about,
        custom, list_avail, listitem_id, custom_list, contextm, desc
    )


def _call_registered(mode, url, keyword=None, extra=None):
    func = URL_Dispatcher.func_registry.get(mode)
    if not func:
        raise RuntimeError('unregistered mode {0}'.format(mode))
    spec = getargspec(func)
    args = list(spec.args or [])
    defaults = spec.defaults or ()
    kwarg_names = args[-len(defaults):] if defaults else []
    pos_names = args[:-len(defaults)] if defaults else args
    call_args = []
    call_kwargs = {}
    extra = extra or {}
    values = {
        'url': extra.get('url', url),
        'keyword': keyword if keyword is not None else extra.get('keyword'),
        'name': extra.get('name') or keyword,
        'page': extra.get('page'),
        'channel': extra.get('channel'),
        'section': extra.get('section'),
    }
    for name in pos_names:
        if name == 'self':
            continue
        if name in values and values[name] is not None and str(values[name]) not in ('None', 'none'):
            call_args.append(values[name])
        elif name == 'url':
            call_args.append(url or '')
        else:
            raise RuntimeError('cannot fill required arg {0} for {1}'.format(name, mode))
    for name in kwarg_names:
        if name in values and values[name] is not None and str(values[name]) not in ('None', 'none'):
            call_kwargs[name] = values[name]
    return func(*call_args, **call_kwargs)


def _search_url_from_source(site):
    func = URL_Dispatcher.func_registry.get(site.default_mode)
    if not func:
        return None, None
    try:
        src = inspect.getsource(func)
    except Exception:
        return None, None
    return extract_search_url_from_source(src, site.url)


def harvest_search_entry(site):
    """Run a site Main() with listings stubbed and capture the Search add_dir."""
    _install_patches()
    from resources.lib import utils as utils_mod
    orig_get = utils_mod.getHtml
    orig_get2 = getattr(utils_mod, 'getHtml2', None)

    def _empty_html(*_a, **_k):
        return ''

    utils_mod.getHtml = _empty_html
    if orig_get2 is not None:
        utils_mod.getHtml2 = _empty_html
    _tls.harvest = True
    _tls.dirs = []
    _tls.items = None
    _tls.collecting = False
    prev_to = socket.getdefaulttimeout()
    socket.setdefaulttimeout(4)
    try:
        _call_registered(site.default_mode, site.url, keyword=None)
    except Exception:
        pass
    finally:
        socket.setdefaulttimeout(prev_to)
        utils_mod.getHtml = orig_get
        if orig_get2 is not None:
            utils_mod.getHtml2 = orig_get2
        dirs = list(getattr(_tls, 'dirs', None) or [])
        _tls.harvest = False
        _tls.dirs = None
    for item in dirs:
        mode = item.get('mode') or ''
        if is_search_mode(mode) and 'user' not in mode.lower():
            return item
    return None


def harvest_listing(mode, url, extra=None, timeout=20, item_limit=4000):
    """Run a registered list mode and capture folders + video rows (no Kodi UI)."""
    _install_patches()
    extra = extra or {}
    _tls.precache = True
    _tls.harvest = True
    _tls.collecting = True
    _tls.dirs = []
    _tls.items = []
    _tls.limit = item_limit
    prev_to = socket.getdefaulttimeout()
    socket.setdefaulttimeout(max(4, int(timeout or 20)))
    from resources.lib import utils as utils_mod
    orig_dialog = getattr(utils_mod, 'dialog', None)

    class _QuietDialog(object):
        def ok(self, *a, **k):
            return True

        def yesno(self, *a, **k):
            return False

        def select(self, *a, **k):
            return -1

        def multiselect(self, *a, **k):
            return None

        def browse(self, *a, **k):
            return ''

        def input(self, *a, **k):
            return ''

        def numeric(self, *a, **k):
            return ''

        def notification(self, *a, **k):
            return

    try:
        utils_mod.dialog = _QuietDialog()
    except Exception:
        pass
    error = None
    try:
        _call_registered(mode, url, keyword=extra.get('keyword'), extra=extra)
    except Exception as exc:
        error = str(exc)
    finally:
        socket.setdefaulttimeout(prev_to)
        try:
            if orig_dialog is not None:
                utils_mod.dialog = orig_dialog
        except Exception:
            pass
        dirs = list(getattr(_tls, 'dirs', None) or [])
        items = list(getattr(_tls, 'items', None) or [])
        _tls.precache = False
        _tls.harvest = False
        _tls.collecting = False
        _tls.dirs = None
        _tls.items = None
        _tls.limit = 9999
    return dirs, items, error


def _target_for_site(site):
    src_url, src_mode = _search_url_from_source(site)
    if src_url and url_looks_complete(src_url):
        for cand in (
            '{0}.{1}'.format(site.name, src_mode) if src_mode else None,
            '{0}.Search'.format(site.name),
            '{0}.XTSearch'.format(site.name),
            '{0}.PTSearch'.format(site.name),
        ):
            if not cand:
                continue
            func = URL_Dispatcher.func_registry.get(cand)
            if not func:
                continue
            spec = getargspec(func)
            if 'keyword' not in list(spec.args or []):
                continue
            return cand, src_url

    harvested = harvest_search_entry(site)
    if harvested and harvested.get('url') is not None:
        mode = harvested.get('mode')
        func = URL_Dispatcher.func_registry.get(mode)
        if func:
            spec = getargspec(func)
            if 'keyword' in list(spec.args or []):
                return mode, harvested.get('url') or site.url

    for cand in (
        '{0}.Search'.format(site.name),
        '{0}.XTSearch'.format(site.name),
        '{0}.PTSearch'.format(site.name),
    ):
        func = URL_Dispatcher.func_registry.get(cand)
        if not func:
            continue
        spec = getargspec(func)
        if 'keyword' not in list(spec.args or []):
            continue
        return cand, src_url or site.url
    return None, None


def _search_disabled_names():
    """Unchecked sites in the global-search checkbox list. Empty means all on.

    A saved list that names every loaded site is the empty-selection bug, not
    a choice to search nothing. Treat that as every site on.
    """
    try:
        from resources.lib import siteflags
        state = siteflags.get_state()
    except Exception:
        return set()
    blocked = set((n or '').lower() for n in (state.get('search_disabled') or []))
    if not blocked:
        return blocked
    try:
        loaded = set((site.name or '').lower() for site in AdultSite.get_sites() if site.name)
    except Exception:
        loaded = set()
    if loaded and loaded <= blocked:
        _kodilog(u'search checkboxes disabled every site; searching all enabled sites', xbmc.LOGWARNING)
        return set()
    return blocked


def iter_search_targets(include=None, exclude=None, webcams=False, max_sites=30, enabled_only=True,
                        search_disabled=None):
    getter = AdultSite.get_sites if enabled_only else AdultSite.get_all_sites
    sites = sorted(getter(), key=lambda s: (s.get_clean_title() or s.name or '').lower())
    blocked = search_disabled if search_disabled is not None else _search_disabled_names()
    count = 0
    for site in sites:
        if not site.default_mode:
            continue
        if site.webcam and not webcams:
            continue
        if (site.name or '').lower() in blocked:
            continue
        if not site_allowed(site.name, include, exclude):
            continue
        try:
            mode, url = _target_for_site(site)
        except Exception as exc:
            _kodilog(u'target fail {0}: {1}'.format(site.name, exc))
            continue
        if not mode:
            continue
        yield site, mode, url
        count += 1
        if max_sites and count >= max_sites:
            break


def _search_one_site(site, mode, url, keyword, limit, timeout):
    _install_patches()
    _tls.collecting = True
    _tls.harvest = False
    _tls.items = []
    _tls.limit = limit
    prev_to = socket.getdefaulttimeout()
    try:
        timeout = float(timeout)
    except (TypeError, ValueError):
        timeout = 12
    if timeout < 1:
        timeout = 12
    socket.setdefaulttimeout(timeout)
    error = None
    try:
        _call_registered(mode, url, keyword=keyword)
    except Exception as exc:
        error = u'{0}: {1}'.format(type(exc).__name__, exc)
        _kodilog(u'{0} search error: {1}'.format(site.name, traceback.format_exc()), xbmc.LOGWARNING)
    finally:
        socket.setdefaulttimeout(prev_to)
        items = list(_tls.items or [])
        _tls.items = None
        _tls.collecting = False
    site_title = site.get_clean_title() if site else site.name
    out = []
    for idx, raw in enumerate(items):
        item = dict(raw)
        enrich_item(item, keyword, site_title, idx)
        item['site_key'] = site.name
        item['name'] = decorate_title(site_title, item.get('name') or '')
        out.append(item)
    return site.name, out, error


def _persist_sort(sort_key):
    sort_key = normalize_sort(sort_key)
    try:
        basics.addon.setSetting('global_search_sort', SORT_INDEX.get(sort_key, '0'))
    except Exception:
        pass
    return sort_key


def resolved_sort(sort_param=None):
    if sort_param not in (None, ''):
        return _persist_sort(sort_param)
    stored = _setting('global_search_sort', '0')
    return normalize_sort(stored)


def prompt_keyword(heading='Search all sites'):
    keyboard = xbmc.Keyboard('', heading)
    keyboard.doModal()
    if not (keyboard.isConfirmed() and keyboard.getText()):
        return None
    text = keyboard.getText()
    if not text or not text.strip():
        return None
    return text.strip()


def _progress_dialog():
    try:
        return xbmcgui.DialogProgress()
    except Exception:
        return None


def _decode_keyword(keyword):
    """parse_qs already unquotes once. Undo a second encoding from a skin path."""
    text = str(keyword or '').strip()
    if '%' not in text and '+' not in text:
        return text
    try:
        decoded = urllib_parse.unquote_plus(text)
    except Exception:
        return text
    decoded = str(decoded or '').strip()
    return decoded or text


def _open_progress(title, line):
    """Background progress. A modal dialog replaces the plugin container, and
    closing it commits the directory before the combined rows are added.

    Returns (dialog, cancellable). Background progress often reports cancelled
    before it is drawn; that must not stop the search after the first site.
    """
    dlg = None
    cancellable = False
    try:
        dlg = xbmcgui.DialogProgressBG()
    except Exception:
        dlg = None
    if dlg is None:
        dlg = _progress_dialog()
        cancellable = dlg is not None
    if dlg is None:
        return None, False
    try:
        dlg.create(title, line)
    except Exception:
        try:
            dlg.create(title)
        except Exception:
            return None, False
    return dlg, cancellable


def _finish_directory():
    """Commit the listing once. succeeded=True so Kodi keeps the rows.

    cacheToDisc=True lets a skin widget read the directory. updateListing
    stays false so this does not wipe a container that was already replaced.
    """
    if _gate['committed']:
        return
    _gate['committed'] = True
    _gate['owner'] = threading.current_thread()
    try:
        handle = int(basics.addon_handle)
    except Exception:
        handle = -1
    set_content = _ORIG.get('setContent') or getattr(xbmcplugin, 'setContent', None)
    try:
        if set_content:
            content = 'movies' if _setting('content', '0') == '0' else 'videos'
            set_content(handle, content)
    except Exception:
        pass
    end = _ORIG.get('endOfDirectory') or xbmcplugin.endOfDirectory
    try:
        end(handle, True, False, True)
    except TypeError:
        try:
            end(handle, succeeded=True, updateListing=False, cacheToDisc=True)
        except Exception as exc:
            _kodilog(u'endOfDirectory failed: {0}'.format(exc), xbmc.LOGERROR)
    except Exception as exc:
        _kodilog(u'endOfDirectory failed: {0}'.format(exc), xbmc.LOGERROR)


def _release_search(progress):
    """Commit the directory first, then close progress so the list stays."""
    if not _gate['committed']:
        _gate['owner'] = threading.current_thread()
        _finish_directory()
    try:
        if progress:
            progress.close()
    except Exception:
        pass
    _gate['hold'] = False


def _message_and_finish(label, progress=None):
    _gate['owner'] = threading.current_thread()
    _tls.collecting = False
    _tls.harvest = False
    _tls.precache = False
    _tls.items = None
    _tls.dirs = None
    try:
        basics.addDir(
            label, '', 'main.INDEX', basics.cum_image('cum-search.png'),
            Folder=True, list_avail=False,
        )
    except Exception as exc:
        _kodilog(u'message row failed: {0}'.format(exc), xbmc.LOGERROR)
    _release_search(progress)


def _progress_update(progress, pct, line):
    if not progress:
        return
    try:
        progress.update(int(pct), 'Search all sites', line)
    except Exception:
        try:
            progress.update(int(pct), line)
        except Exception:
            pass


def run(keyword=None, sort=None, prompt=True, widget=False):
    """Build one combined Kodi directory of search hits.

    widget=True (the skin search row) must not open a keyboard or a modal
    progress dialog. Those dialogs report cancelled inside a container and
    the old code then called endOfDirectory before any site finished.
    """
    # hold before clearing committed, so a leftover site thread cannot commit
    # succeeded=False in the gap between two searches.
    _gate['hold'] = True
    _gate['owner'] = None
    _gate['committed'] = False
    interactive = bool(prompt) and not widget
    if not keyword_is_provided(keyword):
        if interactive:
            keyword = prompt_keyword()
            if not keyword:
                _release_search(None)
                return
        else:
            _message_and_finish('[COLOR white]Skin search — type a query in the search box[/COLOR]')
            return
    keyword = _decode_keyword(keyword)
    sort_key = resolved_sort(sort)

    include = parse_csv_names(_setting('global_search_include', ''))
    exclude = parse_csv_names(_setting('global_search_exclude', ''))
    webcams = _setting_bool('global_search_webcams', False)
    enabled_only = _setting_bool('global_search_enabled_only', True)
    # A saved timeout of 0 makes sockets non-blocking and every site fails at once.
    timeout = max(5, _setting_int('global_search_timeout', 12))
    max_sites = max(1, _setting_int('global_search_max_sites', 30))
    per_site = max(1, _setting_int('global_search_max_per_site', 24))
    search_disabled = _search_disabled_names()
    # A skin container will not wait forever. Return whatever has arrived.
    if not interactive:
        timeout = min(timeout, 8)
    deadline = None if interactive else (time.time() + 22)

    progress = None
    cancellable = False
    if interactive:
        progress, cancellable = _open_progress('Search all sites', u'Searching for "{0}"'.format(keyword))

    def _cancelled():
        if not cancellable or progress is None:
            return False
        try:
            return bool(progress.iscanceled())
        except Exception:
            return False

    if not any(AdultSite.get_sites()):
        try:
            from resources.lib import siteload
            siteload.import_all_sites(basics.addon)
        except Exception as exc:
            _kodilog(u'site import before search failed: {0}'.format(exc), xbmc.LOGERROR)

    targets = []
    try:
        for row in iter_search_targets(
            include, exclude, webcams, max_sites, enabled_only=enabled_only,
            search_disabled=search_disabled,
        ):
            if deadline is not None and time.time() > deadline:
                break
            targets.append(row)
            if _cancelled():
                break
            _progress_update(
                progress,
                min(20, int(10.0 * len(targets) / max(max_sites, 1))),
                u'Preparing {0}/{1} sites'.format(len(targets), max_sites),
            )
    except Exception as exc:
        _kodilog(u'target list failed: {0}'.format(exc), xbmc.LOGERROR)

    if not targets:
        if interactive:
            try:
                utils.dialog.ok('Cumination (Andrew)', 'No site Search handlers are available for global search.')
            except Exception:
                pass
        _message_and_finish('[COLOR white]No site Search handlers are available[/COLOR]', progress)
        return

    results = []
    errors = 0
    done = 0
    total = len(targets)
    first_skip = {'text': ''}

    def _note_skip(name, err):
        if not err:
            return
        text = u'{0}: {1}'.format(name, err)
        _kodilog(u'skip {0}'.format(text), xbmc.LOGWARNING)
        if not first_skip['text']:
            first_skip['text'] = text

    # Site handlers call Kodi (settings, cache, dialogs). A worker that times
    # out or raises is counted as skipped and its videos are dropped, which
    # made every site look skipped. Search on this thread instead.
    for row in targets:
        if _cancelled() or (deadline is not None and time.time() > deadline):
            break
        site, mode, url = row
        try:
            _name, items, err = _search_one_site(site, mode, url, keyword, per_site, timeout)
        except Exception as exc:
            _name, items, err = getattr(site, 'name', ''), [], exc
        if items:
            results.extend(items)
        elif err:
            errors += 1
            _note_skip(_name, err)
        done += 1
        _progress_update(
            progress,
            min(95, 20 + int(75.0 * done / max(total, 1))),
            u'{0}/{1} sites · {2} videos'.format(done, total, len(results)),
        )

    try:
        results = sort_items(results, sort_key, keyword)
        _render_results(keyword, sort_key, results, total, errors, first_skip['text'])
    finally:
        _release_search(progress)


def _plugin_root():
    return sys.argv[0] if sys.argv else 'plugin://plugin.video.cumination.andrew/'


def _current_mode():
    try:
        q = utils.parse_query(sys.argv[2] if len(sys.argv) > 2 else '')
        q = normalize_plugin_queries(q)
        return q.get('mode') or 'main.global_search'
    except Exception:
        return 'main.global_search'


def _runplugin(mode, **params):
    parts = ['mode=' + urllib_parse.quote_plus(str(mode))]
    for key, val in params.items():
        if val is None:
            continue
        parts.append('{0}={1}'.format(key, urllib_parse.quote_plus(six_text(val))))
    return 'RunPlugin({0}?{1})'.format(_plugin_root(), '&'.join(parts))


def six_text(val):
    if val is None:
        return ''
    try:
        import six
        return six.ensure_str(val)
    except Exception:
        return str(val)


def _render_results(keyword, sort_key, results, site_count, errors, skip_reason=''):
    """Write the combined list on this thread, then endOfDirectory(succeeded=True)."""
    _gate['owner'] = threading.current_thread()
    # Worker capture flags live on the worker thread. Clear this thread too so
    # a leftover harvest/collect flag cannot swallow the rows or the commit.
    _tls.collecting = False
    _tls.harvest = False
    _tls.precache = False
    _tls.items = None
    _tls.dirs = None

    def _row(*args, **kwargs):
        try:
            basics.addDir(*args, **kwargs)
        except Exception as exc:
            _kodilog(u'addDir failed: {0}'.format(exc), xbmc.LOGERROR)

    try:
        sort_label = SORT_LABELS.get(sort_key, sort_key)
        status = u'[COLOR white]{0} videos from {1} sites[/COLOR]'.format(len(results), site_count)
        if errors:
            reason = (skip_reason or '').replace('[', '(').replace(']', ')')
            if len(reason) > 90:
                reason = reason[:87] + '...'
            if reason:
                status += u' [COLOR orange]({0} sites skipped: {1})[/COLOR]'.format(errors, reason)
            else:
                status += u' [COLOR orange]({0} sites skipped)[/COLOR]'.format(errors)
        _row(
            '[COLOR hotpink]Sort: {0}[/COLOR]'.format(sort_label),
            '', 'gsearch.change_sort', basics.cum_image('cum-search.png'),
            keyword=keyword, Folder=False, list_avail=False,
            contextm=('[COLOR hotpink]Change sort[/COLOR]',
                      _runplugin('gsearch.change_sort', keyword=keyword)),
        )
        _row(
            u'[COLOR hotpink]Save search "{0}" as keyword[/COLOR]'.format(keyword),
            '', 'gsearch.save_keyword', basics.cum_image('cum-search.png'),
            keyword=keyword, Folder=False, list_avail=False,
        )
        _row(
            '[COLOR white]Choose sites to search[/COLOR]',
            '', 'gsearch.choose_sites', basics.cum_image('cum-search.png'),
            Folder=False, list_avail=False,
        )
        _row(status, '', 'gsearch.noop', basics.cum_image('cum-search.png'),
             Folder=False, list_avail=False)

        save_query_cm = ('[COLOR hotpink]Save this search as keyword[/COLOR]',
                         _runplugin('gsearch.save_keyword', keyword=keyword))
        for item in results:
            title = item.get('name') or ''
            raw_title = clean_video_title(title)
            add_kw_cm = ('[COLOR hotpink]Add to keywords[/COLOR]',
                         _runplugin('gsearch.save_keyword',
                                    keyword=keyword_from_result_title(raw_title) or keyword))
            try:
                basics.addDownLink(
                    title,
                    item.get('url') or '',
                    item.get('mode'),
                    item.get('iconimage'),
                    desc=item.get('desc') or '',
                    stream=item.get('stream'),
                    contextm=[add_kw_cm, save_query_cm],
                    fanart=item.get('fanart'),
                    duration=item.get('duration') or '',
                    quality=item.get('quality') or '',
                )
            except Exception as exc:
                _kodilog(u'video row failed: {0}'.format(exc), xbmc.LOGERROR)
    finally:
        _finish_directory()


@url_dispatcher.register()
def change_sort(keyword=None):
    options = ['Relevance', 'Newest', 'Most viewed', 'Top rated']
    keys = ['relevance', 'date', 'views', 'rating']
    choice = utils.dialog.select('Sort combined results', options)
    if choice < 0:
        return
    _persist_sort(keys[choice])
    mode = _current_mode()
    if mode not in ('main.global_search', 'main.skin_search', 'main.search'):
        mode = 'main.global_search'
    path = '{0}?mode={1}&keyword={2}'.format(
        _plugin_root(), mode, urllib_parse.quote_plus(keyword or ''))
    xbmc.executebuiltin('Container.Update({0},replace)'.format(path))


@url_dispatcher.register()
def save_keyword(keyword=None, name=None):
    kw = (keyword or name or '').strip()
    kw = strip_colors(kw)
    if not kw:
        utils.notify('Keywords', 'Nothing to save')
        return
    from resources.lib.utils import addKeyword, check_if_keyword_exists
    if check_if_keyword_exists(kw):
        utils.notify('Keywords', u'Already saved: {0}'.format(kw))
        return
    addKeyword(kw)
    utils.notify('Keywords', u'Added: {0}'.format(kw))


def _write_search_status(text):
    try:
        if basics.addon.getSetting('global_search_sites_status') != text:
            basics.addon.setSetting('global_search_sites_status', text)
    except Exception:
        pass


@url_dispatcher.register()
def choose_sites():
    """Checkbox list of sites global search may use. Default is every site on."""
    from resources.lib import precache
    from resources.lib import siteflags
    from resources.lib import siteflags_lib
    try:
        precache.ensure_sites_loaded()
    except Exception as exc:
        _kodilog(u'load sites for chooser: {0}'.format(exc), xbmc.LOGERROR)
    sites = siteflags.catalog()
    if not sites:
        utils.notify('Cumination', 'No sites are loaded yet')
        return
    state = siteflags.get_state()
    current = [s.name for s in sites if siteflags_lib.is_search_site(s.name, state)]
    choice = siteflags._multiselect('Global search sites (unchecked are skipped)', sites, current)
    if choice is None:
        return
    selected = [sites[i].name for i in choice if 0 <= i < len(sites)]
    state['search_disabled'] = siteflags_lib.disabled_from_selection(
        siteflags.catalog_names(), selected)
    siteflags.save_state(state)
    text = siteflags_lib.search_summary(siteflags.catalog_names(), state)
    _write_search_status(text)
    utils.notify('Cumination', text)


@url_dispatcher.register()
def reset_sites():
    """Turn every global-search checkbox back on."""
    from resources.lib import siteflags
    from resources.lib import siteflags_lib
    state = siteflags.get_state()
    state['search_disabled'] = []
    siteflags.save_state(state)
    try:
        names = siteflags.catalog_names()
    except Exception:
        names = []
    text = siteflags_lib.search_summary(names, state) if names else 'All sites selected'
    _write_search_status(text)
    utils.notify('Cumination', text)


@url_dispatcher.register()
def noop():
    return
