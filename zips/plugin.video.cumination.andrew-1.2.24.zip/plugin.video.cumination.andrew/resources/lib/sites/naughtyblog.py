'''
    Cumination
    Copyright (C) 2023 Team Cumination

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import os
import re
import sys
import time
import xbmc
from six.moves import urllib_parse
from resources.lib import basics, starart, utils
from resources.lib.adultsite import AdultSite

site = AdultSite('naughtyblog', '[COLOR hotpink]NaughtyBlog[/COLOR]  [COLOR red][Debrid only][/COLOR]', 'https://www.naughtyblog.st/', 'naughtyblog.png', 'naughtyblog')


@site.register(default_mode=True)
def Main():
    site.add_dir('[COLOR hotpink]Categories[/COLOR]', site.url + 'categories/', 'Categories', site.img_cat)
    site.add_dir('[COLOR hotpink]Sites[/COLOR]', site.url + 'sites/?letter=', 'SitesABC', site.img_cat)
    site.add_dir('[COLOR hotpink]Popular pornstars[/COLOR]', site.url + 'popular-pornstars/', 'PornstarsAndSites', site.img_cat)
    site.add_dir('[COLOR hotpink]Movies[/COLOR]', site.url + 'category/movies/', 'List', site.img_cat)
    site.add_dir('[COLOR hotpink]Search[/COLOR]', site.url + '?s=', 'Search', site.img_search)
    List(site.url + 'category/clips/')
    utils.eod()


@site.register()
def List(url):
    listhtml = utils.getHtml(url, '')
    match = re.compile(r'<div id="post-(.*?)>\s+<a href="([^"]+)".*?title="([^"]+)".*?<img.*?src="([^"]+)".*?<strong>([^<]+)<.*?<em>([^<]+)<.*?<p>([^<]+)<', re.DOTALL | re.IGNORECASE).findall(listhtml)
    if not match:
        return
    for tags, videopage, name, img, title, release, plot in match:
        name = utils.cleantext(name)
        plot = "{}\n{}\n{}".format(utils.cleantext(title), utils.cleantext(release), utils.cleantext(plot))
        if any(tag in tags for tag in ['siterip', 'onlyfans-leak']):
            continue

        contextmenu = []
        contexturl = (utils.addon_sys + "?mode=naughtyblog.Lookupinfo&url=" + urllib_parse.quote_plus(videopage))
        contextmenu.append(('[COLOR deeppink]Lookup info[/COLOR]', 'RunPlugin(' + contexturl + ')'))

        if _is_collection(tags, videopage, name):
            # Pornstar "Mega Collection" posts hold hundreds of videos, not one:
            # open them as a folder listing each video instead of trying to play.
            site.add_dir(name, videopage, 'Collection', img, contextm=contextmenu, desc=plot)
            continue
        site.add_download_link(name, videopage, 'Playvid', img, plot, contextm=contextmenu)

    np = re.compile(r'aria-label="Next Page"\s*href="([^"]+)"', re.DOTALL | re.IGNORECASE).search(listhtml)
    if np:
        page_number = np.group(1).split('/')[-2]
        site.add_dir('Next Page (' + page_number + ')', np.group(1), 'List', site.img_next)
    utils.eod()


COLLECTION_TAGS = ('pornstar-collections', 'megapack')
VIDEO_EXT = ('.mp4', '.mkv', '.avi', '.wmv', '.mov', '.m4v', '.flv', '.webm', '.ts', '.mpg', '.mpeg')


def _is_collection(tags, url, name):
    if any(t in tags for t in COLLECTION_TAGS):
        return True
    return bool(re.search(r'(?:pornstar|mega)[ -]collection', url + ' ' + name, re.IGNORECASE))


def _collection_videos(sitehtml):
    """Return an ordered list of (filename, [links]) for every video file in a
    collection post. The real file list sits in the hidden 'Show links' block
    (div id="hiddenlinks"); the visible div id="download" only holds previews."""
    blocks = re.compile(r'id="hiddenlinks"[^>]*>(.*?)</div>', re.DOTALL | re.IGNORECASE).findall(sitehtml)
    if not blocks:
        blocks = re.compile(r'id="download(?:hidden)?"[^>]*>(.*?)</div>\s*(?:</div>)?', re.DOTALL | re.IGNORECASE).findall(sitehtml)
    videos = {}
    order = []
    for block in blocks:
        for link in HREF_RE.findall(block):
            fname = urllib_parse.unquote(link.rstrip('/').split('/')[-1])
            if fname.lower().endswith('.html'):
                fname = fname[:-5]
            if not fname.lower().endswith(VIDEO_EXT):
                continue  # skips preview .rar archives, galleries, etc.
            if fname not in videos:
                videos[fname] = []
                order.append(fname)
            if link not in videos[fname]:
                videos[fname].append(link)
    return [(f, videos[f]) for f in order]


def _pretty_name(fname):
    name = re.sub(r'\.(?:' + '|'.join(e[1:] for e in VIDEO_EXT) + r')$', '', fname, flags=re.IGNORECASE)
    name = re.sub(r'^[A-Za-z0-9]+Collection_', '', name)  # "CherryKissCollection_" prefix
    name = re.sub(r'-NAUGHTYBLOG$', '', name, flags=re.IGNORECASE)
    quality = ''
    q = re.search(r'\b(2160p|1080p|720p|576p|480p|360p|4K|UHD|SD)\b', name, re.IGNORECASE)
    if q:
        quality = q.group(1)
        name = name[:q.start()] + name[q.end():]  # Kodi shows quality as its own badge
    name = name.replace('.', ' ').replace('_', ' ')
    return name.strip(), quality


def _hoster(link):
    host = urllib_parse.urlparse(link).netloc.lower()
    return host[4:] if host.startswith('www.') else host


# Keep2Share family. Real-Debrid lists these hosts, but its own API answers
# "supported": 0 for k2s links (checked Nov 2026), and AllDebrid has no K2S at
# all, so a Rapidgator copy is always tried first.
K2S_RE = re.compile(r'https?://(?:www\.)?(?:k2s|keep2share|keep2s|k2share)\.(?:cc|com)/file/([0-9a-zA-Z]+)(?:/([^?#"\'<>\s]*))?', re.IGNORECASE)
K2S_FAMILY = ('k2s.cc', 'keep2share.cc', 'keep2share.com', 'keep2s.cc', 'k2share.cc', 'tezfiles.com', 'fboom.me', 'fileboom.me')
RG_FAMILY = ('rg.to', 'rapidgator.net', 'rapidgator.asia')
HREF_RE = re.compile(r'''href=["'](https?://[^"']+)["']''', re.IGNORECASE)


def _normalize_link(link):
    """k2s.cc / keep2s.cc / k2share.cc -> https://keep2share.cc/file/<id>/<name>.
    keep2share.cc is the one domain every debrid service that carries K2S lists
    (LinkSnappy only knows keep2share.cc; Real-Debrid matches both)."""
    link = link.strip().replace('&amp;', '&')
    m = K2S_RE.match(link)
    if m:
        return 'https://keep2share.cc/file/{0}{1}'.format(m.group(1), '/' + m.group(2) if m.group(2) else '')
    return link


def _is_k2s(link):
    return _hoster(link) in K2S_FAMILY


def _is_rg(link):
    return _hoster(link) in RG_FAMILY


def _link_label(link):
    if _is_rg(link):
        return 'Rapidgator'
    if _is_k2s(link):
        return 'Keep2Share'
    return _hoster(link)


def _quality_of(text):
    q = re.search(r'\b(2160p|1080p|720p|576p|480p|360p|4K|UHD|SD)\b', text or '', re.IGNORECASE)
    return q.group(1).upper().replace('P', 'p') if q else ''


def _link_order(label):
    # Rapidgator first, then other hosts, Keep2Share last.
    return (0 if label.startswith('Rapidgator') else 2 if 'Keep2Share' in label else 1, label)


def _scene_key(fname):
    """('Tushy 24.06.23 Cherry Kiss', 'tushy.24.06.23.cherry', '1080p') for a
    collection file such as CherryKissCollection_Tushy.24.06.23.Cherry.Kiss.XXX.1080p.mp4,
    or None when the name has no site + date/episode to search on."""
    base = urllib_parse.unquote(fname)
    base = re.sub(r'\.html$', '', base, flags=re.IGNORECASE)
    base = re.sub(r'\.(?:' + '|'.join(e[1:] for e in VIDEO_EXT) + r')$', '', base, flags=re.IGNORECASE)
    base = re.sub(r'^[A-Za-z0-9]+Collection_', '', base)
    base = re.sub(r'-NAUGHTYBLOG$', '', base, flags=re.IGNORECASE)
    quality = _quality_of(base.replace('.', ' '))
    m = re.match(r'^([A-Za-z0-9-]+)\.((?:\d{2}\.\d{2}\.\d{2})|(?:E\d+))\.([A-Za-z0-9]+)(?:\.([A-Za-z0-9]+))?', base, re.IGNORECASE)
    if not m:
        return None
    sitename, date, first, second = m.group(1), m.group(2), m.group(3), m.group(4) or ''
    if second.upper() in ('XXX', 'AND') or re.match(r'^(?:\d{3,4}p|SD|4K)$', second, re.IGNORECASE):
        second = ''
    query = ' '.join(x for x in (sitename, date, first, second) if x)
    key = '{0}.{1}.{2}'.format(sitename, date, first).lower()
    return query, key, quality


def _fetch(url, tries=2):
    """Uncached fetch with one retry: naughtyblog.st drops TLS connections now
    and then, and a cached empty page would hide the copy for hours."""
    for n in range(tries):
        started = time.time()
        try:
            html = utils._getHtml(url, site.url, error='raise')
            if html:
                return html
        except Exception as e:
            utils.kodilog('NaughtyBlog fetch {0} failed ({1}/{2}): {3}'.format(url, n + 1, tries, e))
        if time.time() - started > 10:
            break  # a slow timeout: don't make the user wait twice
        time.sleep(1)
    return ''


def _rg_cache_path():
    return os.path.join(basics.profileDir, 'nb_rg_copies.json')


def _rg_cache(key, value=None):
    """Remember Rapidgator copies that were found so the next play is instant."""
    import json
    path = _rg_cache_path()
    try:
        with open(path, 'r') as fh:
            data = json.load(fh)
    except Exception:
        data = {}
    if value is None:
        return data.get(key)
    data[key] = value
    try:
        if not os.path.isdir(os.path.dirname(path)):
            os.makedirs(os.path.dirname(path))
        with open(path, 'w') as fh:
            json.dump(data, fh)
    except Exception as e:
        utils.kodilog('NaughtyBlog rg cache write failed: {0}'.format(e))
    return value


def _find_rapidgator_copy(fname, progress=None):
    """Search NaughtyBlog for the single-scene post of a collection file and
    return [(label, rg_link)] for its Rapidgator links, same quality first."""
    sk = _scene_key(fname)
    if not sk:
        return []
    query, key, quality = sk
    cached = _rg_cache(fname)
    if cached:
        return [tuple(x) for x in cached]
    if progress:
        progress.update(40, "[CR]Looking for a Rapidgator copy[CR]{0}".format(query))
    html = _fetch(site.url + '?s=' + urllib_parse.quote_plus(query))
    posts = []
    for tags, post in re.compile(r'''<div id="post-(.*?)>\s+<a href=["']([^"']+)["']''', re.DOTALL | re.IGNORECASE).findall(html or ''):
        post = post.replace('&#038;', '&').replace('&amp;', '&').split('?')[0]
        if _is_collection(tags, post, '') or post in posts:
            continue
        posts.append(post)
    found = {}
    for n, post in enumerate(posts[:4]):
        if progress:
            progress.update(50 + n * 10, "[CR]Checking {0}[CR]".format(post.rstrip('/').split('/')[-1]))
        page = _fetch(post)
        for link in HREF_RE.findall(page or ''):
            if not _is_rg(link):
                continue
            rgname = urllib_parse.unquote(link.rstrip('/').split('/')[-1]).lower()
            if key not in rgname:
                continue
            q = _quality_of(rgname.replace('.', ' ')) or '?'
            found.setdefault('Rapidgator {0} (single-scene post)'.format(q), link)
        if found:
            break
    result = sorted(found.items(), key=lambda kv: (0 if quality and quality.lower() in kv[0].lower() else 1, kv[0]))
    if result:
        _rg_cache(fname, [list(x) for x in result])
    return result


def _resolve_and_play(vp, link):
    """Resolve one hoster link with ResolveURL (debrid). Returns True when it played."""
    hmf = vp.resolveurl.HostedMediaFile(link, title=_link_label(link))
    if not hmf.valid_url():
        return False
    vp.progress.update(80, "[CR]Resolving {0} via your debrid account[CR]".format(_link_label(link)))
    try:
        stream = hmf.resolve()
    except Exception as e:
        utils.kodilog('NaughtyBlog resolve error {0}: {1}'.format(link, e))
        stream = False
    if not stream:
        utils.kodilog('NaughtyBlog: could not resolve {0}'.format(link))
        return False
    vp.progress.close()
    utils.playvid(stream, vp.name, vp.download, IA_check=getattr(vp, 'IA_check', 'check'))
    return True


K2S_FAIL_MSG = ('Keep2Share did not resolve. Real-Debrid lists K2S but currently refuses it, '
                'AllDebrid has no K2S, and no Rapidgator copy was found for this video.')


def _play_choices(vp, choices, fname=''):
    """choices: {label: link}. Rapidgator first; K2S-only lists get a Rapidgator
    copy looked up on NaughtyBlog; a failed link falls through to Rapidgator ones."""
    bypass = utils.addon.getSetting('filter_hosters')
    bypasslist = [x for x in bypass.split(';') if x] if bypass else []
    choices = dict((label, _normalize_link(link)) for label, link in choices.items()
                   if not any(x.lower() in link.lower() for x in bypasslist))
    has_rg = any(_is_rg(link) for link in choices.values())
    if not has_rg and fname and any(_is_k2s(link) for link in choices.values()) \
            and utils.addon.getSetting('nb_rg_fallback') != 'false':
        rg = _find_rapidgator_copy(fname, vp.progress)
        for label, link in rg:
            choices[label] = link
        want = (_scene_key(fname) or ('', '', ''))[2]
        if rg and want and want.lower() in rg[0][0].lower():
            # Same quality on Rapidgator: play it straight away.
            if _resolve_and_play(vp, rg[0][1]):
                return
    valid = dict((label, link) for label, link in choices.items()
                 if vp.resolveurl.HostedMediaFile(link).valid_url())
    if not valid:
        vp.progress.close()
        if choices and all(_is_k2s(link) for link in choices.values()):
            utils.notify('NaughtyBlog', 'Keep2Share only, and none of your debrid services accept K2S. No Rapidgator copy found.', 8000)
        else:
            utils.notify('NaughtyBlog', 'Only K2S/Rapidgator-type links here: set up a debrid account in ResolveURL (Real-Debrid, AllDebrid, Premiumize...)')
        return
    picked = utils.selector('Select link', valid, sort_by=_link_order)
    if not picked:
        vp.progress.close()
        return
    order = [picked] + [link for label, link in sorted(valid.items(), key=lambda kv: _link_order(kv[0]))
                        if link != picked and _is_rg(link)]
    for link in order:
        if _resolve_and_play(vp, link):
            return
    vp.progress.close()
    if _is_k2s(picked):
        utils.notify('NaughtyBlog', K2S_FAIL_MSG, 10000)
    else:
        utils.notify('NaughtyBlog', 'Could not resolve {0} with your debrid account (file removed or host down?)'.format(_link_label(picked)), 8000)


@site.register()
def Collection(url):
    sitehtml = utils.getHtml(url, site.url)
    img = ''
    m = re.search(r'class="post-content-single[^"]*">.*?<img[^>]+src="([^"]+)"', sitehtml, re.DOTALL | re.IGNORECASE)
    if m:
        img = m.group(1)
    info = re.search(r'<em>([^<]*Videos[^<]*)</em>', sitehtml, re.IGNORECASE)
    info = utils.cleantext(info.group(1)) if info else ''
    videos = _collection_videos(sitehtml)
    if not videos:
        utils.notify('NaughtyBlog', 'No videos found in this collection')
        return
    for fname, links in videos:
        name, quality = _pretty_name(fname)
        plot = "{}\n{}\n{}".format(name, fname, info)
        site.add_download_link(name, '|'.join(links), 'PlayLink', img, plot, quality=quality)
    utils.eod()


def _fname_of(link):
    tail = urllib_parse.unquote(link.rstrip('/').split('/')[-1])
    if tail.lower().endswith('.html'):
        tail = tail[:-5]
    return tail if tail.lower().endswith(VIDEO_EXT) else ''


@site.register()
def PlayLink(url, name, download=None):
    vp = utils.VideoPlayer(name, download)
    vp.progress.update(25, "[CR]Checking links[CR]")
    links = [x for x in url.split('|') if x]
    fname = next((f for f in (_fname_of(x) for x in links) if f), '')
    choices = {}
    for link in links:
        label = _link_label(link)
        q = _quality_of(_fname_of(link).replace('.', ' '))
        if q:
            label = '{0} {1}'.format(label, q)
        while label in choices:
            label += ' '
        choices[label] = link
    _play_choices(vp, choices, fname)


@site.register()
def Playvid(url, name, download=None):
    vp = utils.VideoPlayer(name, download)
    vp.progress.update(25, "[CR]Loading video page[CR]")
    sitehtml = utils.getHtml(url, site.url)
    if 'id="hiddenlinks"' in sitehtml and _is_collection('', url, name):
        # Old favourite / widget entry pointing at a collection: let the user pick a video.
        videos = _collection_videos(sitehtml)
        choices = {}
        for fname, links in videos:
            choices[_pretty_name(fname)[0]] = links
        vp.progress.close()
        picked = utils.selector('Select video', choices)
        if picked:
            PlayLink('|'.join(picked), name, download)
        return
    downloads = re.compile('id="download">(.*?)</div>', re.DOTALL | re.IGNORECASE).findall(sitehtml)
    downloads = downloads[0] if downloads else ''
    sources = re.compile(r'''href=["']([^"']+)["']\s+?title=["']([^\s"']+)\s''', re.DOTALL | re.IGNORECASE).findall(downloads)
    choices = {}
    fname = ''
    for link, hoster in sources:
        f = _fname_of(link)
        fname = fname or f
        label = "{0} {1}".format('Rapidgator' if _is_rg(link) else 'Keep2Share' if _is_k2s(link) else hoster,
                                 f or link.rstrip('/').split('/')[-1])
        choices[label] = link
    if not choices:
        vp.progress.close()
        utils.notify('NaughtyBlog', 'No download links found on this post')
        return
    _play_choices(vp, choices, fname)


@site.register()
def Search(url, keyword=None):
    searchUrl = url
    if not keyword:
        site.search_dir(searchUrl, 'Search')
    else:
        title = keyword.replace(' ', '+')
        searchUrl = searchUrl + title
        List(searchUrl)


@site.register()
def Categories(url):
    listhtml = utils.getHtml(url)
    match = re.compile(r'''href=["']([^"']+)["'][^>]*>([^<]+)<span class=["']pocetvideicat["']>([^<]+)<''', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for catpage, name, videos in match:
        name = utils.cleantext(name.strip())
        name = "{0} - {1} videos".format(name, videos.strip())
        site.add_dir(name, catpage, 'List', '')
    utils.eod()


@site.register()
def SitesABC(url):
    letters = ['#', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    for letter in letters:
        sitepage = '{}{}'.format(url, letter.lower() if letter != '#' else '0')
        site.add_dir(letter, sitepage, 'PornstarsAndSites', '')
    utils.eod()


@site.register()
def PornstarsAndSites(url):
    listhtml = utils.getHtml(url)
    # naughtyblog.st writes these lists with single-quoted attributes (href='/pornstar/x'), so accept either quote
    match = re.compile(r'''<li><a href=["']([^"']+)["'][^>]*>([^<]+)<span[^>]*>([^<]+)<''', re.DOTALL | re.IGNORECASE).findall(listhtml)
    star_art = _star_art_enabled()
    missing = 0
    for listpage, name, videos in match:
        name = utils.cleantext(name.strip())
        label = "{0} - {1} videos".format(name, videos.strip())
        if listpage.startswith('/'):
            listpage = site.url + listpage[1:]
        art = None
        if star_art:
            slug = starart.slug_from_url(listpage)
            if slug:
                art = starart.cached_art(_star_cache_dir(), slug)
                if art is None:
                    missing += 1
        if art:
            site.add_dir(label, listpage, 'List', art.get('poster') or '', art=art)
        else:
            site.add_dir(label, listpage, 'List', '')
    np = re.compile(r'''class=["']next page-numbers["'] href=["']([^"']+)["']>Next''', re.DOTALL | re.IGNORECASE).search(listhtml)
    if np:
        page_number = np.group(1).split('/')[-2]
        site.add_dir('Next Page (' + page_number + ')', np.group(1), 'PornstarsAndSites', site.img_next)
    utils.eod()
    if missing and not starart_busy():
        # Build the missing posters/landscapes/fanart in a separate background call
        xbmc.executebuiltin('RunPlugin({0}?mode=naughtyblog.BuildStarArt&url={1})'.format(
            sys.argv[0], urllib_parse.quote_plus(url)))


def _star_art_enabled():
    try:
        return utils.addon.getSetting('nb_starart') != 'false'
    except Exception:
        return True


def _star_cache_dir():
    return os.path.join(basics.profileDir, 'starart')


def starart_busy():
    path = os.path.join(_star_cache_dir(), '.build.lock')
    try:
        return time.time() - os.path.getmtime(path) < starart.LOCK_STALE_SECS
    except OSError:
        return False


def _star_entries(url):
    html = utils.getHtml(url)
    entries = []
    for listpage, name in re.findall(r'''<li><a href=["']([^"']+)["'][^>]*>([^<]+)<span''', html, re.IGNORECASE):
        if listpage.startswith('/'):
            listpage = site.url + listpage[1:]
        slug = starart.slug_from_url(listpage)
        if slug:
            entries.append((slug, utils.cleantext(name.strip()), listpage))
    return entries


@site.register()
def BuildStarArt(url=None, force=False):
    """Background job: poster/landscape/fanart for every pornstar on the list page."""
    if not url or url == 'None':
        url = site.url + 'popular-pornstars/'
    force = force in (True, 'True', 'true', '1')
    cache_dir = _star_cache_dir()
    if not starart.acquire_lock(cache_dir):
        if force:
            utils.notify('NaughtyBlog', 'Pornstar art is already being built')
        return
    try:
        entries = _star_entries(url)
        todo = [e for e in entries if force or starart.needs_build(cache_dir, e[0])]
        if not todo:
            if force:
                utils.notify('NaughtyBlog', 'Pornstar art is up to date ({0})'.format(len(entries)))
            return
        utils.notify('NaughtyBlog', 'Building pornstar art: {0} in the background'.format(len(todo)), duration=4000)
        api_key = (utils.addon.getSetting('tpdb_api_key') or '').strip()
        monitor = xbmc.Monitor()
        step = 60 if len(todo) > 90 else max(10, len(todo) // 2)

        def progress(n, total):
            if n % step == 0 and n < total:
                _refresh_if_showing(url)

        starart.build_many(cache_dir, todo, api_key=api_key, workers=4,
                           on_progress=progress, should_stop=monitor.abortRequested)
        utils.notify('NaughtyBlog', 'Pornstar art ready ({0})'.format(len(todo)), duration=3000)
    finally:
        starart.release_lock(cache_dir)
    _refresh_if_showing(url)


def _refresh_if_showing(url):
    path = xbmc.getInfoLabel('Container.FolderPath') or ''
    if 'PornstarsAndSites' in path and urllib_parse.quote_plus(url) in path:
        xbmc.executebuiltin('Container.Refresh')


@site.register()
def Lookupinfo(url):
    lookup_list = [
        ("Cat", r'/((?:category|tag)/[^"]+)"\s*?rel="(?:category )*?tag">([^<]+)<', ''),
        ("Site", r'(site/[^"]+)"\s*?rel="tag">([^<]+)', ''),
        ("Model", r'/(pornstar/[^"]+)"\s*?rel="tag">([^<]+)<', '')
    ]

    lookupinfo = utils.LookupInfo(site.url, url, 'naughtyblog.List', lookup_list)
    lookupinfo.getinfo()
