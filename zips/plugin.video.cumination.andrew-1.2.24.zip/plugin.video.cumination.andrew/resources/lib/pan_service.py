# -*- coding: utf-8 -*-
"""Background Precache runner.

Portrait pan used to live here: it polled the focused list item several times
a second and downloaded/cropped thumbs into Window(Home) fanart properties.
That work is gone. This loop only continues a Precache job the user started,
and it waits while idle so it does not compete with directory listings.
"""
from __future__ import absolute_import

HOME_WINDOW_ID = 10000
_PAN_KEYS = (
    'PanFanart', 'FanartMode', 'FanartAlignY', 'FanartAspect',
    'FanartPanDuration', 'FanartSource',
)


def _clear_pan_properties():
    try:
        from kodi_six import xbmcgui
        home = xbmcgui.Window(HOME_WINDOW_ID)
        for key in _PAN_KEYS:
            home.setProperty('Cumination.' + key, '')
    except Exception:
        pass


def _precache_is_running():
    """True only when a Precache job is actually in progress.

    Reading the job file here avoids importing the precache stack (and Pillow)
    on every idle wake. Kodi startup no longer loads that code until a job exists.
    """
    try:
        import json
        import os
        from resources.lib import basics
        path = os.path.join(basics.profileDir, 'precache.json')
        if not os.path.isfile(path):
            return False
        with open(path, 'r') as handle:
            data = json.load(handle)
        return isinstance(data, dict) and data.get('status') == 'running'
    except Exception:
        return False


def make_monitor():
    """Monitor that only records a settings change.

    Kodi invokes onSettingsChanged while it holds the addon settings lock.
    getSetting or setSetting on that stack deadlocks Kodi, so the plugin
    never opens. The service loop applies the preset after the callback
    returns.
    """
    from kodi_six import xbmc

    class _Monitor(xbmc.Monitor):
        def __init__(self):
            xbmc.Monitor.__init__(self)
            self.settings_dirty = False

        def onSettingsChanged(self):
            self.settings_dirty = True

    return _Monitor()


def apply_pending_preset(monitor):
    """Apply a speed preset if a settings callback has fired."""
    if not getattr(monitor, 'settings_dirty', False):
        return False
    monitor.settings_dirty = False
    try:
        from resources.lib import basics
        from resources.lib import speedmode
        speedmode.on_settings_changed(basics.addon)
    except Exception:
        pass
    return True


def run():
    monitor = make_monitor()
    try:
        from resources.lib import basics
        from resources.lib import speedmode
        speedmode.capture(basics.addon)
    except Exception:
        pass
    _clear_pan_properties()
    while not monitor.abortRequested():
        pending = apply_pending_preset(monitor)
        busy = False
        try:
            if _precache_is_running():
                from resources.lib import precache
                busy = bool(precache.service_tick(monitor, budget_sec=1.0))
        except Exception:
            busy = False
        # A preset has to land quickly, but never inside the settings callback.
        if pending or monitor.settings_dirty:
            monitor.waitForAbort(0.2)
        else:
            monitor.waitForAbort(2.0 if busy else 8.0)
