# -*- coding: utf-8 -*-
"""Poster / landscape / fanart for NaughtyBlog "Popular pornstars" entries.

Sources, in order:
  headshot  ThePornDB performer image (only when an API key is set in settings),
            otherwise the IAFD performer headshot (no key, 340x400 portrait).
  scene     the newest video thumbnail on the star's NaughtyBlog page (landscape).

Built art is written once to addon_data/.../starart/<slug>/ and reused on every
later open, so listings only do a few file lookups. Missing stars are built by a
background RunPlugin job (naughtyblog.BuildStarArt), never inside the listing.
"""
from __future__ import absolute_import

import hashlib
import io
import json
import os
import re
import threading
import time

try:
    from urllib.parse import quote_plus
except ImportError:  # Python 2
    from urllib import quote_plus

ART_VERSION = 1
RETRY_SECS = 7 * 24 * 3600
LOCK_STALE_SECS = 20 * 60
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36'
POSTER = (600, 900)
LANDSCAPE = (960, 540)
FANART = (1280, 720)
KINDS = ('poster', 'landscape', 'fanart')


def slug_from_url(url):
    m = re.search(r'/pornstar/([^/?#]+)', url or '')
    return m.group(1).lower() if m else None


def star_dir(cache_dir, slug):
    safe = re.sub(r'[^a-z0-9_-]', '_', slug.lower())[:80]
    return os.path.join(cache_dir, safe)


def _meta_path(cache_dir, slug):
    return os.path.join(star_dir(cache_dir, slug), 'meta.json')


def load_meta(cache_dir, slug):
    try:
        with open(_meta_path(cache_dir, slug)) as fh:
            return json.load(fh)
    except Exception:
        return None


def cached_art(cache_dir, slug):
    """Return a ListItem art dict for a built star, or None when not built yet."""
    meta = load_meta(cache_dir, slug)
    if not meta or meta.get('v') != ART_VERSION:
        return None
    d = star_dir(cache_dir, slug)
    files = meta.get('files') or {}
    art = {}
    for kind in KINDS:
        # Files carry a build stamp so Kodi's texture cache picks up a rebuilt image
        path = os.path.join(d, files.get(kind) or kind + '.jpg')
        if os.path.isfile(path):
            art[kind] = path
    if not art:
        return {} if not needs_build(cache_dir, slug, meta) else None
    poster = art.get('poster') or art.get('landscape')
    art['thumb'] = poster
    art['icon'] = poster
    if 'landscape' in art:
        art['banner'] = art['landscape']
    return art


def needs_build(cache_dir, slug, meta=None):
    meta = meta if meta is not None else load_meta(cache_dir, slug)
    if not meta or meta.get('v') != ART_VERSION:
        return True
    if meta.get('headshot'):
        return False
    # No headshot yet (source busy or no match): retry next day twice, then weekly.
    wait = 86400 if meta.get('tries', 1) < 3 else RETRY_SECS
    return time.time() - meta.get('t', 0) > wait


# ---------------------------------------------------------------- network

def _session():
    import requests
    s = requests.Session()
    s.headers.update({'User-Agent': UA})
    return s


def _get(session, url, timeout=15, tries=1, **kw):
    for attempt in range(tries):
        try:
            r = session.get(url, timeout=timeout, **kw)
            if r.status_code == 200:
                return r
            if r.status_code < 500:
                return None
        except Exception:
            pass
        if attempt + 1 < tries:
            time.sleep(2)
    return None


def _norm(name):
    return re.sub(r'[^a-z0-9]', '', (name or '').lower())


def iafd_headshot(session, names):
    """First IAFD female/male performer headshot whose name or AKA matches."""
    for name in names:
        if not name:
            continue
        r = _get(session, 'https://www.iafd.com/results.asp?searchtype=comprehensive&searchstring=' + quote_plus(name), timeout=25, tries=2)
        if r is None:
            continue
        rows = re.findall(r'<tr><td><a href="/person\.rme/[^"]+"><img[^>]+src="([^"]+)"[^>]*></a></td>\s*'
                          r'<td><a[^>]*>([^<]+)</a></td>\s*<td[^>]*>([^<]*)</td>', r.text)
        want = _norm(name)
        best = None
        for img, pname, aka in rows:
            if 'nophoto' in img.lower() or '/headshots/' not in img:
                continue
            if _norm(pname) == want or want in [_norm(a) for a in aka.split(',')]:
                best = img
                break
            if best is None:
                best = img
        if best:
            return best
    return None


def tpdb_headshot(session, api_key, names):
    if not api_key:
        return None
    for name in names:
        if not name:
            continue
        r = _get(session, 'https://api.theporndb.net/performers?q=' + quote_plus(name),
                 headers={'Authorization': 'Bearer ' + api_key, 'Accept': 'application/json'})
        if r is None:
            continue
        try:
            data = r.json().get('data') or []
        except Exception:
            continue
        want = _norm(name)
        data.sort(key=lambda p: 0 if _norm(p.get('name')) == want else 1)
        for p in data:
            posters = p.get('posters') or []
            img = (posters[0].get('url') if posters and isinstance(posters[0], dict) else None) or p.get('image')
            if img:
                return img
    return None


def scene_thumbs(html):
    """Video thumbnails on a NaughtyBlog pornstar page: newest regular posts
    first, the highlighted collection collage last."""
    normal, collections = [], []
    for cls, img in re.findall(r'<div id="post-\d+" class="([^"]*)"[^>]*>.*?<img[^>]*src="([^"]+)"', html or '', re.S):
        target = collections if ('highlighted-post' in cls or 'pornstar-collections' in cls) else normal
        if img not in normal and img not in collections:
            target.append(img)
    return normal + collections


def alt_names(html):
    """Name variants NaughtyBlog lists for the star (h1 and its Babepedia slug)."""
    names = []
    h1 = re.search(r'<h1>([^<]+)<span', html or '')
    if h1:
        names.append(h1.group(1).strip())
    bp = re.search(r'babepedia\.com/babe/([^"/]+)"', html or '')
    if bp:
        names.append(bp.group(1).replace('_', ' '))
    return names


# ---------------------------------------------------------------- images

def _pil():
    from resources.lib import andrew_art
    return andrew_art._import_pil()


def _open(session, url):
    Image = _pil()
    if Image is None or not url:
        return None
    r = _get(session, url, timeout=15, headers={'Referer': url})
    if r is None or len(r.content) < 512:
        return None
    try:
        im = Image.open(io.BytesIO(r.content))
        im.load()
        return im.convert('RGB')
    except Exception:
        return None


def _cover(im, size, top=False):
    Image = _pil()
    tw, th = size
    sw, sh = im.size
    scale = max(float(tw) / sw, float(th) / sh)
    nw, nh = max(tw, int(round(sw * scale))), max(th, int(round(sh * scale)))
    r = im.resize((nw, nh), Image.LANCZOS)
    left = (nw - tw) // 2
    y = 0 if top else (nh - th) // 2
    return r.crop((left, y, left + tw, y + th))


def _blur_fill(im, size):
    """Whole image centred on a blurred, darkened cover of itself."""
    from PIL import ImageFilter, ImageEnhance
    Image = _pil()
    tw, th = size
    bg = _cover(im, (tw // 4, th // 4)).filter(ImageFilter.GaussianBlur(6)).resize((tw, th), Image.BILINEAR)
    bg = ImageEnhance.Brightness(bg).enhance(0.45)
    sw, sh = im.size
    scale = min(float(tw) / sw, float(th) / sh)
    fg = im.resize((max(1, int(sw * scale)), max(1, int(sh * scale))), Image.LANCZOS)
    bg.paste(fg, ((tw - fg.size[0]) // 2, (th - fg.size[1]) // 2))
    return bg


def _save(im, path):
    d = os.path.dirname(path)
    if not os.path.isdir(d):
        try:
            os.makedirs(d)
        except OSError:
            pass
    tmp = '{0}.{1}.{2}.tmp'.format(path, os.getpid(), threading.current_thread().ident)
    im.save(tmp, 'JPEG', quality=85, optimize=True)
    try:
        os.replace(tmp, path)
    except OSError:
        try:
            os.remove(tmp)
        except OSError:
            pass


# ---------------------------------------------------------------- build

def build_one(cache_dir, slug, name, page_url, api_key='', session=None):
    """Fetch sources and write poster/landscape/fanart for one star. Returns meta."""
    session = session or _session()
    old = load_meta(cache_dir, slug) or {}
    r = _get(session, page_url, timeout=20, tries=2)
    html = r.text if r is not None else ''
    names = [name] + [n for n in alt_names(html) if _norm(n) != _norm(name)]
    head_url = tpdb_headshot(session, api_key, names) or iafd_headshot(session, names)
    head = _open(session, head_url) if head_url else None
    if head is None and old.get('headshot'):
        head_url = old['headshot']
        head = _open(session, head_url)
    scene = None
    scene_url = None
    for u in scene_thumbs(html)[:3]:
        scene = _open(session, u)
        if scene is not None:
            scene_url = u
            break
    d = star_dir(cache_dir, slug)
    stamp = '{0:x}'.format(int(time.time()))
    files = {}
    images = {}
    if head is not None:
        images['poster'] = _cover(head, POSTER, top=True)
        images['fanart'] = _blur_fill(head, FANART)
    elif scene is not None:
        images['poster'] = _blur_fill(scene, POSTER)
        images['fanart'] = _cover(scene, FANART)
    if scene is not None:
        images['landscape'] = _cover(scene, LANDSCAPE)
    elif head is not None:
        images['landscape'] = _blur_fill(head, LANDSCAPE)
    for kind, im in images.items():
        files[kind] = '{0}_{1}.jpg'.format(kind, stamp)
        _save(im, os.path.join(d, files[kind]))
    if images and os.path.isdir(d):
        keep = set(files.values())
        for fn in os.listdir(d):
            if fn.endswith('.jpg') and fn not in keep:
                try:
                    os.remove(os.path.join(d, fn))
                except OSError:
                    pass
    if not images:
        files = old.get('files') or {}
    meta = {'v': ART_VERSION, 't': time.time(), 'name': name, 'files': files,
            'headshot': head_url if head is not None else None,
            'scene': scene_url,
            'tries': 1 if head is not None else int(old.get('tries', 0)) + 1}
    if not os.path.isdir(d):
        os.makedirs(d)
    with open(_meta_path(cache_dir, slug), 'w') as fh:
        json.dump(meta, fh)
    return meta


def _lock_path(cache_dir):
    return os.path.join(cache_dir, '.build.lock')


def acquire_lock(cache_dir):
    if not os.path.isdir(cache_dir):
        os.makedirs(cache_dir)
    path = _lock_path(cache_dir)
    try:
        if os.path.isfile(path) and time.time() - os.path.getmtime(path) < LOCK_STALE_SECS:
            return False
    except OSError:
        pass
    with open(path, 'w') as fh:
        fh.write(str(os.getpid()))
    return True


def release_lock(cache_dir):
    try:
        os.remove(_lock_path(cache_dir))
    except OSError:
        pass


def build_many(cache_dir, entries, api_key='', workers=4, on_progress=None, should_stop=None):
    """entries: list of (slug, name, page_url). Builds them in parallel."""
    from concurrent.futures import ThreadPoolExecutor
    done = [0]
    lock = threading.Lock()
    local = threading.local()

    def work(entry):
        if should_stop and should_stop():
            return
        if not hasattr(local, 's'):
            local.s = _session()
        slug, name, url = entry
        try:
            build_one(cache_dir, slug, name, url, api_key, local.s)
        except Exception:
            pass
        with lock:
            done[0] += 1
            n = done[0]
        try:
            os.utime(_lock_path(cache_dir), None)  # keep our lock fresh while busy
        except OSError:
            pass
        if on_progress:
            on_progress(n, len(entries))

    with ThreadPoolExecutor(max_workers=workers) as ex:
        list(ex.map(work, entries))
    return done[0]


def entries_digest(entries):
    return hashlib.md5('|'.join(e[0] for e in entries).encode('utf-8')).hexdigest()
