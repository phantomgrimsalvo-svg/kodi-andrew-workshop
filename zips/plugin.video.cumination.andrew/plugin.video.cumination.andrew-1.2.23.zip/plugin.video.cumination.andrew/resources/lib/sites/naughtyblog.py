'''
    Cumination
    Copyright (C) 2023 Team Cumination

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import os
import re
import sys
import time
import xbmc
from six.moves import urllib_parse
from resources.lib import basics, starart, utils
from resources.lib.adultsite import AdultSite

site = AdultSite('naughtyblog', '[COLOR hotpink]NaughtyBlog[/COLOR]  [COLOR red][Debrid only][/COLOR]', 'https://www.naughtyblog.st/', 'naughtyblog.png', 'naughtyblog')


@site.register(default_mode=True)
def Main():
    site.add_dir('[COLOR hotpink]Categories[/COLOR]', site.url + 'categories/', 'Categories', site.img_cat)
    site.add_dir('[COLOR hotpink]Sites[/COLOR]', site.url + 'sites/?letter=', 'SitesABC', site.img_cat)
    site.add_dir('[COLOR hotpink]Popular pornstars[/COLOR]', site.url + 'popular-pornstars/', 'PornstarsAndSites', site.img_cat)
    site.add_dir('[COLOR hotpink]Movies[/COLOR]', site.url + 'category/movies/', 'List', site.img_cat)
    site.add_dir('[COLOR hotpink]Search[/COLOR]', site.url + '?s=', 'Search', site.img_search)
    List(site.url + 'category/clips/')
    utils.eod()


@site.register()
def List(url):
    listhtml = utils.getHtml(url, '')
    match = re.compile(r'<div id="post-(.*?)>\s+<a href="([^"]+)".*?title="([^"]+)".*?<img.*?src="([^"]+)".*?<strong>([^<]+)<.*?<em>([^<]+)<.*?<p>([^<]+)<', re.DOTALL | re.IGNORECASE).findall(listhtml)
    if not match:
        return
    for tags, videopage, name, img, title, release, plot in match:
        name = utils.cleantext(name)
        plot = "{}\n{}\n{}".format(utils.cleantext(title), utils.cleantext(release), utils.cleantext(plot))
        if any(tag in tags for tag in ['siterip', 'onlyfans-leak']):
            continue

        contextmenu = []
        contexturl = (utils.addon_sys + "?mode=naughtyblog.Lookupinfo&url=" + urllib_parse.quote_plus(videopage))
        contextmenu.append(('[COLOR deeppink]Lookup info[/COLOR]', 'RunPlugin(' + contexturl + ')'))

        if _is_collection(tags, videopage, name):
            # Pornstar "Mega Collection" posts hold hundreds of videos, not one:
            # open them as a folder listing each video instead of trying to play.
            site.add_dir(name, videopage, 'Collection', img, contextm=contextmenu, desc=plot)
            continue
        site.add_download_link(name, videopage, 'Playvid', img, plot, contextm=contextmenu)

    np = re.compile(r'aria-label="Next Page"\s*href="([^"]+)"', re.DOTALL | re.IGNORECASE).search(listhtml)
    if np:
        page_number = np.group(1).split('/')[-2]
        site.add_dir('Next Page (' + page_number + ')', np.group(1), 'List', site.img_next)
    utils.eod()


COLLECTION_TAGS = ('pornstar-collections', 'megapack')
VIDEO_EXT = ('.mp4', '.mkv', '.avi', '.wmv', '.mov', '.m4v', '.flv', '.webm', '.ts', '.mpg', '.mpeg')


def _is_collection(tags, url, name):
    if any(t in tags for t in COLLECTION_TAGS):
        return True
    return bool(re.search(r'(?:pornstar|mega)[ -]collection', url + ' ' + name, re.IGNORECASE))


def _collection_videos(sitehtml):
    """Return an ordered list of (filename, [links]) for every video file in a
    collection post. The real file list sits in the hidden 'Show links' block
    (div id="hiddenlinks"); the visible div id="download" only holds previews."""
    blocks = re.compile(r'id="hiddenlinks"[^>]*>(.*?)</div>', re.DOTALL | re.IGNORECASE).findall(sitehtml)
    if not blocks:
        blocks = re.compile(r'id="download(?:hidden)?"[^>]*>(.*?)</div>\s*(?:</div>)?', re.DOTALL | re.IGNORECASE).findall(sitehtml)
    videos = {}
    order = []
    for block in blocks:
        for link in re.compile(r'href="(https?://[^"]+)"', re.IGNORECASE).findall(block):
            fname = urllib_parse.unquote(link.rstrip('/').split('/')[-1])
            if fname.lower().endswith('.html'):
                fname = fname[:-5]
            if not fname.lower().endswith(VIDEO_EXT):
                continue  # skips preview .rar archives, galleries, etc.
            if fname not in videos:
                videos[fname] = []
                order.append(fname)
            if link not in videos[fname]:
                videos[fname].append(link)
    return [(f, videos[f]) for f in order]


def _pretty_name(fname):
    name = re.sub(r'\.(?:' + '|'.join(e[1:] for e in VIDEO_EXT) + r')$', '', fname, flags=re.IGNORECASE)
    name = re.sub(r'^[A-Za-z0-9]+Collection_', '', name)  # "CherryKissCollection_" prefix
    name = re.sub(r'-NAUGHTYBLOG$', '', name, flags=re.IGNORECASE)
    quality = ''
    q = re.search(r'\b(2160p|1080p|720p|576p|480p|360p|4K|UHD|SD)\b', name, re.IGNORECASE)
    if q:
        quality = q.group(1)
        name = name[:q.start()] + name[q.end():]  # Kodi shows quality as its own badge
    name = name.replace('.', ' ').replace('_', ' ')
    return name.strip(), quality


def _hoster(link):
    host = urllib_parse.urlparse(link).netloc.lower()
    return host[4:] if host.startswith('www.') else host


@site.register()
def Collection(url):
    sitehtml = utils.getHtml(url, site.url)
    img = ''
    m = re.search(r'class="post-content-single[^"]*">.*?<img[^>]+src="([^"]+)"', sitehtml, re.DOTALL | re.IGNORECASE)
    if m:
        img = m.group(1)
    info = re.search(r'<em>([^<]*Videos[^<]*)</em>', sitehtml, re.IGNORECASE)
    info = utils.cleantext(info.group(1)) if info else ''
    videos = _collection_videos(sitehtml)
    if not videos:
        utils.notify('NaughtyBlog', 'No videos found in this collection')
        return
    for fname, links in videos:
        name, quality = _pretty_name(fname)
        plot = "{}\n{}\n{}".format(name, fname, info)
        site.add_download_link(name, '|'.join(links), 'PlayLink', img, plot, quality=quality)
    utils.eod()


@site.register()
def PlayLink(url, name, download=None):
    vp = utils.VideoPlayer(name, download)
    vp.progress.update(25, "[CR]Checking links[CR]")
    links = {}
    bypasslist = [x for x in utils.addon.getSetting('filter_hosters').split(';') if x] if utils.addon.getSetting('filter_hosters') else []
    for link in url.split('|'):
        if any(x.lower() in link.lower() for x in bypasslist):
            continue
        if vp.resolveurl.HostedMediaFile(link).valid_url():
            links[_hoster(link)] = link
    videourl = utils.selector('Select link', links)
    if not videourl:
        vp.progress.close()
        if not links:
            utils.notify('NaughtyBlog', 'Only K2S/Rapidgator-type links here: set up a debrid account in ResolveURL (Real-Debrid, AllDebrid, Premiumize...)')
        return
    vp.play_from_link_to_resolve(videourl)


@site.register()
def Playvid(url, name, download=None):
    vp = utils.VideoPlayer(name, download)
    vp.progress.update(25, "[CR]Loading video page[CR]")
    sitehtml = utils.getHtml(url, site.url)
    if 'id="hiddenlinks"' in sitehtml and _is_collection('', url, name):
        # Old favourite / widget entry pointing at a collection: let the user pick a video.
        videos = _collection_videos(sitehtml)
        choices = {}
        for fname, links in videos:
            choices[_pretty_name(fname)[0]] = links
        vp.progress.close()
        picked = utils.selector('Select video', choices)
        if picked:
            PlayLink('|'.join(picked), name, download)
        return
    downloads = re.compile('id="download">(.*?)</div>', re.DOTALL | re.IGNORECASE).findall(sitehtml)[0]
    sources = re.compile(r'href="([^"]+)"\s+?title="([^\s]+)\s', re.DOTALL | re.IGNORECASE).findall(downloads)
    links = {}
    for link, hoster in sources:
        if utils.addon.getSetting('filter_hosters'):
            bypasslist = utils.addon.getSetting('filter_hosters').split(';')
            if any(x.lower() in link.lower() for x in bypasslist):
                continue
        if vp.resolveurl.HostedMediaFile(link).valid_url():
            linkparts = link.split('/')
            # quality = linkparts[-3] if link.endswith('.html') else linkparts[-2]
            hoster = "{0} {1}".format(hoster, linkparts[-1])
            links[hoster] = link
    if not links:
        vp.progress.close()
        utils.notify('NaughtyBlog', 'Only Rapidgator/K2S-type links here: set up a debrid account in ResolveURL (Real-Debrid, AllDebrid, Premiumize...)')
        return
    videourl = utils.selector('Select link', links)
    if not videourl:
        vp.progress.close()
        return
    vp.play_from_link_to_resolve(videourl)


@site.register()
def Search(url, keyword=None):
    searchUrl = url
    if not keyword:
        site.search_dir(searchUrl, 'Search')
    else:
        title = keyword.replace(' ', '+')
        searchUrl = searchUrl + title
        List(searchUrl)


@site.register()
def Categories(url):
    listhtml = utils.getHtml(url)
    match = re.compile(r'''href=["']([^"']+)["'][^>]*>([^<]+)<span class=["']pocetvideicat["']>([^<]+)<''', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for catpage, name, videos in match:
        name = utils.cleantext(name.strip())
        name = "{0} - {1} videos".format(name, videos.strip())
        site.add_dir(name, catpage, 'List', '')
    utils.eod()


@site.register()
def SitesABC(url):
    letters = ['#', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    for letter in letters:
        sitepage = '{}{}'.format(url, letter.lower() if letter != '#' else '0')
        site.add_dir(letter, sitepage, 'PornstarsAndSites', '')
    utils.eod()


@site.register()
def PornstarsAndSites(url):
    listhtml = utils.getHtml(url)
    # naughtyblog.st writes these lists with single-quoted attributes (href='/pornstar/x'), so accept either quote
    match = re.compile(r'''<li><a href=["']([^"']+)["'][^>]*>([^<]+)<span[^>]*>([^<]+)<''', re.DOTALL | re.IGNORECASE).findall(listhtml)
    star_art = _star_art_enabled()
    missing = 0
    for listpage, name, videos in match:
        name = utils.cleantext(name.strip())
        label = "{0} - {1} videos".format(name, videos.strip())
        if listpage.startswith('/'):
            listpage = site.url + listpage[1:]
        art = None
        if star_art:
            slug = starart.slug_from_url(listpage)
            if slug:
                art = starart.cached_art(_star_cache_dir(), slug)
                if art is None:
                    missing += 1
        if art:
            site.add_dir(label, listpage, 'List', art.get('poster') or '', art=art)
        else:
            site.add_dir(label, listpage, 'List', '')
    np = re.compile(r'''class=["']next page-numbers["'] href=["']([^"']+)["']>Next''', re.DOTALL | re.IGNORECASE).search(listhtml)
    if np:
        page_number = np.group(1).split('/')[-2]
        site.add_dir('Next Page (' + page_number + ')', np.group(1), 'PornstarsAndSites', site.img_next)
    utils.eod()
    if missing and not starart_busy():
        # Build the missing posters/landscapes/fanart in a separate background call
        xbmc.executebuiltin('RunPlugin({0}?mode=naughtyblog.BuildStarArt&url={1})'.format(
            sys.argv[0], urllib_parse.quote_plus(url)))


def _star_art_enabled():
    try:
        return utils.addon.getSetting('nb_starart') != 'false'
    except Exception:
        return True


def _star_cache_dir():
    return os.path.join(basics.profileDir, 'starart')


def starart_busy():
    path = os.path.join(_star_cache_dir(), '.build.lock')
    try:
        return time.time() - os.path.getmtime(path) < starart.LOCK_STALE_SECS
    except OSError:
        return False


def _star_entries(url):
    html = utils.getHtml(url)
    entries = []
    for listpage, name in re.findall(r'''<li><a href=["']([^"']+)["'][^>]*>([^<]+)<span''', html, re.IGNORECASE):
        if listpage.startswith('/'):
            listpage = site.url + listpage[1:]
        slug = starart.slug_from_url(listpage)
        if slug:
            entries.append((slug, utils.cleantext(name.strip()), listpage))
    return entries


@site.register()
def BuildStarArt(url=None, force=False):
    """Background job: poster/landscape/fanart for every pornstar on the list page."""
    if not url or url == 'None':
        url = site.url + 'popular-pornstars/'
    force = force in (True, 'True', 'true', '1')
    cache_dir = _star_cache_dir()
    if not starart.acquire_lock(cache_dir):
        if force:
            utils.notify('NaughtyBlog', 'Pornstar art is already being built')
        return
    try:
        entries = _star_entries(url)
        todo = [e for e in entries if force or starart.needs_build(cache_dir, e[0])]
        if not todo:
            if force:
                utils.notify('NaughtyBlog', 'Pornstar art is up to date ({0})'.format(len(entries)))
            return
        utils.notify('NaughtyBlog', 'Building pornstar art: {0} in the background'.format(len(todo)), duration=4000)
        api_key = (utils.addon.getSetting('tpdb_api_key') or '').strip()
        monitor = xbmc.Monitor()
        step = 60 if len(todo) > 90 else max(10, len(todo) // 2)

        def progress(n, total):
            if n % step == 0 and n < total:
                _refresh_if_showing(url)

        starart.build_many(cache_dir, todo, api_key=api_key, workers=4,
                           on_progress=progress, should_stop=monitor.abortRequested)
        utils.notify('NaughtyBlog', 'Pornstar art ready ({0})'.format(len(todo)), duration=3000)
    finally:
        starart.release_lock(cache_dir)
    _refresh_if_showing(url)


def _refresh_if_showing(url):
    path = xbmc.getInfoLabel('Container.FolderPath') or ''
    if 'PornstarsAndSites' in path and urllib_parse.quote_plus(url) in path:
        xbmc.executebuiltin('Container.Refresh')


@site.register()
def Lookupinfo(url):
    lookup_list = [
        ("Cat", r'/((?:category|tag)/[^"]+)"\s*?rel="(?:category )*?tag">([^<]+)<', ''),
        ("Site", r'(site/[^"]+)"\s*?rel="tag">([^<]+)', ''),
        ("Model", r'/(pornstar/[^"]+)"\s*?rel="tag">([^<]+)<', '')
    ]

    lookupinfo = utils.LookupInfo(site.url, url, 'naughtyblog.List', lookup_list)
    lookupinfo.getinfo()
