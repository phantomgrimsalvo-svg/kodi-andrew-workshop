'''Turn a Brain recs.json file into Hearth rows. Bad items are skipped.'''

from __future__ import annotations

KIND_SLUGS = {
    'for_you': 'recs',
    'shows': 'recs_shows',
    'movies': 'recs_movies',
    'gems': 'recs_gems',
    'twins': 'recs_twins',
    'mood': 'recs_mood',
    'because': 'recs_loved_0'
}

ALLOWED_KIND = set(KIND_SLUGS) | {'custom'}
ALLOWED_MEDIA = {'movie', 'show'}


def validate_recs(document):
    '''Return (clean, errors). Unknown fields are ignored. A bad schema fails the file.'''
    if not isinstance(document, dict):
        return None, ['Brain file was not an object']
    if int(document.get('schema_version') or 0) != 1:
        return None, ['schema_version must be 1']
    errors = []
    twins = []
    for twin in document.get('twins') or []:
        if not isinstance(twin, dict):
            errors.append('twin was not an object')
            continue
        name = str(twin.get('name') or '').strip()
        where = str(twin.get('where') or '').strip()
        why = str(twin.get('why') or '').strip()
        link = str(twin.get('link') or '').strip()
        if not (name and where and why and link.startswith('http')):
            errors.append('twin %s is missing name, where, why, or a link' % (name or 'item'))
            continue
        twins.append({'name': name, 'where': where, 'why': why, 'link': link})
    rows = []
    for row in document.get('rows') or []:
        if not isinstance(row, dict):
            errors.append('row was not an object')
            continue
        kind = str(row.get('kind') or 'custom').strip().lower()
        if kind not in ALLOWED_KIND:
            kind = 'custom'
        items = []
        for item in row.get('items') or []:
            if not isinstance(item, dict):
                errors.append('item was not an object')
                continue
            media = str(item.get('media_type') or '').strip().lower()
            if media == 'tv':
                media = 'show'
            title = str(item.get('title') or '').strip()
            tmdb = item.get('tmdb_id')
            if media not in ALLOWED_MEDIA or not title or tmdb in (None, ''):
                errors.append('skipped %s' % (title or 'item'))
                continue
            try:
                match = int(item.get('match') or 0)
            except (TypeError, ValueError):
                match = 0
            items.append({
                'media_type': media,
                'tmdb_id': str(tmdb),
                'imdb_id': item.get('imdb_id') or None,
                'title': title,
                'year': item.get('year'),
                'reason': str(item.get('reason') or ''),
                'match': max(0, min(100, match)),
                'source': str(item.get('source') or 'brain')
            })
        slug = _slug(row.get('slug'), kind, len(rows))
        rows.append({
            'slug': slug,
            'title': str(row.get('title') or slug),
            'kind': kind,
            'mood': str(row.get('mood') or ''),
            'because': str(row.get('because') or ''),
            'items': items
        })
    if len(rows) > 12:
        errors.append('only the first 12 rows are kept')
        rows = rows[:12]
    clean = {
        'schema_version': 1,
        'generated_at': str(document.get('generated_at') or ''),
        'based_on': str(document.get('based_on') or ''),
        'profile_md': str(document.get('profile_md') or ''),
        'insights': [str(item) for item in (document.get('insights') or []) if str(item).strip()],
        'twins': twins,
        'rows': rows
    }
    return clean, errors


def apply_recs(store, settings, document, guard=None):
    clean, errors = validate_recs(document)
    if clean is None:
        return {'failed': '; '.join(errors)}
    from recs.profile import save_research
    save_research(
        store, clean['insights'], clean['profile_md'], clean['twins'], []
    )
    placed = 0
    for row in clean['rows']:
        items = []
        for item in row['items']:
            title_id = _title_id(store, settings, guard, item)
            if title_id is None:
                errors.append('could not save %s' % item['title'])
                continue
            items.append({
                'title_id': title_id,
                'episode_id': None,
                'reason': item['reason'],
                'detail': {
                    'source': item['source'],
                    'match': item['match'],
                    'why': item['reason'],
                    'mood': row['mood'],
                    'because': row['because']
                }
            })
            placed += 1
        label = row['title']
        if row['kind'] == 'because' and row['because']:
            label = 'Because you loved %s' % row['because']
        store.ensure_list(row['slug'], label, show=True)
        store.replace_list_items(row['slug'], items)
        store.set_list_menu(row['slug'], True, label)
    store.meta_set('brain_lists_at', clean['generated_at'])
    store.meta_set('brain_based_on', clean['based_on'])
    from recs.rows import apply_row_visibility
    apply_row_visibility(store, settings)
    return {
        'message': 'Brain lists from %s, based on taste from %s' % (
            clean['generated_at'] or 'an unknown time',
            clean['based_on'] or 'an unknown time'
        ),
        'placed': placed,
        'rows': len(clean['rows']),
        'errors': errors,
        'generated_at': clean['generated_at'],
        'based_on': clean['based_on']
    }


def _slug(raw, kind, index):
    text = str(raw or '').strip().lower()
    safe = ''.join(ch if ch.isalnum() or ch == '_' else '_' for ch in text).strip('_')
    if safe:
        return safe[:40]
    if kind == 'because':
        return 'recs_loved_%s' % index
    if kind == 'custom':
        return 'recs_brain_%s' % index
    return KIND_SLUGS[kind]


def _title_id(store, settings, guard, item):
    existing = store.find_title(media_type=item['media_type'], tmdb=item['tmdb_id'])
    if existing is not None:
        return existing['id']
    if guard is None or not (settings.get('tmdb_api_key') or '').strip():
        return store.upsert_title(
            media_type=item['media_type'],
            title=item['title'],
            year=item.get('year'),
            tmdb=item['tmdb_id'],
            imdb=item.get('imdb_id')
        )
    try:
        from recs.engine import _fetch_new
        return _fetch_new(store, settings, guard, item)
    except Exception:
        return store.upsert_title(
            media_type=item['media_type'],
            title=item['title'],
            year=item.get('year'),
            tmdb=item['tmdb_id'],
            imdb=item.get('imdb_id')
        )
