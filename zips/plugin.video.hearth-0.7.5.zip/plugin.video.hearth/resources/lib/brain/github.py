'''GitHub contents API for one private repo. The token stays in the header.'''

from __future__ import annotations

import base64
import json
from urllib.parse import quote

API = 'https://api.github.com'


class GitHubError(Exception):
    pass


def put_json(guard, repo, token, path, document, message):
    '''Write a JSON file. Returns the blob sha. Overwrites when the file exists.'''
    encoded = base64.b64encode(
        json.dumps(document, indent=2, sort_keys=True).encode('utf-8')
    ).decode('ascii')
    body = {'message': message, 'content': encoded}
    current = get_file(guard, repo, token, path, missing_ok=True)
    if current and current.get('sha'):
        body['sha'] = current['sha']
    response = _request(guard, 'PUT', _url(repo, path), token, body)
    content = (response.get('content') or {}) if isinstance(response, dict) else {}
    sha = content.get('sha') or ''
    if not sha:
        raise GitHubError('GitHub did not return a sha for %s' % path)
    check = get_file(guard, repo, token, path, missing_ok=False)
    if (check or {}).get('sha') != sha:
        raise GitHubError('Read-back sha did not match for %s' % path)
    return sha


def get_json(guard, repo, token, path):
    found = get_file(guard, repo, token, path, missing_ok=False)
    raw = found.get('text') or ''
    try:
        return json.loads(raw)
    except ValueError as exc:
        raise GitHubError('Brain file was not JSON') from exc


def get_file(guard, repo, token, path, missing_ok=False):
    url = _url(repo, path)
    response = guard.get(url, 'brain', headers=_headers(token))
    status = int(getattr(response, 'status', 0) or 0)
    if status == 404 and missing_ok:
        return None
    body = getattr(response, 'body', None)
    if status < 200 or status >= 300 or not isinstance(body, dict):
        raise GitHubError('GitHub %s returned %s' % (path, status or 0))
    encoded = body.get('content') or ''
    text = ''
    if encoded:
        text = base64.b64decode(''.join(encoded.split())).decode('utf-8')
    return {'sha': body.get('sha') or '', 'text': text}


def post_webhook(guard, url, key, payload):
    if not url:
        return {'skipped': 'no webhook'}
    from urllib.parse import urlparse
    host = (urlparse(url).hostname or '').lower()
    if host:
        guard.allow_host(host)
    headers = {'Content-Type': 'application/json'}
    if key:
        headers['X-Hearth-Sender-Key'] = key
    response = guard.post(url, 'brain', headers=headers, body=json.dumps(payload))
    status = int(getattr(response, 'status', 0) or 0)
    if status < 200 or status >= 300:
        raise GitHubError('Webhook returned %s' % (status or 0))
    return {'status': status}


def _request(guard, method, url, token, body):
    response = guard.request(
        method, url, 'brain', headers=_headers(token), body=json.dumps(body)
    )
    status = int(getattr(response, 'status', 0) or 0)
    parsed = getattr(response, 'body', None)
    if status not in (200, 201) or not isinstance(parsed, dict):
        raise GitHubError('GitHub returned %s' % (status or 0))
    return parsed


def _url(repo, path):
    owner_repo = (repo or '').strip().strip('/')
    safe = '/'.join(quote(part) for part in path.split('/'))
    return '%s/repos/%s/contents/%s' % (API, owner_repo, safe)


def _headers(token):
    headers = {
        'Accept': 'application/vnd.github+json',
        'Content-Type': 'application/json',
        'User-Agent': 'Hearth'
    }
    if token:
        headers['Authorization'] = 'Bearer ' + token
    return headers
