'''Upload taste and pull finished rows. Tokens are not written into results.'''

from __future__ import annotations

from brain.apply import apply_recs
from brain.bundle import build_bundle, journal_ids
from brain.github import GitHubError, get_json, post_webhook, put_json
from util import dumps, iso, loads


def brain_enabled(settings):
    return settings is not None and settings.flag('brain_enabled', False)


def send_taste(store, settings, guard, progress=None, now=None):
    if not brain_enabled(settings):
        return {'skipped': 'Hearth Brain is off.'}
    repo = (settings.get('brain_repo') or '').strip()
    token = (settings.get('brain_token') or '').strip()
    if not repo or not token:
        return {'skipped': 'Set the Brain repo and a GitHub token first.'}
    if progress is not None:
        progress.update(10, 'Building the taste bundle')
    now = now or iso()
    bundle = build_bundle(store, settings, now=now, version=_version())
    stamp = now.replace(':', '').replace('-', '')
    path = 'inbox/taste-%s.json' % stamp
    try:
        if progress is not None:
            progress.update(40, 'Uploading %s' % path)
        put_json(guard, repo, token, path, bundle, 'Hearth taste %s' % now)
        if progress is not None:
            progress.update(70, 'Updating inbox/latest.json')
        put_json(guard, repo, token, 'inbox/latest.json', bundle, 'Hearth taste latest')
    except GitHubError as exc:
        store.meta_set('brain_last_error', str(exc)[:300])
        return {'failed': str(exc)}
    _webhook(guard, settings, {
        'event': 'taste_uploaded',
        'path': path,
        'generated_at': now,
        'counts': {
            'ratings': len(bundle['ratings']),
            'journal': len(bundle['journal']),
            'in_progress': len(bundle['in_progress'])
        }
    })
    sent = loads(store.meta_get('brain_sent_journal'), []) or []
    sent_ids = set(int(item) for item in sent)
    sent_ids.update(journal_ids(store))
    store.meta_set('brain_sent_journal', dumps(sorted(sent_ids)))
    store.meta_set('brain_last_upload', now)
    store.meta_set('brain_last_error', '')
    store.meta_set('brain_new_count', '0')
    store.meta_set('brain_upload_due', 'false')
    if progress is not None:
        progress.update(100, 'Uploaded')
    return {
        'message': 'Uploaded %s ratings and %s journal notes. Nothing was deleted.' % (
            len(bundle['ratings']), len(bundle['journal'])
        ),
        'path': path,
        'generated_at': now
    }


def pull_lists(store, settings, guard, progress=None):
    if not brain_enabled(settings):
        return {'skipped': 'Hearth Brain is off.'}
    repo = (settings.get('brain_repo') or '').strip()
    token = (settings.get('brain_token') or '').strip()
    if not repo or not token:
        return {'skipped': 'Set the Brain repo and a GitHub token first.'}
    if progress is not None:
        progress.update(20, 'Reading outbox/recs.json')
    try:
        document = get_json(guard, repo, token, 'outbox/recs.json')
    except GitHubError as exc:
        store.meta_set('brain_last_error', str(exc)[:300])
        return {'failed': str(exc)}
    if progress is not None:
        progress.update(60, 'Saving rows')
    result = apply_recs(store, settings, document, guard)
    if result.get('failed'):
        store.meta_set('brain_last_error', result['failed'][:300])
        return result
    store.meta_set('brain_last_pull', iso())
    store.meta_set('brain_last_error', '')
    if progress is not None:
        progress.update(100, 'Saved')
    return result


def status_text(store, settings):
    lines = [
        'Hearth Brain',
        '',
        'Enabled: %s' % ('yes' if brain_enabled(settings) else 'no'),
        'Source: %s' % (settings.get('brain_source') or 'brain_gemini'),
        'Repo: %s' % (settings.get('brain_repo') or '(not set)'),
        'Last upload: %s' % (store.meta_get('brain_last_upload') or 'never'),
        'Last pull: %s' % (store.meta_get('brain_last_pull') or 'never'),
        'Lists from: %s' % (store.meta_get('brain_lists_at') or 'never'),
        'Based on taste from: %s' % (store.meta_get('brain_based_on') or 'never'),
        'Last error: %s' % (store.meta_get('brain_last_error') or 'none')
    ]
    return '\n'.join(lines)


def pull_is_due(store, settings, now=None):
    if not brain_enabled(settings):
        return False
    hours = max(1, settings.integer('brain_pull_hours', 6))
    last = store.meta_get('brain_last_pull') or ''
    if not last:
        return True
    from util import parse_iso
    last_at = parse_iso(last)
    now_at = parse_iso(now or iso())
    if last_at is None or now_at is None:
        return True
    return (now_at - last_at).total_seconds() >= hours * 3600


def _webhook(guard, settings, payload):
    url = (settings.get('brain_webhook_url') or '').strip()
    if not url:
        return
    try:
        post_webhook(guard, url, (settings.get('brain_webhook_key') or '').strip(), payload)
    except GitHubError as exc:
        # The taste file is already confirmed. Remember the wake-up failure.
        return str(exc)[:200]


def _version():
    try:
        import xml.etree.ElementTree as ET
        from pathlib import Path
        root = Path(__file__).resolve().parents[3] / 'addon.xml'
        return ET.parse(root).getroot().attrib.get('version') or 'dev'
    except Exception:
        return 'dev'
