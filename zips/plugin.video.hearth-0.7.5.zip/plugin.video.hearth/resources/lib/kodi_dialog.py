'''Kodi 22 renamed Dialog.input's default argument to defaultt.

Always pass the starting text positionally. A dialog failure is reported
and does not take the add-on down.
'''

from __future__ import annotations


def kodi_input(dialog, heading, default=''):
    text = default or ''
    try:
        typed = dialog.input(heading, text)
    except TypeError:
        try:
            typed = dialog.input(heading)
        except Exception as exc:
            _failed(exc)
            return ''
    except Exception as exc:
        _failed(exc)
        return ''
    return typed or ''


def kodi_select(dialog, heading, choices, preselect=0):
    items = list(choices)
    try:
        return dialog.select(heading, items, preselect=preselect)
    except TypeError:
        try:
            return dialog.select(heading, items, 0, preselect)
        except Exception as exc:
            _failed(exc)
            return -1
    except Exception as exc:
        _failed(exc)
        return -1


def kodi_yesno(dialog, heading, message):
    try:
        return bool(dialog.yesno(heading, message))
    except Exception as exc:
        _failed(exc)
        return False


def _failed(exc):
    message = 'A dialog failed: %s' % exc
    try:
        import xbmc
        safe = message.replace(',', ' ')[:160]
        xbmc.log('Hearth: %s' % safe, xbmc.LOGERROR)
        xbmc.executebuiltin('Notification(Hearth, %s, 5000)' % safe)
    except Exception:
        return
