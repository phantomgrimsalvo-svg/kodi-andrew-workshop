'''Menus on a recommendation, and the notes screens.'''

from __future__ import annotations

from urllib.parse import quote

from util import loads


def run_rec_action(name, parts, store, settings, notify, show_text):
    title_id = int(parts[2]) if len(parts) > 2 and str(parts[2]).isdigit() else None
    if name == 'deep_research':
        _research(store, settings, notify)
    elif name == 'view_ai_notes':
        show_text('AI notes', (store.meta_get('ai_notes') or 'No AI notes yet.')[:12000])
    elif name == 'edit_ai_notes':
        _edit_notes(store)
    elif name == 'clear_ai_notes':
        _clear_notes(store, notify)
    elif name == 'view_twins':
        from recs.profile import twins_text
        show_text('Taste twins', twins_text(store)[:12000])
    elif name == 'pick_mood':
        _pick_mood(store, settings, notify)
    elif name == 'more_like' and title_id:
        _more_like(store, settings, title_id, notify)
    elif name == 'not_interested' and title_id:
        from recs.engine import dismiss_title
        dismiss_title(store, title_id)
        notify('Hearth', 'Hearth will not offer that again.')
    elif name == 'never_show' and title_id:
        _never(store, title_id, notify)
    elif name == 'already_seen' and title_id:
        _already(store, settings, title_id, notify)
    elif name == 'why_pick' and title_id:
        show_text('Why this pick', _why(store, title_id)[:4000])
    elif name == 'trailer' and title_id:
        _trailer(store, title_id)


def _research(store, settings, notify):
    from network.guard import active_guard
    from recs.research import deep_research
    try:
        result = deep_research(store, settings, active_guard())
    except Exception as exc:
        from util import redact
        notify('Hearth', redact(str(exc))[:180])
        return
    if result.get('skipped'):
        notify('Hearth', result['skipped'][:180])
        return
    notify('Hearth', 'Deep research saved %s insights and %s taste twins.' % (
        result.get('insights', 0), result.get('twins', 0)
    ))


def _edit_notes(store):
    import xbmcgui
    from recs.profile import andrew_text, set_andrew_notes
    current = andrew_text(store.meta_get('ai_notes') or '')
    from kodi_dialog import kodi_input
    typed = kodi_input(xbmcgui.Dialog(), 'Your notes', current or '')
    if not typed:
        return
    set_andrew_notes(store, typed)


def _clear_notes(store, notify):
    import xbmcgui
    from recs.profile import clear_notes
    if not xbmcgui.Dialog().yesno('Clear AI notes', 'Remove the AI notes and taste twins?'):
        return
    clear_notes(store)
    notify('Hearth', 'AI notes cleared. Your ratings are still here.')


def _pick_mood(store, settings, notify):
    import xbmcgui
    raw = settings.get('recs_moods') or ''
    moods = [part.strip() for part in raw.split(',') if part.strip()]
    if not moods:
        notify('Hearth', 'Add some moods in Hearth settings.')
        return
    index = xbmcgui.Dialog().select('Mood', moods)
    if index is None or index < 0:
        return
    store.meta_set('recs_mood', moods[index])
    if store.list_row('recs_mood') is not None:
        store.set_list_menu('recs_mood', True, 'Mood: %s' % moods[index])
    notify('Hearth', 'Mood is %s.' % moods[index])


def _more_like(store, settings, title_id, notify):
    from network.guard import active_guard
    from tmdb.client import fetch_movie, fetch_show
    title = store.get_title(title_id)
    key = (settings.get('tmdb_api_key') or '').strip()
    if title is None or not key or not title['tmdb']:
        notify('Hearth', 'This title has no TMDB id to match.')
        return
    guard = active_guard()
    kind = 'movie' if title['media_type'] == 'movie' else 'tv'
    url = 'https://api.themoviedb.org/3/%s/%s/similar?api_key=%s' % (kind, title['tmdb'], key)
    body = guard.get(url, 'explicit_action').body or {}
    rows = []
    for item in (body.get('results') or [])[:12]:
        media = 'show' if kind == 'tv' else 'movie'
        tmdb_id = str(item.get('id') or '')
        if not tmdb_id:
            continue
        existing = store.find_title(media_type=media, tmdb=tmdb_id)
        if existing is None:
            if media == 'movie':
                payload = fetch_movie(guard, key, tmdb_id, 'explicit_action', tmdb_id)
                from tmdb.client import movie_fields
                fields = movie_fields(payload)
            else:
                payload = fetch_show(guard, key, tmdb_id, 'explicit_action', tmdb_id)
                from tmdb.client import show_fields
                fields = show_fields(payload)
                fields.pop('seasons', None)
            fields.pop('images', None)
            existing_id = store.upsert_title(**fields)
        else:
            existing_id = existing['id']
        rows.append({
            'title_id': existing_id,
            'episode_id': None,
            'reason': 'More like %s' % title['title']
        })
    store.ensure_list('recs_more', 'More like %s' % title['title'], show=True)
    store.replace_list_items('recs_more', rows)
    notify('Hearth', 'More like %s is in the menu.' % title['title'])


def _never(store, title_id, notify):
    store.ensure_list('never_show', 'Never show', show=False)
    store.add_list_item('never_show', title_id, None)
    for row in store.all_lists():
        if str(row['slug']).startswith('recs'):
            store.remove_list_item(row['slug'], title_id, None)
    store.add_journal(title_id, 'Never show', source='local')
    notify('Hearth', 'That title will not be recommended.')


def _already(store, settings, title_id, notify):
    from ratings.triggers import run_prompt, save_prompt_result
    title = store.get_title(title_id)
    if title is None:
        return
    watch = store.get_watch(title_id, None)
    plays = int(watch['play_count'] or 0) if watch is not None else 0
    store.set_watch(
        title_id, None, play_count=max(1, plays), resume_seconds=0, source='local'
    )
    if store.get_rating(title_id) is not None and store.get_rating(title_id)['score'] is not None:
        notify('Hearth', 'Marked watched.')
        return
    import xbmcgui
    dialog = xbmcgui.Dialog()

    class Adapter:
        def select(self, heading, choices):
            return dialog.select(heading, choices)

        def input(self, heading, default=''):
            from kodi_dialog import kodi_input
            return kodi_input(dialog, heading, default)

        def multiselect(self, heading, choices):
            return []

    prompt = {'unit': 'movie' if title['media_type'] == 'movie' else 'show', 'title_id': title_id, 'title': title['title'], 'season': None}
    def on_score(partial):
        save_prompt_result(store, settings, prompt, partial)

    try:
        answer = run_prompt(
            Adapter(), prompt, ask=settings.get('recs_ask_level') or 'notes', on_score=on_score
        )
    except Exception as exc:
        from kodi_dialog import _failed
        _failed(exc)
        return
    save_prompt_result(store, settings, prompt, answer)
    notify('Hearth', 'Marked watched.')


def _why(store, title_id):
    for row in store.all_lists():
        if not str(row['slug']).startswith('recs'):
            continue
        for item in store.list_items(row['slug']):
            if item['title_id'] != title_id:
                continue
            detail = loads(item['detail'], {}) if item['detail'] else {}
            lines = [detail.get('why') or item['reason'] or 'No explanation stored.']
            if detail.get('source'):
                lines.append('Source: %s' % detail['source'])
            if detail.get('credit'):
                lines.append(detail['credit'])
            if detail.get('match') not in (None, ''):
                lines.append('Match: %s%%' % detail['match'])
            return '\n\n'.join(lines)
    return 'No explanation stored.'


def _trailer(store, title_id):
    import xbmc
    title = store.get_title(title_id)
    if title is None:
        return
    video = ''
    for row in store.all_lists():
        if not str(row['slug']).startswith('recs'):
            continue
        for item in store.list_items(row['slug']):
            if item['title_id'] == title_id and item['detail']:
                video = (loads(item['detail'], {}) or {}).get('trailer') or ''
                if video:
                    break
    if video:
        target = 'plugin://plugin.video.youtube/play/?video_id=%s' % video
    else:
        target = 'plugin://plugin.video.youtube/kodion/search/query/?q=%s' % quote(
            '%s trailer' % (title['title'] or '')
        )
    xbmc.executebuiltin('PlayMedia("%s")' % target)
