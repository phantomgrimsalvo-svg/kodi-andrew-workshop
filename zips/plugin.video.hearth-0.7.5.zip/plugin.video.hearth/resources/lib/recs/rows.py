'''Which recommendation rows show in Hearth and on the channel app.'''

from __future__ import annotations

ROWS = (
    ('recs', 'recs_row_for_you', 'For You'),
    ('recs_twins', 'recs_row_twins', 'From your taste twins'),
    ('recs_gems', 'recs_row_gems', 'Hidden gems'),
    ('recs_movies', 'recs_row_movies', 'Movies'),
    ('recs_shows', 'recs_row_shows', 'Shows'),
    ('recs_mood', 'recs_row_mood', 'Mood')
)


def apply_row_visibility(store, settings):
    channels = settings.flag('channels_enabled', False)
    mood = (store.meta_get('recs_mood') or '').strip()
    for slug, key, name in ROWS:
        shown = settings.flag(key, True)
        label = name
        if slug == 'recs_mood' and mood:
            label = 'Mood: %s' % mood
        if store.list_row(slug) is None:
            continue
        store.set_list_menu(slug, shown, label if shown else None)
        if shown and channels:
            store.set_publish_channel(slug, True)
        elif not shown:
            store.set_publish_channel(slug, False)
    if not settings.flag('recs_row_because', True):
        for row in store.all_lists():
            if str(row['slug']).startswith('recs_loved_'):
                store.set_list_menu(row['slug'], False)
                store.set_publish_channel(row['slug'], False)
