'''Plugin entry. Directory building stays local; play hands off to a player add-on.'''

from __future__ import annotations

from urllib.parse import parse_qsl, urlparse

from paths import art_dir, bundled_players_dir, db_path, default_backup_dir, user_players_dir
from settings import Settings, load_kodi_settings


def run(argv=None):
    import sys
    argv = list(argv if argv is not None else sys.argv)
    url = argv[0] if argv else ''
    handle = int(argv[1]) if len(argv) > 1 and str(argv[1]).lstrip('-').isdigit() else -1
    query = {}
    if len(argv) > 2 and argv[2]:
        query = dict(parse_qsl(argv[2].lstrip('?')))
    parsed = urlparse(url)
    parts = [part for part in parsed.path.split('/') if part]
    if parsed.query:
        query.update(dict(parse_qsl(parsed.query)))
    settings = load_kodi_settings()
    from data.store import open_store
    store = open_store(db_path())
    store.ensure_system_lists()
    settings.store = store
    from recs.rows import apply_row_visibility
    apply_row_visibility(store, settings)
    _dispatch(handle, parts, query, store, settings)


def _dispatch(handle, parts, query, store, settings):
    from plugin.kodiui import (
        directory, notify, play_with_picker, show_fixup, show_text
    )
    from plugin.listings import build_info, build_list, build_root
    action = parts[0] if parts else ''
    if not parts:
        directory(handle, build_root(store), folder=True)
        return
    if action == 'lists':
        directory(handle, build_root(store), folder=True)
        return
    if action == 'list' and len(parts) > 1:
        directory(handle, build_list(store, parts[1], settings))
        return
    if action == 'show' and len(parts) > 1:
        from plugin.listings import build_season_episodes, build_show_seasons
        if len(parts) > 3 and parts[2] == 'season':
            directory(handle, build_season_episodes(store, parts[1], parts[3]), folder=True)
        else:
            directory(handle, build_show_seasons(store, parts[1]), folder=True)
        return
    if action == 'play' and len(parts) > 1:
        episode_id = int(parts[2]) if len(parts) > 2 else None
        url = play_with_picker(store, settings, int(parts[1]), episode_id, query.get('player'))
        from plugin.playback import play_or_resolve
        play_or_resolve(handle, url)
        return
    if action == 'info' and len(parts) > 1:
        info = build_info(store, parts[1])
        if info:
            show_text(info['title'], info['text'])
        _end(handle, False)
        return
    if action == 'fixup' and len(parts) > 1:
        show_fixup(store, settings, int(parts[1]))
        _end(handle, False)
        return
    if action == 'action' and len(parts) > 1:
        _action(handle, parts, store, settings, query)
        return
    directory(handle, build_root(store), folder=True)


def _action(handle, parts, store, settings, query=None):
    query = query or {}
    name = parts[1] if len(parts) > 1 else ''
    from plugin.kodiui import notify, show_text
    from plugin.settings_actions import dispatch_settings_action
    if dispatch_settings_action(name, store, settings, notify, show_text):
        _end(handle, False)
        return
    if name == 'launch':
        from plugin.playback import open_folder, play_or_resolve
        target = query.get('target') or ''
        mode = query.get('mode') or 'play'
        if mode == 'folder':
            open_folder(handle, target)
        else:
            play_or_resolve(handle, target)
        return
    elif name == 'remove_list' and len(parts) > 2:
        from plugin.kodiui import confirm_remove_list
        confirm_remove_list(store, settings, parts[2])
    elif name == 'toggle_channel' and len(parts) > 2:
        from channels.export import export_channels, toggle_channel
        from paths import channels_export_path
        row = store.list_row(parts[2])
        if row is not None:
            enabled = not bool(row['publish_as_channel'])
            toggle_channel(store, parts[2], enabled)
            if enabled and (row['import_mode'] or '') == 'live':
                from channels.live import kodi_directory, refresh_one
                refresh_one(store, parts[2], kodi_directory)
            export_channels(store, settings, channels_export_path())
            notify('Hearth', '%s will %s as a channel.' % (
                row['name'], 'show' if enabled else 'not show'
            ))
    elif name == 'nextup_menu' and len(parts) > 2:
        from plugin.kodiui import show_nextup_menu
        show_nextup_menu(store, settings, int(parts[2]))
    elif name in (
        'more_like', 'not_interested', 'never_show',
        'already_seen', 'why_pick', 'trailer'
    ):
        from recs.actions import run_rec_action
        run_rec_action(name, parts, store, settings, notify, show_text)
    _end(handle, False)


def _launch_external(target, mode):
    from plugin.kodiui import notify
    if not str(target).startswith('plugin://'):
        notify('Hearth', 'That item has no plugin path.')
        return
    import xbmc
    quoted = '"%s"' % target.replace('"', '')
    if mode == 'folder':
        xbmc.executebuiltin('ActivateWindow(Videos,%s,return)' % quoted)
    else:
        xbmc.executebuiltin('PlayMedia(%s)' % quoted)


def _end(handle, succeeded):
    if handle is None or int(handle) < 0:
        return
    import xbmcplugin
    xbmcplugin.endOfDirectory(int(handle), succeeded=succeeded)
