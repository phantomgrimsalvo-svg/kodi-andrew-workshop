'''Every settings RunPlugin action enters through jobs.run.'''

from __future__ import annotations

from jobs import ACTIONS, action, recent_text, run


def dispatch_settings_action(name, store, settings, notify, show_text):
    spec = ACTIONS.get(name)
    if spec is None:
        return False

    def work(progress):
        return spec['fn'](store, settings, progress, notify, show_text) or {}

    run(
        spec['feature'], name, work, store,
        threaded=spec['threaded'], background=spec['background'],
        notify=notify, show_text=show_text
    )
    return True


@action('backup_now', 'Backup', threaded=True)
def _backup_now(store, settings, progress, notify, show_text):
    from backup.local import backup_now
    from paths import art_dir, default_backup_dir
    from util import iso
    progress.update(10, 'Writing the backup zip')
    folder = settings.get('backup_folder') or str(default_backup_dir())
    result = backup_now(store, settings, folder, art_dir=art_dir(), when=iso())
    return {'message': 'Saved in %s.' % result.get('folder', folder)}


@action('restore', 'Restore')
def _restore(store, settings, progress, notify, show_text):
    from backup.local import list_versions, restore_backup
    from paths import art_dir, db_path
    from plugin.kodiui import pick_folder, pick_version
    progress.update(10, 'Looking for backup folders')
    progress.release()
    chosen = pick_folder('Restore Hearth from a backup folder')
    if not chosen:
        return {'skipped': 'No backup folder was chosen.'}
    versions = list_versions(chosen)
    version = None
    if len(versions) > 1:
        version = pick_version([item.name for item in versions])
        if not version:
            return {'skipped': 'No backup version was chosen.'}
    restore_backup(db_path(), art_dir(), chosen, version=version, confirm=True)
    return {'message': 'The local library was replaced.'}


@action('manage_players', 'Players')
def _manage_players(store, settings, progress, notify, show_text):
    from plugin.kodiui import manage_players
    progress.update(15, 'Reading installed player files')
    progress.release()
    manage_players(store, settings)
    return {'message': 'Player picker closed.'}


@action('update_players', 'Update players')
def _update_players(store, settings, progress, notify, show_text):
    from plugin.kodiui import update_players_now
    progress.update(10, 'Downloading the player file')
    progress.release()
    update_players_now(settings)
    return {'message': 'Player update finished.'}


@action('trakt_sign_out', 'Trakt')
def _trakt_sign_out(store, settings, progress, notify, show_text):
    from trakt.auth import clear_auth
    progress.update(20, 'Forgetting the saved token')
    settings.store = store
    clear_auth(settings, message='Signed out of Trakt.')
    return {'message': 'Signed out. The Hearth library was not deleted.'}


@action('run_wizard', 'Setup')
def _run_wizard(store, settings, progress, notify, show_text):
    from wizard import run_wizard
    progress.update(10, 'Opening setup')
    progress.release()
    run_wizard(store, settings)
    return {'message': 'Setup closed.'}


@action('import_dry_run', 'Import from Trakt')
def _import_trakt(store, settings, progress, notify, show_text):
    from network.guard import active_guard
    from trakt.flow import import_from_trakt
    progress.update(5, 'Checking the Trakt account')
    summary = import_from_trakt(
        store, settings, active_guard(), progress=progress.adapter()
    )
    if not summary:
        return {'skipped': 'Trakt did not return a result.'}
    text = str(summary)
    if 'Nothing was imported' in text or 'cancelled' in text.lower() or 'client id' in text.lower():
        return {'skipped': text[:300]}
    if text.lower().startswith('imported'):
        return {'message': text[:300]}
    return {'message': text[:300]}


@action('resync_playback', 'Re-sync playback', threaded=True)
def _resync(store, settings, progress, notify, show_text):
    from network.guard import active_guard
    from trakt.importer import resync_playback
    progress.update(15, 'Reading Trakt playback')
    result = resync_playback(store, settings, active_guard())
    if isinstance(result, str):
        low = result.lower()
        if 'no ' in low or 'not ' in low or 'sign' in low:
            return {'skipped': result[:300]}
        return {'message': result[:300]}
    return {'message': 'Playback progress updated.'}


@action('push_mirror', 'Cloud push', threaded=True)
def _push_mirror(store, settings, progress, notify, show_text):
    from mirrors.push import push_outbox
    from network.guard import active_guard
    if not settings.mirror_enabled():
        return {'skipped': 'Cloud source is None. Nothing is sent.'}
    progress.update(20, 'Sending queued changes')
    result = push_outbox(store, settings, active_guard())
    return {'message': 'Pushed %s. Skipped %s.' % (
        result.get('pushed', 0), result.get('skipped', 0)
    )}


@action('rebuild_recs', 'Recommendations', threaded=True)
def _rebuild(store, settings, progress, notify, show_text):
    from network.guard import active_guard
    from recs.engine import rebuild_recommendations
    progress.update(5, 'Starting')

    def on_progress(percent, stage):
        progress.update(percent, stage)

    result = rebuild_recommendations(
        store, settings, active_guard(), stop=progress.stop, on_progress=on_progress
    )
    return _recs_result(store, settings, result)


@action('recs_dry_run', 'Recommendations dry run', threaded=True)
def _dry_run(store, settings, progress, notify, show_text):
    from network.guard import active_guard
    from recs.engine import rebuild_recommendations
    progress.update(20, 'Collecting candidates. The model is not called.')
    result = rebuild_recommendations(
        store, settings, active_guard(), dry_run=True, stop=progress.stop
    )
    if result.get('skipped'):
        return {'skipped': result['skipped']}
    text = 'Candidates: %s\n\n%s' % (
        result.get('candidates', 0), (result.get('prompt') or '')[:4000]
    )
    return {
        'message': 'Dry run only. %s candidates. No model call was made.' % result.get('candidates', 0),
        'heading': 'Recommendations dry run',
        'text': text
    }


@action('view_profile', 'Taste profile', threaded=True)
def _view_profile(store, settings, progress, notify, show_text):
    from recs.profile import render_profile
    progress.update(30, 'Building the taste profile')
    text = render_profile(store, settings)[:12000]
    return {'message': 'Showing the taste profile.', 'heading': 'Taste profile', 'text': text}


@action('view_journal', 'Taste journal', threaded=True)
def _view_journal(store, settings, progress, notify, show_text):
    from recs.profile import journal_markdown
    progress.update(30, 'Reading the taste journal')
    text = journal_markdown(store)[:12000]
    return {'message': 'Showing the taste journal.', 'heading': 'Taste journal', 'text': text}


@action('rate_history', 'Rate my history')
def _rate_history(store, settings, progress, notify, show_text):
    from ratings.history import rate_history_kodi
    progress.update(10, 'Finding watched titles with no rating')
    progress.release()
    result = rate_history_kodi(store, settings) or {}
    if result.get('message'):
        return {'skipped': result['message']}
    return {'message': 'Rated %s. %s still open.' % (
        result.get('rated', 0), result.get('left', 0)
    )}


@action('deep_research', 'Deep research', threaded=True)
def _deep_research(store, settings, progress, notify, show_text):
    from network.guard import active_guard
    from recs.research import deep_research
    progress.update(10, 'asking Gemini (can take up to 120 s)')
    try:
        result = deep_research(
            store, settings, active_guard(), stop=progress.stop
        )
    except Exception as exc:
        from recs.engine import friendly_ai_error, report_ai_failure
        report_ai_failure(store, 'Deep research', exc, settings.get('recs_api_key'))
        return {'failed': friendly_ai_error(exc)}
    if result.get('skipped'):
        return {'skipped': result['skipped']}
    if result.get('failed'):
        return {'failed': result['failed']}
    return {'message': 'Saved %s insights and %s taste twins.' % (
        result.get('insights', 0), result.get('twins', 0)
    )}


@action('view_ai_notes', 'AI notes', threaded=True)
def _view_notes(store, settings, progress, notify, show_text):
    progress.update(20, 'Reading AI notes')
    from recs.profile import notes_for_screen
    text = notes_for_screen(store.meta_get('ai_notes') or '')[:12000]
    return {'message': 'Showing AI notes.', 'heading': 'AI notes', 'text': text}


@action('edit_ai_notes', 'AI notes')
def _edit_notes(store, settings, progress, notify, show_text):
    from recs.actions import _edit_notes as edit
    progress.update(10, 'Opening the note editor')
    progress.release()
    edit(store)
    return {'message': 'Notes saved if you typed any.'}


@action('clear_ai_notes', 'AI notes')
def _clear_notes(store, settings, progress, notify, show_text):
    from recs.profile import clear_notes
    import xbmcgui
    progress.update(10, 'Asking before deleting notes')
    progress.release()
    if not xbmcgui.Dialog().yesno('Clear AI notes', 'Remove the AI notes and taste twins?'):
        return {'skipped': 'Clear was cancelled. Ratings are unchanged.'}
    clear_notes(store)
    return {'message': 'AI notes cleared. Ratings are still here.'}


@action('view_twins', 'Taste twins', threaded=True)
def _view_twins(store, settings, progress, notify, show_text):
    from recs.profile import twins_text
    progress.update(20, 'Reading taste twins')
    text = twins_text(store)[:12000]
    return {'message': 'Showing taste twins.', 'heading': 'Taste twins', 'text': text}


@action('pick_mood', 'Mood')
def _pick_mood(store, settings, progress, notify, show_text):
    from recs.actions import _pick_mood as pick
    progress.update(10, 'Loading the mood list')
    progress.release()
    pick(store, settings, notify)
    mood = store.meta_get('recs_mood') or ''
    if not mood:
        return {'skipped': 'No mood was chosen.'}
    return {'message': 'Mood is %s.' % mood}


@action('test_recs', 'Test AI connection', threaded=True)
def _test_recs(store, settings, progress, notify, show_text):
    from network.guard import active_guard
    from recs.engine import friendly_ai_error, report_ai_failure, test_connection
    progress.update(20, 'Sending a short prompt')
    try:
        test_connection(settings, active_guard())
    except Exception as exc:
        report_ai_failure(store, 'Test AI connection', exc, settings.get('recs_api_key'))
        return {'failed': friendly_ai_error(exc)}
    return {'message': 'The AI provider answered.'}


@action('refresh_artwork', 'Refresh artwork', threaded=True)
def _artwork(store, settings, progress, notify, show_text):
    from art.backfill import backfill_all
    from network.guard import active_guard
    if not (settings.get('tmdb_api_key') or '').strip():
        return {'skipped': 'Add a TMDB API key, then refresh artwork.'}
    progress.update(5, 'Looking for titles without art')
    result = backfill_all(
        store, settings, active_guard(),
        progress=progress.adapter(), abort=progress.cancelled
    )
    if result.get('cancelled'):
        return {'skipped': 'Cancelled. The rest continues in the background.'}
    if result.get('skipped'):
        return {'skipped': result['skipped']}
    return {'message': 'Filled %s. %s still waiting.' % (
        result.get('filled', 0), result.get('remaining', 0)
    )}


@action('tmdb_sign_in', 'TMDb sign-in')
def _tmdb_sign_in(store, settings, progress, notify, show_text):
    from network.guard import active_guard
    from tmdb.account import import_account_ratings, sign_in
    import xbmcgui
    progress.update(10, 'Asking TMDb to approve this device')
    progress.release()
    session = sign_in(store, settings, active_guard())
    if not session:
        return {'skipped': 'Sign-in cancelled.'}
    if xbmcgui.Dialog().yesno('TMDb', 'Import your TMDb ratings now?'):
        stats = import_account_ratings(store, settings, active_guard())
        if isinstance(stats, str):
            return {'skipped': stats[:300]}
        return {'message': 'Imported %s movies, %s shows, %s episodes.' % (
            stats.get('movies', 0), stats.get('shows', 0), stats.get('episodes', 0)
        )}
    return {'message': 'Signed in. Ratings stay on TMDb until you import them.'}


@action('tmdb_sign_out', 'TMDb')
def _tmdb_sign_out(store, settings, progress, notify, show_text):
    from tmdb.account import sign_out
    progress.update(20, 'Forgetting the TMDb session')
    sign_out(store, settings)
    return {'message': 'Signed out of TMDb. The API key is still saved.'}


@action('tmdb_import_ratings', 'TMDb ratings', threaded=True)
def _tmdb_import(store, settings, progress, notify, show_text):
    from network.guard import active_guard
    from tmdb.account import import_account_ratings
    progress.update(10, 'Reading ratings from TMDb')
    stats = import_account_ratings(
        store, settings, active_guard(), progress=progress.adapter()
    )
    if isinstance(stats, str):
        return {'skipped': stats[:300]}
    extra = ''
    if not store.meta_get('trakt_rating_backfill_done'):
        from network.guard import active_guard
        from ratings.sync import sync_ratings_to_trakt, wants_trakt_ratings
        if wants_trakt_ratings(settings):
            progress.update(70, 'Sending ratings Trakt does not have yet')
            pushed = sync_ratings_to_trakt(store, settings, active_guard(), progress)
            store.meta_set('trakt_rating_backfill_done', 'true')
            extra = ' ' + (pushed.get('message') or '')
    return {'message': ('Imported %s movies, %s shows, %s episodes.%s' % (
        stats.get('movies', 0), stats.get('shows', 0), stats.get('episodes', 0), extra
    )).strip()}


@action('refresh_live_channels', 'Live channels', threaded=True)
def _refresh_live(store, settings, progress, notify, show_text):
    from channels.export import export_channels
    from channels.live import kodi_directory, refresh_published
    from paths import channels_export_path
    progress.update(20, 'Re-reading published live folders')
    refresh_published(store, settings, kodi_directory, force=True)
    if settings.flag('channels_enabled', False):
        progress.update(80, 'Writing the channel export')
        export_channels(store, settings, channels_export_path())
    return {'message': 'Live channels were refreshed.'}


@action('send_tmdb_ratings', 'Send TMDb ratings to Trakt', threaded=True)
def _send_ratings(store, settings, progress, notify, show_text):
    from network.guard import active_guard
    from ratings.sync import sync_ratings_to_trakt
    result = sync_ratings_to_trakt(store, settings, active_guard(), progress)
    if result.get('skipped'):
        return {'skipped': result['skipped']}
    return {'message': result.get('message') or 'Finished.'}


@action('brain_send', 'Send taste to Brain', threaded=True)
def _brain_send(store, settings, progress, notify, show_text):
    from brain.service import send_taste
    from network.guard import active_guard
    return send_taste(store, settings, active_guard(), progress)


@action('brain_pull', 'Pull lists from Brain', threaded=True)
def _brain_pull(store, settings, progress, notify, show_text):
    from brain.service import pull_lists
    from network.guard import active_guard
    return pull_lists(store, settings, active_guard(), progress)


@action('brain_status', 'Hearth Brain', threaded=True)
def _brain_status(store, settings, progress, notify, show_text):
    from brain.service import status_text
    progress.update(30, 'Reading Brain status')
    return {
        'message': 'Showing Brain status.',
        'heading': 'Hearth Brain',
        'text': status_text(store, settings)
    }


@action('refresh_widgets', 'Widgets')
def _refresh_widgets(store, settings, progress, notify, show_text):
    import xbmc
    progress.update(50, 'Asking Home to reload')
    xbmc.executebuiltin('Container.Refresh')
    return {'message': 'Widgets refresh the next time Home opens this list.'}


@action('recent_activity', 'Recent activity', threaded=True)
def _recent(store, settings, progress, notify, show_text):
    progress.update(40, 'Reading the job log')
    return {
        'message': 'Showing recent jobs.',
        'heading': 'Recent activity',
        'text': recent_text(store)
    }


def _recs_result(store, settings, result):
    if result.get('failed'):
        return {'failed': result['failed']}
    if result.get('skipped'):
        return {'skipped': result['skipped']}
    if result.get('cancelled'):
        return {'skipped': 'Cancelled.'}
    from recs.rows import ROWS
    picks = 0
    rows = 0
    for slug, key, _name in ROWS:
        if not settings.flag(key, True):
            continue
        try:
            count = len(store.list_items(slug))
        except Exception:
            count = 0
        if count:
            rows += 1
            picks += count
    return {'message': '%s picks across %s rows' % (picks, rows)}
