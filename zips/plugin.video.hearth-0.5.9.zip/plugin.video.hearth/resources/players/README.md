# Player files

Hearth does not scrape. A player file tells Hearth how to build a `plugin://` URL for another add-on.

Put extra files in the add-on data folder:

`special://profile/addon_data/plugin.video.hearth/players/`

A file there with the same `id` replaces the bundled one. Hearth reads the same fields TMDb Helper uses (`name`, `plugin`, `play_movie`, `play_episode`, `priority`). Any field Hearth does not understand is ignored, so an existing TMDb Helper player file can be copied in. TMDb Helper does not need to be installed.

Tokens you can use: `{imdb}`, `{tmdb}`, `{tvdb}`, `{title}`, `{year}`, `{season}`, `{episode}`, `{tvshowtitle}`, `{premiered}`. If an id is missing, that query parameter is left out.

Umbrella 6.8.02 is the bundled example. It uses `action=play_Item`.

Example for another player:

```json
{
  "id": "seren",
  "name": "Seren",
  "plugin": "plugin.video.seren",
  "priority": 100,
  "play_movie": "plugin://plugin.video.seren/?action=play&tmdb={tmdb}&imdb={imdb}",
  "play_episode": "plugin://plugin.video.seren/?action=play&tmdb={tmdb}&season={season}&episode={episode}"
}
```

In Settings → Hearth → Playback, leave the default player empty to be asked every time, or set a player id to skip the dialog. Play with… still lets you pick another player for one title.
