'''TMDb Helper-style player JSON. Unknown fields are ignored.'''

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import parse_qsl, quote, urlencode, urlsplit, urlunsplit

TOKEN_RE = re.compile(r'\{([A-Za-z0-9_]+)\}')


@dataclass
class PlayerDefinition:
    id: str
    name: str
    plugin: str
    priority: int
    play_movie: str
    play_episode: str
    source: str

    def template_for(self, media_type):
        if media_type == 'movie':
            return self.play_movie or ''
        if media_type in ('episode', 'show'):
            return self.play_episode or ''
        return ''


def load_players(bundled_dir, user_dir=None):
    found = {}
    for path in _json_files(bundled_dir):
        player = _read_player(path, 'bundled')
        if player is not None:
            found[player.id] = player
    for path in _json_files(user_dir):
        player = _read_player(path, 'user')
        if player is not None:
            found[player.id] = player
    return sorted(found.values(), key=lambda item: (-item.priority, item.name.lower()))


def _json_files(directory):
    if not directory:
        return []
    folder = Path(directory)
    if not folder.exists():
        return []
    return sorted(folder.glob('*.json'))


def _read_player(path, source):
    try:
        payload = json.loads(Path(path).read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return None
    if not isinstance(payload, dict):
        return None
    plugin = payload.get('plugin') or ''
    if not plugin:
        return None
    player_id = str(payload.get('id') or plugin or path.stem)
    try:
        priority = int(payload.get('priority') or 0)
    except (TypeError, ValueError):
        priority = 0
    return PlayerDefinition(
        id=player_id,
        name=str(payload.get('name') or player_id),
        plugin=str(plugin),
        priority=priority,
        play_movie=_template(payload.get('play_movie')),
        play_episode=_template(payload.get('play_episode')),
        source=source
    )


def _template(value):
    if isinstance(value, str):
        return value
    return ''


def build_play_url(template, values):
    '''Fill {tokens}. Drop query params that are empty or still unsubstituted.'''
    if not template:
        return ''
    encoded = {}
    for key, value in (values or {}).items():
        if value is None or value == '':
            encoded[key] = ''
        else:
            encoded[key] = quote(str(value), safe='')

    def replace(match):
        return encoded.get(match.group(1), '')

    filled = TOKEN_RE.sub(replace, template)
    parts = urlsplit(filled)
    kept = []
    for key, value in parse_qsl(parts.query, keep_blank_values=True):
        if value == '' or value == 'None' or '{' in value or '}' in value:
            continue
        kept.append((key, value))
    return urlunsplit((
        parts.scheme, parts.netloc, parts.path, urlencode(kept), parts.fragment
    ))


def values_for(title, episode=None):
    show_title = title['title'] if title['media_type'] == 'show' else ''
    episode_title = ''
    season = ''
    number = ''
    premiered = title['premiered'] or ''
    if episode is not None:
        episode_title = episode['title'] or show_title or title['title']
        season = episode['season']
        number = episode['episode']
        premiered = episode['first_aired'] or premiered
        imdb = episode['imdb'] or title['imdb']
        tmdb = episode['tmdb'] or title['tmdb']
        tvdb = episode['tvdb'] or title['tvdb']
        name = episode_title or show_title
    else:
        imdb = title['imdb']
        tmdb = title['tmdb']
        tvdb = title['tvdb']
        name = title['title']
    return {
        'imdb': imdb or '',
        'tmdb': tmdb or '',
        'tvdb': tvdb or '',
        'trakt': title['trakt_id'] or '',
        'title': name or '',
        'year': title['year'] or '',
        'season': season if season != '' else '',
        'episode': number if number != '' else '',
        'tvshowtitle': show_title or '',
        'premiered': premiered or '',
        'name': name or '',
        'showname': show_title or ''
    }
