'''Add to a Hearth list, or snapshot / link another add-on's folder.'''

from __future__ import annotations

from util import iso

from art.store import download_images
from nextup.algorithm import rebuild_derived
from tmdb.client import (
    episode_fields, fetch_movie, fetch_season, fetch_show, find_external,
    movie_fields, show_fields
)


class LookupFailed(Exception):
    pass


def lists_for_media(store, media_type):
    '''Auto lists that accept a manual add, plus user lists.'''
    chosen = []
    for row in store.lists_in_menu():
        if row['kind'] == 'import' and (row['import_mode'] or '') == 'live':
            continue
        media_filter = row['media_filter']
        if row['slug'] in ('next_up', 'in_progress_movies', 'recent_movies', 'recs'):
            continue
        if media_filter == 'mixed':
            chosen.append(row)
            continue
        if media_type == 'movie' and media_filter == 'movies':
            chosen.append(row)
        elif media_type == 'show' and media_filter in ('shows', 'episodes'):
            chosen.append(row)
        elif media_type == 'episode' and media_filter in ('episodes', 'shows'):
            chosen.append(row)
    return chosen


def add_to_list(store, settings, guard, art_dir, identifiers, list_slug,
                confirm_partial=False):
    title_id, episode_id, fetched = ensure_title(
        store, settings, guard, art_dir, identifiers, confirm_partial
    )
    before = len(guard.calls)
    store.add_list_item(list_slug, title_id, episode_id if identifiers.get('media_type') == 'episode' else None)
    if settings.mirror_enabled() and list_slug in ('watchlist', 'favorites'):
        title = store.get_title(title_id)
        store.enqueue_outbox(list_slug + '_add', {
            'title': title['title'],
            'ids': {'imdb': title['imdb'], 'tmdb': title['tmdb']}
        }, '%s_add:%s' % (list_slug, title_id), settings.get('cloud_mirror'))
    after = len(guard.calls)
    return {
        'title_id': title_id,
        'episode_id': episode_id,
        'fetched': fetched,
        'extra_http': after - before
    }


def ensure_title(store, settings, guard, art_dir, identifiers, confirm_partial=False):
    media_type = identifiers.get('media_type') or 'movie'
    found = store.find_title(
        media_type='show' if media_type == 'episode' else media_type,
        imdb=identifiers.get('imdb'),
        tmdb=identifiers.get('tmdb'),
        trakt_id=identifiers.get('trakt_id'),
        title=identifiers.get('title'),
        year=identifiers.get('year')
    )
    if found is not None:
        episode_id = _match_episode(store, found['id'], identifiers)
        return found['id'], episode_id, False
    try:
        title_id, episode_id = _fetch_one(
            store, settings, guard, art_dir, identifiers
        )
        return title_id, episode_id, True
    except Exception as exc:
        if not confirm_partial:
            raise LookupFailed(str(exc)) from exc
        title_id = store.upsert_title(
            media_type='show' if media_type == 'episode' else media_type,
            title=identifiers.get('title') or 'Untitled',
            year=identifiers.get('year'),
            imdb=identifiers.get('imdb'),
            tmdb=identifiers.get('tmdb'),
            tvdb=identifiers.get('tvdb'),
            trakt_id=identifiers.get('trakt_id')
        )
        return title_id, None, False


def _fetch_one(store, settings, guard, art_dir, identifiers):
    api_key = settings.get('tmdb_api_key')
    if not api_key:
        raise LookupFailed('Add a TMDB API key in Hearth settings, then try again.')
    media_type = identifiers.get('media_type') or 'movie'
    tmdb_id = identifiers.get('tmdb')
    imdb = identifiers.get('imdb')
    item_id = '|'.join(
        str(part) for part in (tmdb_id, imdb, identifiers.get('trakt_id')) if part
    )
    purpose = 'manual_add'
    if not tmdb_id and imdb:
        found = find_external(guard, api_key, imdb, 'imdb_id', purpose, item_id or imdb)
        bucket = 'movie_results' if media_type == 'movie' else 'tv_results'
        hits = found.get(bucket) or []
        if not hits:
            raise LookupFailed('TMDB has no match for %s.' % imdb)
        tmdb_id = str(hits[0].get('id'))
        item_id = '|'.join(part for part in (item_id, tmdb_id) if part)
    if not tmdb_id:
        raise LookupFailed('This item has no TMDB or IMDb id Hearth can look up.')
    if media_type == 'movie':
        payload = fetch_movie(guard, api_key, tmdb_id, purpose, item_id)
        fields = movie_fields(payload)
        images = download_images(
            guard, art_dir, 'movie', tmdb_id, fields.pop('images'), purpose, item_id
        )
        fields['art'] = images
        fields['tmdb'] = str(tmdb_id)
        title_id = store.upsert_title(**fields)
        _merge_trakt_one(store, settings, guard, title_id, None, item_id, media_type='movie')
        return title_id, None
    payload = fetch_show(guard, api_key, tmdb_id, purpose, item_id)
    fields = show_fields(payload)
    seasons = fields.pop('seasons')
    images = download_images(
        guard, art_dir, 'show', tmdb_id, fields.pop('images'), purpose, item_id
    )
    fields['art'] = images
    fields['tmdb'] = str(tmdb_id)
    title_id = store.upsert_title(**fields)
    wanted = identifiers.get('season')
    season_numbers = seasons
    if wanted is not None:
        season_numbers = [int(wanted)]
    episode_id = None
    for season in season_numbers:
        if int(season) == 0 and settings.flag('exclude_specials', True):
            continue
        season_payload = fetch_season(guard, api_key, tmdb_id, season, purpose, item_id)
        for episode in season_payload.get('episodes') or []:
            ep_fields = episode_fields(episode)
            ep_images = ep_fields.pop('images')
            if ep_images.get('thumb'):
                saved = download_images(
                    guard, art_dir, 'episode',
                    '%s-%sx%s' % (tmdb_id, ep_fields['season'], ep_fields['episode']),
                    ep_images, purpose, item_id
                )
                ep_fields['art'] = saved
            new_id = store.upsert_episode(title_id, **ep_fields)
            if (
                identifiers.get('season') is not None
                and identifiers.get('episode') is not None
                and int(identifiers['season']) == ep_fields['season']
                and int(identifiers['episode']) == ep_fields['episode']
            ):
                episode_id = new_id
    _merge_trakt_one(store, settings, guard, title_id, episode_id, item_id, media_type='show')
    rebuild_derived(store, settings)
    return title_id, episode_id


def _merge_trakt_one(store, settings, guard, title_id, episode_id, item_id, media_type):
    '''Optional single-title Trakt merge. Never replaces a newer local resume with nothing.'''
    if not settings.trakt_authorized():
        return
    title = store.get_title(title_id)
    tmdb_id = title['tmdb']
    if not tmdb_id or str(tmdb_id) not in str(item_id):
        item_id = '|'.join(part for part in (item_id, str(tmdb_id)) if part)
    from trakt.client import TraktClient
    client = TraktClient(
        guard, settings.get('trakt_client_id'), settings.get('trakt_access_token')
    )
    try:
        hit = client.lookup_tmdb(tmdb_id, 'movie' if media_type == 'movie' else 'show', item_id)
    except Exception:
        return
    if not hit:
        return
    remote = hit.get('movie') or hit.get('show') or {}
    ids = remote.get('ids') or {}
    if ids.get('trakt'):
        store.update_title_fields(title_id, trakt_id=str(ids['trakt']))


def _match_episode(store, show_id, identifiers):
    if identifiers.get('season') is None or identifiers.get('episode') is None:
        return None
    for episode in store.episodes_for_show(show_id):
        if (
            int(episode['season']) == int(identifiers['season'])
            and int(episode['episode']) == int(identifiers['episode'])
        ):
            return episode['id']
    return None


def add_folder(store, settings, guard, art_dir, path, label, folder_art, mode,
               lister, confirm_fetch):
    '''Snapshot copies the directory now. Live only stores the plugin path.'''
    slug = 'import:' + ''.join(
        ch.lower() if ch.isalnum() else '-' for ch in (label or path)
    ).strip('-')[:80]
    if store.list_row(slug) is None:
        store.create_list(
            slug, label or path, 'import', 'mixed',
            import_plugin_path=path,
            import_mode=mode,
            import_label=label,
            import_art=folder_art
        )
    if mode == 'live':
        return {'slug': slug, 'fetched': 0, 'mode': 'live'}
    entries = list(lister(path) or [])
    missing = []
    for entry in entries:
        found = store.find_title(
            media_type=entry.get('media_type') or 'movie',
            imdb=entry.get('imdb'),
            tmdb=entry.get('tmdb'),
            title=entry.get('title'),
            year=entry.get('year')
        )
        if found is None:
            missing.append(entry)
    if missing:
        allowed = confirm_fetch(len(missing))
        if not allowed:
            return {'slug': slug, 'fetched': 0, 'cancelled': True, 'pending': len(missing)}
    fetched = 0
    for entry in entries:
        result = add_to_list(
            store, settings, guard, art_dir, entry, slug, confirm_partial=True
        )
        store.add_list_item(slug, result['title_id'], None)
        if result['fetched']:
            fetched += 1
    return {'slug': slug, 'fetched': fetched, 'mode': 'snapshot', 'cancelled': False}


def refresh_live_folder(store, slug, lister):
    row = store.list_row(slug)
    if row is None or row['import_mode'] != 'live':
        raise ValueError('This list is not a live folder.')
    entries = list(lister(row['import_plugin_path']) or [])
    store.clear_list(slug)
    for position, entry in enumerate(entries):
        # Live refresh re-lists the plugin path. It does not fetch new metadata
        # until the user confirms a snapshot-style add. Store a pointer row only
        # when the title is already local; otherwise keep the label in the reason.
        found = store.find_title(
            media_type=entry.get('media_type') or 'movie',
            imdb=entry.get('imdb'),
            tmdb=entry.get('tmdb'),
            title=entry.get('title'),
            year=entry.get('year')
        )
        if found is not None:
            store.add_list_item(slug, found['id'], None, position=position)
    store.touch_list(slug, iso())
    return {'count': len(store.list_items(slug))}
