'''Add-on settings with an in-memory implementation for tests and headless jobs.'''

from __future__ import annotations

ADDON_ID = 'plugin.video.hearth'

DEFAULTS = {
    'network_policy': 'strict',
    'watch_threshold_percent': '85',
    'backup_keep': '4',
    'backup_interval_days': '7',
    'include_artwork': 'true',
    'exclude_specials': 'true',
    'include_fully_watched': 'false',
    'recent_limit': '25',
    'resume_behavior': 'ask',
    'track_other_addons': 'true',
    'default_player_movie': '',
    'default_player_episode': '',
    'last_player_movie': '',
    'last_player_episode': '',
    'cloud_mirror': 'none',
    'mirror_base_url': '',
    'trakt_client_id': '',
    'trakt_client_secret': '',
    'trakt_access_token': '',
    'trakt_refresh_token': '',
    'trakt_device_code': '',
    'tmdb_api_key': '',
    'tmdb_list_id': '',
    'tmdb_v4_token': '',
    'tmdb_session_id': '',
    'simkl_client_id': '',
    'simkl_access_token': '',
    'mdblist_api_key': '',
    'mdblist_list_id': '',
    'backup_folder': '',
    'wizard_done': 'false',
    'channels_enabled': 'false',
    'scrobble_during_playback': 'true',
    'seek_floor_percent': '2'
}

TRUTHY = {'1', 'true', 'yes', 'on'}


class Settings:
    '''Key/value settings. Values are stored as strings, matching Kodi.'''

    def __init__(self, values=None):
        self.values = dict(DEFAULTS)
        if values:
            for key, value in values.items():
                self.values[key] = '' if value is None else str(value)

    def get(self, key, default=None):
        if key in self.values:
            return self.values[key]
        if default is not None:
            return default
        return DEFAULTS.get(key, '')

    def set(self, key, value):
        self.values[key] = '' if value is None else str(value)

    def flag(self, key, default=False):
        raw = self.get(key, 'true' if default else 'false')
        return str(raw).strip().lower() in TRUTHY

    def integer(self, key, default=0):
        try:
            return int(float(self.get(key, default)))
        except (TypeError, ValueError):
            return int(default)

    @property
    def threshold(self):
        percent = self.integer('watch_threshold_percent', 85)
        return max(0.01, min(percent, 99)) / 100.0

    @property
    def floor(self):
        percent = self.integer('seek_floor_percent', 2)
        return max(0.0, percent) / 100.0

    def mirror_enabled(self):
        value = (self.get('cloud_mirror') or 'none').strip().lower()
        return value not in ('', 'none', 'off')

    def trakt_authorized(self):
        return bool(self.get('trakt_access_token') or '')

    def policy(self):
        value = (self.get('network_policy') or 'strict').strip().lower()
        if value in ('debug', 'debug log only'):
            return 'debug'
        if value in ('allow_all', 'allow all', 'allow all (developer)'):
            return 'allow_all'
        return 'strict'

    def public_dict(self):
        '''Settings safe to write into a backup. Secrets stay out.'''
        hidden = {
            'trakt_client_secret', 'trakt_access_token', 'trakt_refresh_token',
            'trakt_device_code', 'tmdb_api_key', 'tmdb_v4_token', 'tmdb_session_id',
            'simkl_client_id', 'simkl_access_token', 'mdblist_api_key', 'recs_api_key'
        }
        return {key: value for key, value in self.values.items() if key not in hidden}


def load_kodi_settings():
    '''Read settings from xbmcaddon when the add-on is running inside Kodi.'''
    try:
        import xbmcaddon
    except ImportError:
        return Settings()
    addon = xbmcaddon.Addon(ADDON_ID)
    values = {}
    for key in DEFAULTS:
        try:
            values[key] = addon.getSetting(key)
        except Exception:
            values[key] = DEFAULTS[key]
    return Settings(values)
