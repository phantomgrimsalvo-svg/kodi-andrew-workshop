'''Official Trakt API client. Every call goes through the network guard.'''

from __future__ import annotations

import json
from urllib.parse import urlencode

API = 'https://api.trakt.tv'


class TraktError(Exception):
    pass


class TraktClient:
    def __init__(self, guard, client_id, access_token='', client_secret=''):
        self.guard = guard
        self.client_id = client_id or ''
        self.access_token = access_token or ''
        self.client_secret = client_secret or ''

    def headers(self, auth=True):
        headers = {
            'Content-Type': 'application/json',
            'trakt-api-version': '2',
            'trakt-api-key': self.client_id
        }
        if auth and self.access_token:
            headers['Authorization'] = 'Bearer ' + self.access_token
        return headers

    def request_device_code(self):
        response = self.guard.post(
            API + '/oauth/device/code',
            'explicit_action',
            headers=self.headers(auth=False),
            body=json.dumps({'client_id': self.client_id})
        )
        return response.body

    def poll_device_token(self, device_code):
        response = self.guard.post(
            API + '/oauth/device/token',
            'explicit_action',
            headers=self.headers(auth=False),
            body=json.dumps({
                'code': device_code,
                'client_id': self.client_id,
                'client_secret': self.client_secret
            })
        )
        return response.body

    def get(self, path, params=None, purpose='initial_import', item_id=None):
        query = ('?' + urlencode(params)) if params else ''
        return self.guard.get(
            API + path + query,
            purpose,
            item_id=item_id,
            headers=self.headers()
        )

    def get_paginated(self, path, params=None, purpose='initial_import', item_id=None):
        page = 1
        items = []
        while page < 500:
            query = dict(params or {})
            query['page'] = page
            query['limit'] = query.get('limit') or 100
            response = self.get(path, query, purpose=purpose, item_id=item_id)
            body = response.body or []
            if isinstance(body, dict):
                body = body.get('items') or body.get('list') or []
            items.extend(body)
            page_count = int(response.headers.get('x-pagination-page-count') or 1)
            if page >= page_count or not body:
                break
            page += 1
        return items

    def watched_movies(self):
        return self.get_paginated('/sync/watched/movies')

    def watched_shows(self):
        return self.get_paginated('/sync/watched/shows')

    def history_movies(self):
        return self.get_paginated('/sync/history/movies')

    def history_shows(self):
        return self.get_paginated('/sync/history/shows')

    def playback(self):
        response = self.get('/sync/playback')
        body = response.body or []
        return body if isinstance(body, list) else []

    def ratings(self, media):
        return self.get_paginated('/sync/ratings/' + media)

    def watchlist(self, media):
        return self.get_paginated('/sync/watchlist/' + media)

    def favorites(self, media):
        return self.get_paginated('/users/me/favorites/' + media)

    def user_lists(self):
        return self.get_paginated('/users/me/lists')

    def list_items(self, list_id):
        return self.get_paginated('/users/me/lists/%s/items' % list_id)

    def lookup_tmdb(self, tmdb_id, media_type, item_id):
        kind = 'movie' if media_type == 'movie' else 'show'
        response = self.get(
            '/search/tmdb/%s' % tmdb_id,
            {'type': kind},
            purpose='manual_add',
            item_id=item_id
        )
        body = response.body or []
        return body[0] if body else None
