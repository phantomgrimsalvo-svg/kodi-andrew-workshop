'''Map Hearth list rows onto PreviewProgram fields. No image:// or special:// URIs.'''

from __future__ import annotations

import json
from pathlib import Path

from plugin.listings import build_list

CHANNEL_PACKAGE = 'org.hearth.tvchannels'
CHANNEL_ACTIVITY = 'org.hearth.tvchannels.PublishActivity'

MOVIE_RATINGS = {
    'G': 'US_MV_G',
    'PG': 'US_MV_PG',
    'PG-13': 'US_MV_PG13',
    'R': 'US_MV_R',
    'NC-17': 'US_MV_NC17'
}
TV_RATINGS = {
    'TV-Y': 'US_TV_Y',
    'TV-Y7': 'US_TV_Y7',
    'TV-G': 'US_TV_G',
    'TV-PG': 'US_TV_PG',
    'TV-14': 'US_TV_14',
    'TV-MA': 'US_TV_MA'
}


def content_rating(mpaa, media_type):
    '''Android flattenToString shape. Never the raw MPAA text.'''
    raw = (mpaa or '').upper().replace(' ', '')
    if not raw:
        return ''
    if raw in TV_RATINGS or raw.startswith('TV-'):
        code = TV_RATINGS.get(raw, '')
        if not code:
            return ''
        return 'com.android.tv/US_TV/%s' % code
    code = MOVIE_RATINGS.get(raw, '')
    if not code:
        return ''
    return 'com.android.tv/US_MV/%s' % code


def program_from_item(item):
    mediatype = item.get('mediatype') or 'movie'
    if mediatype == 'episode':
        title = item.get('tvshowtitle') or item.get('showtitle') or item.get('title') or ''
        episode_title = item.get('title') or ''
        kind = 'TYPE_TV_EPISODE'
    elif mediatype == 'tvshow':
        title = item.get('title') or ''
        episode_title = ''
        kind = 'TYPE_TV_SERIES'
    else:
        title = item.get('title') or item.get('label') or ''
        episode_title = ''
        kind = 'TYPE_MOVIE'
    art = item.get('art') or {}
    score = item.get('userrating') or item.get('rating') or 0
    try:
        stars = float(score) / 2.0
    except (TypeError, ValueError):
        stars = 0
    resume = (item.get('resume') or {}).get('position') or 0
    data = _play_uri(item.get('file') or item.get('path') or '')
    return {
        'COLUMN_TITLE': title,
        'COLUMN_EPISODE_TITLE': episode_title,
        'COLUMN_SHORT_DESCRIPTION': (item.get('plot') or '')[:140],
        'COLUMN_LONG_DESCRIPTION': item.get('plot') or '',
        'COLUMN_POSTER_ART_URI': channel_art_uri(art, 'poster'),
        'COLUMN_POSTER_ART_ASPECT_RATIO': 'ASPECT_RATIO_2_3',
        'COLUMN_THUMBNAIL_URI': channel_art_uri(art, 'thumb', 'fanart'),
        'COLUMN_THUMBNAIL_ASPECT_RATIO': 'ASPECT_RATIO_16_9',
        'COLUMN_DURATION_MILLIS': int(item.get('runtime') or 0) * 1000,
        'COLUMN_RELEASE_DATE': item.get('premiered') or _year(item.get('year')),
        'COLUMN_REVIEW_RATING': stars,
        'COLUMN_REVIEW_RATING_STYLE': 'REVIEW_RATING_STYLE_STARS',
        'COLUMN_CONTENT_RATING': content_rating(item.get('mpaa'), mediatype),
        'COLUMN_TYPE': kind,
        'COLUMN_SEASON_DISPLAY_NUMBER': _num(item.get('season')),
        'COLUMN_EPISODE_DISPLAY_NUMBER': _num(item.get('episode')),
        'COLUMN_LAST_PLAYBACK_POSITION_MILLIS': int(float(resume) * 1000),
        'COLUMN_INTERNAL_PROVIDER_ID': str((item.get('uniqueid') or {}).get('hearth') or ''),
        'COLUMN_INTENT_ACTION': 'android.intent.action.VIEW',
        'COLUMN_INTENT_PACKAGE': 'org.xbmc.kodi',
        'COLUMN_INTENT_COMPONENT': 'org.xbmc.kodi.Splash',
        'COLUMN_INTENT_DATA': data
    }


def file_uri(path):
    '''Kept for callers that still want a file URI. Channel export does not use it.'''
    if not path:
        return ''
    text = str(path)
    if text.startswith('image://') or text.startswith('special://'):
        return ''
    if text.startswith(('file://', 'http://', 'https://', 'content:', 'android.resource:')):
        return text
    return 'file://' + text


def channel_art_uri(art, *kinds):
    '''https TMDB URL only. A file inside Kodi's storage cannot be read by Projectivy.'''
    art = art or {}
    for kind in kinds:
        remote = art.get(kind + '_url')
        if isinstance(remote, str) and remote.startswith('https://'):
            return remote
        value = art.get(kind)
        if not value:
            continue
        text = str(value)
        if text.startswith('https://'):
            return text
        if _is_tmdb_file(text):
            from art.store import image_url
            return image_url(text, 'thumb' if kind == 'thumb' else kind)
    return ''


def channel_refresh_command():
    '''Start the channel app with no window so it pulls the new export.'''
    return (
        'StartAndroidActivity('
        '"%s",'
        '"android.intent.action.VIEW",'
        '"",'
        '"",'
        '"268435456",'
        '"",'
        '"android.intent.action.VIEW",'
        '"",'
        '"%s"'
        ')'
    ) % (CHANNEL_PACKAGE, CHANNEL_ACTIVITY)


def notify_channel_app():
    '''Poke org.hearth.tvchannels after a real export change. No-op off Android.'''
    command = channel_refresh_command()
    try:
        import xbmc
        if not xbmc.getCondVisibility('System.Platform.Android'):
            return False
        xbmc.executebuiltin(command)
    except Exception:
        return False
    return True


def export_channels(store, settings, destination):
    '''Write channels-export.json. This is a file copy. It does not use the network.'''
    if not settings.flag('channels_enabled', False):
        document = {'enabled': False, 'channels': []}
    else:
        channels = []
        for row in store.lists_in_menu():
            if not row['publish_as_channel']:
                continue
            programs = []
            for item in build_list(store, row['slug'], settings):
                if not item.get('is_playable'):
                    continue
                programs.append(program_from_item(item))
            channels.append({
                'slug': row['slug'],
                'title': row['name'],
                'programs': programs
            })
        document = {'enabled': True, 'package': CHANNEL_PACKAGE, 'channels': channels}
    path = Path(destination)
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(document, indent=2, sort_keys=True) + '\n'
    changed = not path.exists() or path.read_text(encoding='utf-8') != text
    if changed:
        path.write_text(text, encoding='utf-8')
        notify_channel_app()
    return {'path': str(path), 'channels': len(document['channels']), 'changed': changed}


def toggle_channel(store, slug, enabled):
    store.set_publish_channel(slug, enabled)
    return store.list_row(slug)['publish_as_channel']


def _play_uri(path):
    text = str(path or '')
    if '?' in text:
        text = text.split('?', 1)[0]
    return text.replace('?showinfo=true', '')


def _num(value):
    if value is None or value == '':
        return ''
    return str(value)


def _year(value):
    if not value:
        return ''
    return str(value)


def _is_tmdb_file(text):
    '''TMDB file paths are a single segment, such as /abc.jpg. Local paths are not.'''
    if not text.startswith('/') or text.startswith('//'):
        return False
    rest = text[1:]
    if '/' in rest:
        return False
    return rest.lower().endswith(('.jpg', '.jpeg', '.png', '.webp'))
