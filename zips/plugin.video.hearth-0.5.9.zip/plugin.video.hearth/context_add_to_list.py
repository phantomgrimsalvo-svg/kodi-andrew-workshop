'''Context item: Add to Hearth list…'''

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / 'resources' / 'lib'))

from context.actions import add_to_list, lists_for_media
from data.store import open_store
from paths import art_dir, db_path
from settings import load_kodi_settings


def main():
    import xbmc
    import xbmcgui
    identifiers = {
        'title': xbmc.getInfoLabel('ListItem.Title') or xbmc.getInfoLabel('ListItem.Label'),
        'year': _int(xbmc.getInfoLabel('ListItem.Year')),
        'imdb': xbmc.getInfoLabel('ListItem.IMDBNumber') or xbmc.getInfoLabel('ListItem.UniqueID(imdb)'),
        'tmdb': xbmc.getInfoLabel('ListItem.UniqueID(tmdb)'),
        'tvdb': xbmc.getInfoLabel('ListItem.UniqueID(tvdb)'),
        'season': _int(xbmc.getInfoLabel('ListItem.Season')),
        'episode': _int(xbmc.getInfoLabel('ListItem.Episode')),
        'media_type': _media_type()
    }
    settings = load_kodi_settings()
    store = open_store(db_path())
    store.ensure_system_lists()
    choices = lists_for_media(store, identifiers['media_type'])
    if not choices:
        xbmcgui.Dialog().ok('Hearth', 'There is no list that can take this yet.')
        return
    labels = [row['name'] for row in choices]
    index = xbmcgui.Dialog().select('Add to Hearth list…', labels)
    if index is None or index < 0:
        return
    if store.find_title(
        media_type='show' if identifiers['media_type'] == 'episode' else identifiers['media_type'],
        imdb=identifiers.get('imdb'),
        tmdb=identifiers.get('tmdb'),
        title=identifiers.get('title'),
        year=identifiers.get('year')
    ) is None:
        xbmcgui.Dialog().notification('Hearth', 'Looking up this title…', sound=False)
    from network.guard import active_guard
    try:
        add_to_list(
            store, settings, active_guard(), art_dir(), identifiers, choices[index]['slug'],
            confirm_partial=False
        )
    except Exception as exc:
        from util import redact
        allowed = xbmcgui.Dialog().yesno(
            'Hearth',
            'Lookup failed. Add with the metadata already on this item? Artwork can wait.'
        )
        if not allowed:
            xbmcgui.Dialog().ok('Hearth', redact(str(exc))[:200] or 'Hearth could not add that title.')
            return
        add_to_list(
            store, settings, active_guard(), art_dir(), identifiers,
            choices[index]['slug'], confirm_partial=True
        )
    xbmcgui.Dialog().notification('Hearth', 'Added to %s' % labels[index], sound=False)


def _media_type():
    import xbmc
    dbtype = (xbmc.getInfoLabel('ListItem.DBType') or '').lower()
    if dbtype in ('movie', 'episode', 'tvshow'):
        return 'episode' if dbtype == 'episode' else ('show' if dbtype == 'tvshow' else 'movie')
    if xbmc.getInfoLabel('ListItem.Episode'):
        return 'episode'
    if xbmc.getInfoLabel('ListItem.TVShowTitle'):
        return 'show'
    return 'movie'


def _int(value):
    try:
        if value in (None, ''):
            return None
        return int(value)
    except (TypeError, ValueError):
        return None


if __name__ == '__main__':
    main()
