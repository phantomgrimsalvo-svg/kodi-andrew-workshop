'''Context item: Add this folder/widget to Hearth.'''

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / 'resources' / 'lib'))

from channels.live import default_folder_mode
from context.actions import add_folder
from data.store import open_store
from network.guard import active_guard
from paths import art_dir, db_path
from settings import load_kodi_settings


def main():
    import xbmc
    import xbmcgui
    path = xbmc.getInfoLabel('ListItem.FolderPath') or xbmc.getInfoLabel('Container.FolderPath')
    label = xbmc.getInfoLabel('ListItem.Label') or path
    art = xbmc.getInfoLabel('ListItem.Art(thumb)') or xbmc.getInfoLabel('ListItem.Icon')
    if not path:
        xbmcgui.Dialog().ok('Hearth', 'Hearth could not read that folder path.')
        return
    preview = _list_plugin(path)
    preselect = 0 if default_folder_mode(preview) == 'snapshot' else 1
    mode_index = xbmcgui.Dialog().select('Add this folder to Hearth', [
        'Snapshot (copy movies and shows that have ids)',
        'Live link (open this folder as it is)'
    ], preselect=preselect)
    if mode_index is None or mode_index < 0:
        return
    mode = 'snapshot' if mode_index == 0 else 'live'
    settings = load_kodi_settings()
    store = open_store(db_path())

    def lister(plugin_path):
        return _list_plugin(plugin_path)

    def confirm(count):
        return bool(xbmcgui.Dialog().yesno(
            'Hearth',
            'This will look up %d new titles. Continue?' % count
        ))

    result = add_folder(
        store, settings, active_guard(), art_dir(), path, label, art, mode, lister, confirm
    )
    if result.get('cancelled'):
        xbmcgui.Dialog().notification('Hearth', 'Folder was not added.', sound=False)
        return
    if result.get('empty'):
        xbmcgui.Dialog().notification(
            'Hearth', 'Nothing in that folder could be copied.', sound=False
        )
        return
    xbmcgui.Dialog().notification('Hearth', 'Added %s' % (label or 'folder'), sound=False)


def _list_plugin(path):
    import json
    import xbmc
    raw = xbmc.executeJSONRPC(json.dumps({
        'jsonrpc': '2.0',
        'id': 1,
        'method': 'Files.GetDirectory',
        'params': {
            'directory': path,
            'media': 'video',
            'properties': ['title', 'year', 'imdbnumber', 'uniqueid', 'season', 'episode']
        }
    }))
    try:
        payload = json.loads(raw or '{}')
    except ValueError:
        return []
    found = []
    for entry in (payload.get('result') or {}).get('files') or []:
        if entry.get('filetype') == 'directory':
            continue
        unique = entry.get('uniqueid') or {}
        kind = (entry.get('type') or '').lower()
        if kind == 'episode':
            media_type = 'episode'
        elif kind in ('tvshow', 'season'):
            media_type = 'show'
        else:
            media_type = 'movie'
        found.append({
            'title': entry.get('title') or entry.get('label'),
            'year': entry.get('year'),
            'imdb': unique.get('imdb') or entry.get('imdbnumber'),
            'tmdb': unique.get('tmdb'),
            'tvdb': unique.get('tvdb'),
            'media_type': media_type,
            'season': entry.get('season'),
            'episode': entry.get('episode')
        })
    return found


if __name__ == '__main__':
    main()
