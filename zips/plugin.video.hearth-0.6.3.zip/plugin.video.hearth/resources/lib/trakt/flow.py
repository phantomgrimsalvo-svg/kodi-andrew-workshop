'''Device-code sign-in and the one-time import. Pull only. No collection.'''

from __future__ import annotations

from trakt.client import TraktClient, TraktError
from trakt.importer import import_trakt, plan_import
from util import redact


def dry_run_import(store, settings, guard):
    try:
        return _dry_run_import(store, settings, guard)
    except TraktError as exc:
        return str(exc)


def _dry_run_import(store, settings, guard):
    from trakt.auth import SIGN_IN_AGAIN, ensure_access_token, remember_token
    client_id = settings.get('trakt_client_id')
    if not client_id:
        return (
            'Add a Trakt client id in Hearth settings first. '
            'Create the app at https://trakt.tv/oauth/applications/new and leave the secret blank.'
        )
    if settings.trakt_authorized() and not ensure_access_token(settings, guard):
        return SIGN_IN_AGAIN
    client = TraktClient(
        guard,
        client_id,
        access_token=settings.get('trakt_access_token'),
        client_secret=settings.get('trakt_client_secret'),
        settings=settings
    )
    if not settings.trakt_authorized():
        device_code = settings.get('trakt_device_code')
        if not device_code:
            code = client.request_device_code() or {}
            _persist(settings, 'trakt_device_code', code.get('device_code') or '')
            user_code = code.get('user_code') or ''
            url = code.get('verification_url') or 'https://trakt.tv/activate'
            return 'Open %s and enter %s. Then run Import again.' % (url, user_code)
        token = client.poll_device_token(device_code) or {}
        if not token.get('access_token'):
            return 'Trakt has not confirmed the code yet. Finish the page, then run Import again.'
        remember_token(settings, token)
        client.access_token = token.get('access_token')
    summary, payload = plan_import(client)
    lines = (
        'Dry run: %d movies, %d shows, %d playback rows, %d ratings, '
        '%d watchlist, %d favorites, %d lists. Collection is not included. %s'
    ) % (
        summary['movies'], summary['shows'], summary['playback'], summary['ratings'],
        summary['watchlist'], summary['favorites'], summary['lists'], summary['note']
    )
    # The caller shows this text. Applying is a separate confirmed step so a
    # dry run never writes by accident when the dialog cannot ask.
    store.meta_set('last_import_preview', redact(lines)[:500])
    _ = payload
    return lines


def _persist(settings, key, value):
    settings.set(key, value)
    try:
        import xbmcaddon
        from settings import ADDON_ID
        xbmcaddon.Addon(ADDON_ID).setSetting(key, value)
    except Exception:
        return


def apply_confirmed_import(store, settings, guard):
    from trakt.auth import ensure_access_token
    ensure_access_token(settings, guard)
    client = TraktClient(
        guard,
        settings.get('trakt_client_id'),
        access_token=settings.get('trakt_access_token'),
        client_secret=settings.get('trakt_client_secret'),
        settings=settings
    )
    _summary, payload = plan_import(client)
    return import_trakt(store, settings, client, payload=payload)
