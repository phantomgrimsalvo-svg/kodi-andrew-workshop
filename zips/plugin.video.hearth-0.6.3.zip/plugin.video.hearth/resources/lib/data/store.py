'''Single-writer data access layer. All DB writes go through Store.'''

from __future__ import annotations

import sqlite3
import threading
from pathlib import Path

from data.schema import migrate
from util import dumps, iso, loads

SYSTEM_LISTS = (
    ('next_up', 'Next Up', 'episodes'),
    ('in_progress_movies', 'In-progress movies', 'movies'),
    ('recent_movies', 'Recently watched movies', 'movies'),
    ('watchlist', 'Watchlist', 'mixed'),
    ('favorites', 'Favorites', 'mixed'),
    ('recs', 'Recommendations', 'mixed')
)

_OPEN = {}
_OPEN_LOCK = threading.Lock()


def open_store(path):
    '''One Store per database path in this process, so writers share one lock.'''
    key = str(Path(path).resolve())
    with _OPEN_LOCK:
        store = _OPEN.get(key)
        if store is None:
            store = Store(key)
            _OPEN[key] = store
        return store


def close_store(path):
    key = str(Path(path).resolve())
    with _OPEN_LOCK:
        store = _OPEN.pop(key, None)
    if store is not None:
        store.close()


class Store:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(
            str(self.path), timeout=5, check_same_thread=False
        )
        self._conn.row_factory = sqlite3.Row
        self._conn.execute('PRAGMA journal_mode=WAL')
        self._conn.execute('PRAGMA busy_timeout=5000')
        self._conn.execute('PRAGMA foreign_keys=ON')
        with self._lock:
            migrate(self._conn)
            self._conn.commit()

    def close(self):
        with self._lock:
            self._conn.close()

    def _write(self, fn):
        with self._lock:
            try:
                self._conn.execute('BEGIN IMMEDIATE')
                result = fn()
                self._conn.commit()
                return result
            except Exception:
                self._conn.rollback()
                raise

    def _read(self, fn):
        with self._lock:
            return fn()

    def snapshot_to(self, dest):
        '''Consistent copy. VACUUM INTO, falling back to the backup API.'''
        dest = Path(dest)
        dest.parent.mkdir(parents=True, exist_ok=True)
        if dest.exists():
            dest.unlink()
        with self._lock:
            try:
                escaped = str(dest).replace("'", "''")
                self._conn.execute("VACUUM INTO '%s'" % escaped)
                return dest
            except sqlite3.Error:
                other = sqlite3.connect(str(dest))
                try:
                    self._conn.backup(other)
                finally:
                    other.close()
                return dest

    def integrity(self):
        row = self._read(lambda: self._conn.execute('PRAGMA integrity_check').fetchone())
        return row[0]

    def meta_get(self, key, default=None):
        def read():
            row = self._conn.execute(
                'SELECT value FROM meta WHERE key = ?', (key,)
            ).fetchone()
            return default if row is None else row['value']
        return self._read(read)

    def meta_set(self, key, value):
        def write():
            self._conn.execute(
                '''
                INSERT INTO meta (key, value) VALUES (?, ?)
                ON CONFLICT(key) DO UPDATE SET value = excluded.value
                ''',
                (key, None if value is None else str(value))
            )
        self._write(write)

    def meta_map(self):
        def read():
            rows = self._conn.execute('SELECT key, value FROM meta').fetchall()
            return {row['key']: row['value'] for row in rows}
        return self._read(read)

    def record_network_event(self, purpose, method, host, path, allowed, item_id=None):
        def write():
            self._conn.execute(
                '''
                INSERT INTO network_events
                    (timestamp, purpose, method, host, path, allowed, item_id)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ''',
                (iso(), purpose, method, host, path, 1 if allowed else 0, item_id)
            )
        self._write(write)

    def ensure_system_lists(self):
        def write():
            for slug, name, media_filter in SYSTEM_LISTS:
                self._conn.execute(
                    '''
                    INSERT INTO lists
                        (slug, name, kind, media_filter, sort_default, is_system,
                         show_in_menu, publish_as_channel)
                    VALUES (?, ?, 'auto', ?, 'default', 1, 1, 0)
                    ON CONFLICT(slug) DO NOTHING
                    ''',
                    (slug, name, media_filter)
                )
        self._write(write)

    def list_row(self, slug):
        def read():
            return self._conn.execute(
                'SELECT * FROM lists WHERE slug = ?', (slug,)
            ).fetchone()
        return self._read(read)

    def lists_in_menu(self):
        def read():
            return self._conn.execute(
                '''
                SELECT * FROM lists
                WHERE show_in_menu = 1
                ORDER BY is_system DESC, name COLLATE NOCASE
                '''
            ).fetchall()
        return self._read(read)

    def create_list(self, slug, name, kind, media_filter='mixed', **extra):
        def write():
            self._conn.execute(
                '''
                INSERT INTO lists
                    (slug, name, kind, media_filter, sort_default, is_system,
                     show_in_menu, publish_as_channel, import_plugin_path,
                     import_mode, import_label, import_art)
                VALUES (?, ?, ?, ?, 'default', 0, 1, 0, ?, ?, ?, ?)
                ''',
                (
                    slug, name, kind, media_filter,
                    extra.get('import_plugin_path'),
                    extra.get('import_mode'),
                    extra.get('import_label'),
                    extra.get('import_art')
                )
            )
            return self._conn.execute(
                'SELECT id FROM lists WHERE slug = ?', (slug,)
            ).fetchone()['id']
        return self._write(write)

    def touch_list(self, slug, when=None):
        def write():
            self._conn.execute(
                'UPDATE lists SET last_built_at = ? WHERE slug = ?',
                (when or iso(), slug)
            )
        self._write(write)

    def delete_list(self, slug):
        '''Remove a list George added, and its items. System lists are kept.'''
        def write():
            row = self._conn.execute(
                'SELECT id, is_system FROM lists WHERE slug = ?', (slug,)
            ).fetchone()
            if row is None or int(row['is_system'] or 0):
                return False
            self._conn.execute('DELETE FROM list_items WHERE list_id = ?', (row['id'],))
            self._conn.execute('DELETE FROM lists WHERE id = ?', (row['id'],))
            return True
        return self._write(write)

    def set_publish_channel(self, slug, enabled):
        def write():
            self._conn.execute(
                'UPDATE lists SET publish_as_channel = ? WHERE slug = ?',
                (1 if enabled else 0, slug)
            )
        self._write(write)

    def upsert_title(self, **fields):
        now = fields.pop('now', None) or iso()
        media_type = fields['media_type']
        existing = self.find_title(
            media_type=media_type,
            imdb=fields.get('imdb'),
            tmdb=fields.get('tmdb'),
            trakt_id=fields.get('trakt_id'),
            title=fields.get('title'),
            year=fields.get('year')
        )
        columns = (
            'media_type', 'imdb', 'tmdb', 'tvdb', 'trakt_id', 'title',
            'original_title', 'year', 'premiered', 'runtime_seconds', 'mpaa',
            'genres', 'plot', 'tagline', 'studio', 'status', 'art',
            'original_language', 'nextup_hidden', 'needs_fixup', 'rewatch_mode',
            'rewatch_from_season', 'rewatch_from_episode', 'watch_order',
            'pinned_season', 'pinned_episode'
        )

        def pack(source):
            packed = {}
            for key in columns:
                if key not in source and key not in fields:
                    continue
                value = fields[key] if key in fields else source[key]
                if key in ('genres', 'art') and not isinstance(value, str):
                    value = dumps(value or ([] if key == 'genres' else {}))
                packed[key] = value
            return packed

        if existing is None:
            data = {key: None for key in columns}
            data.update(pack({}))
            data['media_type'] = media_type
            data['title'] = fields.get('title') or 'Untitled'
            data['added_at'] = now
            data['updated_at'] = now
            if data.get('genres') is None:
                data['genres'] = '[]'
            if data.get('art') is None:
                data['art'] = '{}'
            data['nextup_hidden'] = int(data.get('nextup_hidden') or 0)
            data['rewatch_mode'] = int(data.get('rewatch_mode') or 0)
            data['watch_order'] = data.get('watch_order') or 'aired'

            def write():
                keys = list(data.keys())
                sql = 'INSERT INTO titles (%s) VALUES (%s)' % (
                    ', '.join(keys),
                    ', '.join('?' for _ in keys)
                )
                cur = self._conn.execute(sql, [data[key] for key in keys])
                return cur.lastrowid
            return self._write(write)

        title_id = existing['id']
        data = pack(existing)
        data['updated_at'] = now

        def write():
            assignments = ', '.join('%s = ?' % key for key in data)
            self._conn.execute(
                'UPDATE titles SET %s WHERE id = ?' % assignments,
                list(data.values()) + [title_id]
            )
            return title_id
        return self._write(write)

    def find_title(self, media_type=None, imdb=None, tmdb=None, trakt_id=None,
                   tvdb=None, title=None, year=None):
        def read():
            clauses = []
            params = []
            if media_type:
                clauses.append('media_type = ?')
                params.append(media_type)
            id_clause = []
            if tmdb:
                id_clause.append('tmdb = ?')
                params.append(str(tmdb))
            if imdb:
                id_clause.append('imdb = ?')
                params.append(imdb)
            if tvdb:
                id_clause.append('tvdb = ?')
                params.append(str(tvdb))
            if trakt_id:
                id_clause.append('trakt_id = ?')
                params.append(str(trakt_id))
            if id_clause:
                clauses.append('(' + ' OR '.join(id_clause) + ')')
            elif title:
                clauses.append('title = ? COLLATE NOCASE')
                params.append(title)
                if year:
                    clauses.append('year = ?')
                    params.append(int(year))
            else:
                return None
            sql = 'SELECT * FROM titles WHERE ' + ' AND '.join(clauses) + ' LIMIT 1'
            return self._conn.execute(sql, params).fetchone()
        return self._read(read)

    def get_title(self, title_id):
        def read():
            return self._conn.execute(
                'SELECT * FROM titles WHERE id = ?', (title_id,)
            ).fetchone()
        return self._read(read)

    def all_titles(self, media_type=None):
        def read():
            if media_type:
                return self._conn.execute(
                    'SELECT * FROM titles WHERE media_type = ? ORDER BY id',
                    (media_type,)
                ).fetchall()
            return self._conn.execute('SELECT * FROM titles ORDER BY id').fetchall()
        return self._read(read)

    def count_titles(self):
        def read():
            return self._conn.execute('SELECT COUNT(*) AS n FROM titles').fetchone()['n']
        return self._read(read)

    def update_title_fields(self, title_id, **fields):
        if not fields:
            return
        def write():
            keys = list(fields.keys())
            sql = 'UPDATE titles SET %s WHERE id = ?' % ', '.join(
                '%s = ?' % key for key in keys
            )
            self._conn.execute(sql, [fields[key] for key in keys] + [title_id])
        self._write(write)

    def upsert_episode(self, show_id, season, episode, **fields):
        now_art = fields.get('art')
        if now_art is not None and not isinstance(now_art, str):
            fields['art'] = dumps(now_art)

        def write():
            existing = self._conn.execute(
                '''
                SELECT * FROM episodes
                WHERE show_id = ? AND season = ? AND episode = ?
                ''',
                (show_id, int(season), int(episode))
            ).fetchone()
            if existing is None:
                self._conn.execute(
                    '''
                    INSERT INTO episodes
                        (show_id, season, episode, title, first_aired,
                         runtime_seconds, plot, tvdb, tmdb, imdb, trakt_id, art)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ''',
                    (
                        show_id, int(season), int(episode),
                        fields.get('title'), fields.get('first_aired'),
                        fields.get('runtime_seconds'), fields.get('plot'),
                        _as_text(fields.get('tvdb')), _as_text(fields.get('tmdb')),
                        fields.get('imdb'), _as_text(fields.get('trakt_id')),
                        fields.get('art') or '{}'
                    )
                )
            else:
                updates = {}
                for key in (
                    'title', 'first_aired', 'runtime_seconds', 'plot',
                    'tvdb', 'tmdb', 'imdb', 'trakt_id', 'art'
                ):
                    if key in fields and fields[key] is not None:
                        updates[key] = fields[key]
                if updates:
                    sql = 'UPDATE episodes SET %s WHERE id = ?' % ', '.join(
                        '%s = ?' % key for key in updates
                    )
                    self._conn.execute(
                        sql, list(updates.values()) + [existing['id']]
                    )
            row = self._conn.execute(
                '''
                SELECT id FROM episodes
                WHERE show_id = ? AND season = ? AND episode = ?
                ''',
                (show_id, int(season), int(episode))
            ).fetchone()
            return row['id']
        return self._write(write)

    def episodes_for_show(self, show_id):
        def read():
            return self._conn.execute(
                '''
                SELECT * FROM episodes
                WHERE show_id = ?
                ORDER BY season, episode
                ''',
                (show_id,)
            ).fetchall()
        return self._read(read)

    def find_episode_by_ids(self, imdb=None, tmdb=None, tvdb=None):
        def read():
            clauses = []
            params = []
            if imdb:
                clauses.append('imdb = ?')
                params.append(imdb)
            if tmdb:
                clauses.append('tmdb = ?')
                params.append(str(tmdb))
            if tvdb:
                clauses.append('tvdb = ?')
                params.append(str(tvdb))
            if not clauses:
                return None
            sql = 'SELECT * FROM episodes WHERE ' + ' OR '.join(clauses) + ' LIMIT 1'
            return self._conn.execute(sql, params).fetchone()
        return self._read(read)

    def get_episode(self, episode_id):
        def read():
            return self._conn.execute(
                'SELECT * FROM episodes WHERE id = ?', (episode_id,)
            ).fetchone()
        return self._read(read)

    def get_watch(self, title_id, episode_id=None):
        def read():
            return self._conn.execute(
                '''
                SELECT * FROM watch_state
                WHERE title_id = ? AND IFNULL(episode_id, 0) = ?
                ''',
                (title_id, int(episode_id or 0))
            ).fetchone()
        return self._read(read)

    def set_watch(self, title_id, episode_id=None, **fields):
        fields = dict(fields)
        fields.setdefault('updated_at', iso())

        def write():
            existing = self._conn.execute(
                '''
                SELECT * FROM watch_state
                WHERE title_id = ? AND IFNULL(episode_id, 0) = ?
                ''',
                (title_id, int(episode_id or 0))
            ).fetchone()
            if existing is None:
                self._conn.execute(
                    '''
                    INSERT INTO watch_state
                        (title_id, episode_id, play_count, resume_seconds,
                         runtime_seconds, last_played, rewatch_mode,
                         rewatch_from_season, rewatch_from_episode, watch_order,
                         source, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ''',
                    (
                        title_id,
                        episode_id,
                        int(fields.get('play_count') or 0),
                        fields.get('resume_seconds'),
                        fields.get('runtime_seconds'),
                        fields.get('last_played'),
                        int(fields.get('rewatch_mode') or 0),
                        fields.get('rewatch_from_season'),
                        fields.get('rewatch_from_episode'),
                        fields.get('watch_order') or 'aired',
                        fields.get('source'),
                        fields.get('updated_at')
                    )
                )
            else:
                allowed = (
                    'play_count', 'resume_seconds', 'runtime_seconds', 'last_played',
                    'rewatch_mode', 'rewatch_from_season', 'rewatch_from_episode',
                    'watch_order', 'source', 'updated_at'
                )
                updates = {key: fields[key] for key in allowed if key in fields}
                sql = 'UPDATE watch_state SET %s WHERE id = ?' % ', '.join(
                    '%s = ?' % key for key in updates
                )
                self._conn.execute(sql, list(updates.values()) + [existing['id']])
            row = self._conn.execute(
                '''
                SELECT * FROM watch_state
                WHERE title_id = ? AND IFNULL(episode_id, 0) = ?
                ''',
                (title_id, int(episode_id or 0))
            ).fetchone()
            return row
        return self._write(write)

    def save_rating(self, title_id, score, liked='', disliked='', tags=None,
                    episode_id=None, season=None, source='local', rated_at=None):
        if score is not None:
            score = int(score)
            if score < 1 or score > 10:
                raise ValueError('score must be from 1 to 10')
        moment = rated_at or iso()
        tag_text = tags if isinstance(tags, str) else dumps(tags or [])
        season_key = -1 if season is None else int(season)

        def write():
            existing = self._conn.execute(
                '''
                SELECT id FROM ratings
                WHERE title_id = ? AND IFNULL(episode_id, 0) = ?
                  AND IFNULL(season, -1) = ?
                ''',
                (title_id, int(episode_id or 0), season_key)
            ).fetchone()
            if existing is None:
                self._conn.execute(
                    '''
                    INSERT INTO ratings
                        (title_id, episode_id, season, score, liked, disliked, tags,
                         rated_at, source, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ''',
                    (
                        title_id, episode_id, None if season is None else int(season),
                        score, liked or '', disliked or '',
                        tag_text, moment, source, moment
                    )
                )
            else:
                self._conn.execute(
                    '''
                    UPDATE ratings
                    SET score = ?, liked = ?, disliked = ?, tags = ?,
                        rated_at = ?, source = ?, updated_at = ?
                    WHERE id = ?
                    ''',
                    (
                        score, liked or '', disliked or '', tag_text, moment,
                        source, moment, existing['id']
                    )
                )
        self._write(write)

    def get_rating(self, title_id, episode_id=None, season=None):
        season_key = -1 if season is None else int(season)

        def read():
            return self._conn.execute(
                '''
                SELECT * FROM ratings
                WHERE title_id = ? AND IFNULL(episode_id, 0) = ?
                  AND IFNULL(season, -1) = ?
                ''',
                (title_id, int(episode_id or 0), season_key)
            ).fetchone()
        return self._read(read)

    def add_list_item(self, slug, title_id, episode_id=None, reason=None,
                      position=None, graduated_from_list_id=None):
        def write():
            lst = self._conn.execute(
                'SELECT id FROM lists WHERE slug = ?', (slug,)
            ).fetchone()
            if lst is None:
                raise KeyError(slug)
            if position is None:
                row = self._conn.execute(
                    'SELECT COALESCE(MAX(position), -1) + 1 AS n FROM list_items WHERE list_id = ?',
                    (lst['id'],)
                ).fetchone()
                pos = row['n']
            else:
                pos = int(position)
            self._conn.execute(
                '''
                INSERT INTO list_items
                    (list_id, title_id, episode_id, position, reason,
                     graduated_from_list_id)
                VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(list_id, IFNULL(title_id, 0), IFNULL(episode_id, 0))
                DO UPDATE SET
                    position = excluded.position,
                    reason = COALESCE(excluded.reason, list_items.reason),
                    graduated_from_list_id = COALESCE(
                        excluded.graduated_from_list_id,
                        list_items.graduated_from_list_id
                    )
                ''',
                (lst['id'], title_id, episode_id, pos, reason, graduated_from_list_id)
            )
        self._write(write)

    def remove_list_item(self, slug, title_id, episode_id=None):
        def write():
            lst = self._conn.execute(
                'SELECT id FROM lists WHERE slug = ?', (slug,)
            ).fetchone()
            if lst is None:
                return False
            cur = self._conn.execute(
                '''
                DELETE FROM list_items
                WHERE list_id = ? AND IFNULL(title_id, 0) = ?
                  AND IFNULL(episode_id, 0) = ?
                ''',
                (lst['id'], int(title_id or 0), int(episode_id or 0))
            )
            return cur.rowcount > 0
        return self._write(write)

    def in_list(self, slug, title_id, episode_id=None):
        def read():
            row = self._conn.execute(
                '''
                SELECT list_items.id
                FROM list_items
                JOIN lists ON lists.id = list_items.list_id
                WHERE lists.slug = ?
                  AND IFNULL(list_items.title_id, 0) = ?
                  AND IFNULL(list_items.episode_id, 0) = ?
                ''',
                (slug, int(title_id or 0), int(episode_id or 0))
            ).fetchone()
            return row is not None
        return self._read(read)

    def clear_list(self, slug):
        def write():
            lst = self._conn.execute(
                'SELECT id FROM lists WHERE slug = ?', (slug,)
            ).fetchone()
            if lst is None:
                return
            self._conn.execute('DELETE FROM list_items WHERE list_id = ?', (lst['id'],))
        self._write(write)

    def list_items(self, slug):
        def read():
            return self._conn.execute(
                '''
                SELECT list_items.*, lists.slug
                FROM list_items
                JOIN lists ON lists.id = list_items.list_id
                WHERE lists.slug = ?
                ORDER BY list_items.position, list_items.id
                ''',
                (slug,)
            ).fetchall()
        return self._read(read)

    def replace_list_items(self, slug, rows):
        '''rows: dicts with title_id, episode_id, reason, graduated_from_list_id.'''
        def write():
            lst = self._conn.execute(
                'SELECT id FROM lists WHERE slug = ?', (slug,)
            ).fetchone()
            if lst is None:
                raise KeyError(slug)
            self._conn.execute('DELETE FROM list_items WHERE list_id = ?', (lst['id'],))
            for position, row in enumerate(rows):
                self._conn.execute(
                    '''
                    INSERT INTO list_items
                        (list_id, title_id, episode_id, position, reason,
                         graduated_from_list_id)
                    VALUES (?, ?, ?, ?, ?, ?)
                    ''',
                    (
                        lst['id'], row.get('title_id'), row.get('episode_id'),
                        position, row.get('reason'), row.get('graduated_from_list_id')
                    )
                )
            self._conn.execute(
                'UPDATE lists SET last_built_at = ? WHERE id = ?',
                (iso(), lst['id'])
            )
        self._write(write)

    def enqueue_outbox(self, kind, payload, dedupe_key, adapter):
        def write():
            self._conn.execute(
                '''
                INSERT INTO sync_journal
                    (created_at, kind, payload, dedupe_key, adapter, state)
                VALUES (?, ?, ?, ?, ?, 'pending')
                ON CONFLICT(dedupe_key) DO UPDATE SET
                    payload = excluded.payload,
                    adapter = excluded.adapter,
                    state = 'pending',
                    last_error = NULL
                ''',
                (iso(), kind, dumps(payload), dedupe_key, adapter)
            )
        self._write(write)

    def pending_outbox(self, adapter=None):
        def read():
            if adapter:
                return self._conn.execute(
                    '''
                    SELECT * FROM sync_journal
                    WHERE state = 'pending' AND adapter = ?
                    ORDER BY id
                    ''',
                    (adapter,)
                ).fetchall()
            return self._conn.execute(
                "SELECT * FROM sync_journal WHERE state = 'pending' ORDER BY id"
            ).fetchall()
        return self._read(read)

    def mark_outbox(self, row_id, state, remote_id=None, last_error=None):
        def write():
            self._conn.execute(
                '''
                UPDATE sync_journal
                SET state = ?, remote_id = ?, last_error = ?, pushed_at = ?
                WHERE id = ?
                ''',
                (state, remote_id, last_error, iso() if state == 'pushed' else None, row_id)
            )
        self._write(write)

    def export_document(self, settings=None):
        '''Readable JSON backup. Secrets are omitted.'''
        def read():
            def rows(sql):
                return [dict(row) for row in self._conn.execute(sql).fetchall()]
            meta = {
                key: value for key, value in self.meta_map().items()
                if not _secretish(key)
            }
            public_settings = settings.public_dict() if settings is not None else {}
            return {
                'titles': rows('SELECT * FROM titles ORDER BY id'),
                'episodes': rows('SELECT * FROM episodes ORDER BY id'),
                'watch_state': rows('SELECT * FROM watch_state ORDER BY id'),
                'ratings': rows('SELECT * FROM ratings ORDER BY id'),
                'lists': rows('SELECT * FROM lists ORDER BY id'),
                'list_items': rows('SELECT * FROM list_items ORDER BY id'),
                'meta': meta,
                'settings': public_settings,
                'play_events': rows('SELECT * FROM play_events ORDER BY id')
            }
        return self._read(read)

    def record_play(self, title_id, episode_id, watched_at):
        '''Remember one play. The same timestamp is stored once.'''
        if not watched_at:
            return 0

        def write():
            self._conn.execute(
                '''
                INSERT INTO play_events (title_id, episode_id, watched_at)
                VALUES (?, ?, ?)
                ON CONFLICT(title_id, IFNULL(episode_id, 0), watched_at) DO NOTHING
                ''',
                (title_id, episode_id, watched_at)
            )
            row = self._conn.execute(
                '''
                SELECT COUNT(*) AS n FROM play_events
                WHERE title_id = ? AND IFNULL(episode_id, 0) = ?
                ''',
                (title_id, int(episode_id or 0))
            ).fetchone()
            return int(row['n'])
        return self._write(write)

    def list_plays(self, title_id, episode_id=None):
        def read():
            rows = self._conn.execute(
                '''
                SELECT watched_at FROM play_events
                WHERE title_id = ? AND IFNULL(episode_id, 0) = ?
                ORDER BY watched_at
                ''',
                (title_id, int(episode_id or 0))
            ).fetchall()
            return [row['watched_at'] for row in rows]
        return self._read(read)

    def counts(self):
        def read():
            def n(table):
                return self._conn.execute('SELECT COUNT(*) AS n FROM %s' % table).fetchone()['n']
            return {
                'titles': n('titles'),
                'episodes': n('episodes'),
                'watch_state': n('watch_state'),
                'ratings': n('ratings'),
                'lists': n('lists'),
                'list_items': n('list_items')
            }
        return self._read(read)


def _as_text(value):
    if value is None:
        return None
    return str(value)


def _secretish(key):
    lowered = (key or '').lower()
    return any(part in lowered for part in ('token', 'secret', 'api_key', 'password'))


def art_map(row):
    if row is None:
        return {}
    return loads(row['art'], {}) or {}


def genre_list(row):
    if row is None:
        return []
    value = loads(row['genres'], [])
    return value or []
