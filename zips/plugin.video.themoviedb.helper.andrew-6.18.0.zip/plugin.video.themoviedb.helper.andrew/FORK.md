# TMDb Helper (Andrew)

Personal Kodi fork for Andrew Webber. **Not** an official upstream release.
Do not open pull requests against jurialmunkey or dobbelina from this tree.

| | |
|---|---|
| Addon id | `plugin.video.themoviedb.helper.andrew` |
| Version | `6.18.0` |
| License | GPL-3.0-or-later |
| Upstream | https://github.com/jurialmunkey/plugin.video.themoviedb.helper (6.17.1) |
| Upstream authors | jurialmunkey |

Original license files are kept in this tree. Attribution to the original
authors is required. Arctic Fuse 3 remains CC-BY-NC-SA (non-commercial).
